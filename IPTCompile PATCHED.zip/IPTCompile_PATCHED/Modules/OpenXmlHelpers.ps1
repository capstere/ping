<#
OpenXML (DocumentFormat.OpenXml) helpers for PowerShell 5.1

Goal: Update a few signature cells in Worksheet.xlsx WITHOUT saving the workbook through EPPlus.
Some Worksheet templates contain definedNames/named ranges that EPPlus 4.5.3.3 may rewrite/remove,
causing Excel repair: "Removed Records: Named range from /xl/workbook.xml".

This module uses DocumentFormat.OpenXml to edit only the relevant sheet XML parts.

DLL placement (recommended):
  Modules\OpenXMLSDK\DocumentFormat.OpenXml.2.20.0\lib\net46\DocumentFormat.OpenXml.dll
Fallback:
  ...\lib\net40\DocumentFormat.OpenXml.dll
Or simply place DocumentFormat.OpenXml.dll directly in Modules.
#>

Set-StrictMode -Version 2.0

function Resolve-OpenXmlDllPath {
    param(
        [Parameter(Mandatory=$true)][string]$ModulesRoot
    )

    $candidates = New-Object System.Collections.Generic.List[string]

    # 1) Directly in Modules
    $candidates.Add((Join-Path $ModulesRoot 'DocumentFormat.OpenXml.dll'))

    # 2) NuGet extracted layout (preferred)
    $candidates.Add((Join-Path $ModulesRoot 'OpenXMLSDK\DocumentFormat.OpenXml.2.20.0\lib\net46\DocumentFormat.OpenXml.dll'))
    $candidates.Add((Join-Path $ModulesRoot 'OpenXMLSDK\DocumentFormat.OpenXml.2.20.0\lib\net40\DocumentFormat.OpenXml.dll'))

    # 3) Alternative layout
    $candidates.Add((Join-Path $ModulesRoot 'OpenXMLSDK\lib\net46\DocumentFormat.OpenXml.dll'))
    $candidates.Add((Join-Path $ModulesRoot 'OpenXMLSDK\lib\net40\DocumentFormat.OpenXml.dll'))

    foreach ($p in $candidates) {
        if (Test-Path -LiteralPath $p) { return $p }
    }
    return $null
}

function Import-OpenXmlSdk {
    param(
        [Parameter(Mandatory=$true)][string]$ModulesRoot
    )

    if ([AppDomain]::CurrentDomain.GetAssemblies() | Where-Object { $_.GetName().Name -eq 'DocumentFormat.OpenXml' }) {
        return $true
    }

    $dllPath = Resolve-OpenXmlDllPath -ModulesRoot $ModulesRoot
    if (-not $dllPath) {
        throw "DocumentFormat.OpenXml.dll hittades inte. Lägg den i Modules eller i Modules\\OpenXMLSDK\\... (net46 föredras, net40 fallback)."
    }
    try {
        # Assembly.Load(byte[]) kringgår Mark-of-the-Web (MOTW) blockering
        # som annars ger HRESULT 0x80131515 på nätverks-/OneDrive-sökvägar.
        $bytes = [System.IO.File]::ReadAllBytes($dllPath)
        [void][System.Reflection.Assembly]::Load($bytes)
        return $true
    } catch {
        throw "Kunde inte ladda OpenXML DLL: $dllPath`n$($_.Exception.Message)"
    }
}

function Normalize-OpenXmlText {
    param([string]$Text)
    $t = ($Text + '')
    $t = $t -replace [char]0x00A0,' '
    $t = $t.Trim()
    $t = [regex]::Replace($t,'\s+',' ')
    return $t
}

function Convert-ColLetterToIndex {
    param([string]$Col)
    $c = ($Col + '').Trim().ToUpperInvariant()
    if (-not $c) { return 0 }
    $sum = 0
    foreach ($ch in $c.ToCharArray()) {
        if ($ch -lt 'A' -or $ch -gt 'Z') { return 0 }
        $sum = ($sum * 26) + ([int][char]$ch - [int][char]'A' + 1)
    }
    return $sum
}

function Get-OpenXmlCellText {
    param(
        [Parameter(Mandatory=$true)]$WorkbookPart,
        [Parameter(Mandatory=$true)]$Cell
    )
    if (-not $Cell) { return '' }

    $val = $Cell.CellValue
    if (-not $val) {
        if ($Cell.InlineString -and $Cell.InlineString.Text) { return ($Cell.InlineString.Text.Text + '') }
        return ''
    }

    $raw = ($val.Text + '')
    if (-not $raw) { return '' }

    if ($Cell.DataType -and $Cell.DataType.Value -eq [DocumentFormat.OpenXml.Spreadsheet.CellValues]::SharedString) {
        $sst = $WorkbookPart.SharedStringTablePart
        if (-not $sst -or -not $sst.SharedStringTable) { return '' }
        $idx = 0
        if (-not [int]::TryParse($raw, [ref]$idx)) { return '' }
        $item = $sst.SharedStringTable.Elements([DocumentFormat.OpenXml.Spreadsheet.SharedStringItem]) | Select-Object -Skip $idx -First 1
        if (-not $item) { return '' }
        if ($item.Text) { return ($item.Text.Text + '') }
        $sb = New-Object System.Text.StringBuilder
        foreach ($t in $item.Descendants([DocumentFormat.OpenXml.Spreadsheet.Text])) {
            [void]$sb.Append(($t.Text + ''))
        }
        return $sb.ToString()
    }

    return $raw
}

function Ensure-OpenXmlCell {
    param(
        [Parameter(Mandatory=$true)]$WorksheetPart,
        [Parameter(Mandatory=$true)][int]$RowIndex,
        [Parameter(Mandatory=$true)][string]$ColLetter
    )
    $ws = $WorksheetPart.Worksheet
    $sheetData = $ws.GetFirstChild([DocumentFormat.OpenXml.Spreadsheet.SheetData])
    if (-not $sheetData) {
        $sheetData = New-Object DocumentFormat.OpenXml.Spreadsheet.SheetData
        $ws.AppendChild($sheetData) | Out-Null
    }

    $row = $sheetData.Elements([DocumentFormat.OpenXml.Spreadsheet.Row]) | Where-Object { $_.RowIndex -and $_.RowIndex.Value -eq $RowIndex } | Select-Object -First 1
    if (-not $row) {
        $row = New-Object DocumentFormat.OpenXml.Spreadsheet.Row
        $row.RowIndex = [uint32]$RowIndex
        $ref = $sheetData.Elements([DocumentFormat.OpenXml.Spreadsheet.Row]) | Where-Object { $_.RowIndex -and $_.RowIndex.Value -gt $RowIndex } | Select-Object -First 1
        if ($ref) { $sheetData.InsertBefore($row, $ref) | Out-Null } else { $sheetData.AppendChild($row) | Out-Null }
    }

    $cellRef = "$ColLetter$RowIndex"
    $cell = $row.Elements([DocumentFormat.OpenXml.Spreadsheet.Cell]) | Where-Object { $_.CellReference -and $_.CellReference.Value -eq $cellRef } | Select-Object -First 1
    if ($cell) { return $cell }

    $cell = New-Object DocumentFormat.OpenXml.Spreadsheet.Cell
    $cell.CellReference = $cellRef

    # Insert in correct column order
    $targetIdx = Convert-ColLetterToIndex -Col $ColLetter
    $refCell = $row.Elements([DocumentFormat.OpenXml.Spreadsheet.Cell]) |
        Where-Object {
            $_.CellReference -and (Convert-ColLetterToIndex -Col (($_.CellReference.Value -replace '\\d+$',''))) -gt $targetIdx
        } | Select-Object -First 1

    if ($refCell) { $row.InsertBefore($cell, $refCell) | Out-Null } else { $row.AppendChild($cell) | Out-Null }
    return $cell
}

function Set-OpenXmlCellText {
    param(
        [Parameter(Mandatory=$true)]$WorksheetPart,
        [Parameter(Mandatory=$true)]$WorkbookPart,
        [Parameter(Mandatory=$true)][int]$RowIndex,
        [Parameter(Mandatory=$true)][string]$ColLetter,
        [Parameter(Mandatory=$true)][string]$Value,
        [switch]$Overwrite
    )
    if ($RowIndex -lt 1) { return $false }

    $cell = Ensure-OpenXmlCell -WorksheetPart $WorksheetPart -RowIndex $RowIndex -ColLetter $ColLetter
    if (-not $cell) { return $false }

    $existing = Normalize-OpenXmlText (Get-OpenXmlCellText -WorkbookPart $WorkbookPart -Cell $cell)
    if ($existing -and -not $Overwrite) { return $false }

    # Write as InlineString (no SharedStringTable changes)
    $cell.DataType = [DocumentFormat.OpenXml.Spreadsheet.CellValues]::InlineString
    $cell.CellValue = $null
    $cell.InlineString = New-Object DocumentFormat.OpenXml.Spreadsheet.InlineString
    $cell.InlineString.Text = New-Object DocumentFormat.OpenXml.Spreadsheet.Text
    $cell.InlineString.Text.Text = $Value
    return $true
}

function Find-FirstRowByContains_OpenXml {
    param(
        [Parameter(Mandatory=$true)]$WorksheetPart,
        [Parameter(Mandatory=$true)]$WorkbookPart,
        [Parameter(Mandatory=$true)][string]$ColLetter,
        [Parameter(Mandatory=$true)][string]$Needle
    )
    $needleNorm = (Normalize-OpenXmlText $Needle).ToLowerInvariant()
    $sheetData = $WorksheetPart.Worksheet.GetFirstChild([DocumentFormat.OpenXml.Spreadsheet.SheetData])
    if (-not $sheetData) { return $null }

    foreach ($row in $sheetData.Elements([DocumentFormat.OpenXml.Spreadsheet.Row])) {
        $r = 0
        if ($row.RowIndex) { $r = [int]$row.RowIndex.Value }
        if ($r -le 0) { continue }
        $cellRef = "$ColLetter$r"
        $cell = $row.Elements([DocumentFormat.OpenXml.Spreadsheet.Cell]) | Where-Object { $_.CellReference -and $_.CellReference.Value -eq $cellRef } | Select-Object -First 1
        if (-not $cell) { continue }
        $txt = Normalize-OpenXmlText (Get-OpenXmlCellText -WorkbookPart $WorkbookPart -Cell $cell)
        if (-not $txt) { continue }
        if ($txt.ToLowerInvariant().Contains($needleNorm)) { return $r }
    }
    return $null
}

function Test-OpenXmlDataSummaryHasData {
    param(
        [Parameter(Mandatory=$true)]$WorksheetPart,
        [Parameter(Mandatory=$true)]$WorkbookPart,
        [string]$DataColLetter = 'C'
    )
    $sheetData = $WorksheetPart.Worksheet.GetFirstChild([DocumentFormat.OpenXml.Spreadsheet.SheetData])
    if (-not $sheetData) { return $false }

    foreach ($row in $sheetData.Elements([DocumentFormat.OpenXml.Spreadsheet.Row])) {
        $r = 0
        if ($row.RowIndex) { $r = [int]$row.RowIndex.Value }
        if ($r -le 0) { continue }
        $cellRef = "$DataColLetter$r"
        $cell = $row.Elements([DocumentFormat.OpenXml.Spreadsheet.Cell]) | Where-Object { $_.CellReference -and $_.CellReference.Value -eq $cellRef } | Select-Object -First 1
        if (-not $cell) { continue }
        $txt = Normalize-OpenXmlText (Get-OpenXmlCellText -WorkbookPart $WorkbookPart -Cell $cell)
        if (-not $txt) { continue }
        if ($txt -match '^(?i)(Performed By:|Recorded By:|PQC Reviewed By:|Date:)$') { continue }
        return $true
    }
    return $false
}

function Invoke-WorksheetSignature_OpenXml {
    <#
    Mode:
      - Sammanstallning
      - Granskning

    Returns: object with Written/Skipped.
    #>
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [Parameter(Mandatory=$true)][string]$FullName,
        [Parameter(Mandatory=$true)][string]$SignDateYmd,
        [Parameter(Mandatory=$true)][ValidateSet('Sammanstallning','Granskning')][string]$Mode,
        [switch]$HasResample,
        [switch]$Overwrite,
        [Parameter(Mandatory=$true)][string]$ModulesRoot
    )

    Import-OpenXmlSdk -ModulesRoot $ModulesRoot | Out-Null

    $res = [pscustomobject]@{
        Mode    = $Mode
        Written = New-Object System.Collections.Generic.List[string]
        Skipped = New-Object System.Collections.Generic.List[string]
    }

    $doc = $null
    try {
        $doc = [DocumentFormat.OpenXml.Packaging.SpreadsheetDocument]::Open($Path, $true)
        $wbp = $doc.WorkbookPart
        if (-not $wbp -or -not $wbp.Workbook) { throw 'WorkbookPart saknas.' }
        $sheets = $wbp.Workbook.Sheets
        if (-not $sheets) { throw 'Sheets saknas.' }

        $targets = @()
        if ($Mode -eq 'Sammanstallning') {
            $targets = @(
                @{ Name='Test Summary';                 NameLabelCol='B'; NameNeedle='Recorded By:';       NameWriteCol='C'; DateLabelCols=@('I');     DateNeedle='Date:'; DateWriteCol='J'; Offset=0;  DataSummaryGuard=$false },
                @{ Name='Data Summary';                 NameLabelCol='A'; NameNeedle='Recorded By:';       NameWriteCol='B'; DateLabelCols=@('C');     DateNeedle='Date:'; DateWriteCol='D'; Offset=0;  DataSummaryGuard=$true  },
                @{ Name='Extra Data Summary';           NameLabelCol='A'; NameNeedle='Recorded By:';       NameWriteCol='B'; DateLabelCols=@('C');     DateNeedle='Date:'; DateWriteCol='D'; Offset=0;  DataSummaryGuard=$true  },
                @{ Name='Resample Data Summary';        NameLabelCol='A'; NameNeedle='Recorded By:';       NameWriteCol='B'; DateLabelCols=@('C');     DateNeedle='Date:'; DateWriteCol='D'; Offset=0;  DataSummaryGuard=$true; ResampleOnly=$true },
                @{ Name='Seal Test Failure Count';      NameLabelCol='K'; NameNeedle='Performed By:';      NameWriteCol='L'; DateLabelCols=@('K');     DateNeedle='Date:'; DateWriteCol='L'; Offset=-1; DataSummaryGuard=$false },
                @{ Name='Statistical Process Control';  NameLabelCol='K'; NameNeedle='Performed By:';      NameWriteCol='L'; DateLabelCols=@('K');     DateNeedle='Date:'; DateWriteCol='L'; Offset=-1; DataSummaryGuard=$false },
                @{ Name='Vacuum Seal Data';             NameLabelCol='B'; NameNeedle='Recorded By:';       NameWriteCol='C'; DateLabelCols=@('D','E'); DateNeedle='Date:'; DateWriteCol='F'; Offset=0;  DataSummaryGuard=$false }
            )
        } else {
            $targets = @(
                @{ Name='Test Summary'; NameLabelCol='B'; NameNeedle='PQC Reviewed By:'; NameWriteCol='C'; DateLabelCols=@('I'); DateNeedle='Date:'; DateWriteCol='J'; Offset=0; DataSummaryGuard=$false }
            )
        }

        foreach ($t in $targets) {
            $sheetName = $t.Name

            if ($t.ContainsKey('ResampleOnly') -and $t.ResampleOnly -and (-not $HasResample)) {
                [void]$res.Skipped.Add("$sheetName (ej resample)")
                continue
            }

            $sheet = $sheets.Elements([DocumentFormat.OpenXml.Spreadsheet.Sheet]) | Where-Object { $_.Name -and $_.Name.Value -eq $sheetName } | Select-Object -First 1
            if (-not $sheet) {
                [void]$res.Skipped.Add($sheetName)
                continue
            }
            $wsp = $wbp.GetPartById($sheet.Id)
            if (-not $wsp) {
                [void]$res.Skipped.Add($sheetName)
                continue
            }

            if ($t.DataSummaryGuard) {
                $hasData = Test-OpenXmlDataSummaryHasData -WorksheetPart $wsp -WorkbookPart $wbp -DataColLetter 'C'
                if (-not $hasData) {
                    [void]$res.Skipped.Add("$sheetName (ingen data)")
                    continue
                }
            }

            $nameRow = Find-FirstRowByContains_OpenXml -WorksheetPart $wsp -WorkbookPart $wbp -ColLetter $t.NameLabelCol -Needle $t.NameNeedle
            $dateRow = $null
            foreach ($dc in $t.DateLabelCols) {
                $dateRow = Find-FirstRowByContains_OpenXml -WorksheetPart $wsp -WorkbookPart $wbp -ColLetter $dc -Needle $t.DateNeedle
                if ($dateRow) { break }
            }

            $wroteAny = $false
            if ($nameRow) {
                $wroteAny = (Set-OpenXmlCellText -WorksheetPart $wsp -WorkbookPart $wbp -RowIndex ($nameRow + $t.Offset) -ColLetter $t.NameWriteCol -Value $FullName -Overwrite:$Overwrite) -or $wroteAny
            }
            if ($dateRow) {
                $wroteAny = (Set-OpenXmlCellText -WorksheetPart $wsp -WorkbookPart $wbp -RowIndex ($dateRow + $t.Offset) -ColLetter $t.DateWriteCol -Value $SignDateYmd -Overwrite:$Overwrite) -or $wroteAny
            }

            if ($wroteAny) {
                [void]$res.Written.Add($sheetName)
            } else {
                [void]$res.Skipped.Add("$sheetName (labels saknas eller redan ifyllt)")
            }
        }

        $wbp.Workbook.Save()
    } finally {
        try { if ($doc) { $doc.Dispose() } } catch {}
    }

    return $res
}
