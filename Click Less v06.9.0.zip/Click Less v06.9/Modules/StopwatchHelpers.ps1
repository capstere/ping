#requires -Version 5.1

<#
    StopwatchHelpers.ps1

    This helper module provides a simple wrapper around the .NET
    System.Diagnostics.Stopwatch type.  It exposes two convenience
    functions, Start-Timer and Stop-Timer, which can be used to
    instrument sections of the pipeline without modifying the core
    business logic.  Each timer is identified by a user supplied
    name.  When Stop‑Timer is called the elapsed time in seconds is
    recorded in a global hashtable ($Global:CL_TimerResults).  At
    any time Get-TopTimers can be called to retrieve a sorted view
    of the most time consuming steps.  This module is loaded by
    Main.ps1 during startup.
#>

using namespace System.Diagnostics

if (-not $Global:CL_TimerResults) {
    $Global:CL_TimerResults = [ordered]@{}
}

function Start-Timer {
    <#
        .SYNOPSIS
            Starts a new stopwatch for the supplied name.

        .DESCRIPTION
            Creates and returns a new System.Diagnostics.Stopwatch
            instance.  The stopwatch is started immediately.  The caller
            is responsible for passing the object back to Stop-Timer.

        .PARAMETER Name
            Logical name of the operation being timed.

        .EXAMPLE
            $sw = Start-Timer -Name 'CSV Parsing'
            # do work
            Stop-Timer -Name 'CSV Parsing' -Stopwatch $sw
    #>
    param([Parameter(Mandatory)][string]$Name)
    $sw = [Stopwatch]::StartNew()
    return $sw
}

function Stop-Timer {
    <#
        .SYNOPSIS
            Stops the supplied stopwatch and records the elapsed time.

        .PARAMETER Name
            Logical name of the operation timed.

        .PARAMETER Stopwatch
            The stopwatch returned by Start‑Timer.

        .EXAMPLE
            Stop-Timer -Name 'CSV Parsing' -Stopwatch $sw
    #>
    param(
        [Parameter(Mandatory)][string]$Name,
        [Parameter(Mandatory)][Stopwatch]$Stopwatch
    )
    try {
        $Stopwatch.Stop()
        $elapsed = $Stopwatch.Elapsed.TotalSeconds
        if (-not $Global:CL_TimerResults.ContainsKey($Name)) {
            $Global:CL_TimerResults[$Name] = @()
        }
        $Global:CL_TimerResults[$Name] += $elapsed
    } catch {
        # Ignore timing failures
    }
}

function Get-TopTimers {
    <#
        .SYNOPSIS
            Returns the recorded timer results sorted by total time.

        .DESCRIPTION
            Aggregates the elapsed times for each timer name and
            returns an ordered list of the top entries.  Useful for
            diagnostic logging at the end of a report build.

        .PARAMETER Top
            Number of top entries to return.  Defaults to 10.

        .EXAMPLE
            Get-TopTimers -Top 5
    #>
    param([int]$Top = 10)
    $res = @()
    foreach ($k in $Global:CL_TimerResults.Keys) {
        $total = ($Global:CL_TimerResults[$k] | Measure-Object -Sum).Sum
        $res += [pscustomobject]@{ Name = $k; TotalSeconds = [math]::Round($total,2) }
    }
    return $res | Sort-Object -Property TotalSeconds -Descending | Select-Object -First $Top
}

Export-ModuleMember -Function Start-Timer,Stop-Timer,Get-TopTimers