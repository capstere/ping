﻿param(
    [Parameter(Mandatory=$true)]
    [string]$ShortcutName,

    [Parameter(Mandatory=$true)]
    [string]$LauncherPs1,

    [Parameter(Mandatory=$false)]
    [string]$WorkingDir = 'C:\IPTCompile'
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

function Get-PowerShellExePath {
    # Prefer Windows PowerShell for maximum compatibility (pwsh is not guaranteed on all clients)
    return (Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe')
}

$desktop = [Environment]::GetFolderPath([Environment+SpecialFolder]::DesktopDirectory)
if ([string]::IsNullOrWhiteSpace($desktop)) {
    throw 'Could not resolve DesktopDirectory.'
}

$batName = $ShortcutName
if (-not $batName.ToLower().EndsWith('.bat')) { $batName = $batName + '.bat' }
$batPath = Join-Path $desktop $batName

$launcherFull = [System.IO.Path]::GetFullPath($LauncherPs1)
if (-not (Test-Path -LiteralPath $launcherFull)) {
    throw ("Launcher PS1 not found: {0}" -f $launcherFull)
}

$psExe = Get-PowerShellExePath

# Create a quiet desktop launcher that does not print console output.
# This avoids confusing output for non-technical users and just starts the GUI.
$wd = $WorkingDir
if ([string]::IsNullOrWhiteSpace($wd)) { $wd = '' }

$bat = @()
$bat += '@echo off'
$bat += 'setlocal'
if (-not [string]::IsNullOrWhiteSpace($wd)) {
    # Only pushd if the folder exists (avoid "The system cannot find the path specified")
    $bat += ('if exist "{0}" pushd "{0}"' -f $wd)
}

# Use -WindowStyle Hidden to avoid a flashing console window.
# Redirect stdout/stderr to NUL to prevent any "greek" output on-screen.
$bat += ('"{0}" -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "{1}" 1^>nul 2^>nul' -f $psExe, $launcherFull)

if (-not [string]::IsNullOrWhiteSpace($wd)) {
    $bat += ('if exist "{0}" popd' -f $wd)
}
$bat += 'endlocal'

Set-Content -LiteralPath $batPath -Value ($bat -join "`r`n") -Encoding ASCII

Write-Host ("Desktop launcher created/updated: {0}" -f $batPath)
exit 0