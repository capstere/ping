﻿#Requires -Version 5.1
Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles() | Out-Null

$BasePath      = 'N:\QC\QC-1\IPT\Skiftspecifika dokument\Skift 1\Mahdi\powerpoint\AutoMappscript'
$EquipmentPath = Join-Path $BasePath 'equipment.xml'
$StatusPath    = Join-Path $BasePath 'status.txt'

#region ── Tema ──────────────────────────────────────────────────────────────────
$T = @{
    BgDark       = [System.Drawing.Color]::FromArgb(15, 25, 35)
    BgCard       = [System.Drawing.Color]::FromArgb(23, 34, 49)
    BgCardHover  = [System.Drawing.Color]::FromArgb(30, 45, 63)
    Accent       = [System.Drawing.Color]::FromArgb(0, 180, 216)
    AccentDim    = [System.Drawing.Color]::FromArgb(0, 144, 173)
    AccentGlow   = [System.Drawing.Color]::FromArgb(0, 212, 255)
    Error        = [System.Drawing.Color]::FromArgb(255, 107, 107)
    Success      = [System.Drawing.Color]::FromArgb(74, 222, 128)
    Warning      = [System.Drawing.Color]::FromArgb(255, 179, 71)
    TextPrimary  = [System.Drawing.Color]::FromArgb(232, 237, 242)
    TextSecondary= [System.Drawing.Color]::FromArgb(136, 153, 170)
    TextMuted    = [System.Drawing.Color]::FromArgb(90, 106, 122)
    Border       = [System.Drawing.Color]::FromArgb(42, 58, 74)
    BtnBg        = [System.Drawing.Color]::FromArgb(30, 45, 63)
    BtnHover     = [System.Drawing.Color]::FromArgb(40, 60, 80)
    GridHeader   = [System.Drawing.Color]::FromArgb(20, 30, 42)
    GridRow      = [System.Drawing.Color]::FromArgb(23, 34, 49)
    GridRowAlt   = [System.Drawing.Color]::FromArgb(26, 40, 56)
    GridSel      = [System.Drawing.Color]::FromArgb(0, 144, 173)
}

$FontTitle  = New-Object System.Drawing.Font('Segoe UI', 16, [System.Drawing.FontStyle]::Bold)
$FontHeader = New-Object System.Drawing.Font('Segoe UI Semibold', 11)
$FontBody   = New-Object System.Drawing.Font('Segoe UI', 10)
$FontSmall  = New-Object System.Drawing.Font('Segoe UI', 9)
$FontMono   = New-Object System.Drawing.Font('Cascadia Code, Consolas', 10)

function Style-Button {
    param([System.Windows.Forms.Button]$Btn, [switch]$Primary)
    $Btn.FlatStyle = 'Flat'
    $Btn.FlatAppearance.BorderSize  = 1
    $Btn.FlatAppearance.BorderColor = if ($Primary) { $T.Accent } else { $T.Border }
    $Btn.Font      = $FontBody
    $Btn.Cursor    = [System.Windows.Forms.Cursors]::Hand
    if ($Primary) {
        $Btn.BackColor = $T.Accent
        $Btn.ForeColor = [System.Drawing.Color]::White
        $Btn.FlatAppearance.MouseOverBackColor = $T.AccentDim
    } else {
        $Btn.BackColor = $T.BtnBg
        $Btn.ForeColor = $T.TextPrimary
        $Btn.FlatAppearance.MouseOverBackColor = $T.BtnHover
    }
}
#endregion

#region ── Data / Logik (oförändrad) ─────────────────────────────────────────────

function ConvertTo-DataTable {
    [CmdletBinding()]
    param (
        [Parameter(ValueFromPipeline = $true)]
        [PSObject[]] $InputObject,
        [Parameter()]
        [string] $DefaultType = 'System.String'
    )
    begin {
        $dataTable = New-Object -TypeName 'System.Data.DataTable'
        $first = $true
        $types = @(
            'System.String','System.Boolean','System.Byte[]','System.Byte','System.Char','System.DateTime',
            'System.Decimal','System.Double','System.Guid','System.Int16','System.Int32','System.Int64',
            'System.Single','System.UInt16','System.UInt32','System.UInt64'
        )
    }
    process {
        foreach ($object in $InputObject) {
            $dataRow = $dataTable.NewRow()
            foreach ($property in $object.PSObject.get_properties()) {
                if ($first) {
                    if ($types -contains $property.TypeNameOfValue) { $dataType = $property.TypeNameOfValue }
                    else { $dataType = $DefaultType }
                    $dataColumn = New-Object 'System.Data.DataColumn' $property.Name, $dataType
                    $null = $dataTable.Columns.Add($dataColumn)
                }
                if ($property.Value -ne $null) {
                    if (($property.Value.GetType().IsArray) -or ($property.TypeNameOfValue -like '*collection*')) {
                        $dataRow.Item($property.Name) = $property.Value | ConvertTo-Xml -As 'String' -NoTypeInformation -Depth 1
                    } else {
                        $dataRow.Item($property.Name) = $property.Value -as $dataType
                    }
                }
            }
            $null = $dataTable.Rows.Add($dataRow)
            $first = $false
        }
    }
    end { Write-Output (,($dataTable)) }
}

try {
    Import-Module PnP.PowerShell -ErrorAction Stop
} catch {
    Install-Module PnP.PowerShell -MaximumVersion 1.12.0 -Scope CurrentUser -Force
    Import-Module PnP.PowerShell
}
$env:PNPPOWERSHELL_UPDATECHECK = "Off"

$equipment = Import-Clixml -LiteralPath $EquipmentPath

function Get-StatusText {
    if (-not (Test-Path -LiteralPath $StatusPath)) { return 'Disabled' }
    ($null = $null)
    try { return ((Get-Content -LiteralPath $StatusPath -ErrorAction Stop) + '').Trim() } catch { return 'Disabled' }
}

function Set-StatusText([string]$NewStatus) {
    Set-Content -LiteralPath $StatusPath -Value $NewStatus
}
#endregion

#region ── Equipment Dialog ──────────────────────────────────────────────────────
function Show-EquipmentDialog {
    param([hashtable]$Hashtable)

    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text            = "Instrumentlist (AutoMappscript)"
    $dlg.StartPosition   = 'CenterParent'
    $dlg.Size            = New-Object System.Drawing.Size(750, 560)
    $dlg.MinimumSize     = New-Object System.Drawing.Size(650, 450)
    $dlg.BackColor       = $T.BgDark
    $dlg.ForeColor       = $T.TextPrimary
    $dlg.Font            = $FontBody

    # ── Header ──
    $panelTop = New-Object System.Windows.Forms.Panel
    $panelTop.Dock      = 'Top'
    $panelTop.Height    = 60
    $panelTop.BackColor = $T.BgCard
    $dlg.Controls.Add($panelTop)

    $lblTop = New-Object System.Windows.Forms.Label
    $lblTop.Text      = "🔧  Instrumentlista — ändringar sparas automatiskt"
    $lblTop.ForeColor = $T.TextPrimary
    $lblTop.Font      = $FontHeader
    $lblTop.AutoSize  = $true
    $lblTop.Location  = New-Object System.Drawing.Point(16, 18)
    $panelTop.Controls.Add($lblTop)

    # ── Separator ──
    $sep = New-Object System.Windows.Forms.Panel
    $sep.Dock      = 'Top'
    $sep.Height    = 2
    $sep.BackColor = $T.Accent
    $dlg.Controls.Add($sep)

    # ── Grid ──
    $panelBody = New-Object System.Windows.Forms.Panel
    $panelBody.Dock    = [System.Windows.Forms.DockStyle]::Fill
    $panelBody.Padding = New-Object System.Windows.Forms.Padding(12, 12, 12, 12)
    $panelBody.BackColor = $T.BgDark
    $dlg.Controls.Add($panelBody)
    $panelBody.BringToFront()

    $grid = New-Object System.Windows.Forms.DataGridView
    $grid.Dock                    = [System.Windows.Forms.DockStyle]::Fill
    $grid.AllowUserToAddRows      = $false
    $grid.AllowUserToDeleteRows   = $false
    $grid.AutoSizeColumnsMode     = 'Fill'
    $grid.SelectionMode           = 'CellSelect'
    $grid.MultiSelect             = $false
    $grid.RowHeadersVisible       = $false
    $grid.BackgroundColor         = $T.BgCard
    $grid.GridColor               = $T.Border
    $grid.BorderStyle             = 'None'
    $grid.Font                    = $FontSmall
    $grid.ForeColor               = $T.TextPrimary
    $grid.DefaultCellStyle.BackColor          = $T.GridRow
    $grid.DefaultCellStyle.ForeColor          = $T.TextPrimary
    $grid.DefaultCellStyle.SelectionBackColor = $T.GridSel
    $grid.DefaultCellStyle.SelectionForeColor = [System.Drawing.Color]::White
    $grid.AlternatingRowsDefaultCellStyle.BackColor = $T.GridRowAlt
    $grid.ColumnHeadersDefaultCellStyle.BackColor   = $T.GridHeader
    $grid.ColumnHeadersDefaultCellStyle.ForeColor   = $T.Accent
    $grid.ColumnHeadersDefaultCellStyle.Font        = $FontSmall
    $grid.EnableHeadersVisualStyles = $false
    $grid.ColumnHeadersBorderStyle  = 'Single'
    $panelBody.Controls.Add($grid)

    $dataTable = $Hashtable.GetEnumerator() | ForEach-Object {
        [PSCustomObject]@{ Key = $_.Key; Value = $_.Value }
    } | ConvertTo-DataTable

    $grid.DataSource = $dataTable
    try { $grid.Columns["Key"].ReadOnly = $true } catch {}

    $grid.Add_CellValueChanged({
        try {
            $key   = $grid.Rows[$_.RowIndex].Cells["Key"].Value
            $value = $grid.Rows[$_.RowIndex].Cells["Value"].Value
            $Hashtable[$key] = $value
            Export-Clixml -LiteralPath $EquipmentPath -InputObject $Hashtable
        } catch {}
    })

    $grid.Add_CurrentCellDirtyStateChanged({
        if ($grid.IsCurrentCellDirty) { $grid.CommitEdit([System.Windows.Forms.DataGridViewDataErrorContexts]::Commit) }
    })

    $null = $dlg.ShowDialog()
    return
}
#endregion

#region ── Huvudformulär ─────────────────────────────────────────────────────────
$form = New-Object System.Windows.Forms.Form
$form.Text            = "AutoMappscript – Control Panel"
$form.StartPosition   = 'CenterScreen'
$form.Size            = New-Object System.Drawing.Size(560, 380)
$form.MinimumSize     = New-Object System.Drawing.Size(560, 380)
$form.MaximizeBox     = $false
$form.FormBorderStyle = 'FixedDialog'
$form.BackColor       = $T.BgDark
$form.ForeColor       = $T.TextPrimary
$form.Font            = $FontBody

# ── Header ──
$header = New-Object System.Windows.Forms.Panel
$header.Dock      = 'Top'
$header.Height    = 72
$header.BackColor = $T.BgCard
$form.Controls.Add($header)

# Accent line
$accentLine = New-Object System.Windows.Forms.Panel
$accentLine.Dock      = 'Top'
$accentLine.Height    = 2
$accentLine.BackColor = $T.Accent
$form.Controls.Add($accentLine)

# Icon box
$iconBox = New-Object System.Windows.Forms.Label
$iconBox.Text      = "A"
$iconBox.Font      = New-Object System.Drawing.Font('Segoe UI', 16, [System.Drawing.FontStyle]::Bold)
$iconBox.ForeColor = [System.Drawing.Color]::White
$iconBox.BackColor = $T.Accent
$iconBox.Size      = New-Object System.Drawing.Size(42, 42)
$iconBox.Location  = New-Object System.Drawing.Point(16, 15)
$iconBox.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
$header.Controls.Add($iconBox)

$title = New-Object System.Windows.Forms.Label
$title.Text      = "AutoMappscript Control"
$title.ForeColor = $T.TextPrimary
$title.Font      = $FontTitle
$title.AutoSize  = $true
$title.Location  = New-Object System.Drawing.Point(68, 12)
$header.Controls.Add($title)

$subtitle = New-Object System.Windows.Forms.Label
$subtitle.Text      = "Status & Instruments"
$subtitle.ForeColor = $T.TextSecondary
$subtitle.Font      = $FontSmall
$subtitle.AutoSize  = $true
$subtitle.Location  = New-Object System.Drawing.Point(70, 44)
$header.Controls.Add($subtitle)

# ── Status Card ──
$statusCard = New-Object System.Windows.Forms.Panel
$statusCard.Size      = New-Object System.Drawing.Size(510, 70)
$statusCard.Location  = New-Object System.Drawing.Point(22, 92)
$statusCard.BackColor = $T.BgCard
$form.Controls.Add($statusCard)

# Status-etikett
$statusCaption = New-Object System.Windows.Forms.Label
$statusCaption.Text      = "AUTOMAPPSCRIPT STATUS"
$statusCaption.ForeColor = $T.TextMuted
$statusCaption.Font      = New-Object System.Drawing.Font('Segoe UI', 8, [System.Drawing.FontStyle]::Bold)
$statusCaption.AutoSize  = $true
$statusCaption.Location  = New-Object System.Drawing.Point(16, 10)
$statusCard.Controls.Add($statusCaption)

$statusLbl = New-Object System.Windows.Forms.Label
$statusLbl.Font     = New-Object System.Drawing.Font('Segoe UI Semibold', 18)
$statusLbl.AutoSize = $true
$statusLbl.Location = New-Object System.Drawing.Point(14, 30)
$statusCard.Controls.Add($statusLbl)

# Status-ikon (cirkel)
$statusDot = New-Object System.Windows.Forms.Panel
$statusDot.Size      = New-Object System.Drawing.Size(14, 14)
$statusDot.Location  = New-Object System.Drawing.Point(480, 32)
$statusCard.Controls.Add($statusDot)

function Refresh-StatusUi {
    $s = Get-StatusText
    if ($s -eq 'Enabled') {
        $statusLbl.Text      = "ENABLED"
        $statusLbl.ForeColor = $T.Success
        $statusDot.BackColor = $T.Success
    } else {
        $statusLbl.Text      = "DISABLED"
        $statusLbl.ForeColor = $T.Error
        $statusDot.BackColor = $T.Error
    }
}

# ── Knappar ──
$btnToggle = New-Object System.Windows.Forms.Button
$btnToggle.Text     = "⏻  Aktivera / Inaktivera"
$btnToggle.Size     = New-Object System.Drawing.Size(245, 46)
$btnToggle.Location = New-Object System.Drawing.Point(22, 180)
Style-Button $btnToggle -Primary

$btnEdit = New-Object System.Windows.Forms.Button
$btnEdit.Text     = "🔧  Visa / Ändra Instrumentlista"
$btnEdit.Size     = New-Object System.Drawing.Size(245, 46)
$btnEdit.Location = New-Object System.Drawing.Point(287, 180)
Style-Button $btnEdit

# ── Sökväg-info ──
$lblPath = New-Object System.Windows.Forms.Label
$lblPath.Text      = "Sökväg: $BasePath"
$lblPath.ForeColor = $T.TextMuted
$lblPath.Font      = New-Object System.Drawing.Font('Segoe UI', 8)
$lblPath.AutoSize  = $false
$lblPath.Size      = New-Object System.Drawing.Size(400, 18)
$lblPath.Location  = New-Object System.Drawing.Point(22, 244)
$lblPath.AutoEllipsis = $true
$form.Controls.Add($lblPath)

# ── Avsluta ──
$btnExit = New-Object System.Windows.Forms.Button
$btnExit.Text     = "Stäng"
$btnExit.Size     = New-Object System.Drawing.Size(100, 36)
$btnExit.Location = New-Object System.Drawing.Point(432, 294)
Style-Button $btnExit

$form.Controls.Add($btnToggle)
$form.Controls.Add($btnEdit)
$form.Controls.Add($btnExit)
#endregion

#region ── Event Handlers (oförändrad logik) ─────────────────────────────────────
$btnToggle.Add_Click({
    $current = Get-StatusText
    $new = if ($current -eq 'Enabled') { 'Disabled' } else { 'Enabled' }
    try {
        Set-StatusText -NewStatus $new
    } catch {
        [System.Windows.Forms.MessageBox]::Show("Kunde inte uppdatera statusfilen.`r`n$StatusPath`r`n`r`n$($_.Exception.Message)", "Fel", 'OK', 'Error') | Out-Null
        return
    }
    Refresh-StatusUi
})

$btnEdit.Add_Click({
    try {
        $script:equipment = Import-Clixml -LiteralPath $EquipmentPath
        Show-EquipmentDialog -Hashtable $script:equipment
    } catch {
        [System.Windows.Forms.MessageBox]::Show("Kunde inte öppna instrumentlistan.`r`n$EquipmentPath`r`n`r`n$($_.Exception.Message)", "Fel", 'OK', 'Error') | Out-Null
    }
})

$btnExit.Add_Click({ $form.Close() })

$form.Add_Shown({ Refresh-StatusUi })
[void]$form.ShowDialog()
#endregion
