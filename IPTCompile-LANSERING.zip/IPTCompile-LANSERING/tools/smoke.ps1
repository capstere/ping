Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

$repoRoot = Split-Path -Parent $PSScriptRoot
$helpersPath = Join-Path $repoRoot 'IPTCompile-LANSERING/Modules/DataHelpers.ps1'

if (-not (Test-Path -LiteralPath $helpersPath)) {
    Write-Host "FAIL load-datahelpers ($helpersPath saknas)"
    exit 1
}

. $helpersPath

function New-TestCsv {
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter(Mandatory)][string[]]$SampleIds
    )

    $lines = @(
        'Header line 1'
        'Header line 2'
        'Header line 3'
        'Header line 4'
        'Header line 5'
        'Header line 6'
        'Header line 7'
        'Assay;Sample ID;Value'
        ''
    )

    foreach ($sid in $SampleIds) {
        $lines += ('AssayX;{0};1' -f $sid)
    }

    Set-Content -LiteralPath $Path -Value $lines -Encoding Default
}

function Write-CaseResult {
    param(
        [Parameter(Mandatory)][string]$Name,
        [Parameter(Mandatory)][bool]$Ok,
        [string]$Details = ''
    )

    if ($Ok) {
        Write-Host ("PASS {0}" -f $Name)
    } else {
        if ($Details) {
            Write-Host ("FAIL {0}: {1}" -f $Name, $Details)
        } else {
            Write-Host ("FAIL {0}" -f $Name)
        }
    }
}

$failed = 0
$tempRoot = Join-Path ([System.IO.Path]::GetTempPath()) ("iptcompile_smoke_{0}" -f ([Guid]::NewGuid().ToString('N')))

try {
    [void](New-Item -ItemType Directory -Path $tempRoot -Force)

    $csvPrimary = Join-Path $tempRoot 'primary.csv'
    $csvResample = Join-Path $tempRoot 'resample.csv'

    New-TestCsv -Path $csvPrimary -SampleIds @('SAMPLE_001','SAMPLE_002','SAMPLE_003')
    New-TestCsv -Path $csvResample -SampleIds @('SAMPLE_RES_001','SAMPLE_RES_002','SAMPLE_RES_003','SAMPLE_004')

    $caseNoRes = Resolve-CsvPrimaryAndResample -CsvPaths @($csvPrimary)
    $okNoRes = (
        $caseNoRes.Ok -and
        $caseNoRes.PrimaryCsv -eq $csvPrimary -and
        -not $caseNoRes.ResampleCsv -and
        -not $caseNoRes.HasResample
    )
    if (-not $okNoRes) { $failed++ }
    Write-CaseResult -Name 'single-primary' -Ok $okNoRes -Details ("Ok={0}, HasResample={1}" -f $caseNoRes.Ok, $caseNoRes.HasResample)

    $caseWithRes = Resolve-CsvPrimaryAndResample -CsvPaths @($csvResample, $csvPrimary)
    $okWithRes = (
        $caseWithRes.Ok -and
        $caseWithRes.PrimaryCsv -eq $csvPrimary -and
        $caseWithRes.ResampleCsv -eq $csvResample -and
        $caseWithRes.HasResample
    )
    if (-not $okWithRes) { $failed++ }
    Write-CaseResult -Name 'primary-plus-resample' -Ok $okWithRes -Details ("Ok={0}, HasResample={1}" -f $caseWithRes.Ok, $caseWithRes.HasResample)
}
catch {
    $failed++
    Write-Host ("FAIL smoke-exception: {0}" -f $_.Exception.Message)
}
finally {
    try {
        if (Test-Path -LiteralPath $tempRoot) {
            Remove-Item -LiteralPath $tempRoot -Recurse -Force -ErrorAction SilentlyContinue
        }
    } catch {}
}

if ($failed -eq 0) {
    Write-Host 'PASS smoke'
    exit 0
}

Write-Host ("FAIL smoke ({0} case(s) failed)" -f $failed)
exit 1
