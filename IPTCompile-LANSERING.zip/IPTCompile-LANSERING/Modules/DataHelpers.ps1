﻿function Ensure-EPPlus {
    param(
        [string] $Version = "4.5.3.3",
        [string] $SourceDllPath = "",
        [string] $LocalFolder = "$env:TEMP\EPPlus"
    )
    try {
        $candidatePaths = New-Object 'System.Collections.Generic.List[string]'
        try {
            if ($global:Config -and $global:Config.EpplusDllPath) {
                [void]$candidatePaths.Add(($global:Config.EpplusDllPath + ''))
            }
        } catch {}
        $localModuleDll = $null
        try {
            if ($global:LibRoot) {
                $localModuleDll = Join-Path $global:LibRoot 'EPPlus.dll'
            }
        } catch {}
        if (-not $localModuleDll) { $localModuleDll = Join-Path $PSScriptRoot 'EPPlus.dll' }
        [void]$candidatePaths.Add($localModuleDll)
        if ($SourceDllPath) {
            $defaultRoot = 'N:\QC\QC-1\IPT'
            if ($env:IPT_ROOT -and $SourceDllPath -like "$defaultRoot\*") {
                $SourceDllPath = ($env:IPT_ROOT.TrimEnd('\') + $SourceDllPath.Substring($defaultRoot.Length))
            }
            [void]$candidatePaths.Add($SourceDllPath)
        }
        $userModRoot = Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'WindowsPowerShell\Modules'
        if (Test-Path -LiteralPath $userModRoot) {
            Get-ChildItem -Path (Join-Path $userModRoot 'EPPlus') -Directory -ErrorAction SilentlyContinue | ForEach-Object {
                [void]$candidatePaths.Add((Join-Path $_.FullName 'lib\net45\EPPlus.dll'))
                [void]$candidatePaths.Add((Join-Path $_.FullName 'lib\net40\EPPlus.dll'))
                [void]$candidatePaths.Add((Join-Path $_.FullName 'lib\net35\EPPlus.dll'))
            }
        }
        $progFiles = $env:ProgramFiles
        $systemModRoot = Join-Path $progFiles 'WindowsPowerShell\Modules'
        if (Test-Path -LiteralPath $systemModRoot) {
            Get-ChildItem -Path (Join-Path $systemModRoot 'EPPlus') -Directory -ErrorAction SilentlyContinue | ForEach-Object {
                [void]$candidatePaths.Add((Join-Path $_.FullName 'lib\net45\EPPlus.dll'))
                [void]$candidatePaths.Add((Join-Path $_.FullName 'lib\net40\EPPlus.dll'))
                [void]$candidatePaths.Add((Join-Path $_.FullName 'lib\net35\EPPlus.dll'))
            }
        }
        foreach ($cand in $candidatePaths) {
            if (-not [string]::IsNullOrWhiteSpace($cand) -and (Test-Path -LiteralPath $cand)) { return $cand }
        }
        $allowOnline = $false
        try {
            if (Get-Command Get-ConfigValue -ErrorAction SilentlyContinue) {
                $allowOnline = [bool](Get-ConfigValue -Name 'AllowNuGetDownload' -Default $false)
            } elseif ($global:Config -and $global:Config.AllowNuGetDownload) {
                $allowOnline = [bool]$global:Config.AllowNuGetDownload
            }
        } catch { $allowOnline = $false }
        if ($allowOnline) {
            $nugetUrl = "https://www.nuget.org/api/v2/package/EPPlus/$Version"
            try {
                $guid = [Guid]::NewGuid().ToString()
                $tempDir = Join-Path $env:TEMP "EPPlus_$guid"
                New-Item -ItemType Directory -Path $tempDir -Force | Out-Null
                $zipPath  = Join-Path $tempDir 'EPPlus.zip'
                $reqParams = @{ Uri = $nugetUrl; OutFile = $zipPath; UseBasicParsing = $true; Headers = @{ 'User-Agent' = 'DocMerge/1.0' } }
                Invoke-WebRequest @reqParams -ErrorAction Stop | Out-Null

                if (-not ([System.AppDomain]::CurrentDomain.GetAssemblies() | Where-Object { $_.GetName().Name -eq 'System.IO.Compression.FileSystem' })) {
                    Add-Type -AssemblyName 'System.IO.Compression.FileSystem' -ErrorAction SilentlyContinue
                }
                [System.IO.Compression.ZipFile]::ExtractToDirectory($zipPath, $tempDir)
                $extractedRoot = Join-Path $tempDir 'lib'
                if (Test-Path -LiteralPath $extractedRoot) {
                    $dllCandidate = Get-ChildItem -Path (Join-Path $extractedRoot 'net45'), (Join-Path $extractedRoot 'net40'), (Join-Path $extractedRoot 'net35') -Filter 'EPPlus.dll' -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
                    if ($dllCandidate) {
                        try {
                            if (-not (Test-Path -LiteralPath $localModuleDll)) {
                                Copy-Item -Path $dllCandidate.FullName -Destination $localModuleDll -Force -ErrorAction SilentlyContinue
                            }
                        } catch { Gui-Log "⚠️ Kunde inte kopiera EPPlus.dll: $($_.Exception.Message)" 'Warn' }
                        if (Test-Path -LiteralPath $localModuleDll) { return $localModuleDll }
                        return $dllCandidate.FullName
                    }
                }
            } catch {
                Gui-Log "❌ EPPlus: Kunde inte hämta EPPlus ($Version): $($_.Exception.Message)" 'Error'
            }
        }
    } catch {
        Gui-Log "❌ Ensure-EPPlus fel: $($_.Exception.Message)" 'Error'
    }

    Gui-Log "❌ EPPlus.dll hittades inte. Lägg EPPlus.dll lokalt i Lib\ (rekommenderat) eller Modules\ (bakåtkompatibilitet) eller installera EPPlus $Version." 'Error'
    return $null
}

function Load-EPPlus {
    if ([System.AppDomain]::CurrentDomain.GetAssemblies() | Where-Object { $_.GetName().Name -eq 'EPPlus' }) { return $true }
    $dllPath = Ensure-EPPlus -Version '4.5.3.3'
    if (-not $dllPath) { return $false }
    try {
        $bytes = [System.IO.File]::ReadAllBytes($dllPath)
        [System.Reflection.Assembly]::Load($bytes) | Out-Null
        return $true
    } catch {
        Gui-Log "❌ EPPlus-fel: $($_.Exception.Message)" 'Error'
        return $false
    }
}

function Set-RowBorder {
    param ($ws, [int] $row, [int] $firstRow, [int] $lastRow)
    foreach ($col in 'B','C','D','E','F','G','H') {
        $ws.Cells["$col$row"].Style.Border.Left.Style   = "None"
        $ws.Cells["$col$row"].Style.Border.Right.Style  = "None"
        $ws.Cells["$col$row"].Style.Border.Top.Style    = "None"
        $ws.Cells["$col$row"].Style.Border.Bottom.Style = "None"
    }
    $ws.Cells["B$row"].Style.Border.Left.Style  = "Medium"
    $ws.Cells["H$row"].Style.Border.Right.Style = "Medium"
    foreach ($col in 'B','C','D','E','F','G') { $ws.Cells["$col$row"].Style.Border.Right.Style = "Thin" }
    $topStyle = if ($row -eq $firstRow) { "Medium" } else { "Thin" }
    $bottomStyle = if ($row -eq $lastRow)  { "Medium" } else { "Thin" }
    foreach ($col in 'B','C','D','E','F','G','H') {
        $ws.Cells["$col$row"].Style.Border.Top.Style    = $topStyle
        $ws.Cells["$col$row"].Style.Border.Bottom.Style = $bottomStyle
    }
}

function Style-Cell { param($cell,$bold,$bg,$border,$fontColor)
    if ($bold) { $cell.Style.Font.Bold = $true }
    if ($bg)   { $cell.Style.Fill.PatternType = "Solid"; $cell.Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml("#$bg")) }
    if ($fontColor) { $cell.Style.Font.Color.SetColor([System.Drawing.ColorTranslator]::FromHtml("#$fontColor")) }
    if ($border) { $cell.Style.Border.Top.Style=$border; $cell.Style.Border.Bottom.Style=$border; $cell.Style.Border.Left.Style=$border; $cell.Style.Border.Right.Style=$border }
}

function Test-FileLocked {
    param([Parameter(Mandatory=$true)][string]$Path)
    # B1: Primärt ReadWrite; fallback till Read vid read-only share
    try {
        $fs = [IO.File]::Open($Path, 'Open', 'ReadWrite', 'None')
        $fs.Close()
        return $false
    } catch [System.UnauthorizedAccessException] {
        # Read-only share: filen är inte "låst" av annan process
        try {
            $fs = [IO.File]::Open($Path, 'Open', 'Read', 'None')
            $fs.Close()
            return $false
        } catch { return $true }
    } catch {
        return $true
    }
}

function Get-CsvDelimiter { param([string]$Path)
    try {
        $first = Get-Content -LiteralPath $Path -Encoding Default -TotalCount 30 | Where-Object { $_ -and $_.Trim() } | Select-Object -First 1
        if (-not $first) { return ';' }
        $sc = ($first -split ';').Count; $cc = ($first -split ',').Count
        if ($cc -gt $sc -and $cc -ge 2) { return ',' } else { return ';' }
    } catch {
        Gui-Log "⚠️ Get-CsvDelimiter misslyckades: $($_.Exception.Message)" 'Warn'
        return ';'
    }
}

function Test-IsResampleCsv {
    <# Returnerar $true om CSV:n innehåller _RES_ i Sample ID-kolumnen (>= MinHits träffar). #>
    param(
        [Parameter(Mandatory)][string]$Path,
        [int]$MinHits = 3
    )

    if (-not (Test-Path -LiteralPath $Path)) { return $false }
    $threshold = [Math]::Max(1, [int]$MinHits)

    try {
        $lines = Get-Content -LiteralPath $Path -TotalCount 30 -ErrorAction Stop
        if (-not $lines -or $lines.Count -le 9) { return $false }

        $delim = Get-CsvDelimiter -Path $Path

        # Rubriken ligger på rad 8 (index 7) i Test Summary-CSV
        $hdr = $null
        try { $hdr = ConvertTo-CsvFields -Line $lines[7] -Delimiter $delim } catch { $hdr = $null }

        # Hitta kolumnindex för Sample ID
        $sampleIdIdx = 0
        if ($hdr) {
            for ($i = 0; $i -lt $hdr.Count; $i++) {
                $h = ($hdr[$i] + '').Trim()
                if ($h -imatch '^Sample\s*ID$' -or $h -ieq 'SampleID' -or $h -imatch '^Sample\s*Id$') {
                    $sampleIdIdx = $i
                    break
                }
            }
        }

        $resCount = 0
        for ($r = 9; $r -lt $lines.Count; $r++) {
            $line = $lines[$r]
            if (-not $line -or $line.Trim().Length -eq 0) { continue }

            $fields = $null
            try { $fields = ConvertTo-CsvFields -Line $line -Delimiter $delim } catch { $fields = $null }
            if (-not $fields -or $fields.Count -le $sampleIdIdx) { continue }

            $sid = ($fields[$sampleIdIdx] + '')
            if ($sid -imatch '_RES_') { $resCount++ }
        }

        return ($resCount -ge $threshold)
    } catch {
        try {
            Gui-Log ("⚠️ Test-IsResampleCsv misslyckades för '{0}': {1}" -f (Split-Path $Path -Leaf), $_.Exception.Message) 'Warn' 'DEBUG'
        } catch {}
        return $false
    }
}

function Resolve-CsvPrimaryAndResample {
    <# Klassificerar 0-2 CSV-filer till Primary + ev. Resample med samma regel som i buildflödet. #>
    param([string[]]$CsvPaths)

    $result = [pscustomobject]@{
        Ok             = $true
        PrimaryCsv     = $null
        ResampleCsv    = $null
        HasResample    = $false
        ErrorMessage   = $null
        WarningMessage = $null
    }

    $paths = @($CsvPaths | Where-Object { $_ -and (($_ + '').Trim().Length -gt 0) })

    if ($paths.Count -eq 0) { return $result }

    if ($paths.Count -eq 1) {
        if (Test-IsResampleCsv -Path $paths[0]) {
            $result.Ok = $false
            $result.ResampleCsv = $paths[0]
            $result.ErrorMessage = '❌ Enbart Resampling-CSV vald. Välj även Primary CSV innan rapport kan skapas.'
            return $result
        }
        $result.PrimaryCsv = $paths[0]
        return $result
    }

    if ($paths.Count -eq 2) {
        $isRes0 = Test-IsResampleCsv -Path $paths[0]
        $isRes1 = Test-IsResampleCsv -Path $paths[1]

        if ($isRes0 -and -not $isRes1) {
            $result.ResampleCsv = $paths[0]
            $result.PrimaryCsv = $paths[1]
        } elseif ($isRes1 -and -not $isRes0) {
            $result.PrimaryCsv = $paths[0]
            $result.ResampleCsv = $paths[1]
        } elseif (-not $isRes0 -and -not $isRes1) {
            $result.Ok = $false
            $result.ErrorMessage = '❌ Du har valt 2 CSV-filer men ingen Resampling CSV-fil. Avmarkera en fil eller välj korrekt Resampling CSV-fil.'
            return $result
        } else {
            # Båda innehåller _RES_ -> fallback för bakåtkompatibilitet.
            $result.PrimaryCsv = $paths[0]
            $result.ResampleCsv = $paths[1]
            $result.WarningMessage = '⚠️ Båda CSV har _RES_ i Sample ID – autoväljer Resampling + Original.'
        }

        $result.HasResample = [bool]$result.ResampleCsv
        return $result
    }

    $result.Ok = $false
    $result.ErrorMessage = ("❌ Du har valt {0} CSV-filer. Välj max 2 (Primary + ev. Resample)." -f $paths.Count)
    return $result
}

function Get-AssayFromCsv { param([string]$Path,[int]$StartRow=10)
    if (-not (Test-Path -LiteralPath $Path)) { return $null }
    $delim = Get-CsvDelimiter $Path
    try {
        $lines = Get-Content -LiteralPath $Path -Encoding Default
        if (-not $lines -or $lines.Count -lt $StartRow) { return $null }
        for ($i = ($StartRow-1); $i -lt $lines.Count; $i++) {
            $ln = $lines[$i]
            if (-not $ln -or $ln.Trim().Length -eq 0) { continue }
            $f = ConvertTo-CsvFields -Line $ln -Delimiter $delim
            if (-not $f -or $f.Length -lt 1) { continue }
            $a = ([string]$f[0]).Trim()
            if ($a -and $a -notmatch '^(?i)\s*assay\s*$') { return $a }
        }
    } catch {
        Gui-Log "⚠️ Kunde inte läsa Assay från CSV: $($_.Exception.Message)" 'Warn'
    }
    return $null
}

function Import-CsvRows { param([string]$Path,[int]$StartRow=10)
    if (-not (Test-Path -LiteralPath $Path)) { return @() }
    $delim = Get-CsvDelimiter $Path
    $list  = New-Object System.Collections.Generic.List[object]
    try {
        $lines = Get-Content -LiteralPath $Path -Encoding Default
        if (-not $lines -or $lines.Count -lt $StartRow) { return @() }
        for ($i = ($StartRow-1); $i -lt $lines.Count; $i++) {
            $ln = $lines[$i]
            if (-not $ln -or $ln.Trim().Length -eq 0) { continue }
            $f = ConvertTo-CsvFields -Line $ln -Delimiter $delim
            if (-not $f -or ($f -join '').Trim().Length -eq 0) { continue }
            [void]$list.Add($f)
        }
    } catch {
        Gui-Log "⚠️ Kunde inte läsa rader från CSV: $($_.Exception.Message)" 'Warn'
    }
    return ,@($list.ToArray())
}

function ConvertTo-CsvFields {
    param(
        [Parameter(Mandatory=$true)][string]$Line,
        [string]$Delimiter
    )
    if ($null -eq $Line) { return @() }

    $del = $Delimiter
    if ([string]::IsNullOrWhiteSpace($del)) {
        # Upptäck avgränsare automatiskt (';' i svensk Excel-export, annars ',')
        $cSemi  = ([regex]::Matches($Line, ';')).Count
        $cComma = ([regex]::Matches($Line, ',')).Count
        $del = $(if ($cSemi -gt $cComma) { ';' } else { ',' })
    }

    $d  = [regex]::Escape($del)
    $rx = $d + '(?=(?:(?:[^"]*"){2})*[^"]*$)'
    $arr = [regex]::Split($Line, $rx)
    return ,@($arr | ForEach-Object { (($_ + '') -replace '^"|"$','').Trim() })
}

function Get-CsvStats {
    param(
        [string]$Path,
        [string[]]$Lines
    )
    $out = [ordered]@{
        TestCount       = 0
        DupCount        = 0
        Duplicates      = @()
        LspValues       = @()
        LspOK           = $null
        InstrumentByType= [ordered]@{}
    }
    $lines = @($Lines)
    if ($lines.Count -eq 1 -and -not $lines[0]) { $lines = @() }
    if ($lines.Count -eq 0) {
        if (-not (Test-Path -LiteralPath $Path)) { return [pscustomobject]$out }
        try { $lines = @(Get-Content -LiteralPath $Path) } catch { Gui-Log "⚠️ Kunde inte läsa CSV-statistik: $($_.Exception.Message)" 'Warn'; return [pscustomobject]$out }
    }
    if ($lines.Count -lt 8) { return [pscustomobject]$out }
    $header = ConvertTo-CsvFields $lines[7]
    $dataLines = @()
    if ($lines.Count -gt 9) { $dataLines = $lines[9..($lines.Count-1)] }
    $csv = $null
    try {
        if ($dataLines.Count -gt 0) {
            $csv = ConvertFrom-Csv -InputObject ($dataLines -join "`n") -Header $header
        }
    } catch { $csv = $null }

    $cartSnList = New-Object System.Collections.Generic.List[string]
    $lspList    = New-Object System.Collections.Generic.List[string]
    $instrList  = New-Object System.Collections.Generic.List[string] 
    if ($csv) {
        foreach ($row in $csv) {
            $cart = $row.'Cartridge S/N'
            $lsp  = $row.'Reagent Lot ID'
            $ins  = $row.'Instrument S/N'
            if (-not $cart) { try { $cart = $row.Item(3) } catch {} }
            if (-not $ins)  { try { $ins  = $row.Item(6) } catch {} }
            if ($cart) { $cartSnList.Add( ($cart + '').Trim() ) }
            if ($lsp)  { $lspList.Add(  ($lsp  + '').Trim() ) }
            if ($ins)  { $instrList.Add(($ins  + '').Trim() ) }
        }
    } else {
        foreach ($ln in $dataLines) {
            if (-not $ln -or -not $ln.Trim()) { continue }
            $f = ConvertTo-CsvFields $ln
            if ($f.Count -lt 7) { continue }
            $cartSnList.Add( ($f[3] + '').Trim() )
            $lspList.Add(    ($f[4] + '').Trim() )
            $instrList.Add(  ($f[6] + '').Trim() )
        }
    }
    $cartSn = $cartSnList | Where-Object { $_ -and $_ -ne '' }
    $out.TestCount = @($cartSn).Count
    $dups = $cartSn | Group-Object | Where-Object { $_.Count -gt 1 }
    if ($dups) {
        # @() gör det robust när endast 1 grupp returneras (annars tolkas .Count som gruppens storlek)
        $out.DupCount   = @($dups).Count
        $out.Duplicates = @($dups) | ForEach-Object { "$($_.Name) x$($_.Count)" }
    }
    $lspClean = $lspList | ForEach-Object {
        $m = [regex]::Match($_, '(?<!\d)(\d{5})(?!\d)')
        if ($m.Success) { $m.Groups[1].Value } else { $null }
    } | Where-Object { $_ } | Select-Object -Unique
    $out.LspValues = @($lspClean)
    if (@($lspClean).Count -gt 0) {
        $out.LspOK = (@($lspClean).Count -eq 1)
    }
    $lut = @{}
    foreach ($k in $script:GXINF_Map.Keys) {
        $codes = $script:GXINF_Map[$k].Split(',') | ForEach-Object { $_.Trim() } | Where-Object { $_ }
        foreach ($code in $codes) { $lut[$code] = $k }
    }
    foreach ($ins in ($instrList | Where-Object { $_ })) {
        $t = $null
        if ($lut.ContainsKey($ins)) { $t = $lut[$ins] } else { $t = 'Unknown' }
        if (-not $out.InstrumentByType.Contains($t)) { $out.InstrumentByType[$t] = 0 }
        $out.InstrumentByType[$t]++
    }
    return [pscustomobject]$out
}

function Format-SpPresenceGrandTotalStrict {
    param([hashtable]$Counts) 
    if (-not $Counts -or $Counts.Count -eq 0) { return '—' }
    $present = @(
        $Counts.GetEnumerator() |
        Where-Object { $_.Value -gt 0 } |
        ForEach-Object { [int]$_.Key } |
        Sort-Object
    )
    if ($present.Count -eq 0) { return '—' }
    $parts = New-Object System.Collections.Generic.List[string]
    $i = 0
    while ($i -lt $present.Count) {
        $start = $present[$i]; $end = $start
        $j = $i + 1
        while ($j -lt $present.Count -and $present[$j] -eq $end + 1) {
            $end = $present[$j]; $j++
        }
        if ($start -eq $end) { $parts.Add( ('#{0:00}' -f $start) ) }
        else { $parts.Add( ('#{0:00}-{1:00}' -f $start, $end) ) }
        $i = $j
    }
    $total = (
        $Counts.GetEnumerator() |
        Where-Object { $_.Value -gt 0 } |
        Measure-Object -Property Value -Sum
    ).Sum
    return ( ($parts -join '+') + (' x{0}' -f $total) )
}

if (Get-Command Get-InfinitySpFromCsvStrict -ErrorAction SilentlyContinue) {
    Remove-Item Function:\Get-InfinitySpFromCsvStrict -ErrorAction SilentlyContinue
}

function Get-InfinitySpFromCsvStrict {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Path,
        [Alias('InfinitySerials')][string[]]$InstrumentSerials,
        [string[]]$Lines
    )
    if (-not $Lines -and -not (Test-Path -LiteralPath $Path)) { return '—' }
    $useConvertFn = $false
    try { $useConvertFn = [bool](Get-Command ConvertTo-CsvFields -ErrorAction Stop) } catch {}
    function Split-CsvSmart([string]$ln) {
        if ($ln -like '*;*' -and $ln -notlike '*,*') {
            return [regex]::Split($ln, ';(?=(?:[^"]*"[^"]*")*[^"]*$)')
        } else {
            return [regex]::Split($ln, ',(?=(?:[^"]*"[^"]*")*[^"]*$)')
        }
    }

    $serSet = New-Object System.Collections.Generic.HashSet[string]([StringComparer]::OrdinalIgnoreCase)
    foreach ($s in ($InstrumentSerials | Where-Object { $_ })) { $null = $serSet.Add( ($s + '').Trim().Trim('"') ) }
    if ($serSet.Count -eq 0) { return '—' } 

    $lines = $Lines
    if (-not $lines) {
        try { $lines = Get-Content -LiteralPath $Path } catch { Gui-Log "⚠️ Kunde inte läsa Infinity SP från CSV: $($_.Exception.Message)" 'Warn'; return '—' }
    }
    if (-not $lines -or $lines.Count -lt 10) { return '—' }

    $headerIndex = 7
    $dataStart   = 9

    $hdr = if ($useConvertFn) { ConvertTo-CsvFields $lines[$headerIndex] } else { Split-CsvSmart $lines[$headerIndex] }
    $colCount = $hdr.Count

    $idxInstr = -1
    for ($i=0; $i -lt $colCount; $i++) {
        $h = (($hdr[$i] + '') -replace '[\uFEFF\u200B]','').Trim().ToLowerInvariant()
        if ($h -match 'instrument' -and ($h -match 's/?n' -or $h -match 'serial')) { $idxInstr = $i; break }
    }
    if ($idxInstr -lt 0) { $idxInstr = 6 }  # G
    $idxSample = 2
    $counts = @{}

    for ($r = $dataStart; $r -lt $lines.Count; $r++) {
        $ln = $lines[$r]; if (-not $ln -or -not $ln.Trim()) { continue }
        $f = if ($useConvertFn) { ConvertTo-CsvFields $ln } else { Split-CsvSmart $ln }
        if ($f.Count -le [Math]::Max($idxInstr,$idxSample)) { continue }

        $instr  = ($f[$idxInstr] + '').Trim().Trim('"')
        if (-not $serSet.Contains($instr)) { continue }  # inte Infinity → skippa

        $sample = ($f[$idxSample] + '').Trim().Trim('"')
        if (-not $sample) { continue }

        $m = [regex]::Match($sample, '_(\d{2})_')
         if ($m.Success) {
             $nRaw = 0
             if ([int]::TryParse($m.Groups[1].Value, [ref]$nRaw)) {

                $sp = $nRaw 
                if ($sp -ge 0 -and $sp -le 10) {
                     if (-not $counts.ContainsKey($sp)) { $counts[$sp] = 0 }
                     $counts[$sp]++
                 }
             }
         }
    }

    if ($counts.Count -eq 0) { return '—' }
    return (Format-SpPresenceGrandTotalStrict -Counts $counts)
 }

function Normalize-Assay { param([string]$s)
    if ([string]::IsNullOrWhiteSpace($s)) { return $null }
    $x=$s.ToLowerInvariant(); $x=[regex]::Replace($x,'[^a-z0-9]+',' '); $x=$x.Trim() -replace '\s+',' '; return $x
}
$AssayMap = @(

    @{ Tab='MTB ULTRA';            Aliases=@('Xpert MTB-RIF Ultra', 'MTB-RIF Ultra v2 RUO') }
    @{ Tab='MTB RIF';              Aliases=@('Xpert MTB-RIF Assay G4', 'Xpert MTB-RIF US IVD') }
    @{ Tab='MTB JP';               Aliases=@('Xpert MTB-RIF JP IVD') }
    @{ Tab='MTB XDR';              Aliases=@('Xpert MTB-XDR', 'MTB-XDR RUO', 'MTB-XDR IUO') }
    @{ Tab='FLUVID | FLUVID+';     Aliases=@('Xpress SARS-CoV-2_Flu_RSV plus','Xpert Xpress_SARS-CoV-2_Flu_RSV') }
    @{ Tab='SARS-COV-2 Plus';      Aliases=@('Xpert Xpress CoV-2 plus', 'LCE009 Xpress SARS-CoV-2 plus','Xpert Xpress CoV-2 plus IVD', 'Xpress CoV-2 plus RUO', 'Xpress CoV-2 plus IUO') }
    @{ Tab='CTNG | CTNG JP';       Aliases=@('Xpert CT_NG','Xpert CT_CE') }
    @{ Tab='C.DIFF | C.DIFF JP';   Aliases=@('Xpert C.difficile G3','Xpert C.difficile BT', 'Xpert-C. difficile G2', 'Xpert C.diff-Epi') }
    @{ Tab='HPV';                  Aliases=@('Xpert HPV HR','Xpert HPV v2 HR') }
    @{ Tab='HBV VL';               Aliases=@('Xpert HBV Viral Load') }
    @{ Tab='HCV VL';               Aliases=@('Xpert HCV Viral Load','Xpert_HCV Viral Load') }
    @{ Tab='HCV VL FS';            Aliases=@('Xpert HCV VL Fingerstick') }
    @{ Tab='HIV VL';               Aliases=@('Xpert HIV-1 Viral Load','Xpert_HIV-1 Viral Load') }
    @{ Tab='HIV VL XC';            Aliases=@('Xpert HIV-1 Viral Load XC') }
    @{ Tab='HIV QA';               Aliases=@('Xpert HIV-1 Qual','Xpert_HIV-1 Qual') }
    @{ Tab='HIV QA XC';            Aliases=@('Xpert HIV-1 Qual XC PQC','Xpert HIV-1 Qual XC') }
    @{ Tab='SARS-COV-2';           Aliases=@('Xpert Xpress SARS-CoV-2 CE-IVD','Xpert Xpress SARS-CoV-2') }
    @{ Tab='FLU RSV';              Aliases=@('Xpert Xpress Flu-RSV','Xpress Flu IPT_EAT off') }
    @{ Tab='MRSA SA';              Aliases=@('Xpert SA Nasal Complete G3','Xpert MRSA-SA SSTI G3') }
    @{ Tab='MRSA NxG';             Aliases=@('Xpert MRSA NxG') }
    @{ Tab='NORO';                 Aliases=@('Xpert Norovirus') }
    @{ Tab='VAN AB';               Aliases=@('Xpert vanA vanB') }
    @{ Tab='GBS';                  Aliases=@('Xpert GBS LB XC','Xpert Xpress GBS','Xpert Xpress GBS US-IVD') }
    @{ Tab='STREP A';              Aliases=@('Xpert Xpress Strep A', 'Xpert Xpress_Strep A') }
    @{ Tab='CARBA R';              Aliases=@('Xpert Carba-R','Xpert_Carba-R', 'CARBA-R IUO','Carba-R BEU IUO', 'CARBA-R RUO', 'Carba-R BEU RUO') }
    @{ Tab='EBOLA';                Aliases=@('Xpert Ebola EUA','Xpert Ebola CE-IVD', 'Ebola RUO') }
    @{ Tab='Respiratory Panel';    Aliases=@('Respiratory panel', 'Respiratory panel CE-IVD', 'Respiratory panel UKCA-IVD', 'Respiratory Panel RUO', 'Respiratory Panel IUO') }
    @{ Tab='TAP Panel';            Aliases=@('Xpert TAP Panel', 'TAP Panel IUO', 'TAP Panel RUO') }
    @{ Tab='GI Panel';             Aliases=@('GI Panel', 'Xpert GI Panel CE-IVD', 'Xpert GI Panel', 'GI Panel IUO', 'GI Panel RUO') }

)

$AssayIndex = @{}
foreach($row in $AssayMap){ foreach($a in $row.Aliases){ $k=Normalize-Assay $a; if($k -and -not $AssayIndex.ContainsKey($k)){ $AssayIndex[$k]=$row.Tab } } }

function Get-ControlTabName {
    param([string]$AssayName)
    $k = Normalize-Assay $AssayName
    if ($k -and $AssayIndex.ContainsKey($k)) { return $AssayIndex[$k] }

    if (Test-Path -LiteralPath $SlangAssayPath) {
        $mapPkg = $null
        try {
            $mapPkg = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($SlangAssayPath))
            $ws = $mapPkg.Workbook.Worksheets['Slang till Assay']; if (-not $ws) { $ws = $mapPkg.Workbook.Worksheets[1] }
            if ($ws -and $ws.Dimension) {
                for ($r=2; $r -le $ws.Dimension.End.Row; $r++){
                    $sheet=$ws.Cells[$r,1].Text.Trim()
                    $aliases=@($ws.Cells[$r,2].Text,$ws.Cells[$r,3].Text,$ws.Cells[$r,4].Text) | Where-Object { $_ -and $_.Trim() }
                    foreach($al in $aliases){ if ($k -and $k -eq (Normalize-Assay $al)) { return $sheet } }
                }
            }
        } catch {
            Gui-Log "Get-ControlTabName: $($_.Exception.Message)" 'Warn'
        } finally {
            if ($mapPkg) {
                try { $mapPkg.Dispose() } catch {}
            }
        }
    }
    return $null
}

$MinitabMap = @(

    @{ Aliases=@('Xpert MTB-RIF Ultra');                           Macro='%D12547-MTBU-SWE' }
    @{ Aliases=@('Xpert MTB-RIF Assay G4');                        Macro='%D12547-MTB-SWE' }
    @{ Aliases=@('Xpress SARS-CoV-2_Flu_RSV plus','Xpert Xpress_SARS-CoV-2_Flu_RSV'); Macro='%D12547-XP3COV2FLURSV-SWE' }
    @{ Aliases=@('Xpert Xpress CoV-2 plus');                        Macro='%D12547-XP3SARSCOV2-SWE' }
    @{ Aliases=@('CT_NG','Xpert CT_CE');                            Macro='%D12547-CTNG-SWE' }
    @{ Aliases=@('Xpert C.difficile G3','Xpert C.difficile BT');    Macro='%D12547-CDCE-SWE' }
    @{ Aliases=@('Xpert HPV HR','Xpert HPV v2 HR');                 Macro='%D12547-HPV-SWE' }
    @{ Aliases=@('Xpert HBV Viral Load');                           Macro='%D12547-HBVVL-SWE' }
    @{ Aliases=@('Xpert HCV Viral Load','Xpert_HCV Viral Load');    Macro='%D12547-HCVVL-SWE' }
    @{ Aliases=@('Xpert HCV VL Fingerstick');                       Macro='%D12547-FSHCV-SWE' }
    @{ Aliases=@('Xpert HIV-1 Viral Load','Xpert_HIV-1 Viral Load'); Macro='%D12547-HIVVL-SWE' }
    @{ Aliases=@('Xpert HIV-1 Qual','Xpert_HIV-1 Qual');            Macro='%D12547-HIVQA-SWE' }
    @{ Aliases=@('Xpert Xpress SARS-CoV-2 CE-IVD','Xpert Xpress SARS-CoV-2'); Macro='%D12547-XPRSARSCOV2-SWE' }
    @{ Aliases=@('Xpert Xpress Flu-RSV');                           Macro='%D12547-XPFLURSV-SWE' }
    @{ Aliases=@('Xpress Flu IPT_EAT off');                         Macro='%D12547-FLUNG-SWE' } 
    @{ Aliases=@('Xpert Norovirus');                                Macro='%D12547-NORO-SWE' }
    @{ Aliases=@('Xpert vanA vanB');                                Macro='%D12547-VAB-SWE' }
    @{ Aliases=@('Xpert Xpress Strep A');                           Macro='%D12547-STREPA-SWE' }
    @{ Aliases=@('Xpert Carba-R','Xpert_Carba-R');                  Macro='%D12547-CARBAR-SWE' }
    @{ Aliases=@('Xpert Ebola EUA','Xpert Ebola CE-IVD');           Macro='%D12547-EBOLA-SWE' }
    @{ Aliases=@('Xpert SA Nasal Complete G3','Xpert MRSA-SA SSTI G3'); Macro='%D12547-SACOMP-SWE' }

    # N/A-gruppen:
    @{ Aliases=@('Xpert GBS LB XC','Xpert Xpress GBS','Xpert Xpress GBS US-IVD'); Macro=$null }
    @{ Aliases=@('Xpert HIV-1 Qual XC PQC','Xpert HIV-1 Qual XC');  Macro=$null }
    @{ Aliases=@('Xpert HIV-1 Viral Load XC');                      Macro=$null }
    @{ Aliases=@('Xpert MTB-RIF JP IVD');                           Macro=$null }
    @{ Aliases=@('Xpert MTB-XDR');                                  Macro=$null }
    @{ Aliases=@('Xpert MRSA NxG');                                 Macro=$null }
)

$MinitabIndex = @{}
foreach ($row in $MinitabMap) { foreach ($a in $row.Aliases) { $k = Normalize-Assay $a; if ($k -and -not $MinitabIndex.ContainsKey($k)) { $MinitabIndex[$k] = $row.Macro } } }

function Get-MinitabMacro { param([string]$AssayName)
    if ([string]::IsNullOrWhiteSpace($AssayName)) { return $null }
    $k = Normalize-Assay $AssayName
    if ($k -and $MinitabIndex.ContainsKey($k)) { return $MinitabIndex[$k] }
    return $null
}

function Find-ObservationCol { param($ws)
    $default = 13
    if (-not $ws -or -not $ws.Dimension) { return $default }
    $maxR = [Math]::Min(5, $ws.Dimension.End.Row)
    $maxC = $ws.Dimension.End.Column

    for ($r=1; $r -le $maxR; $r++) {
        for ($c=1; $c -le $maxC; $c++) {
            $t = ($ws.Cells[$r,$c].Text + '').Trim()
            if ($t -match '^(?i)\s*(obs|observation)') { return $c }
        }
    }
    return $default
}

function Test-IsWorksheetHeaderSkipSheet {
    param([string]$SheetName)
    if ([string]::IsNullOrWhiteSpace($SheetName)) { return $false }
    if ($SheetName -match '(?i)^\s*Worksheet\s*Instructions\s*$') { return $true }
    if ($SheetName -match '(?i)for reference only') { return $true }
    # QC Data saknar i vissa VL-mallar konsekvent jämförbart headerinnehåll; exkluderas explicit.
    if ($SheetName -match '(?i)^\s*QC\s+Data\s*$') { return $true }
    return $false
}

if (-not (Get-Command Extract-WorksheetHeader -ErrorAction SilentlyContinue)) {
    function Extract-WorksheetHeader {
        param([object]$Pkg)
        $result = [pscustomobject]@{
            PartNo         = $null
            BatchNo        = $null
            CartridgeNo    = $null
            DocumentNumber = $null
            Attachment     = $null
            Rev            = $null
            Effective      = $null
        }
        if (-not $Pkg) { return $result }
        try {
            foreach ($ws in $Pkg.Workbook.Worksheets) {
                if (-not $ws.Dimension) { continue }
                if (Test-IsWorksheetHeaderSkipSheet -SheetName $ws.Name) { continue }
                $left  = (($ws.HeaderFooter.OddHeader.LeftAlignedText  + '') -replace '\r?\n',' ')
                if (-not $left)  { $left  = (($ws.HeaderFooter.EvenHeader.LeftAlignedText  + '') -replace '\r?\n',' ') }
                $right = (($ws.HeaderFooter.OddHeader.RightAlignedText + '') -replace '\r?\n',' ')
                if (-not $right) { $right = (($ws.HeaderFooter.EvenHeader.RightAlignedText + '') -replace '\r?\n',' ') }
                $raw = (($left + ' ' + $right) + '').Trim()
                if (-not $raw) { continue }
                $parsed = Parse-WorksheetHeaderRaw -Raw $raw
                if (-not $result.PartNo         -and $parsed.PartNo)         { $result.PartNo         = $parsed.PartNo }
                if (-not $result.BatchNo        -and $parsed.BatchNo)        { $result.BatchNo        = $parsed.BatchNo }
                if (-not $result.CartridgeNo    -and $parsed.CartridgeNo)    { $result.CartridgeNo    = $parsed.CartridgeNo }
                if (-not $result.DocumentNumber -and $parsed.DocumentNumber) { $result.DocumentNumber = $parsed.DocumentNumber }
                if (-not $result.Attachment     -and $parsed.Attachment)     { $result.Attachment     = $parsed.Attachment }
                if (-not $result.Rev            -and $parsed.Rev)            { $result.Rev            = $parsed.Rev }
                if (-not $result.Effective      -and $parsed.Effective)      { $result.Effective      = $parsed.Effective }
            }
        } catch { Gui-Log "⚠️ Kunde inte läsa Worksheet-header: $($_.Exception.Message)" 'Warn' }
        if (-not $result.CartridgeNo) {
            foreach ($ws in $Pkg.Workbook.Worksheets) {
                if (-not $ws.Dimension) { continue }
                if (Test-IsWorksheetHeaderSkipSheet -SheetName $ws.Name) { continue }
                $left  = (($ws.HeaderFooter.OddHeader.LeftAlignedText  + '') -replace '\r?\n',' ').Trim()
                $right = (($ws.HeaderFooter.OddHeader.RightAlignedText + '') -replace '\r?\n',' ').Trim()
                $m  = [regex]::Match($left,  '(?<!\d)(\d{5})(?!\d)')
                $m2 = if (-not $m.Success) { [regex]::Match($right,'(?<!\d)(\d{5})(?!\d)') } else { $null }
                if ($m.Success) { $result.CartridgeNo = $m.Groups[1].Value; break }
                if ($m2 -and $m2.Success) { $result.CartridgeNo = $m2.Groups[1].Value; break }
            }
        }
        return $result
    }
}

if (-not (Get-Command Get-WorksheetHeaderPerSheet -ErrorAction SilentlyContinue)) {
    function Get-WorksheetHeaderPerSheet {
        param([object]$Pkg)

        $rxPart      = '(?i)^\s*Part\s*(?:No|Number)\.?\s*(?:\(s\))?\s*$'
        $rxBatch     = '(?i)^\s*Batch\s*(?:No|Number)(?:\s*\(s\))?\.?\s*$'
        $rxCartridge = '(?i)^\s*Cartridge\s*(?:No|Number)?\s*(?:\(?LSP\)?)?\.?\s*$'
        $rxDoc       = '(?i)^\s*Document\s*(?:No|Number|#)\s*$'
        $rxRev       = '(?i)^\s*Rev(?:ision)?\.?\s*$'
        $rxEff       = '(?i)^\s*Effective(?:\s*Date)?\s*$'
        function Get-HeaderFooterText([Object]$ws) {
            $left  = Normalize-HeaderText ((($ws.HeaderFooter.OddHeader.LeftAlignedText  + '') -replace '\r?\n',' '))
            if (-not $left)  { $left  = Normalize-HeaderText ((($ws.HeaderFooter.EvenHeader.LeftAlignedText  + '') -replace '\r?\n',' ')) }
            $right = Normalize-HeaderText ((($ws.HeaderFooter.OddHeader.RightAlignedText + '') -replace '\r?\n',' '))
            if (-not $right) { $right = Normalize-HeaderText ((($ws.HeaderFooter.EvenHeader.RightAlignedText + '') -replace '\r?\n',' ')) }
            return @($left,$right)
        }

        function Try-FromHeaderFooter([string[]]$lr, [string]$kind) {
            $left,$right = $lr
            $raw = (($left + ' ' + $right) + '').Trim()
            if (-not $raw) {
                return @{ Has = $false; Val = $null }
            }
            $parsed = Parse-WorksheetHeaderRaw -Raw $raw
            $has = $false
            $val = $null

            switch ($kind) {
                'Part' {
                    $has = ($raw -match '(?i)\bPart\b')
                    $val = $parsed.PartNo
                }
                'Batch' {
                    $has = ($raw -match '(?i)\bBatch\b')
                    $val = $parsed.BatchNo
                }
                'Cartridge' {
                    $has = ($raw -match '(?i)\bCartridge\b')
                    $val = $parsed.CartridgeNo
                }
                'Doc' {
                    $has = ($raw -match '(?i)Document\s*Number')
                    $val = $parsed.DocumentNumber
                }
                'REV' {
                    $has = ($raw -match '(?i)\bRev(?:ision)?\b')
                    $val = $parsed.Rev
                }
                'EFF' {
                    $has = ($raw -match '(?i)\bEffective(\s*Date)?\b')
                    $val = $parsed.Effective
                }
            }
            return @{ Has = [bool]$has; Val = $val }
        }

        function Try-FromCells([Object]$ws, [string]$rxLabel, [int]$maxR=30, [int]$maxC=20, [string]$canon='') {
            $has=$false; $val=$null
            for($r=1;$r -le $maxR;$r++){
                for($c=1;$c -le $maxC;$c++){
                    $t     = Normalize-HeaderText (""+$ws.Cells[$r,$c].Text)
                    if([string]::IsNullOrWhiteSpace($t)){ continue }
                    if($t -match $rxLabel){
                        $has=$true
$right = Normalize-HeaderText (""+$ws.Cells[$r,[Math]::Min($c+1,$maxC)].Text)
$down  = Normalize-HeaderText (""+$ws.Cells[[Math]::Min($r+1,$maxR),$c].Text)
                        $val = if($right){$right}elseif($down){$down}else{''}
                        if($canon -eq 'Cartridge' -and $val){
                            $m=[regex]::Match($val,'(?<!\d)(\d{5})(?!\d)'); if($m.Success){$val=$m.Groups[1].Value}
                        }
                        elseif ($canon -eq 'EFF' -and $val) {
                            $dt = $null
                            if (Try-Parse-HeaderDate $val ([ref]$dt)) { $val = $dt.ToString('yyyy-MM-dd') }
                        }
                        return @{Has=$has; Val=$val}
                    }
                }
            }
            return @{Has=$has; Val=$val}
        }
        $rows = New-Object System.Collections.Generic.List[object]
        if(-not $Pkg){ return @() }

foreach ($ws in $Pkg.Workbook.Worksheets) {
    if (Test-IsWorksheetHeaderSkipSheet -SheetName $ws.Name) {
        continue
    }

            $partLabel=$false; $batchLabel=$false; $cartLabel=$false; $docLabel=$false; $revLabel=$false; $effLabel=$false
            $part=$null; $batch=$null; $cart=$null; $doc=$null; $rev=$null; $eff=$null
            $lr = Get-HeaderFooterText $ws
            $r1 = Try-FromHeaderFooter $lr 'Part';      $partLabel=$partLabel -or $r1.Has; if($r1.Val){$part=$r1.Val}
            $r2 = Try-FromHeaderFooter $lr 'Batch';     $batchLabel=$batchLabel -or $r2.Has; if($r2.Val){$batch=$r2.Val}
            $r3 = Try-FromHeaderFooter $lr 'Cartridge'; $cartLabel=$cartLabel -or $r3.Has; if($r3.Val){$cart=$r3.Val}
            $r4 = Try-FromHeaderFooter $lr 'Doc';       $docLabel=$docLabel -or $r4.Has; if($r4.Val){$doc=$r4.Val}
            $r5 = Try-FromHeaderFooter $lr 'REV';       $revLabel=$revLabel -or $r5.Has; if($r5.Val){$rev=$r5.Val}
            $r6 = Try-FromHeaderFooter $lr 'EFF';       $effLabel=$effLabel -or $r6.Has; if($r6.Val){$eff=$r6.Val}
            if(-not $part){  $c=Try-FromCells $ws $rxPart      30 20 'Part';      $partLabel=$partLabel -or $c.Has; if($c.Val){$part=$c.Val} }
            if(-not $batch){ $c=Try-FromCells $ws $rxBatch     30 20 'Batch';     $batchLabel=$batchLabel -or $c.Has; if($c.Val){$batch=$c.Val} }
            if(-not $cart){  $c=Try-FromCells $ws $rxCartridge 30 20 'Cartridge'; $cartLabel=$cartLabel -or $c.Has; if($c.Val){$cart=$c.Val} }
            if(-not $doc){   $c=Try-FromCells $ws $rxDoc       30 20;             $docLabel=$docLabel -or $c.Has; if($c.Val){$doc=$c.Val} }
            if(-not $rev){   $c=Try-FromCells $ws $rxRev       30 20;             $revLabel=$revLabel -or $c.Has; if($c.Val){$rev=$c.Val} }
            if(-not $eff){   $c=Try-FromCells $ws $rxEff       30 20 'EFF';       $effLabel=$effLabel -or $c.Has; if($c.Val){$eff=$c.Val} }
            [void]$rows.Add([pscustomobject]@{
                Sheet              = $ws.Name
                PartNo             = $part
                BatchNo            = $batch
                CartridgeNo        = $cart
                DocumentNumber     = $doc
                Rev                = $rev
                Effective          = $eff
                HasPartNoLabel     = [bool]$partLabel
                HasBatchNoLabel    = [bool]$batchLabel
                HasCartridgeLabel  = [bool]$cartLabel
                HasDocumentLabel   = [bool]$docLabel
                HasRevLabel        = [bool]$revLabel
                HasEffectiveLabel  = [bool]$effLabel
            })
        }
        return @($rows.ToArray())
    }
}

function Get-TestSummaryEquipmentFromWorksheet {
    param(
        [object]$Worksheet
    )

    $result = [pscustomobject]@{
        WorksheetName = $null
        Pipettes      = @()
        Instruments   = @()
    }

    if (-not $Worksheet -or -not $Worksheet.Dimension) {
        return $result
    }

    $result.WorksheetName = $Worksheet.Name

    $maxR = $Worksheet.Dimension.End.Row
    $maxC = $Worksheet.Dimension.End.Column
    $maxR = [Math]::Min($maxR, 350)
    $maxC = [Math]::Min($maxC, 40)
    $getCellText = {
        param(
            $Ws,
            [int]$Row,
            [int]$Col
        )
        if ($Row -le 0 -or $Col -le 0) { return '' }
        if (-not $Ws.Dimension) { return '' }
        $t = $Ws.Cells[$Row,$Col].Text
        if ($t) { return $t.Trim() }
        return ''
    }
    $excelDateBase = Get-Date '1899-12-30'
    $resolveDueCellValue = {
        param($Cell)

        if (-not $Cell) { return $null }

        $dueVal = $Cell.Value
        if ($dueVal -is [datetime]) {
            return $dueVal
        }

        if ($dueVal -is [double] -or $dueVal -is [int]) {
            try {
                return $excelDateBase.AddDays([double]$dueVal)
            } catch {
                $fallback = ($Cell.Text + '').Trim()
                if ($fallback) { return $fallback }
                return $null
            }
        }

        $txt = ($Cell.Text + '').Trim()
        if ($txt) { return $txt }
        return $null
    }
    $dedupeEquipmentById = {
        param([object[]]$Items)

        if (-not $Items -or $Items.Count -eq 0) { return @() }

        $uniq = New-Object System.Collections.Generic.List[object]
        $seen = @{}
        foreach ($item in $Items) {
            if (-not $item -or -not $item.Id) { continue }
            if ($seen.ContainsKey($item.Id)) { continue }
            $seen[$item.Id] = $true
            [void]$uniq.Add($item)
        }
        return @($uniq.ToArray())
    }

    $pipHeaderRows = New-Object 'System.Collections.Generic.List[int]'
    for ($r = 1; $r -le $maxR; $r++) {
        $txt = & $getCellText $Worksheet $r 1
        if (-not $txt) { continue }

        if ($txt -match '(?i)table\s*2\b.*pipett(e)?\b') {
            [void]$pipHeaderRows.Add($r)
        }
    }

    $pipPairs = New-Object System.Collections.Generic.List[object]

    foreach ($hdrRow in $pipHeaderRows) {
        $searchMax = [Math]::Min($maxR, $hdrRow + 12)

        for ($r = $hdrRow + 1; $r -le $searchMax; $r++) {
            $label = & $getCellText $Worksheet $r 1
            if ($label -match '(?i)cepheid\s*id') {

                $calRow = $null
                for ($cRow = $r + 1; $cRow -le [Math]::Min($maxR, $r + 6); $cRow++) {
                    $lab2 = & $getCellText $Worksheet $cRow 1
                    if ($lab2 -match '(?i)calibration\s+due\s+date') {
                        $calRow = $cRow
                        break
                    }
                }

                if ($calRow) {
                    [void]$pipPairs.Add([pscustomobject]@{
                        IdRow  = $r
                        CalRow = $calRow
                    })
                }
            }
        }
    }

    $pipettes = New-Object System.Collections.Generic.List[object]

    $pipetteIdRegex = '(?i)\b(?:nr|no)\.?\s*\d+\b'

    foreach ($pair in $pipPairs) {
        for ($c = 2; $c -le $maxC; $c += 2) {
            $idTxt = & $getCellText $Worksheet $pair.IdRow $c
            if (-not $idTxt) { continue }

            if ($idTxt -match '^(?i)N/?A$') { continue }
            if ($idTxt -notmatch $pipetteIdRegex) { continue }

            $dueOut = & $resolveDueCellValue $Worksheet.Cells[$pair.CalRow,$c]

            [void]$pipettes.Add([pscustomobject]@{
                Id                 = $idTxt
                CalibrationDueDate = $dueOut
            })
        }
    }

    $pipettes = & $dedupeEquipmentById $pipettes.ToArray()

    $result.Pipettes = $pipettes

    $instHeaderRows = New-Object 'System.Collections.Generic.List[int]'
    for ($r = 1; $r -le $maxR; $r++) {
        $txt = & $getCellText $Worksheet $r 1
        if (-not $txt) { continue }
        if ($txt -match '(?i)table\s*3\b.*(gene\s*experts?|genexperts?|genex?perts?|infinitys?)') {
            [void]$instHeaderRows.Add($r)
        }
    }

    $instPairs = New-Object System.Collections.Generic.List[object]

    foreach ($hdrRow in $instHeaderRows) {
        $searchMax = [Math]::Min($maxR, $hdrRow + 20)

        for ($r = $hdrRow + 1; $r -le $searchMax; $r++) {
            $label = & $getCellText $Worksheet $r 1
            if ($label -match '(?i)cepheid\s*id') {

                $calRow = $null
                for ($cRow = $r + 1; $cRow -le [Math]::Min($maxR, $r + 6); $cRow++) {
                    $lab2 = & $getCellText $Worksheet $cRow 1
                    if ($lab2 -match '(?i)calibration\s+due\s+date') {
                        $calRow = $cRow
                        break
                    }
                }

                if ($calRow) {
                    [void]$instPairs.Add([pscustomobject]@{
                        IdRow  = $r
                        CalRow = $calRow
                    })
                }
            }
        }
    }

    $insts = New-Object System.Collections.Generic.List[object]

    foreach ($pair in $instPairs) {
        for ($c = 2; $c -le $maxC; $c += 2) {
            $idTxt = & $getCellText $Worksheet $pair.IdRow $c
            if (-not $idTxt) { continue }
            if ($idTxt -match '^(?i)N/?A$') { continue }

            if ($idTxt -notmatch '(?i)^(infinity|gx\s*\d+|gx\d+)') {
                continue
            }

            $dueOut = & $resolveDueCellValue $Worksheet.Cells[$pair.CalRow,$c]

            [void]$insts.Add([pscustomobject]@{
                Id                 = $idTxt
                CalibrationDueDate = $dueOut
            })
        }
    }

    $insts = & $dedupeEquipmentById $insts.ToArray()

    $result.Instruments = $insts

    return $result
}

function Get-TestSummaryEquipment {
    param(
        [object]$Pkg
    )

    $empty = [pscustomobject]@{
        WorksheetName = $null
        Pipettes      = @()
        Instruments   = @()
    }

    if (-not $Pkg) { return $empty }

    $best = $null

    try {
        foreach ($ws in $Pkg.Workbook.Worksheets) {
            if (-not $ws.Dimension) { continue }
            if ($ws.Name -match '(?i)worksheet\s*instructions') { continue }

            $info = Get-TestSummaryEquipmentFromWorksheet -Worksheet $ws
            if (-not $info) { continue }

            $pipCount  = if ($info.Pipettes)   { $info.Pipettes.Count }   else { 0 }
            $instCount = if ($info.Instruments){ $info.Instruments.Count } else { 0 }

            if (-not $best) { $best = $info }

            if ($pipCount -gt 0 -or $instCount -gt 0) {
                if ($ws.Name -match '(?i)test\s*summary') {
                    return $info
                }
                $best = $info
            }
        }
    } catch {
        return $empty
    }

    if ($best) { return $best }
    return $empty
}

if (-not (Get-Command Compare-WorksheetHeaderSet -ErrorAction SilentlyContinue)) {
    function Compare-WorksheetHeaderSet {
        param([Parameter(Mandatory)][object[]]$Rows)

        $devIssues  = 0
        $reqIssues  = 0
        $detailsLst = New-Object System.Collections.Generic.List[string]

function _canonWorksheet([string]$raw, [string]$type) {
    if ([string]::IsNullOrWhiteSpace($raw)) { return $null }
    $txt = Normalize-HeaderText $raw
            switch ($type) {
                'Part'      { $m=[regex]::Match($txt,'(?i)\b(\d{3}-\d{4})\b'); return $(if($m.Success){$m.Groups[1].Value}else{$txt.ToUpper()}) }
                'Batch'     { $m=[regex]::Match($txt,'(?<!\d)(\d{10})(?!\d)');  return $(if($m.Success){$m.Groups[1].Value}else{$txt.ToUpper()}) }
                'Cartridge' { $m=[regex]::Match($txt,'(?<!\d)(\d{5})(?!\d)');   return $(if($m.Success){$m.Groups[1].Value}else{$txt.ToUpper()}) }
                'Doc'       { $m=[regex]::Match($txt,'(?i)\b(D\d+)\b');         return $(if($m.Success){$m.Groups[1].Value.ToUpper()}else{$txt.ToUpper()}) }
                'REV'       { return $txt.ToUpper() }
                'EFF' {
    $dt = $null
    if (Try-Parse-HeaderDate $txt ([ref]$dt)) { return $dt.ToString('yyyy-MM-dd') }
    return $txt
}
                default     { return $txt }
            }
        }
        $keys = @(

            @{K='PartNo';         T='Part';      Required=$true;  Label='HasPartNoLabel'    },
            @{K='BatchNo';        T='Batch';     Required=$true;  Label='HasBatchNoLabel'   },
            @{K='CartridgeNo';    T='Cartridge'; Required=$true;  Label='HasCartridgeLabel' },
            @{K='DocumentNumber'; T='Doc';       Required=$false; Label='HasDocumentLabel'  },
            @{K='Rev';            T='REV';       Required=$false; Label='HasRevLabel'       },
            @{K='Effective';      T='EFF';       Required=$false; Label='HasEffectiveLabel' }
        )

        foreach ($entry in $keys) {
            $k=$entry.K; $t=$entry.T; $req=$entry.Required; $labelProp=$entry.Label
            $vals = foreach($r in $Rows){
                [pscustomobject]@{
                    Sheet  = $r.Sheet
                    Canon  = _canonWorksheet ($r.$k) $t
                    Raw    = if([string]::IsNullOrWhiteSpace($r.$k)){ $null } else { $r.$k.Trim() }
                    HasLbl = [bool]($r.$labelProp)
                }
            }
            $nonEmpty = @($vals | Where-Object { $_.Canon })
            $useSet   = if(@($nonEmpty).Count -gt 0){$nonEmpty}else{$vals}
            $byVal    = @($useSet | Group-Object Canon | Sort-Object Count -Descending)
            $major    = if(@($byVal).Count -gt 0){ $byVal[0].Name } else { $null }
            $deviants = @()
            if($major){
                $deviants = @($vals | Where-Object { $_.Canon -and ($_.Canon -ne $major) } | Select-Object -ExpandProperty Sheet -Unique)
            }

            if(@($deviants).Count -gt 0){
                $devIssues++
                $majShow = if($major){"'$major'"}else{'(empty)'}
                $line = "- $k majoritet=$majShow | avvikande flikar: " + ($deviants -join ', ')
                [void]$detailsLst.Add($line)
            }

            if($req){
                $missingSheets = @($vals | Where-Object { $_.HasLbl -and -not $_.Canon } | Select-Object -ExpandProperty Sheet -Unique)
                if(@($missingSheets).Count -gt 0){
                    $reqIssues++
                    $line = "*Saknas* - $k " + ($missingSheets -join ', ')
                    [void]$detailsLst.Add($line)
                }
            }
        }
        $issuesTotal = $devIssues + $reqIssues
        $summary = if($issuesTotal -eq 0){ 'OK' } else { "Avvikelser: $issuesTotal (avvikare=$devIssues, saknas=$reqIssues)" }

        return [pscustomobject]@{
            Issues  = $issuesTotal
            Summary = $summary
            Details = ($detailsLst -join "`r`n")
        }
    }
}

if (-not (Get-Command Get-SealTestHeaderPerSheet -ErrorAction SilentlyContinue)) {
    function Get-SealTestHeaderPerSheet {
        param([object]$Pkg)

        $rows = New-Object System.Collections.Generic.List[object]
        if (-not $Pkg) { return @() }

        $rxDoc = '(?i)^\s*Document\s*(?:No|Number|#)\s*$'
        $rxRev = '(?i)^\s*Rev(?:ision)?\.?\s*$'
        $rxEff = '(?i)^\s*Effective(?:\s*Date)?\s*$'

        function _getRightHeader([object]$ws) {
            $right = (($ws.HeaderFooter.OddHeader.RightAlignedText + '') -replace '\r?\n',' ').Trim()
            if (-not $right) { $right = (($ws.HeaderFooter.EvenHeader.RightAlignedText + '') -replace '\r?\n',' ').Trim() }
            return (Normalize-HeaderText $right)
        }

        function _tryFromCells([object]$ws, [string]$rxLabel, [int]$maxR=30, [int]$maxC=20, [string]$canon='') {
            $has=$false; $val=$null
            for($r=1;$r -le $maxR;$r++){
                for($c=1;$c -le $maxC;$c++){
                    $t = Normalize-HeaderText (""+$ws.Cells[$r,$c].Text)
                    if([string]::IsNullOrWhiteSpace($t)){ continue }
                    if($t -match $rxLabel){
                        $has=$true
                        $right = Normalize-HeaderText (""+$ws.Cells[$r,[Math]::Min($c+1,$maxC)].Text)
                        $down  = Normalize-HeaderText (""+$ws.Cells[[Math]::Min($r+1,$maxR),$c].Text)
                        $val = if($right){$right}elseif($down){$down}else{''}

                        if($canon -eq 'Doc' -and $val){
                            $m=[regex]::Match($val,'(?i)\b(D\d+)\b'); if($m.Success){$val=$m.Groups[1].Value.ToUpper()}
                        }
                        elseif($canon -eq 'EFF' -and $val){
                            $dt=$null
                            if(Try-Parse-HeaderDate $val ([ref]$dt)) { $val = $dt.ToString('yyyy-MM-dd') }
                        }
                        elseif($canon -eq 'REV' -and $val){
                            $val = (Normalize-HeaderText $val).ToUpper()
                        }

                        return @{Has=$has; Val=$val}
                    }
                }
            }
            return @{Has=$has; Val=$val}
        }

        foreach ($ws in $Pkg.Workbook.Worksheets) {
            if ($ws.Name -eq 'Worksheet Instructions' -or $ws.Name -match '(?i)for reference only') { continue }

            $doc=$null; $rev=$null; $eff=$null
            $docLbl=$false; $revLbl=$false; $effLbl=$false

            $right = _getRightHeader $ws

            if ($right) {
                if ($right -match '(?i)\bDocument\s*(?:No|Number|#)\s*[:#]?\s*(D\d+)\b') { $doc = $matches[1].ToUpper() }
                if ($right -match '(?i)\bRev(?:ision)?\.?\s*[:#]?\s*([A-Z]{1,3}(?:\.\d+)?)\b') { $rev = $matches[1].ToUpper() }
                if ($right -match '(?i)\bEffective\s*[:#]?\s*([0-9]{1,2}[\/\-][0-9]{1,2}[\/\-][0-9]{4}|[0-9]{4}[\/\-][0-9]{2}[\/\-][0-9]{2})') {
                    $val = $matches[1]
                    $dt=$null
                    if (Try-Parse-HeaderDate $val ([ref]$dt)) { $eff = $dt.ToString('yyyy-MM-dd') } else { $eff = $val }
                }
            }

            # Cellfallback (för mallar utan högerheader)
            if (-not $doc) { $c=_tryFromCells $ws $rxDoc 30 20 'Doc'; $docLbl=$docLbl -or $c.Has; if($c.Val){$doc=$c.Val} }
            if (-not $rev) { $c=_tryFromCells $ws $rxRev 30 20 'REV'; $revLbl=$revLbl -or $c.Has; if($c.Val){$rev=$c.Val} }
            if (-not $eff) { $c=_tryFromCells $ws $rxEff 30 20 'EFF'; $effLbl=$effLbl -or $c.Has; if($c.Val){$eff=$c.Val} }

            [void]$rows.Add([pscustomobject]@{
                Sheet            = $ws.Name
                DocumentNumber   = $doc
                Rev              = $rev
                Effective        = $eff
                HasDocumentLabel = [bool]$docLbl
                HasRevLabel      = [bool]$revLbl
                HasEffectiveLabel= [bool]$effLbl
            })
        }
        return @($rows.ToArray())
    }
}

if (-not (Get-Command Compare-SealTestHeaderSet -ErrorAction SilentlyContinue)) {
    function Compare-SealTestHeaderSet {
        param([Parameter(Mandatory)][object[]]$Rows)

        $devIssues  = 0
        $detailsLst = New-Object System.Collections.Generic.List[string]

        function _canonSealHeader([string]$raw, [string]$type) {
            if ([string]::IsNullOrWhiteSpace($raw)) { return $null }
            $txt = Normalize-HeaderText $raw
            switch ($type) {
                'Doc' { $m=[regex]::Match($txt,'(?i)\b(D\d+)\b'); return $(if($m.Success){$m.Groups[1].Value.ToUpper()}else{$txt.ToUpper()}) }
                'REV' { return $txt.ToUpper() }
                'EFF' {
                    $dt = $null
                    if (Try-Parse-HeaderDate $txt ([ref]$dt)) { return $dt.ToString('yyyy-MM-dd') }
                    return $txt
                }
                default { return $txt }
            }
        }

        $keys = @(
            @{K='DocumentNumber'; T='Doc' },
            @{K='Rev';            T='REV' },
            @{K='Effective';      T='EFF' }
        )

        foreach ($entry in $keys) {
            $k=$entry.K; $t=$entry.T
            $vals = foreach($r in $Rows){
                [pscustomobject]@{
                    Sheet = $r.Sheet
                    Canon = _canonSealHeader ($r.$k) $t
                }
            }
            $nonEmpty = @($vals | Where-Object { $_.Canon })
            $useSet   = if(@($nonEmpty).Count -gt 0){$nonEmpty}else{$vals}
            $byVal    = @($useSet | Group-Object Canon | Sort-Object Count -Descending)
            $major    = if(@($byVal).Count -gt 0){ $byVal[0].Name } else { $null }
            $deviants = @()
            if($major){
                $deviants = @($vals | Where-Object { $_.Canon -and ($_.Canon -ne $major) } | Select-Object -ExpandProperty Sheet -Unique)
            }
            if(@($deviants).Count -gt 0){
                $devIssues++
                $majShow = if($major){"'$major'"}else{'(empty)'}
                $detailsLst.Add(("- {0} majoritet={1} | avvikande flikar: {2}" -f $k,$majShow,($deviants -join ', ')))
            }
        }

        $summary = if($devIssues -eq 0){ '✓ Alla flikar matchar' } else { ('⚠ {0} fält avviker mellan flikar' -f $devIssues) }

        return [pscustomobject]@{
            Deviations = $devIssues
            Summary    = $summary
            Details    = ($detailsLst -join "`r`n")
        }
    }
}

if (-not (Get-Command Extract-SealTestHeader -ErrorAction SilentlyContinue)) {
    function Extract-SealTestHeader {
        param([object]$Pkg)

        $result = [pscustomobject]@{
            DocumentNumber = $null
            Rev            = $null
            Effective      = $null
            PartNumber     = $null
            BatchNumber    = $null
            CartridgeNo    = $null
            HeaderCheck    = $null
            PerSheet       = @()
        }

        if (-not $Pkg) { return $result }

        $rows = @()
        try { $rows = Get-SealTestHeaderPerSheet -Pkg $Pkg } catch { $rows = @() }
        if ($rows) {
            $result.PerSheet = $rows
            try { $result.HeaderCheck = Compare-SealTestHeaderSet -Rows $rows } catch { $result.HeaderCheck = $null }

            function _pickMajor([object[]]$rws, [string]$prop) {
                $vals = @($rws | ForEach-Object { $_.$prop } | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
                if (-not $vals -or $vals.Count -eq 0) { return $null }
                $g = $vals | Group-Object | Sort-Object Count -Descending
                return $g[0].Name
            }

            $result.DocumentNumber = _pickMajor $rows 'DocumentNumber'
            $result.Rev            = _pickMajor $rows 'Rev'
            $result.Effective      = _pickMajor $rows 'Effective'
            return $result
        }

        # Reservväg: äldre logik (om per blad misslyckas helt)
        foreach ($ws in $Pkg.Workbook.Worksheets) {
            if ($ws.Name -eq 'Worksheet Instructions') { continue }
            $right = (($ws.HeaderFooter.OddHeader.RightAlignedText + '') -replace '\r?\n',' ').Trim()
            if (-not $right) { $right = (($ws.HeaderFooter.EvenHeader.RightAlignedText + '') -replace '\r?\n',' ').Trim() }
            if (-not $result.DocumentNumber -and $right -match '(?i)\bDocument\s*(?:No|Number|#)\s*[:#]?\s*(D\d+)\b') { $result.DocumentNumber = $matches[1] }
            if (-not $result.Rev            -and $right -match '(?i)\bRev(?:ision)?\.?\s*[:#]?\s*([A-Z]{1,3}(?:\.\d+)?)\b') { $result.Rev = $matches[1] }
            if (-not $result.Effective      -and $right -match '(?i)\bEffective\s*[:#]?\s*([0-9]{1,2}[\/\-][0-9]{1,2}[\/\-][0-9]{4}|[0-9]{4}[\/\-][0-9]{2}[\/\-][0-9]{2})') { $result.Effective = $matches[1] }
            if ($result.DocumentNumber -and $result.Rev -and $result.Effective) { break }
        }
        return $result
    }
}

function Normalize-Id {
    param([string]$Value, [ValidateSet('Batch','Part','Cartridge')] [string]$Type)
    if ([string]::IsNullOrWhiteSpace($Value)) { return $null }
    $v = $Value.Trim()
    switch ($Type) {
        'Batch'     { return ($v -replace '[^\d]', '') }                      
        'Part'      { return (($v -replace '[^0-9A-Za-z\-]', '')).ToUpper() } 
        'Cartridge' { return ($v -replace '[^\d]', '') }                      
        default     { return $v }
    }
}

function Normalize-HeaderText {
    param([string]$s)

    if ([string]::IsNullOrWhiteSpace($s)) { return '' }
    $s = $s -replace '(?i)_x000D_', ' '
    $s = $s -replace '(?i)_x000A_', ' '
    $s = $s -replace "[\uFEFF\u200B\u2060]", ""
    $s = $s -replace "[\u00A0\u2007\u202F]", " "
    $s = $s -replace "[\u2013\u2014\u2212]", "-"
    $s = $s -replace '&P', ''
    $s = $s -replace '&N', ''
    $s = $s -replace '&L', ' '
    $s = $s -replace '&C', ' '
    $s = $s -replace '&R', ' '
    $s = ($s -replace "\s+", " ").Trim()
    return $s
}

function Parse-WorksheetHeaderRaw {
    param(
        [string]$Raw
    )
    $obj = [pscustomobject]@{
        PartNo         = $null
        BatchNo        = $null
        CartridgeNo    = $null
        DocumentNumber = $null
        Attachment     = $null
        Rev            = $null
        Effective      = $null
    }
    if (-not $Raw) { return $obj }

    $txt = $Raw + ''
    $txt = $txt -replace '&P', ''
    $txt = $txt -replace '&N', ''
    $txt = $txt -replace '&L', ' '
    $txt = Normalize-HeaderText $txt
    $m = [regex]::Match(
        $txt,
        '(?i)\bDocument\s*Number\b\s*[:#]?\s*(D\d{5})(?:\s+Attachment[:\s]+([0-9A-Za-z\.]+))?'
    )
    if ($m.Success) {
        $obj.DocumentNumber = $m.Groups[1].Value.Trim()
        if ($m.Groups.Count -ge 3 -and $m.Groups[2].Value) {
            $obj.Attachment = $m.Groups[2].Value.Trim()
        }
    }
    if (-not $obj.Attachment) {
        $m = [regex]::Match($txt, '(?i)\bAttachment\b\s*:?\s*([0-9A-Za-z\.]+)')
        if ($m.Success) {
            $obj.Attachment = $m.Groups[1].Value.Trim()
        }
    }
		
    $m = [regex]::Match(
    $txt,
    '(?i)\bRev(?:ision)?\.?\s*[:#]?\s*([A-Z0-9]{1,3}(?:\.[0-9]+)?)\b')
    if ($m.Success) {
    $obj.Rev = $m.Groups[1].Value.Trim()
    }
			
    $m = [regex]::Match($txt, '(\d{1,2}/\d{1,2}/\d{4})')
    if ($m.Success) {
        $obj.Effective = $m.Groups[1].Value.Trim()
    }

    $m = [regex]::Match($txt, '(?i)Part\s*No\.\s*:\s*([0-9A-Z\-]+)')
    if ($m.Success) {
        $obj.PartNo = $m.Groups[1].Value.Trim()
    }
    $m = [regex]::Match($txt, '(?i)Batch\s*(?:No(?:\(s\))?|Number(?:\(s\))?)\.?\s*:\s*(\d{6,12})')
    if ($m.Success) {
        $obj.BatchNo = $m.Groups[1].Value.Trim()
    }
    $m = [regex]::Match($txt, '(?i)Cartridge\s*No\.\s*\(LSP\)\s*:\s*(\d{5,7})')
    if ($m.Success) {
        $obj.CartridgeNo = $m.Groups[1].Value.Trim()
    }
    return $obj
}

function Try-Parse-HeaderDate {
    param([object]$cellValue, [ref]$out)
    $out.Value = $null
    if ($null -eq $cellValue) { return $false }
    if ($cellValue -is [double] -or $cellValue -is [int]) {
        try { $out.Value = [DateTime]::FromOADate([double]$cellValue); return $true } catch {}
    }
    if ($cellValue -is [DateTime]) { $out.Value = [DateTime]$cellValue; return $true }
    $s = Normalize-HeaderText ([string]$cellValue)
    if ([string]::IsNullOrWhiteSpace($s)) { return $false }
    $cultures = @('sv-SE','en-US','en-GB')
    foreach ($c in $cultures) {
        try {
            $dt = [DateTime]::Parse($s, [Globalization.CultureInfo]::GetCultureInfo($c), [Globalization.DateTimeStyles]::AssumeLocal)
            $out.Value = $dt; return $true
        } catch {}
    }
    $formats = @(
        'yyyy-MM-dd','yyyy/MM/dd','dd/MM/yyyy','d/M/yyyy','MM/dd/yyyy','M/d/yyyy',
        'dd-MM-yyyy','d-M-yyyy','dd.M.yyyy','d.M.yyyy','dd-MMM-yyyy','MMM-yy'
    )
    foreach ($fmt in $formats) {
        try {
            $dt = [DateTime]::ParseExact($s, $fmt, [Globalization.CultureInfo]::InvariantCulture, [Globalization.DateTimeStyles]::AssumeLocal)
            $out.Value = $dt; return $true
        } catch {}
    }
    return $false
}

function Get-ConsensusValue {
    param(
        [string]$Ws,  [string]$Pos, [string]$Neg,
        [ValidateSet('Batch','Part','Cartridge')] [string]$Type
    )

    $nWs  = Normalize-Id $Ws  $Type
    $nPos = Normalize-Id $Pos $Type
    $nNeg = Normalize-Id $Neg $Type
    $present = @{}
    if ($nWs)  { $present['WS']  = $nWs  }
    if ($nPos) { $present['POS'] = $nPos }
    if ($nNeg) { $present['NEG'] = $nNeg }
    $chosenNorm = $null
    $sources    = New-Object System.Collections.Generic.List[string]
    $counts = @{}
    foreach ($k in $present.Keys) {
        $val = $present[$k]
        if (-not $counts.ContainsKey($val)) { $counts[$val] = 0 }
        $counts[$val]++
    }
    $maxCount = 0; $maxVal = $null
    foreach ($kv in $counts.GetEnumerator()) {
        if ($kv.Value -gt $maxCount) { $maxCount = $kv.Value; $maxVal = $kv.Key }
    }
    if ($maxCount -ge 2) {
        $chosenNorm = $maxVal
        foreach ($k in $present.Keys) { if ($present[$k] -eq $chosenNorm) { [void]$sources.Add([string]$k) } }
    }
    if (-not $chosenNorm -and $nWs) {
        $posMatch = ($nPos -and $nPos -eq $nWs)
        $negMatch = ($nNeg -and $nNeg -eq $nWs)
        if (($posMatch -and -not $negMatch) -or ($negMatch -and -not $posMatch)) {
            $chosenNorm = $nWs
            $sources = New-Object System.Collections.Generic.List[string]
            [void]$sources.Add('WS')
            if ($posMatch) { [void]$sources.Add('POS') }
            if ($negMatch) { [void]$sources.Add('NEG') }
        }
    }
    if (-not $chosenNorm -and $nPos -and $nNeg -and $nPos -eq $nNeg) {
        $chosenNorm = $nPos
        $sources = New-Object System.Collections.Generic.List[string]
        [void]$sources.Add('POS')
        [void]$sources.Add('NEG')
    }
    if (-not $chosenNorm) {
        if ($nWs)      { $chosenNorm = $nWs;  $sources = New-Object System.Collections.Generic.List[string]; [void]$sources.Add('WS')  }
        elseif ($nPos) { $chosenNorm = $nPos; $sources = New-Object System.Collections.Generic.List[string]; [void]$sources.Add('POS') }
        elseif ($nNeg) { $chosenNorm = $nNeg; $sources = New-Object System.Collections.Generic.List[string]; [void]$sources.Add('NEG') }
    }
    $orig = @{ WS=$Ws; POS=$Pos; NEG=$Neg }
    $pretty = $null
    foreach ($pref in @('WS','POS','NEG')) {
        if ($present.ContainsKey($pref) -and $present[$pref] -eq $chosenNorm) { $pretty = $orig[$pref]; break }
    }
    $note = $null
    if ($sources -and $sources.Count -gt 0) {
        $note = "Consensus: " + (@($sources) -join '+')
        $others = New-Object System.Collections.Generic.List[string]
        foreach ($k in @('WS','POS','NEG')) {
            if ($present.ContainsKey($k) -and (@($sources) -notcontains $k)) {
                $val = $orig[$k]
                if (-not [string]::IsNullOrEmpty($val)) { [void]$others.Add(($k + '=' + $val)) }
            }
        }
        if ($others.Count -gt 0) { $note += " | Others: " + (@($others) -join ', ') }
    }
    return @{ Value=$pretty; Source=(@($sources) -join '+'); Note=$note }
}


function Import-CsvRowsStreaming {
    param(
        [Parameter(Mandatory)][string]$Path,
        [int]$StartRow = 10,
        [Parameter(Mandatory)][scriptblock]$ProcessRow
    )
    $delim = Get-CsvDelimiter -Path $Path
    $sr = $null
    try {
        $sr = [System.IO.StreamReader]::new($Path, [System.Text.Encoding]::UTF8, $true)
        $r = 0
        while (($line = $sr.ReadLine()) -ne $null) {
            $r++
            if ($r -lt $StartRow) { continue }
            if (-not $line -or $line.Trim().Length -eq 0) { continue }
            $fields = ConvertTo-CsvFields -Line $line -Delimiter $delim
            if ($fields -and (($fields -join '').Trim().Length -gt 0)) {
                & $ProcessRow -Fields $fields -RowIndex $r
            }
        }
    } finally {
        try { if ($sr) { $sr.Close() } } catch {}
        try { if ($sr) { $sr.Dispose() } } catch {}
    }
}

function Test-IsNetworkPath {
    param([Parameter(Mandatory)][string]$Path)

    if ([string]::IsNullOrWhiteSpace($Path)) { return $false }
    if ($Path -like '\\\\*') { return $true }

    try {
        $root = [System.IO.Path]::GetPathRoot($Path)
        if (-not $root) { return $false }
        $driveName = $root.TrimEnd('\')
        $di = New-Object System.IO.DriveInfo($driveName)
        return ($di.DriveType -eq [System.IO.DriveType]::Network)
    } catch {
        return $false
    }
}

# Kopiera indatafil till temporär mapp (snapshot) oavsett om den ligger lokalt eller på nätverk.
# Används för att undvika att rapportbygget fastnar om någon har originalfilen öppen.
function Stage-InputFileSnapshot {
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter(Mandatory)][string]$StageDir,
        [Parameter()][string]$Prefix = ''
    )

    if ([string]::IsNullOrWhiteSpace($Path)) { return $Path }
    if (-not (Test-Path -LiteralPath $Path)) { return $Path }

    # Respektera filer som uttryckligen ska köras från nätverk (t.ex. makron) för att undvika sid-effekter.
    try {
        if (Get-Command Get-ConfigValue -ErrorAction SilentlyContinue) {
            $networkOnly = @(Get-ConfigValue -Name 'NetworkOnlyFileNames' -Default @())
            $leaf = Split-Path $Path -Leaf
            foreach ($n in $networkOnly) {
                if ($n -and ($leaf -ieq ($n + ''))) { return $Path }
            }
        }
    } catch {}

    try {
        if (-not (Test-Path -LiteralPath $StageDir)) {
            New-Item -ItemType Directory -Path $StageDir -Force | Out-Null
        }

        $leaf = Split-Path $Path -Leaf
        $dstLeaf = if ($Prefix) { ($Prefix + '__' + $leaf) } else { $leaf }
        $dst  = Join-Path $StageDir $dstLeaf

        $srcInfo = Get-Item -LiteralPath $Path -ErrorAction Stop
        if (Test-Path -LiteralPath $dst) {
            try {
                $dstInfo = Get-Item -LiteralPath $dst -ErrorAction Stop
                if ($dstInfo.Length -eq $srcInfo.Length -and $dstInfo.LastWriteTimeUtc -eq $srcInfo.LastWriteTimeUtc) {
                    return $dst
                }
            } catch {}
        }

        Gui-Log ("📥 Snapshot → TEMP: {0}" -f $dstLeaf) 'Info' 'PROGRESS'
        Copy-Item -LiteralPath $Path -Destination $dst -Force -ErrorAction Stop
        try { (Get-Item -LiteralPath $dst).LastWriteTimeUtc = $srcInfo.LastWriteTimeUtc } catch {}
        return $dst
    } catch {
        Gui-Log ("⚠️ Arbetskopia misslyckades, använder originalfil: {0}" -f (Split-Path $Path -Leaf)) 'Warn'
        return $Path
    }
}

# -------------------- EPPlus AutoFit (prestandasäker) --------------------
function Safe-AutoFitColumns {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][object]$Ws,
        [Parameter(Mandatory=$false)][object]$Range,
        [Parameter(Mandatory=$false)][ValidateSet('OFF','ON','SMART')][string]$Mode,
        [Parameter(Mandatory=$false)][int]$MaxRows,
        [Parameter(Mandatory=$false)][string]$Context
    )
    if (-not $Mode) {
        try {
            if ($global:Config -and ($global:Config -is [hashtable]) -and $global:Config.ContainsKey('EpplusAutoFitMode')) {
                $Mode = (($global:Config['EpplusAutoFitMode'] + '')).Trim().ToUpperInvariant()
            }
        } catch {}
    }
    if (-not $Mode) { $Mode = 'SMART' }

    if ($MaxRows -le 0) {
        try {
            if ($global:Config -and ($global:Config -is [hashtable]) -and $global:Config.ContainsKey('EpplusAutoFitMaxRows')) {
                $MaxRows = [int]$global:Config['EpplusAutoFitMaxRows']
            }
        } catch {}
    }
    if ($MaxRows -le 0) { $MaxRows = 500 }

    switch ($Mode) {
        'OFF' { return }
        default { }
    }

    $rng = $Range
    if (-not $rng) {
        try { if ($Ws.Dimension) { $rng = $Ws.Cells[$Ws.Dimension.Address] } } catch { $rng = $null }
    }
    if (-not $rng) { return }

    if ($Mode -eq 'SMART') {
        $rows = 0
        try {
            $rows = [int]($rng.End.Row - $rng.Start.Row + 1)
        } catch { $rows = 0 }

        if ($rows -gt 0 -and $rows -gt $MaxRows) {
            try {
                if ($Context) {
                    Gui-Log ("⏩ AutoFit hoppad över ({0} rader > {1}) [{2}]" -f $rows, $MaxRows, $Context) 'Info'
                }
            } catch {}
            return
        }
    }

    try { $rng.AutoFitColumns() | Out-Null } catch {}
}

# ============================================================================
# CENTRALISERADE HJÄLPFUNKTIONER (läser från $global:IPTConstants)
# ============================================================================

function Get-OutSheetName {
    <# Returnerar fliknamn från centrala konstanter. Reservvärde är $Default. #>
    param([Parameter(Mandatory)][string]$Key, [string]$Default = '')
    try {
        if ($global:IPTConstants -and $global:IPTConstants.OutSheetNames.ContainsKey($Key)) {
            return $global:IPTConstants.OutSheetNames[$Key]
        }
    } catch {}
    return $Default
}

function Get-Threshold {
    <# Returnerar tröskelvärde från centrala konstanter. Reservvärde är $Default. #>
    param([Parameter(Mandatory)][string]$Key, $Default = $null)
    try {
        if ($global:IPTConstants -and $global:IPTConstants.Thresholds.ContainsKey($Key)) {
            return $global:IPTConstants.Thresholds[$Key]
        }
    } catch {}
    return $Default
}

function Is-FeatureEnabled {
    <# Kollar funktionsflagga: $Config först, annars IPTConstants, annars $Default. #>
    param([Parameter(Mandatory)][string]$Name, [bool]$Default = $false, [object]$ConfigOverride = $null)
    # Prioritet 1: Config (körning)
    try {
        $val = Get-ConfigFlag -Name $Name -Default $null -ConfigOverride $ConfigOverride
        if ($val -ne $null) { return [bool]$val }
    } catch {}
    # Prioritet 2: IPTConstants (standard vid uppstart)
    try {
        if ($global:IPTConstants -and $global:IPTConstants.FeatureFlags.ContainsKey($Name)) {
            return [bool]$global:IPTConstants.FeatureFlags[$Name]
        }
    } catch {}
    return $Default
}

function Is-VlAssay {
    <# Returnerar $true om assaynamn matchar en VL-analys (skiftlägesokänsligt, delsträng). #>
    param([Parameter(Mandatory)][string]$AssayName)
    $list = @()
    try {
        if ($global:IPTConstants -and $global:IPTConstants.VlAssays) {
            $list = @($global:IPTConstants.VlAssays)
        }
    } catch {}
    if ($list.Count -eq 0) { return $false }
    foreach ($vl in $list) {
        if ($AssayName -imatch [regex]::Escape($vl)) { return $true }
    }
    return $false
}

function Get-SafeCellText {
    <# Läser celltext: .Text först, .Value som reserv. Aldrig .Formula. Returnerar trimmat.
       Stödjer båda anropsformer:
         Get-SafeCellText -Ws $ws -Row 3 -Col 8
         Get-SafeCellText -Ws $ws -Addr 'H3'
    #>
    param(
        [Parameter(Mandatory)][object]$Ws,
        [Parameter(Mandatory=$false)][int]$Row,
        [Parameter(Mandatory=$false)][int]$Col,
        [Parameter(Mandatory=$false)][string]$Addr
    )
    try {
        $cell = $null
        if ($Addr) {
            $cell = $Ws.Cells[$Addr]
        } else {
            $cell = $Ws.Cells[$Row, $Col]
        }
        $txt = ($cell.Text + '').Trim()
        if ($txt) { return $txt }
        return ($cell.Value + '').Trim()
    } catch { return '' }
}

function Get-CellText {
    <#
    .SYNOPSIS  Säker cellläsning med A1-notation. Returnerar alltid trimmat string, aldrig $null.
    .EXAMPLE   Get-CellText $ws 'B3'            → celltext
    .EXAMPLE   Get-CellText $ws 'H3' -Raw       → cell.Value (utan Text-konvertering)
    #>
    param(
        [Parameter(Mandatory)][object]$Ws,
        [Parameter(Mandatory)][string]$Address,
        [switch]$Raw
    )
    try {
        $cell = $Ws.Cells[$Address]
        if (-not $cell) { return '' }
        if ($Raw) { return ($cell.Value + '').Trim() }
        $txt = ($cell.Text + '').Trim()
        if ($txt) { return $txt }
        return ($cell.Value + '').Trim()
    } catch { return '' }
}
