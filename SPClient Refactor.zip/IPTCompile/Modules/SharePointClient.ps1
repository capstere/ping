###############################################################################
# SharePointClient.ps1  –  Dedikerad entrådig runspace för alla PnP-anrop
#
# PROBLEM: PnP.PowerShell lagrar anslutningsstate per runspace.
#          Om Connect-PnPOnline körs i en BackgroundWorker / annan tråd
#          ser inte UI-trådens Get-PnP* den anslutningen.
#
# LÖSNING: Alla PnP-anrop (import, connect, get-list etc.) körs i EN
#          och samma PowerShell-runspace via Invoke-SPClient.
#          UI-tråden anropar Invoke-SPClient synkront (blockerar)
#          eller Connect-SPClientAsync + en WinForms Timer som pollar.
#
# FUNKTIONER (publika):
#   Start-SPClient          – Skapar runspace, importerar PnP
#   Connect-SPClient        – Kör Connect-PnPOnline i runspace (synkront)
#   Connect-SPClientAsync   – Startar Connect-PnPOnline asynkront
#   Poll-SPClientAsync      – Kollar om async-anropet är klart
#   Invoke-SPClient         – Kör godtycklig ScriptBlock i runspace
#   Get-SPClientStatus      – Returnerar connected/error/connecting-flaggor
#   Stop-SPClient           – Stänger och städar runspace
###############################################################################

# ── State ──────────────────────────────────────────────────────────────────
$script:SpRunspace   = $null   # [System.Management.Automation.Runspaces.Runspace]
$script:SpPowerShell = $null   # [System.Management.Automation.PowerShell]  (reusable)
$script:SpAsyncHandle = $null  # IAsyncResult från BeginInvoke
$script:SpAsyncPS     = $null  # PowerShell-objekt för pågående async

$global:SpConnected  = $false
$global:SpError      = $null
$global:SpConnecting = $false

# ── Start-SPClient ─────────────────────────────────────────────────────────
function Start-SPClient {
    <#
    .SYNOPSIS  Skapar en dedikerad STA-runspace och importerar PnP.PowerShell i den.
    .PARAMETER ProgressCallback  Valfri scriptblock { param($msg) ... } för att visa status.
    .OUTPUTS   $true om lyckad, $false vid fel. Felet finns i $global:SpError.
    #>
    param(
        [scriptblock]$ProgressCallback = $null
    )

    if ($script:SpRunspace -and $script:SpRunspace.RunspaceStateInfo.State -eq 'Opened') {
        return $true
    }

    try {
        # Skapa runspace med STA apartment (krävs av PnP i vissa scenarier)
        $script:SpRunspace = [System.Management.Automation.Runspaces.RunspaceFactory]::CreateRunspace()
        $script:SpRunspace.ApartmentState = [System.Threading.ApartmentState]::STA
        $script:SpRunspace.ThreadOptions  = [System.Management.Automation.Runspaces.PSThreadOptions]::ReuseThread
        $script:SpRunspace.Open()

        # Stäng av update-check inuti runspace
        $null = _Invoke-InRunspace -Script {
            $env:PNPPOWERSHELL_UPDATECHECK = 'Off'
            $ProgressPreference = 'SilentlyContinue'
        }

        # NuGet bootstrap
        if ($ProgressCallback) { & $ProgressCallback 'Förbereder NuGet…' }
        $null = _Invoke-InRunspace -Script {
            try { $null = Get-PackageProvider -Name 'NuGet' -ForceBootstrap -ErrorAction SilentlyContinue } catch {}
        }

        # Import PnP.PowerShell (eller installera först)
        if ($ProgressCallback) { & $ProgressCallback 'Laddar PnP-modul…' }
        $importResult = _Invoke-InRunspace -Script {
            try {
                Import-Module PnP.PowerShell -ErrorAction Stop
                return @{ Ok = $true }
            } catch {
                try {
                    Install-Module PnP.PowerShell -MaximumVersion 1.12.0 -Scope CurrentUser -Force -AllowClobber -ErrorAction Stop
                    Import-Module PnP.PowerShell -ErrorAction Stop
                    return @{ Ok = $true }
                } catch {
                    return @{ Ok = $false; Err = $_.Exception.ToString() }
                }
            }
        }

        if (-not $importResult -or -not $importResult.Ok) {
            $global:SpError = if ($importResult -and $importResult.Err) { $importResult.Err } else { 'PnP-import misslyckades (okänt)' }
            return $false
        }

        return $true

    } catch {
        $global:SpError = "Start-SPClient: $($_.Exception.ToString())"
        return $false
    }
}


# ── Connect-SPClient (synkron) ─────────────────────────────────────────────
function Connect-SPClient {
    <#
    .SYNOPSIS  Kör Connect-PnPOnline inuti den dedikerade runspacen.
    .OUTPUTS   $true vid lyckad anslutning, $false vid fel.
    #>
    param(
        [scriptblock]$ProgressCallback = $null
    )

    if (-not $script:SpRunspace -or $script:SpRunspace.RunspaceStateInfo.State -ne 'Opened') {
        $global:SpError = 'SPClient-runspace ej startad. Kör Start-SPClient först.'
        return $false
    }

    if ($ProgressCallback) { & $ProgressCallback 'Loggar in…' }

    $url    = $global:SP_SiteUrl
    $tenant = $global:SP_Tenant
    $cid    = $global:SP_ClientId
    $cert   = $global:SP_CertBase64

    $result = _Invoke-InRunspace -Script {
        param($u,$t,$c,$b)
        try {
            Connect-PnPOnline -Url $u -Tenant $t -ClientId $c -CertificateBase64Encoded $b -ErrorAction Stop
            return @{ Ok = $true }
        } catch {
            return @{ Ok = $false; Err = $_.Exception.ToString() }
        }
    } -Arguments @($url, $tenant, $cid, $cert)

    if ($result -and $result.Ok) {
        $global:SpConnected = $true
        $global:SpError     = $null
        return $true
    } else {
        $global:SpConnected = $false
        $global:SpError     = if ($result -and $result.Err) { $result.Err } else { 'Connect-PnPOnline misslyckades (okänt)' }
        return $false
    }
}


# ── Connect-SPClientAsync ──────────────────────────────────────────────────
function Connect-SPClientAsync {
    <#
    .SYNOPSIS  Startar Connect-PnPOnline asynkront. Anropa Poll-SPClientAsync
               från en WinForms Timer för att kolla resultat.
    .OUTPUTS   $true om async startades, $false om det redan körs / ej initierat.
    #>

    if ($global:SpConnecting) { return $false }
    if (-not $script:SpRunspace -or $script:SpRunspace.RunspaceStateInfo.State -ne 'Opened') {
        $global:SpError = 'SPClient-runspace ej startad.'
        return $false
    }

    $global:SpConnecting = $true

    $url    = $global:SP_SiteUrl
    $tenant = $global:SP_Tenant
    $cid    = $global:SP_ClientId
    $cert   = $global:SP_CertBase64

    $ps = [System.Management.Automation.PowerShell]::Create()
    $ps.Runspace = $script:SpRunspace

    $null = $ps.AddScript({
        param($u,$t,$c,$b)
        try {
            Connect-PnPOnline -Url $u -Tenant $t -ClientId $c -CertificateBase64Encoded $b -ErrorAction Stop
            return @{ Ok = $true }
        } catch {
            return @{ Ok = $false; Err = $_.Exception.ToString() }
        }
    }).AddArgument($url).AddArgument($tenant).AddArgument($cid).AddArgument($cert)

    $script:SpAsyncPS     = $ps
    $script:SpAsyncHandle = $ps.BeginInvoke()
    return $true
}


# ── Poll-SPClientAsync ─────────────────────────────────────────────────────
function Poll-SPClientAsync {
    <#
    .SYNOPSIS  Kolla om pågående async-anslutning är klar.
    .OUTPUTS   $null om fortfarande igång, annars @{ Ok=$bool; Err=$string }.
    #>

    if (-not $script:SpAsyncHandle -or -not $script:SpAsyncPS) {
        return $null
    }

    if (-not $script:SpAsyncHandle.IsCompleted) {
        return $null
    }

    # Hämta resultat
    $result = $null
    try {
        $output = $script:SpAsyncPS.EndInvoke($script:SpAsyncHandle)
        if ($output -and $output.Count -gt 0) {
            $result = $output[$output.Count - 1]
        }
    } catch {
        $result = @{ Ok = $false; Err = $_.Exception.ToString() }
    }

    # Städa
    try { $script:SpAsyncPS.Dispose() } catch {}
    $script:SpAsyncPS     = $null
    $script:SpAsyncHandle = $null

    # Uppdatera global state
    if ($result -and $result.Ok) {
        $global:SpConnected  = $true
        $global:SpError      = $null
    } else {
        $global:SpConnected  = $false
        $global:SpError      = if ($result -and $result.Err) { $result.Err } else { 'Okänt fel' }
    }
    $global:SpConnecting = $false

    return $result
}


# ── Invoke-SPClient ────────────────────────────────────────────────────────
function Invoke-SPClient {
    <#
    .SYNOPSIS  Kör en godtycklig ScriptBlock i den dedikerade PnP-runspacen.
    .PARAMETER Script     ScriptBlock att köra.
    .PARAMETER Arguments  Argument till scriptet (param()-ordning).
    .OUTPUTS   Vad scriptet returnerar, eller $null vid fel.
    #>
    param(
        [Parameter(Mandatory=$true)]
        [scriptblock]$Script,
        [object[]]$Arguments
    )

    if (-not $script:SpRunspace -or $script:SpRunspace.RunspaceStateInfo.State -ne 'Opened') {
        throw 'SPClient-runspace ej startad.'
    }

    return (_Invoke-InRunspace -Script $Script -Arguments $Arguments)
}


# ── Get-SPClientStatus ─────────────────────────────────────────────────────
function Get-SPClientStatus {
    return [pscustomobject]@{
        Connected  = [bool]$global:SpConnected
        Connecting = [bool]$global:SpConnecting
        Error      = $global:SpError
        RunspaceOk = ($null -ne $script:SpRunspace -and $script:SpRunspace.RunspaceStateInfo.State -eq 'Opened')
    }
}


# ── Stop-SPClient ──────────────────────────────────────────────────────────
function Stop-SPClient {
    try {
        if ($script:SpAsyncPS) {
            try { $script:SpAsyncPS.Stop() } catch {}
            try { $script:SpAsyncPS.Dispose() } catch {}
            $script:SpAsyncPS     = $null
            $script:SpAsyncHandle = $null
        }
        if ($script:SpRunspace) {
            try { $script:SpRunspace.Close() } catch {}
            try { $script:SpRunspace.Dispose() } catch {}
            $script:SpRunspace = $null
        }
    } catch {}
    $global:SpConnecting = $false
}


# ── Intern hjälpfunktion ───────────────────────────────────────────────────
function _Invoke-InRunspace {
    param(
        [Parameter(Mandatory=$true)]
        [scriptblock]$Script,
        [object[]]$Arguments
    )

    $ps = [System.Management.Automation.PowerShell]::Create()
    $ps.Runspace = $script:SpRunspace

    $null = $ps.AddScript($Script)
    if ($Arguments) {
        foreach ($a in $Arguments) {
            $null = $ps.AddArgument($a)
        }
    }

    try {
        $output = $ps.Invoke()
        if ($ps.Streams.Error.Count -gt 0) {
            $errText = ($ps.Streams.Error | ForEach-Object { $_.ToString() }) -join '; '
            # Logga men returnera ändå output (PnP kan skriva non-terminating errors)
            try { Write-Host "[SPClient WARN] Non-terminating error: $errText" } catch {}
        }
        if ($output -and $output.Count -gt 0) {
            return $output[$output.Count - 1]
        }
        return $null
    } finally {
        $ps.Dispose()
    }
}
