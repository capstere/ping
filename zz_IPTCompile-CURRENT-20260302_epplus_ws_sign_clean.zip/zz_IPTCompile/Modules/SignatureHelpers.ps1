# Write-WorksheetSignatures (EPPlus) har ersatts av Invoke-WorksheetSignature_OpenXml i OpenXmlHelpers.ps1!!!!!

function Test-UiVar { param([object]$o) return ($null -ne $o) }

# --- Worksheet signering via EPPlus (4.5.3.3) med "merge-städning" ---
# Syfte: undvika OpenXML-problemen och samtidigt undvika att EPPlus triggar Excel-repair genom att bara ändra minimalt,
# samt rensa bort "gömda" tail-värden (t.ex. N/A) i mergeområdet innan skrivning.

function Normalize-CellText_EPPlus {
    param([string]$Text)
    $t = ($Text + '')
    $t = $t -replace [char]0x00A0,' '
    $t = $t.Trim()
    $t = [regex]::Replace($t,'\s+',' ')
    return $t
}

function Convert-ColLetterToIndex_EPPlus {
    param([string]$Col)
    $c = ($Col + '').Trim().ToUpperInvariant()
    if (-not $c) { return 0 }
    $sum = 0
    foreach ($ch in $c.ToCharArray()) {
        if ($ch -lt 'A' -or $ch -gt 'Z') { return 0 }
        $sum = ($sum * 26) + ([int][char]$ch - [int][char]'A' + 1)
    }
    return $sum
}

function Convert-ColIndexToLetter_EPPlus {
    param([int]$Index)
    if ($Index -le 0) { return '' }
    $i = $Index
    $letters = New-Object System.Text.StringBuilder
    while ($i -gt 0) {
        $i--  # 1-based
        $rem = ($i % 26)
        [void]$letters.Insert(0, [char]([int][char]'A' + $rem))
        $i = [int][math]::Floor($i / 26)
    }
    return $letters.ToString()
}

function Find-FirstRowByContains_EPPlus {
    param(
        [Parameter(Mandatory=$true)][OfficeOpenXml.ExcelWorksheet]$Worksheet,
        [Parameter(Mandatory=$true)][string]$ColLetter,
        [Parameter(Mandatory=$true)][string]$Needle
    )
    $needleNorm = (Normalize-CellText_EPPlus $Needle).ToLowerInvariant()
    $colIdx = Convert-ColLetterToIndex_EPPlus -Col $ColLetter
    if ($colIdx -le 0) { return $null }
    if (-not $Worksheet.Dimension) { return $null }

    $endRow = $Worksheet.Dimension.End.Row
    for ($r = 1; $r -le $endRow; $r++) {
        $txt = Normalize-CellText_EPPlus ($Worksheet.Cells[$r, $colIdx].Text + '')
        if (-not $txt) { continue }
        if ($txt.ToLowerInvariant().Contains($needleNorm)) { return $r }
    }
    return $null
}

function Resolve-MergeOwnerAndRange_EPPlus {
    <#
      Returns PSCustomObject:
        OwnerRow, OwnerCol, RangeAddress (null if not merged)
    #>
    param(
        [Parameter(Mandatory=$true)][OfficeOpenXml.ExcelWorksheet]$Worksheet,
        [Parameter(Mandatory=$true)][int]$Row,
        [Parameter(Mandatory=$true)][int]$Col
    )
    $ownerRow = $Row
    $ownerCol = $Col
    $rangeAddr = $null
    try {
        $id = $Worksheet.GetMergeCellId($Row, $Col)
        if ($id -gt 0) {
            $rangeAddr = $Worksheet.MergedCells[$id - 1]
            if ($rangeAddr) {
                $rng = $Worksheet.Cells[$rangeAddr]
                $ownerRow = $rng.Start.Row
                $ownerCol = $rng.Start.Column
            }
        }
    } catch {}
    return [pscustomobject]@{ OwnerRow=$ownerRow; OwnerCol=$ownerCol; RangeAddress=$rangeAddr }
}

function Clear-MergeTailRow_EPPlus {
    <#
      Clears tail cells (same row as owner) inside merged range.
      Leaves owner cell untouched here.
    #>
    param(
        [Parameter(Mandatory=$true)][OfficeOpenXml.ExcelWorksheet]$Worksheet,
        [Parameter(Mandatory=$true)][string]$RangeAddress,
        [Parameter(Mandatory=$true)][int]$OwnerRow,
        [Parameter(Mandatory=$true)][int]$OwnerCol
    )
    if (-not $RangeAddress) { return }
    $rng = $Worksheet.Cells[$RangeAddress]
    $row = $OwnerRow
    # Only horizontal tail on owner row
    if ($row -lt $rng.Start.Row -or $row -gt $rng.End.Row) { return }
    for ($c = $rng.Start.Column; $c -le $rng.End.Column; $c++) {
        if ($c -eq $OwnerCol) { continue }
        try { $Worksheet.Cells[$row, $c].Value = $null } catch {}
    }
}

function Invoke-WorksheetSignature_EPPlusClean {
    <#
      Writes worksheet signatures using EPPlus, with optional overwrite.
      Overwrite behavior:
        - Overwrite:$true => clears merge tails on the target row (removes hidden N/A), then writes owner.
        - Overwrite:$false => will not write if owner cell already contains non-empty text.

      Returns: PSCustomObject with Written/Skipped + WrittenCells (sheet + owner coords).
    #>
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [Parameter(Mandatory=$true)][string]$FullName,
        [Parameter(Mandatory=$true)][string]$SignDateYmd,
        [Parameter(Mandatory=$true)][ValidateSet('Sammanstallning','Granskning')][string]$Mode,
        [switch]$HasResample,
        [bool]$Overwrite = $false
    )

    if (-not (Load-EPPlus)) { throw "EPPlus kunde inte laddas." }

    $res = [pscustomobject]@{
        Mode         = $Mode
        Written      = New-Object System.Collections.Generic.List[string]
        Skipped      = New-Object System.Collections.Generic.List[string]
        WrittenCells = New-Object System.Collections.Generic.List[pscustomobject]
    }

    $pkg = $null
    try {
        $pkg = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($Path))

        $targets = @()
        if ($Mode -eq 'Sammanstallning') {
            $targets = @(
                @{ Name='Test Summary';                 NameLabelCol='B'; NameNeedle='Recorded By:';       NameWriteCol='C'; DateLabelCols=@('I');     DateNeedle='Date:'; DateWriteCol='J'; Offset=0;  DataSummaryGuard=$false },
                @{ Name='Data Summary';                 NameLabelCol='A'; NameNeedle='Recorded By:';       NameWriteCol='B'; DateLabelCols=@('C');     DateNeedle='Date:'; DateWriteCol='D'; Offset=0;  DataSummaryGuard=$true  },
                @{ Name='Extra Data Summary';           NameLabelCol='A'; NameNeedle='Recorded By:';       NameWriteCol='B'; DateLabelCols=@('C');     DateNeedle='Date:'; DateWriteCol='D'; Offset=0;  DataSummaryGuard=$true  },
                @{ Name='Resample Data Summary';        NameLabelCol='A'; NameNeedle='Recorded By:';       NameWriteCol='B'; DateLabelCols=@('C');     DateNeedle='Date:'; DateWriteCol='D'; Offset=0;  DataSummaryGuard=$true; ResampleOnly=$true },
                @{ Name='Resample Date Summary';        NameLabelCol='A'; NameNeedle='Recorded By:';       NameWriteCol='B'; DateLabelCols=@('C');     DateNeedle='Date:'; DateWriteCol='D'; Offset=0;  DataSummaryGuard=$true; ResampleOnly=$true },
                @{ Name='Seal Test Failure Count';      NameLabelCol='K'; NameNeedle='Performed By:';      NameWriteCol='L'; DateLabelCols=@('K');     DateNeedle='Date:'; DateWriteCol='L'; Offset=-1; DataSummaryGuard=$false },
                @{ Name='Statistical Process Control';  NameLabelCol='K'; NameNeedle='Performed By:';      NameWriteCol='L'; DateLabelCols=@('K');     DateNeedle='Date:'; DateWriteCol='L'; Offset=-1; DataSummaryGuard=$false },
                @{ Name='Vacuum Seal Data';             NameLabelCol='B'; NameNeedle='Recorded By:';       NameWriteCol='C'; DateLabelCols=@('D','E'); DateNeedle='Date:'; DateWriteCol='F'; Offset=0;  DataSummaryGuard=$false }
            )
        } else {
            $targets = @(
                @{ Name='Test Summary'; NameLabelCol='B'; NameNeedle='PQC Reviewed By:'; NameWriteCol='C'; DateLabelCols=@('I'); DateNeedle='Date:'; DateWriteCol='J'; Offset=0; DataSummaryGuard=$false }
            )
        }

        foreach ($t in $targets) {
            $sheetName = $t.Name

            if ($t.ContainsKey('ResampleOnly') -and $t.ResampleOnly -and (-not $HasResample)) {
                [void]$res.Skipped.Add("$sheetName (ej resample)")
                continue
            }

            $ws = $pkg.Workbook.Worksheets[$sheetName]
            if (-not $ws) { [void]$res.Skipped.Add($sheetName); continue }

            if ($t.DataSummaryGuard) {
                $cIdx = Convert-ColLetterToIndex_EPPlus -Col 'C'
                $hasData = $false
                if ($ws.Dimension) {
                    for ($r=1; $r -le $ws.Dimension.End.Row; $r++) {
                        $txt = Normalize-CellText_EPPlus ($ws.Cells[$r,$cIdx].Text + '')
                        if (-not $txt) { continue }
                        if ($txt -match '^(?i)(Performed By:|Recorded By:|PQC Reviewed By:|Date:)$') { continue }
                        $hasData = $true; break
                    }
                }
                if (-not $hasData) { [void]$res.Skipped.Add("$sheetName (ingen data)"); continue }
            }

            $nameRow = Find-FirstRowByContains_EPPlus -Worksheet $ws -ColLetter $t.NameLabelCol -Needle $t.NameNeedle
            $dateRow = $null
            foreach ($dc in $t.DateLabelCols) {
                $dateRow = Find-FirstRowByContains_EPPlus -Worksheet $ws -ColLetter $dc -Needle $t.DateNeedle
                if ($dateRow) { break }
            }

            $wroteAny = $false

            if ($nameRow) {
                $wr = $nameRow + $t.Offset
                $wc = Convert-ColLetterToIndex_EPPlus -Col $t.NameWriteCol
                $m = Resolve-MergeOwnerAndRange_EPPlus -Worksheet $ws -Row $wr -Col $wc
                $ownerTxt = Normalize-CellText_EPPlus ($ws.Cells[$m.OwnerRow, $m.OwnerCol].Text + '')
                if ($Overwrite) {
                    if ($m.RangeAddress) { Clear-MergeTailRow_EPPlus -Worksheet $ws -RangeAddress $m.RangeAddress -OwnerRow $m.OwnerRow -OwnerCol $m.OwnerCol }
                    $ws.Cells[$m.OwnerRow, $m.OwnerCol].Value = $FullName
                    $wroteAny = $true
                    [void]$res.WrittenCells.Add([pscustomobject]@{ Sheet=$sheetName; Row=$m.OwnerRow; Col=(Convert-ColIndexToLetter_EPPlus $m.OwnerCol); Value=$FullName })
                } else {
                    if (-not $ownerTxt) {
                        $ws.Cells[$m.OwnerRow, $m.OwnerCol].Value = $FullName
                        $wroteAny = $true
                        [void]$res.WrittenCells.Add([pscustomobject]@{ Sheet=$sheetName; Row=$m.OwnerRow; Col=(Convert-ColIndexToLetter_EPPlus $m.OwnerCol); Value=$FullName })
                    }
                }
            }

            if ($dateRow) {
                $wr = $dateRow + $t.Offset
                $wc = Convert-ColLetterToIndex_EPPlus -Col $t.DateWriteCol
                $m = Resolve-MergeOwnerAndRange_EPPlus -Worksheet $ws -Row $wr -Col $wc
                $ownerTxt = Normalize-CellText_EPPlus ($ws.Cells[$m.OwnerRow, $m.OwnerCol].Text + '')
                if ($Overwrite) {
                    if ($m.RangeAddress) { Clear-MergeTailRow_EPPlus -Worksheet $ws -RangeAddress $m.RangeAddress -OwnerRow $m.OwnerRow -OwnerCol $m.OwnerCol }
                    $ws.Cells[$m.OwnerRow, $m.OwnerCol].Value = $SignDateYmd
                    $wroteAny = $true
                    [void]$res.WrittenCells.Add([pscustomobject]@{ Sheet=$sheetName; Row=$m.OwnerRow; Col=(Convert-ColIndexToLetter_EPPlus $m.OwnerCol); Value=$SignDateYmd })
                } else {
                    if (-not $ownerTxt) {
                        $ws.Cells[$m.OwnerRow, $m.OwnerCol].Value = $SignDateYmd
                        $wroteAny = $true
                        [void]$res.WrittenCells.Add([pscustomobject]@{ Sheet=$sheetName; Row=$m.OwnerRow; Col=(Convert-ColIndexToLetter_EPPlus $m.OwnerCol); Value=$SignDateYmd })
                    }
                }
            }

            if ($wroteAny) { [void]$res.Written.Add($sheetName) }
            else {
                if (-not $nameRow -and -not $dateRow) { [void]$res.Skipped.Add("$sheetName (labels saknas)") }
                else { [void]$res.Skipped.Add("$sheetName (redan ifyllt)") }
            }
        }

        if ($res.Written.Count -gt 0) {
            $pkg.Save()
        }
    } finally {
        if ($pkg) { try { $pkg.Dispose() } catch {} }
    }
    return $res
}
# --- /Worksheet signering via EPPlus ---

function Get-DataSheets { param([OfficeOpenXml.ExcelPackage]$Pkg)
    $all = @($Pkg.Workbook.Worksheets | Where-Object { $_.Name -ne "Worksheet Instructions" })
    if ($all.Count -gt 1) { return $all | Select-Object -Skip 1 } else { return @() }
}

function Test-SignatureFormat {
    param([string]$Text)
    $raw = ($Text + '')
    $trim = $raw.Trim()
    $parts = $trim -split '\s*,\s*'
    $name = if ($parts.Count -ge 1) { $parts[0] } else { '' }
    $sign = if ($parts.Count -ge 2) { $parts[1] } else { '' }
    $date = if ($parts.Count -ge 3) { $parts[2] } else { '' }
    $dateOk = $false
    if ($date) { if ($date -match '^\d{4}-\d{2}-\d{2}$' -or $date -match '^\d{8}$') { $dateOk = $true } }
    [pscustomobject]@{ Raw=$raw; Name=$name; Sign=$sign; Date=$date; Parts=$parts.Count; DateOk=$dateOk; LooksOk=($name -ne '' -and $sign -ne '') }
}

function Confirm-SignatureInput { param([string]$Text)
    $info = Test-SignatureFormat $Text
    $hint = @()
    if (-not $info.Name) { $hint += 'Namn verkar saknas' }
    if (-not $info.Sign) { $hint += 'Signatur verkar saknas' }
    $sep = [string]::new([char]0x2500, 34)
    $status = if ($hint.Count) { "OBS: " + ($hint -join ', ') } else { "Ser bra ut." }
    $msg = "SEAL TEST  —  Bekräfta signatur`n" +
           "$sep`n`n" +
           "  Namn       $($info.Name)`n" +
           "  Signatur   $($info.Sign)`n" +
           "  Datum      $($info.Date)`n`n" +
           "$sep`n" +
           "$status`n`n" +
           "Vill du fortsätta?"
    $res = [System.Windows.Forms.MessageBox]::Show($msg, 'Seal Test-signatur', 'YesNo', 'Question')
    return ($res -eq 'Yes')
}

function Normalize-Signature {
    param([string]$s)
    if (-not $s) { return '' }
    $x = $s.Trim().ToLowerInvariant()
    $x = [regex]::Replace($x, '\s+', ' ')
    $x = $x -replace '\s*,\s*', ','
    return $x
}
 
function Get-SignatureSetForDataSheets {
    param([OfficeOpenXml.ExcelPackage]$Pkg)
    $result = [pscustomobject]@{
        RawFirst  = $null
        NormSet   = New-Object 'System.Collections.Generic.HashSet[string]'
        Occ       = @{}
        RawByNorm = @{} 
    }
    if (-not $Pkg) { return $result }

    foreach ($ws in ($Pkg.Workbook.Worksheets | Where-Object { $_.Name -ne 'Worksheet Instructions' })) {
        $h3 = ($ws.Cells['H3'].Text + '').Trim()
        if ($h3 -match '^[0-9]') {
            $raw = ($ws.Cells['B47'].Text + '').Trim()
            if ($raw) {
                $norm = Normalize-Signature $raw
                [void]$result.NormSet.Add($norm)
                if (-not $result.RawFirst) { $result.RawFirst = $raw }
                if (-not $result.Occ.ContainsKey($norm)) {
                    $result.Occ[$norm] = New-Object 'System.Collections.Generic.List[string]'
                }
                if (-not $result.RawByNorm.ContainsKey($norm)) {
                    $result.RawByNorm[$norm] = $raw
                }
                [void]$result.Occ[$norm].Add($ws.Name)
            }
        } elseif ([string]::IsNullOrWhiteSpace($h3) -or $h3 -match '^(?i)(N\/?A|NA|Tomt( innehåll)?)$') {
            break
        }
    }
    return $result
}

function UrlEncode([string]$s){ try { [System.Uri]::EscapeDataString($s) } catch { $s } }

function Get-BatchNumberFromSealFile([string]$Path){
    if (-not (Test-Path -LiteralPath $Path)) { return $null }
    if (-not (Load-EPPlus)) { return $null }
    $pkg = $null
    try {
        $pkg = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($Path))
        foreach ($ws in (Get-DataSheets $pkg)) {
            $txt = ($ws.Cells['D2'].Text + '').Trim()   # Batchnummer från D2
            if ($txt) { return $txt }
        }
    } catch {
        Gui-Log "⚠️ Kunde inte läsa Batch # från Seal-fil: $($_.Exception.Message)" 'Warn'
    } finally { if ($pkg) { try { $pkg.Dispose() } catch {} } }
    return $null
}

function Update-BatchLink {
    if (-not (Get-Variable -Name slBatchLink -Scope Script -ErrorAction SilentlyContinue) -and -not (Get-Variable -Name slBatchLink -Scope Global -ErrorAction SilentlyContinue)) { return }
    try {
        $selNeg = Get-CheckedFilePath $clbNeg
        $selPos = Get-CheckedFilePath $clbPos
        $bnNeg  = if ($selNeg) { Get-BatchNumberFromSealFile $selNeg } else { $null }
        $bnPos  = if ($selPos) { Get-BatchNumberFromSealFile $selPos } else { $null }
        $lsp    = $txtLSP.Text.Trim()
        $mismatch = ($bnNeg -and $bnPos -and ($bnNeg -ne $bnPos))
        if ($mismatch) {
            $slBatchLink.Text        = 'SharePoint: mismatch'
            $slBatchLink.Enabled     = $false
            $slBatchLink.Tag         = $null
            $slBatchLink.ToolTipText = "NEG: $bnNeg  |  POS: $bnPos"
            return
        }
        $batch = if ($bnPos) { $bnPos } elseif ($bnNeg) { $bnNeg } else { $null }
        if ($batch) {
            $url = $SharePointBatchLinkTemplate -replace '\{BatchNumber\}', (UrlEncode $batch) -replace '\{LSP\}', (UrlEncode $lsp)

            $slBatchLink.Text        = "SharePoint: $batch"
            $slBatchLink.Enabled     = $true
            $slBatchLink.Tag         = $url
            $slBatchLink.ToolTipText = $url
        } else {
            $slBatchLink.Text        = 'SharePoint: —'
            $slBatchLink.Enabled     = $false
            $slBatchLink.Tag         = $null
            $slBatchLink.ToolTipText = 'Direktlänk aktiveras när Batch# hittas i sökt LSP.'
        }
    } catch {
        Gui-Log "⚠️ Kunde inte uppdatera SharePoint-länk: $($_.Exception.Message)" 'Warn'
    }
}

# =============================================================
# Worksheet-signatur  (Sammanställning / Granskning)
# =============================================================

function Confirm-WorksheetSignInput {
    param([string]$FullName, [string]$SignDate, [string[]]$Targets)
    $sep = [string]::new([char]0x2500, 34)
    $targetList = ($Targets | ForEach-Object { "    $_" }) -join "`n"
    $msg = "WORKSHEET  —  Bekräfta signatur`n" +
           "$sep`n`n" +
           "  Namn     $FullName`n" +
           "  Datum    $SignDate`n`n" +
           "$sep`n" +
           "Flikar som signeras:`n$targetList`n`n" +
           "Vill du fortsätta?"
    $res = [System.Windows.Forms.MessageBox]::Show($msg, 'Worksheet-signatur', 'YesNo', 'Question')
    return ($res -eq 'Yes')
}

# =============================================================
# GDP-SAFE: Forensik och verifiering
# =============================================================

function Save-ForensicSnapshot {
    <#
    .SYNOPSIS
        Kopierar workbook + skriver loggfil vid signeringsfel.
    #>
    param(
        [Parameter(Mandatory=$true)][string]$SourcePath,
        [Parameter(Mandatory=$true)][string]$Reason,
        [Parameter(Mandatory=$false)][string]$AuditDir,
        [Parameter(Mandatory=$false)][hashtable]$Details = @{}
    )
    try {
        if (-not $AuditDir) { $AuditDir = Join-Path $PSScriptRoot 'audit' }
        $forensicDir = Join-Path $AuditDir 'forensics'
        if (-not (Test-Path -LiteralPath $forensicDir)) {
            New-Item -ItemType Directory -Path $forensicDir -Force | Out-Null
        }

        $ts = (Get-Date).ToString('yyyyMMdd_HHmmss')
        $leaf = Split-Path $SourcePath -Leaf
        $snapName = "${ts}_${env:USERNAME}_${leaf}"
        $snapPath = Join-Path $forensicDir $snapName

        if (Test-Path -LiteralPath $SourcePath) {
            Copy-Item -LiteralPath $SourcePath -Destination $snapPath -Force -ErrorAction Stop
        }

        $logPath = Join-Path $forensicDir "${ts}_${env:USERNAME}_forensic.log"
        $logLines = @(
            "FORENSIC SIGNATURE LOG"
            "======================"
            "Tidpunkt:    $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
            "Användare:   $env:USERNAME"
            "Dator:       $env:COMPUTERNAME"
            "Källfil:     $SourcePath"
            "Snapshot:    $snapPath"
            "Orsak:       $Reason"
        )
        foreach ($k in $Details.Keys) {
            $logLines += "${k}: $($Details[$k])"
        }
        Set-Content -LiteralPath $logPath -Value ($logLines -join "`r`n") -Encoding UTF8

        return $snapPath
    } catch {
        try { Gui-Log "⚠️ Kunde inte spara forensisk snapshot: $($_.Exception.Message)" 'Warn' } catch {}
        return $null
    }
}

function Verify-SealTestSignatures {
    <#
    .SYNOPSIS
        Säker read-back: öppnar Seal Test-fil med EPPlus och verifierar
        att B47 matchar förväntat värde i alla aktiva datablad.
        PSCustomObject med OK, SheetsChecked, Mismatches
    #>
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [Parameter(Mandatory=$true)][string]$ExpectedText,
        [Parameter(Mandatory=$true)][string]$SignatureCell,
        [Parameter(Mandatory=$true)][string]$ActiveCheckCell,
        [Parameter(Mandatory=$true)][int]$ExpectedWritten
    )

    $result = [pscustomobject]@{
        OK             = $false
        SheetsChecked  = 0
        SheetsVerified = 0
        Mismatches     = New-Object System.Collections.Generic.List[string]
        Error          = $null
    }

    if (-not (Test-Path -LiteralPath $Path)) {
        $result.Error = "Filen finns inte: $Path"
        return $result
    }

    $pkg = $null
    try {
        $pkg = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($Path))
        foreach ($ws in $pkg.Workbook.Worksheets) {
            if ($ws.Name -eq 'Worksheet Instructions') { continue }
            $h3 = ($ws.Cells[$ActiveCheckCell].Text + '').Trim()
            if ($h3 -match '^[0-9]') {
                $result.SheetsChecked++
                $actual = ($ws.Cells[$SignatureCell].Text + '').Trim()
                if ($actual -eq $ExpectedText) {
                    $result.SheetsVerified++
                } else {
                    [void]$result.Mismatches.Add("$($ws.Name): Förväntade='$ExpectedText' Faktisk='$actual'")
                }
            }
            elseif ([string]::IsNullOrWhiteSpace($h3) -or $h3 -match '^(?i)(N\/?A|NA|Tomt( innehåll)?)$') {
                break
            }
        }

        if ($result.Mismatches.Count -eq 0 -and $result.SheetsVerified -ge $ExpectedWritten) {
            $result.OK = $true
        }
    } catch {
        $result.Error = $_.Exception.Message
    } finally {
        try { if ($pkg) { $pkg.Dispose() } } catch {}
    }
    return $result
}

function Verify-WorksheetSignatures {
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [Parameter(Mandatory=$true)][object[]]$WrittenCells
    )

    $result = [pscustomobject]@{
        OK             = $false
        CellsChecked   = 0
        CellsVerified  = 0
        Mismatches     = New-Object System.Collections.Generic.List[string]
        Error          = $null
    }

    if (-not $WrittenCells -or $WrittenCells.Count -eq 0) {
        $result.OK = $true
        return $result
    }

    if (-not (Test-Path -LiteralPath $Path)) {
        $result.Error = "Filen finns inte: $Path"
        return $result
    }

    $pkg = $null
    try {
        $pkg = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($Path))

        foreach ($wc in $WrittenCells) {
            $result.CellsChecked++
            $ws = $pkg.Workbook.Worksheets[$wc.Sheet]
            if (-not $ws) {
                [void]$result.Mismatches.Add("$($wc.Sheet) $($wc.Col)$($wc.Row): Fliken hittades inte")
                continue
            }

            $cellAddr = "$($wc.Col)$($wc.Row)"
            $actual = ($ws.Cells[$cellAddr].Text + '').Trim()
            $expected = ($wc.Value + '').Trim()

            if ($actual -eq $expected) {
                $result.CellsVerified++
            } else {
                [void]$result.Mismatches.Add("$($wc.Sheet) ${cellAddr}: Förväntade='$expected' Faktisk='$actual'")
            }
        }

        $result.OK = ($result.Mismatches.Count -eq 0 -and $result.CellsVerified -eq $WrittenCells.Count)
    } catch {
        $result.Error = $_.Exception.Message
    } finally {
        try { if ($pkg) { $pkg.Dispose() } } catch {}
    }
    return $result
}