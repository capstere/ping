#requires -Version 3.0

<#
Migration Notes (WinForms -> WPF)
- Mapping kontroller:
  - Form -> WPF Window (`MainWindow`) + `form`-shim (Close/Height/Cursor/Refresh)
  - CheckedListBox -> WPF `ListBox` med `CheckBox`-items via `clb*`-shim (`GetItemChecked`, `SetItemChecked`, `CheckedItems`, `add_ItemCheck`)
  - StatusStrip/ToolStripStatusLabel -> WPF statusrad (`TextBlock`/`Button`) via `sl*`/`status`-shims
  - ToolStripProgressBar -> WPF `ProgressBar` via `pbWork`-shim (`Visible`, `Style`, `Value`)
  - WinForms Button/CheckBox -> WPF `Button`/`CheckBox` via shims (`Text`, `Enabled`, `Visible`, `Checked`, `PerformClick`)
- Event mapping:
  - `Add_Click`/`add_Click` -> WPF `Click`
  - `add_TextChanged` -> WPF `TextChanged`
  - `CheckedListBox.ItemCheck` -> syntetiskt event från wrappern när item-`CheckBox` togglas
  - Form KeyDown -> WPF `PreviewKeyDown`
- Theme/accent:
  - Basfärger/stilar finns i `GUI/WPF/Themes/Light.xaml` och `GUI/WPF/Themes/Dark.xaml`
  - Accent uppdateras dynamiskt från `UiStyling.ps1` (`$Accent` / `Get-WinAccentColor`) i `Set-WpfThemeResources`
- Felsökning XAML-load:
  - `Import-WpfXamlWindow` fångar fel, loggar via `Gui-Log` (om tillgängligt) och visar `MessageBox` med stacktrace
  - Vanliga fel: stavfel i `x:Name`, saknad resource key, ogiltig XAML-syntax
#>

$script:WpfGuiRoot = $PSScriptRoot
$script:WpfThemeDictionary = $null
if (-not $script:UI) { $script:UI = @{} }

function Import-WpfAssemblies {
    $assemblies = @('PresentationFramework','PresentationCore','WindowsBase','System.Xaml')
    foreach ($asm in $assemblies) {
        try { Add-Type -AssemblyName $asm -ErrorAction Stop } catch {}
    }
}

function Show-WpfBootstrapError {
    param(
        [Parameter(Mandatory)][string]$Title,
        [Parameter(Mandatory)][string]$Message,
        [System.Exception]$Exception
    )

    $detail = $Message
    if ($Exception) {
        try { $detail = $detail + "`r`n`r`n" + $Exception.ToString() } catch {}
    }

    try { Gui-Log ("❌ {0}: {1}" -f $Title, $detail) 'Error' } catch {}

    try {
        [System.Windows.MessageBox]::Show($detail, $Title, [System.Windows.MessageBoxButton]::OK, [System.Windows.MessageBoxImage]::Error) | Out-Null
    } catch {
        try { Write-Host ("[{0}] {1}" -f $Title, $detail) } catch {}
    }
}

function Import-WpfXamlWindow {
    param([Parameter(Mandatory)][string]$Path)

    Import-WpfAssemblies

    if (-not (Test-Path -LiteralPath $Path)) {
        $ex = New-Object System.IO.FileNotFoundException("XAML hittades inte: $Path")
        Show-WpfBootstrapError -Title 'WPF/XAML fel' -Message 'Kunde inte ladda MainWindow.xaml.' -Exception $ex
        throw $ex
    }

    try {
        $raw = Get-Content -LiteralPath $Path -Raw -Encoding UTF8
        $xml = New-Object System.Xml.XmlDocument
        $xml.PreserveWhitespace = $true
        $xml.LoadXml($raw)

        # Ta bort x:Class om det finns (PowerShell XamlReader hanterar inte code-behind-klass)
        $nsMgr = New-Object System.Xml.XmlNamespaceManager($xml.NameTable)
        $nsMgr.AddNamespace('x','http://schemas.microsoft.com/winfx/2006/xaml')
        $root = $xml.DocumentElement
        if ($root -and $root.Attributes['x:Class']) {
            $null = $root.Attributes.RemoveNamedItem('x:Class')
        }

        $sr = New-Object System.IO.StringReader($xml.OuterXml)
        $xr = [System.Xml.XmlReader]::Create($sr)
        try {
            return [Windows.Markup.XamlReader]::Load($xr)
        } finally {
            try { $xr.Close() } catch {}
            try { $sr.Dispose() } catch {}
        }
    }
    catch {
        Show-WpfBootstrapError -Title 'WPF/XAML fel' -Message ("Kunde inte ladda XAML: {0}" -f $Path) -Exception $_.Exception
        throw
    }
}

function Get-WpfNamedControlMap {
    param(
        [Parameter(Mandatory)][System.Windows.FrameworkElement]$Root,
        [Parameter(Mandatory)][string]$XamlPath
    )

    $map = @{}
    try {
        [xml]$xml = Get-Content -LiteralPath $XamlPath -Raw -Encoding UTF8
        $nsmgr = New-Object System.Xml.XmlNamespaceManager($xml.NameTable)
        $nsmgr.AddNamespace('x','http://schemas.microsoft.com/winfx/2006/xaml')
        $nodes = @($xml.SelectNodes('//*[@x:Name or @Name]', $nsmgr))
        foreach ($n in $nodes) {
            $name = $null
            try { $name = $n.Attributes['Name'].Value } catch {}
            if (-not $name) { try { $name = $n.Attributes['x:Name'].Value } catch {} }
            if (-not $name) { try { $name = $n.GetAttribute('Name') } catch {} }
            if (-not $name) { continue }
            try {
                $ctrl = $Root.FindName($name)
                if ($ctrl) { $map[$name] = $ctrl }
            } catch {}
        }
    } catch {}
    return $map
}

function Get-WpfThemePath {
    param([ValidateSet('light','dark')][string]$Theme)
    $file = if ($Theme -eq 'dark') { 'Dark.xaml' } else { 'Light.xaml' }
    return (Join-Path $script:WpfGuiRoot (Join-Path 'Themes' $file))
}

function Convert-FromDrawingColorToWpf {
    param([Parameter(Mandatory)][System.Drawing.Color]$Color)
    return [System.Windows.Media.Color]::FromArgb([byte]$Color.A, [byte]$Color.R, [byte]$Color.G, [byte]$Color.B)
}

function New-WpfSolidBrush {
    param([Parameter(Mandatory)][System.Windows.Media.Color]$Color)
    $b = New-Object System.Windows.Media.SolidColorBrush $Color
    try { $b.Freeze() } catch {}
    return $b
}

function Get-WpfAccentInfo {
    $accentDrawing = $null
    try {
        if ($script:Accent -and ($script:Accent -is [System.Drawing.Color])) { $accentDrawing = $script:Accent }
    } catch {}
    if (-not $accentDrawing) {
        try {
            if ($global:Accent -and ($global:Accent -is [System.Drawing.Color])) { $accentDrawing = $global:Accent }
        } catch {}
    }
    if (-not $accentDrawing) {
        try {
            if (Get-Command Get-WinAccentColor -ErrorAction SilentlyContinue) {
                $accentDrawing = Get-WinAccentColor
            }
        } catch {}
    }
    if (-not $accentDrawing) {
        $accentDrawing = [System.Drawing.Color]::FromArgb(38,120,178)
    }

    $accent = Convert-FromDrawingColorToWpf -Color $accentDrawing
    $hoverR = [byte][Math]::Min(255, [int]$accent.R + 18)
    $hoverG = [byte][Math]::Min(255, [int]$accent.G + 18)
    $hoverB = [byte][Math]::Min(255, [int]$accent.B + 18)
    $hover = [System.Windows.Media.Color]::FromArgb([byte]255, $hoverR, $hoverG, $hoverB)

    $isDark = (($accent.R * 0.299) + ($accent.G * 0.587) + ($accent.B * 0.114)) -lt 150
    $fg = if ($isDark) {
        [System.Windows.Media.Color]::FromArgb(255,255,255,255)
    } else {
        [System.Windows.Media.Color]::FromArgb(255,15,23,32)
    }

    [pscustomobject]@{
        AccentColor = $accent
        AccentHover = $hover
        AccentFg    = $fg
    }
}

function Set-WpfThemeResources {
    param([ValidateSet('light','dark')][string]$Theme = 'light')

    if (-not $script:UI -or -not $script:UI.Window) { return }

    try {
        $themePath = Get-WpfThemePath -Theme $Theme
        $dict = Import-WpfXamlWindow -Path $themePath
        if ($dict -isnot [System.Windows.ResourceDictionary]) {
            throw "Theme-filen laddades inte som ResourceDictionary: $themePath"
        }

        $md = $script:UI.Window.Resources.MergedDictionaries
        if (-not $md) { return }

        if ($script:WpfThemeDictionary) {
            try { $null = $md.Remove($script:WpfThemeDictionary) } catch {}
        }

        $accent = Get-WpfAccentInfo
        $dict['AccentBrush'] = (New-WpfSolidBrush -Color $accent.AccentColor)
        $dict['AccentHoverBrush'] = (New-WpfSolidBrush -Color $accent.AccentHover)
        $dict['AccentForegroundBrush'] = (New-WpfSolidBrush -Color $accent.AccentFg)

        $md.Add($dict)
        $script:WpfThemeDictionary = $dict
        $script:UI.Theme = $Theme
    }
    catch {
        Show-WpfBootstrapError -Title 'Tema-fel' -Message ("Kunde inte växla tema till '{0}'." -f $Theme) -Exception $_.Exception
    }
}

function Invoke-WpfUi {
    param([Parameter(Mandatory)][scriptblock]$ScriptBlock)

    $dispatcher = $null
    try { $dispatcher = $script:UI.Window.Dispatcher } catch {}
    if (-not $dispatcher) { & $ScriptBlock; return }

    if ($dispatcher.CheckAccess()) {
        & $ScriptBlock
    } else {
        $dispatcher.Invoke([action]$ScriptBlock)
    }
}

function Invoke-WpfUiAsync {
    param([Parameter(Mandatory)][scriptblock]$ScriptBlock)

    $dispatcher = $null
    try { $dispatcher = $script:UI.Window.Dispatcher } catch {}
    if (-not $dispatcher) { & $ScriptBlock; return $null }

    if ($dispatcher.CheckAccess()) {
        & $ScriptBlock
        return $null
    }
    return $dispatcher.BeginInvoke([action]$ScriptBlock)
}

function Invoke-WpfUiPump {
    try {
        if (-not $script:UI.Window) { return }
        $dispatcher = $script:UI.Window.Dispatcher
        if (-not $dispatcher) { return }

        if ($dispatcher.CheckAccess()) {
            $frame = New-Object System.Windows.Threading.DispatcherFrame
            $cb = [System.Windows.Threading.DispatcherOperationCallback]{
                param($f)
                try { $f.Continue = $false } catch {}
                return $null
            }
            $null = $dispatcher.BeginInvoke([System.Windows.Threading.DispatcherPriority]::Background, $cb, $frame)
            [System.Windows.Threading.Dispatcher]::PushFrame($frame)
        } else {
            $dispatcher.Invoke([action]{})
        }
    } catch {}
}

function Get-AppWindowOwner {
    try {
        if ($script:UI -and $script:UI.Window -and ($script:UI.Window -is [System.Windows.Window])) {
            return $script:UI.Window
        }
    } catch {}
    return $null
}

function Convert-AppMessageButton {
    param([string]$Buttons = 'OK')
    $b = ($Buttons + '').Trim()
    if (-not $b) { $b = 'OK' }
    switch -Regex ($b) {
        '^(?i)OK$' { return [System.Windows.MessageBoxButton]::OK }
        '^(?i)OKCancel$' { return [System.Windows.MessageBoxButton]::OKCancel }
        '^(?i)YesNo$' { return [System.Windows.MessageBoxButton]::YesNo }
        '^(?i)YesNoCancel$' { return [System.Windows.MessageBoxButton]::YesNoCancel }
        default { return [System.Windows.MessageBoxButton]::OK }
    }
}

function Convert-AppMessageImage {
    param([string]$Icon = 'None')
    $i = ($Icon + '').Trim()
    if (-not $i) { $i = 'None' }
    switch -Regex ($i) {
        '^(?i)(Info|Information)$' { return [System.Windows.MessageBoxImage]::Information }
        '^(?i)(Warn|Warning)$' { return [System.Windows.MessageBoxImage]::Warning }
        '^(?i)(Err|Error|Stop)$' { return [System.Windows.MessageBoxImage]::Error }
        '^(?i)(Question)$' { return [System.Windows.MessageBoxImage]::Question }
        default { return [System.Windows.MessageBoxImage]::None }
    }
}

function Show-AppMessage {
    param(
        [Parameter(Mandatory)][string]$Message,
        [string]$Title = 'IPTCompile',
        [string]$Buttons = 'OK',
        [string]$Icon = 'None'
    )

    Import-WpfAssemblies
    $btn = Convert-AppMessageButton -Buttons $Buttons
    $img = Convert-AppMessageImage -Icon $Icon
    $owner = Get-AppWindowOwner
    try {
        if ($owner) {
            return [System.Windows.MessageBox]::Show($owner, $Message, $Title, $btn, $img)
        }
        return [System.Windows.MessageBox]::Show($Message, $Title, $btn, $img)
    } catch {
        try { Write-Host ("[{0}] {1}" -f $Title, $Message) } catch {}
        return [System.Windows.MessageBoxResult]::None
    }
}

function New-AppDialogWindow {
    param(
        [string]$Title = 'IPTCompile',
        [double]$Width = 520,
        [double]$Height = 420,
        [double]$MinWidth = 0,
        [double]$MinHeight = 0
    )

    Import-WpfAssemblies

    $wnd = New-Object System.Windows.Window
    $wnd.Title = $Title
    $wnd.Width = $Width
    $wnd.Height = $Height
    if ($MinWidth -gt 0) { $wnd.MinWidth = $MinWidth }
    if ($MinHeight -gt 0) { $wnd.MinHeight = $MinHeight }
    $wnd.WindowStartupLocation = 'CenterOwner'
    $wnd.ResizeMode = 'NoResize'
    $wnd.ShowInTaskbar = $false
    $wnd.Background = [System.Windows.Media.Brushes]::White
    try {
        $owner = Get-AppWindowOwner
        if ($owner) { $wnd.Owner = $owner }
    } catch {}
    return $wnd
}

function Show-AppTextInputDialog {
    param(
        [Parameter(Mandatory)][string]$Title,
        [Parameter(Mandatory)][string]$Prompt,
        [string]$DefaultText = '',
        [switch]$IsPassword
    )

    $wnd = New-AppDialogWindow -Title $Title -Width 420 -Height 210 -MinWidth 420 -MinHeight 210

    $root = New-Object System.Windows.Controls.Grid
    $root.Margin = '12'
    $root.RowDefinitions.Add((New-Object System.Windows.Controls.RowDefinition -Property @{ Height = 'Auto' })) | Out-Null
    $root.RowDefinitions.Add((New-Object System.Windows.Controls.RowDefinition -Property @{ Height = '*' })) | Out-Null
    $root.RowDefinitions.Add((New-Object System.Windows.Controls.RowDefinition -Property @{ Height = 'Auto' })) | Out-Null

    $txtPrompt = New-Object System.Windows.Controls.TextBlock
    $txtPrompt.Text = $Prompt
    $txtPrompt.TextWrapping = 'Wrap'
    $txtPrompt.Margin = '0,0,0,10'
    [System.Windows.Controls.Grid]::SetRow($txtPrompt, 0)
    $root.Children.Add($txtPrompt) | Out-Null

    $inputCtrl = $null
    if ($IsPassword) {
        $pb = New-Object System.Windows.Controls.PasswordBox
        $pb.Password = ($DefaultText + '')
        $pb.Height = 30
        $pb.Padding = '8,4'
        $inputCtrl = $pb
    } else {
        $tb = New-Object System.Windows.Controls.TextBox
        $tb.Text = ($DefaultText + '')
        $tb.Height = 30
        $tb.Padding = '8,4'
        $inputCtrl = $tb
    }
    [System.Windows.Controls.Grid]::SetRow($inputCtrl, 1)
    $root.Children.Add($inputCtrl) | Out-Null

    $btnPanel = New-Object System.Windows.Controls.StackPanel
    $btnPanel.Orientation = 'Horizontal'
    $btnPanel.HorizontalAlignment = 'Right'
    $btnPanel.Margin = '0,12,0,0'
    [System.Windows.Controls.Grid]::SetRow($btnPanel, 2)

    $btnCancel = New-Object System.Windows.Controls.Button
    $btnCancel.Content = 'Avbryt'
    $btnCancel.MinWidth = 90
    $btnCancel.Margin = '0,0,8,0'
    $btnCancel.IsCancel = $true

    $btnOk = New-Object System.Windows.Controls.Button
    $btnOk.Content = 'OK'
    $btnOk.MinWidth = 90
    $btnOk.IsDefault = $true

    $script:__DialogResultValue = $null
    $btnCancel.add_Click({
        $script:__DialogResultValue = $null
        $wnd.DialogResult = $false
        $wnd.Close()
    })
    $btnOk.add_Click({
        if ($IsPassword) { $script:__DialogResultValue = $inputCtrl.Password } else { $script:__DialogResultValue = $inputCtrl.Text }
        $wnd.DialogResult = $true
        $wnd.Close()
    })

    $btnPanel.Children.Add($btnCancel) | Out-Null
    $btnPanel.Children.Add($btnOk) | Out-Null
    $root.Children.Add($btnPanel) | Out-Null

    $wnd.Content = $root
    $wnd.add_ContentRendered({ try { $inputCtrl.Focus() | Out-Null } catch {} })

    $res = $wnd.ShowDialog()
    if ($res -ne $true) { return $null }
    return [string]$script:__DialogResultValue
}

function Show-AppMultilineInputDialog {
    param(
        [Parameter(Mandatory)][string]$Title,
        [Parameter(Mandatory)][string]$Prompt,
        [string]$OkButtonText = 'OK',
        [string]$CancelButtonText = 'Avbryt'
    )

    $wnd = New-AppDialogWindow -Title $Title -Width 520 -Height 380 -MinWidth 420 -MinHeight 300
    $wnd.ResizeMode = 'CanResize'

    $root = New-Object System.Windows.Controls.Grid
    $root.Margin = '12'
    foreach ($h in @('Auto','*','Auto')) {
        $root.RowDefinitions.Add((New-Object System.Windows.Controls.RowDefinition -Property @{ Height = $h })) | Out-Null
    }

    $txtPrompt = New-Object System.Windows.Controls.TextBlock
    $txtPrompt.Text = $Prompt
    $txtPrompt.TextWrapping = 'Wrap'
    $txtPrompt.Margin = '0,0,0,10'
    [System.Windows.Controls.Grid]::SetRow($txtPrompt, 0)
    $root.Children.Add($txtPrompt) | Out-Null

    $tb = New-Object System.Windows.Controls.TextBox
    $tb.AcceptsReturn = $true
    $tb.VerticalScrollBarVisibility = 'Auto'
    $tb.TextWrapping = 'Wrap'
    $tb.Margin = '0,0,0,10'
    [System.Windows.Controls.Grid]::SetRow($tb, 1)
    $root.Children.Add($tb) | Out-Null

    $btnPanel = New-Object System.Windows.Controls.StackPanel
    $btnPanel.Orientation = 'Horizontal'
    $btnPanel.HorizontalAlignment = 'Right'
    [System.Windows.Controls.Grid]::SetRow($btnPanel, 2)

    $btnCancel = New-Object System.Windows.Controls.Button
    $btnCancel.Content = $CancelButtonText
    $btnCancel.MinWidth = 96
    $btnCancel.Margin = '0,0,8,0'
    $btnCancel.IsCancel = $true

    $btnOk = New-Object System.Windows.Controls.Button
    $btnOk.Content = $OkButtonText
    $btnOk.MinWidth = 96
    $btnOk.IsDefault = $true

    $script:__DialogResultValue = $null
    $btnCancel.add_Click({ $script:__DialogResultValue = $null; $wnd.DialogResult = $false; $wnd.Close() })
    $btnOk.add_Click({ $script:__DialogResultValue = $tb.Text; $wnd.DialogResult = $true; $wnd.Close() })

    $btnPanel.Children.Add($btnCancel) | Out-Null
    $btnPanel.Children.Add($btnOk) | Out-Null
    $root.Children.Add($btnPanel) | Out-Null
    $wnd.Content = $root

    $res = $wnd.ShowDialog()
    if ($res -ne $true) { return $null }
    return [string]$script:__DialogResultValue
}

function Show-AppRetryCancelDialog {
    param(
        [Parameter(Mandatory)][string]$Title,
        [Parameter(Mandatory)][string]$Message
    )

    $wnd = New-AppDialogWindow -Title $Title -Width 480 -Height 220 -MinWidth 420 -MinHeight 200

    $root = New-Object System.Windows.Controls.Grid
    $root.Margin = '12'
    $root.RowDefinitions.Add((New-Object System.Windows.Controls.RowDefinition -Property @{ Height = '*' })) | Out-Null
    $root.RowDefinitions.Add((New-Object System.Windows.Controls.RowDefinition -Property @{ Height = 'Auto' })) | Out-Null

    $txt = New-Object System.Windows.Controls.TextBlock
    $txt.Text = $Message
    $txt.TextWrapping = 'Wrap'
    $txt.VerticalAlignment = 'Center'
    [System.Windows.Controls.Grid]::SetRow($txt, 0)
    $root.Children.Add($txt) | Out-Null

    $btnPanel = New-Object System.Windows.Controls.StackPanel
    $btnPanel.Orientation = 'Horizontal'
    $btnPanel.HorizontalAlignment = 'Right'
    $btnPanel.Margin = '0,12,0,0'
    [System.Windows.Controls.Grid]::SetRow($btnPanel, 1)

    $btnCancel = New-Object System.Windows.Controls.Button
    $btnCancel.Content = 'Avbryt'
    $btnCancel.MinWidth = 96
    $btnCancel.Margin = '0,0,8,0'
    $btnCancel.IsCancel = $true

    $btnRetry = New-Object System.Windows.Controls.Button
    $btnRetry.Content = 'Försök igen'
    $btnRetry.MinWidth = 110
    $btnRetry.IsDefault = $true

    $script:__DialogResultValue = 'Cancel'
    $btnCancel.add_Click({ $script:__DialogResultValue = 'Cancel'; $wnd.DialogResult = $false; $wnd.Close() })
    $btnRetry.add_Click({ $script:__DialogResultValue = 'Retry'; $wnd.DialogResult = $true; $wnd.Close() })

    $btnPanel.Children.Add($btnCancel) | Out-Null
    $btnPanel.Children.Add($btnRetry) | Out-Null
    $root.Children.Add($btnPanel) | Out-Null
    $wnd.Content = $root
    $null = $wnd.ShowDialog()
    return [string]$script:__DialogResultValue
}

function Show-AppListSelectionDialog {
    param(
        [Parameter(Mandatory)][string]$Title,
        [Parameter(Mandatory)][string]$Prompt,
        [Parameter(Mandatory)][string[]]$Items
    )

    $wnd = New-AppDialogWindow -Title $Title -Width 560 -Height 440 -MinWidth 520 -MinHeight 420
    $wnd.ResizeMode = 'CanResize'

    $root = New-Object System.Windows.Controls.Grid
    $root.Margin = '12'
    foreach ($h in @('Auto','*','Auto')) {
        $root.RowDefinitions.Add((New-Object System.Windows.Controls.RowDefinition -Property @{ Height = $h })) | Out-Null
    }

    $lbl = New-Object System.Windows.Controls.TextBlock
    $lbl.Text = $Prompt
    $lbl.TextWrapping = 'Wrap'
    $lbl.Margin = '0,0,0,10'
    [System.Windows.Controls.Grid]::SetRow($lbl, 0)
    $root.Children.Add($lbl) | Out-Null

    $list = New-Object System.Windows.Controls.ListBox
    foreach ($it in @($Items)) { [void]$list.Items.Add([string]$it) }
    [System.Windows.Controls.Grid]::SetRow($list, 1)
    $root.Children.Add($list) | Out-Null

    $btnPanel = New-Object System.Windows.Controls.StackPanel
    $btnPanel.Orientation = 'Horizontal'
    $btnPanel.HorizontalAlignment = 'Right'
    $btnPanel.Margin = '0,10,0,0'
    [System.Windows.Controls.Grid]::SetRow($btnPanel, 2)

    $btnCancel = New-Object System.Windows.Controls.Button
    $btnCancel.Content = 'Avbryt'
    $btnCancel.MinWidth = 96
    $btnCancel.Margin = '0,0,8,0'
    $btnCancel.IsCancel = $true

    $btnOk = New-Object System.Windows.Controls.Button
    $btnOk.Content = 'OK'
    $btnOk.MinWidth = 96
    $btnOk.IsDefault = $true

    $script:__DialogResultValue = $null
    $btnCancel.add_Click({ $script:__DialogResultValue = $null; $wnd.DialogResult = $false; $wnd.Close() })
    $btnOk.add_Click({
        if ($list.SelectedItem) {
            $script:__DialogResultValue = [string]$list.SelectedItem
            $wnd.DialogResult = $true
            $wnd.Close()
        }
    })
    $list.add_MouseDoubleClick({
        if ($list.SelectedItem) {
            $script:__DialogResultValue = [string]$list.SelectedItem
            $wnd.DialogResult = $true
            $wnd.Close()
        }
    })

    $btnPanel.Children.Add($btnCancel) | Out-Null
    $btnPanel.Children.Add($btnOk) | Out-Null
    $root.Children.Add($btnPanel) | Out-Null
    $wnd.Content = $root
    $null = $wnd.ShowDialog()
    return $script:__DialogResultValue
}

function Show-AppFileMoveSelectionDialog {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Title,
        [Parameter(Mandatory)][string]$Prompt,
        [Parameter(Mandatory)][System.IO.FileInfo[]]$Files,
        [string[]]$DefaultCheckedExtensions = @('.csv','.xlsx','.xlsm','.pdf')
    )

    $wnd = New-AppDialogWindow -Title $Title -Width 860 -Height 560 -MinWidth 780 -MinHeight 520
    $wnd.ResizeMode = 'CanResize'

    $root = New-Object System.Windows.Controls.Grid
    $root.Margin = '12'
    foreach ($h in @('Auto','*','Auto')) {
        $root.RowDefinitions.Add((New-Object System.Windows.Controls.RowDefinition -Property @{ Height = $h })) | Out-Null
    }

    $lbl = New-Object System.Windows.Controls.TextBlock
    $lbl.Text = $Prompt
    $lbl.TextWrapping = 'Wrap'
    $lbl.Margin = '0,0,0,10'
    [System.Windows.Controls.Grid]::SetRow($lbl, 0)
    $root.Children.Add($lbl) | Out-Null

    $list = New-Object System.Windows.Controls.ListBox
    [System.Windows.Controls.Grid]::SetRow($list, 1)
    $root.Children.Add($list) | Out-Null

    $defaultExt = @($DefaultCheckedExtensions | ForEach-Object { (''+$_).ToLowerInvariant() })
    foreach ($f in ($Files | Sort-Object LastWriteTime -Descending)) {
        $ts = ''
        try { $ts = $f.LastWriteTime.ToString('yyyy-MM-dd HH:mm') } catch {}
        $kb = ''
        try { $kb = [Math]::Round(($f.Length / 1KB),0) } catch {}
        $display = "{0}    ({1}, {2} KB)" -f $f.Name, $ts, $kb
        $cb = New-Object System.Windows.Controls.CheckBox
        $cb.Content = $display
        $cb.Tag = $f
        $cb.ToolTip = $f.FullName
        $cb.Margin = '2'
        $cb.IsChecked = ($defaultExt -contains (($f.Extension + '').ToLowerInvariant()))
        [void]$list.Items.Add($cb)
    }

    $footer = New-Object System.Windows.Controls.Grid
    $footer.Margin = '0,10,0,0'
    $footer.ColumnDefinitions.Add((New-Object System.Windows.Controls.ColumnDefinition -Property @{ Width = '*' })) | Out-Null
    $footer.ColumnDefinitions.Add((New-Object System.Windows.Controls.ColumnDefinition -Property @{ Width = 'Auto' })) | Out-Null
    [System.Windows.Controls.Grid]::SetRow($footer, 2)

    $leftBtns = New-Object System.Windows.Controls.StackPanel
    $leftBtns.Orientation = 'Horizontal'
    [System.Windows.Controls.Grid]::SetColumn($leftBtns, 0)
    $footer.Children.Add($leftBtns) | Out-Null

    $btnAll = New-Object System.Windows.Controls.Button
    $btnAll.Content = 'Markera alla'
    $btnAll.MinWidth = 120
    $btnAll.Margin = '0,0,8,0'

    $btnNone = New-Object System.Windows.Controls.Button
    $btnNone.Content = 'Avmarkera alla'
    $btnNone.MinWidth = 140

    $leftBtns.Children.Add($btnAll) | Out-Null
    $leftBtns.Children.Add($btnNone) | Out-Null

    $rightBtns = New-Object System.Windows.Controls.StackPanel
    $rightBtns.Orientation = 'Horizontal'
    $rightBtns.HorizontalAlignment = 'Right'
    [System.Windows.Controls.Grid]::SetColumn($rightBtns, 1)
    $footer.Children.Add($rightBtns) | Out-Null

    $btnCancel = New-Object System.Windows.Controls.Button
    $btnCancel.Content = 'Avbryt'
    $btnCancel.MinWidth = 100
    $btnCancel.Margin = '0,0,8,0'
    $btnCancel.IsCancel = $true

    $btnOk = New-Object System.Windows.Controls.Button
    $btnOk.Content = 'Flytta valda'
    $btnOk.MinWidth = 120
    $btnOk.IsDefault = $true

    $rightBtns.Children.Add($btnCancel) | Out-Null
    $rightBtns.Children.Add($btnOk) | Out-Null

    $script:__DialogResultValue = $null
    $btnAll.add_Click({
        foreach ($item in $list.Items) {
            try { if ($item -is [System.Windows.Controls.CheckBox]) { $item.IsChecked = $true } } catch {}
        }
    })
    $btnNone.add_Click({
        foreach ($item in $list.Items) {
            try { if ($item -is [System.Windows.Controls.CheckBox]) { $item.IsChecked = $false } } catch {}
        }
    })
    $btnCancel.add_Click({ $script:__DialogResultValue = $null; $wnd.DialogResult = $false; $wnd.Close() })
    $btnOk.add_Click({
        $selected = New-Object System.Collections.Generic.List[System.IO.FileInfo]
        foreach ($item in $list.Items) {
            try {
                if ($item -is [System.Windows.Controls.CheckBox] -and [bool]$item.IsChecked -and $item.Tag) {
                    $selected.Add([System.IO.FileInfo]$item.Tag)
                }
            } catch {}
        }
        $script:__DialogResultValue = @($selected)
        $wnd.DialogResult = $true
        $wnd.Close()
    })

    $root.Children.Add($footer) | Out-Null
    $wnd.Content = $root

    $res = $wnd.ShowDialog()
    if ($res -ne $true) { return $null }
    return @($script:__DialogResultValue)
}

function New-WpfTimerShim {
    param([int]$Interval = 200)

    Import-WpfAssemblies
    $timer = New-Object System.Windows.Threading.DispatcherTimer
    $timer.Interval = [TimeSpan]::FromMilliseconds([Math]::Max(10,$Interval))

    $shim = [pscustomobject]@{
        __Timer = $timer
    }

    Add-Member -InputObject $shim -MemberType ScriptMethod -Name add_Tick -Value {
        param([scriptblock]$Handler)
        $t = $this.__Timer
        $t.add_Tick($Handler)
    } -Force
    Add-Member -InputObject $shim -MemberType ScriptMethod -Name Start -Value { $this.__Timer.Start() } -Force
    Add-Member -InputObject $shim -MemberType ScriptMethod -Name Stop -Value { $this.__Timer.Stop() } -Force
    Add-Member -InputObject $shim -MemberType ScriptMethod -Name Dispose -Value {
        try { $this.__Timer.Stop() } catch {}
    } -Force
    Add-Member -InputObject $shim -MemberType NoteProperty -Name Interval -Value $Interval -Force

    return $shim
}

function Ui-LogAppend {
    param(
        [Parameter(Mandatory)][object]$Control,
        [Parameter(Mandatory)][string]$Text
    )

    if ($Control -is [System.Windows.Controls.TextBox]) {
        $append = {
            param($tb,$line)
            $tb.AppendText($line + "`r`n")
            $tb.CaretIndex = $tb.Text.Length
            $tb.ScrollToEnd()
        }

        try {
            if ($Control.Dispatcher -and -not $Control.Dispatcher.CheckAccess()) {
                $null = $Control.Dispatcher.BeginInvoke([action[object,string]]$append, @($Control,$Text))
            } else {
                & $append $Control $Text
            }
            return $true
        } catch { return $false }
    }
    return $false
}

function Start-WpfGui {
    if (-not $script:UI -or -not $script:UI.Window) {
        throw 'WPF GUI är inte initierat. Kör Initialize-WpfGui först.'
    }

    try {
        $null = $script:UI.Window.ShowDialog()
    } catch {
        Show-WpfBootstrapError -Title 'WPF körfel' -Message 'Huvudfönstret kunde inte startas.' -Exception $_.Exception
        throw
    }
}
