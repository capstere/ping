#requires -Version 3.0

function New-WpfTextBlockShim {
    param([Parameter(Mandatory)][System.Windows.Controls.TextBlock]$Control)

    $shim = [pscustomobject]@{ __Ctrl = $Control }

    Add-Member -InputObject $shim -MemberType ScriptProperty -Name Text -Value {
        [string]$this.__Ctrl.Text
    } -SecondValue {
        param($v)
        $ctrl = $this.__Ctrl
        Invoke-WpfUi { $ctrl.Text = [string]$v }
    } -Force

    Add-Member -InputObject $shim -MemberType ScriptMethod -Name Refresh -Value { } -Force
    return $shim
}

function New-WpfStatusShim {
    param([Parameter(Mandatory)][System.Windows.FrameworkElement]$Control)
    $shim = [pscustomobject]@{ __Ctrl = $Control }
    Add-Member -InputObject $shim -MemberType ScriptMethod -Name Refresh -Value {
        $ctrl = $this.__Ctrl
        Invoke-WpfUi { try { $ctrl.UpdateLayout() } catch {} }
    } -Force
    return $shim
}

function New-WpfProgressBarShim {
    param([Parameter(Mandatory)][System.Windows.Controls.ProgressBar]$Control)

    $shim = [pscustomobject]@{ __Ctrl = $Control }

    Add-Member -InputObject $shim -MemberType ScriptProperty -Name Visible -Value {
        ($this.__Ctrl.Visibility -eq [System.Windows.Visibility]::Visible)
    } -SecondValue {
        param($v)
        $ctrl = $this.__Ctrl
        $boolVal = [bool]$v
        Invoke-WpfUi { $ctrl.Visibility = if ($boolVal) { 'Visible' } else { 'Collapsed' } }
    } -Force

    Add-Member -InputObject $shim -MemberType ScriptProperty -Name Style -Value {
        if ($this.__Ctrl.IsIndeterminate) { 'Marquee' } else { 'Blocks' }
    } -SecondValue {
        param($v)
        $ctrl = $this.__Ctrl
        $styleText = ([string]$v)
        Invoke-WpfUi {
            $ctrl.IsIndeterminate = ($styleText -match '^(?i)Marquee$')
        }
    } -Force

    foreach ($prop in 'Value','Minimum','Maximum','Width') {
        $p = $prop
        Add-Member -InputObject $shim -MemberType ScriptProperty -Name $p -Value ([scriptblock]::Create("`$this.__Ctrl.$p")) -SecondValue ([scriptblock]::Create(@"
param(`$v)
`$ctrl = `$this.__Ctrl
Invoke-WpfUi { `$ctrl.$p = `$v }
"@)) -Force
    }

    return $shim
}

function New-WpfButtonShim {
    param([Parameter(Mandatory)][System.Windows.Controls.Button]$Control)

    $shim = [pscustomobject]@{ __Ctrl = $Control }

    Add-Member -InputObject $shim -MemberType ScriptProperty -Name Text -Value {
        [string]$this.__Ctrl.Content
    } -SecondValue {
        param($v)
        $ctrl = $this.__Ctrl
        Invoke-WpfUi { $ctrl.Content = [string]$v }
    } -Force

    Add-Member -InputObject $shim -MemberType ScriptProperty -Name Enabled -Value {
        [bool]$this.__Ctrl.IsEnabled
    } -SecondValue {
        param($v)
        $ctrl = $this.__Ctrl
        Invoke-WpfUi { $ctrl.IsEnabled = [bool]$v }
    } -Force

    Add-Member -InputObject $shim -MemberType ScriptProperty -Name Visible -Value {
        ($this.__Ctrl.Visibility -eq [System.Windows.Visibility]::Visible)
    } -SecondValue {
        param($v)
        $ctrl = $this.__Ctrl
        $boolVal = [bool]$v
        Invoke-WpfUi { $ctrl.Visibility = if ($boolVal) { 'Visible' } else { 'Collapsed' } }
    } -Force

    Add-Member -InputObject $shim -MemberType ScriptProperty -Name Tag -Value {
        $this.__Ctrl.Tag
    } -SecondValue {
        param($v)
        $ctrl = $this.__Ctrl
        Invoke-WpfUi { $ctrl.Tag = $v }
    } -Force

    Add-Member -InputObject $shim -MemberType ScriptProperty -Name ToolTipText -Value {
        [string]$this.__Ctrl.ToolTip
    } -SecondValue {
        param($v)
        $ctrl = $this.__Ctrl
        Invoke-WpfUi { $ctrl.ToolTip = [string]$v }
    } -Force

    Add-Member -InputObject $shim -MemberType ScriptMethod -Name add_Click -Value {
        param([scriptblock]$Handler)
        $ctrl = $this.__Ctrl
        $ctrl.add_Click($Handler)
    } -Force

    Add-Member -InputObject $shim -MemberType ScriptMethod -Name Add_Click -Value { param([scriptblock]$Handler) $this.add_Click($Handler) } -Force

    Add-Member -InputObject $shim -MemberType ScriptMethod -Name PerformClick -Value {
        $ctrl = $this.__Ctrl
        Invoke-WpfUi {
            if (-not $ctrl.IsEnabled) { return }
            $args = New-Object System.Windows.RoutedEventArgs ([System.Windows.Controls.Button]::ClickEvent)
            $ctrl.RaiseEvent($args)
        }
    } -Force

    Add-Member -InputObject $shim -MemberType ScriptMethod -Name Refresh -Value {
        $ctrl = $this.__Ctrl
        Invoke-WpfUi { try { $ctrl.UpdateLayout() } catch {} }
    } -Force

    return $shim
}

function New-WpfMenuItemShim {
    param([Parameter(Mandatory)][System.Windows.Controls.MenuItem]$Control)

    $shim = [pscustomobject]@{ __Ctrl = $Control }

    Add-Member -InputObject $shim -MemberType ScriptProperty -Name Text -Value {
        [string]$this.__Ctrl.Header
    } -SecondValue {
        param($v)
        $ctrl = $this.__Ctrl
        Invoke-WpfUi { $ctrl.Header = [string]$v }
    } -Force

    Add-Member -InputObject $shim -MemberType ScriptProperty -Name ToolTipText -Value {
        [string]$this.__Ctrl.ToolTip
    } -SecondValue {
        param($v)
        $ctrl = $this.__Ctrl
        Invoke-WpfUi { $ctrl.ToolTip = [string]$v }
    } -Force

    Add-Member -InputObject $shim -MemberType ScriptProperty -Name Enabled -Value {
        [bool]$this.__Ctrl.IsEnabled
    } -SecondValue {
        param($v)
        $ctrl = $this.__Ctrl
        Invoke-WpfUi { $ctrl.IsEnabled = [bool]$v }
    } -Force

    Add-Member -InputObject $shim -MemberType ScriptMethod -Name add_Click -Value {
        param([scriptblock]$Handler)
        $ctrl = $this.__Ctrl
        $ctrl.add_Click($Handler)
    } -Force

    Add-Member -InputObject $shim -MemberType ScriptMethod -Name Add_Click -Value { param([scriptblock]$Handler) $this.add_Click($Handler) } -Force

    return $shim
}

function New-WpfCheckBoxShim {
    param([Parameter(Mandatory)][System.Windows.Controls.CheckBox]$Control)

    $shim = [pscustomobject]@{ __Ctrl = $Control }

    Add-Member -InputObject $shim -MemberType ScriptProperty -Name Checked -Value {
        [bool]$this.__Ctrl.IsChecked
    } -SecondValue {
        param($v)
        $ctrl = $this.__Ctrl
        $boolVal = [bool]$v
        Invoke-WpfUi { $ctrl.IsChecked = $boolVal }
    } -Force

    Add-Member -InputObject $shim -MemberType ScriptProperty -Name Enabled -Value {
        [bool]$this.__Ctrl.IsEnabled
    } -SecondValue {
        param($v)
        $ctrl = $this.__Ctrl
        Invoke-WpfUi { $ctrl.IsEnabled = [bool]$v }
    } -Force

    Add-Member -InputObject $shim -MemberType ScriptProperty -Name Text -Value {
        [string]$this.__Ctrl.Content
    } -SecondValue {
        param($v)
        $ctrl = $this.__Ctrl
        Invoke-WpfUi { $ctrl.Content = [string]$v }
    } -Force

    Add-Member -InputObject $shim -MemberType ScriptMethod -Name add_CheckedChanged -Value {
        param([scriptblock]$Handler)
        $ctrl = $this.__Ctrl
        $ctrl.add_Checked($Handler)
        $ctrl.add_Unchecked($Handler)
    } -Force

    Add-Member -InputObject $shim -MemberType ScriptMethod -Name Add_CheckedChanged -Value { param([scriptblock]$Handler) $this.add_CheckedChanged($Handler) } -Force

    return $shim
}

function New-WpfVisibilityShim {
    param([Parameter(Mandatory)][System.Windows.FrameworkElement]$Control)

    $shim = [pscustomobject]@{ __Ctrl = $Control }

    Add-Member -InputObject $shim -MemberType ScriptProperty -Name Visible -Value {
        ($this.__Ctrl.Visibility -eq [System.Windows.Visibility]::Visible)
    } -SecondValue {
        param($v)
        $ctrl = $this.__Ctrl
        $boolVal = [bool]$v
        Invoke-WpfUi { $ctrl.Visibility = if ($boolVal) { 'Visible' } else { 'Collapsed' } }
    } -Force

    Add-Member -InputObject $shim -MemberType ScriptProperty -Name Height -Value {
        $h = [double]$this.__Ctrl.Height
        if ([double]::IsNaN($h)) {
            try { return [double]$this.__Ctrl.ActualHeight } catch { return 0 }
        }
        return $h
    } -SecondValue {
        param($v)
        $ctrl = $this.__Ctrl
        Invoke-WpfUi { $ctrl.Height = [double]$v }
    } -Force

    Add-Member -InputObject $shim -MemberType ScriptMethod -Name Refresh -Value {
        $ctrl = $this.__Ctrl
        Invoke-WpfUi { try { $ctrl.UpdateLayout() } catch {} }
    } -Force

    return $shim
}

function New-WpfFormShim {
    param([Parameter(Mandatory)][System.Windows.Window]$Window)

    $shim = [pscustomobject]@{ __Window = $Window; __Font = (New-Object System.Drawing.Font('Segoe UI',10)) }

    Add-Member -InputObject $shim -MemberType ScriptProperty -Name Text -Value {
        [string]$this.__Window.Title
    } -SecondValue {
        param($v)
        $wnd = $this.__Window
        Invoke-WpfUi { $wnd.Title = [string]$v }
    } -Force

    Add-Member -InputObject $shim -MemberType ScriptProperty -Name Height -Value {
        [double]$this.__Window.Height
    } -SecondValue {
        param($v)
        $wnd = $this.__Window
        Invoke-WpfUi { $wnd.Height = [double]$v }
    } -Force

    Add-Member -InputObject $shim -MemberType ScriptProperty -Name Font -Value {
        $this.__Font
    } -SecondValue {
        param($v)
        $this.__Font = $v
    } -Force

    Add-Member -InputObject $shim -MemberType ScriptProperty -Name Cursor -Value {
        $this.__Window.Cursor
    } -SecondValue {
        param($v)
        $wnd = $this.__Window
        $cursor = [System.Windows.Input.Cursors]::Arrow
        try {
            $t = ("$v").ToLowerInvariant()
            if ($t -match 'wait') { $cursor = [System.Windows.Input.Cursors]::Wait }
        } catch {}
        Invoke-WpfUi { $wnd.Cursor = $cursor }
    } -Force

    Add-Member -InputObject $shim -MemberType ScriptMethod -Name Close -Value {
        $wnd = $this.__Window
        Invoke-WpfUi { $wnd.Close() }
    } -Force

    Add-Member -InputObject $shim -MemberType ScriptMethod -Name Refresh -Value {
        $wnd = $this.__Window
        Invoke-WpfUi { try { $wnd.UpdateLayout() } catch {} }
    } -Force

    return $shim
}

function New-WpfCheckedListBoxShim {
    param(
        [Parameter(Mandatory)][System.Windows.Controls.ListBox]$ListBox,
        [string]$CheckBoxStyleKey = 'ListItemCheckBoxStyle'
    )

    $shim = [pscustomobject]@{
        __ListBox = $ListBox
        __Handlers = (New-Object System.Collections.ArrayList)
        __Suspend  = 0
    }

    Add-Member -InputObject $shim -MemberType ScriptProperty -Name Items -Value {
        $this.__ListBox.Items
    } -Force

    Add-Member -InputObject $shim -MemberType ScriptProperty -Name CheckedItems -Value {
        $list = New-Object System.Collections.ArrayList
        foreach ($item in $this.__ListBox.Items) {
            if ($item -is [System.Windows.Controls.CheckBox]) {
                if ([bool]$item.IsChecked) {
                    [void]$list.Add($item.Tag)
                }
            }
        }
        return $list
    } -Force

    Add-Member -InputObject $shim -MemberType ScriptMethod -Name BeginUpdate -Value {
        $this.__Suspend = ($this.__Suspend + 1)
    } -Force

    Add-Member -InputObject $shim -MemberType ScriptMethod -Name EndUpdate -Value {
        if ($this.__Suspend -gt 0) { $this.__Suspend = ($this.__Suspend - 1) }
    } -Force

    Add-Member -InputObject $shim -MemberType ScriptMethod -Name BeginInvoke -Value {
        param([System.Action]$Action)
        if (-not $Action) { return $null }
        $lb = $this.__ListBox
        if ($lb.Dispatcher -and -not $lb.Dispatcher.CheckAccess()) {
            return $lb.Dispatcher.BeginInvoke([System.Windows.Threading.DispatcherPriority]::Background, $Action)
        }
        return $lb.Dispatcher.BeginInvoke([System.Windows.Threading.DispatcherPriority]::Background, [action]$Action)
    } -Force

    Add-Member -InputObject $shim -MemberType ScriptMethod -Name add_ItemCheck -Value {
        param([scriptblock]$Handler)
        if ($Handler) { [void]$this.__Handlers.Add($Handler) }
    } -Force

    Add-Member -InputObject $shim -MemberType ScriptMethod -Name Add_ItemCheck -Value { param([scriptblock]$Handler) $this.add_ItemCheck($Handler) } -Force

    Add-Member -InputObject $shim -MemberType ScriptMethod -Name GetItemChecked -Value {
        param([int]$Index)
        if ($Index -lt 0 -or $Index -ge $this.__ListBox.Items.Count) { return $false }
        $cb = $this.__ListBox.Items[$Index]
        if ($cb -isnot [System.Windows.Controls.CheckBox]) { return $false }
        return [bool]$cb.IsChecked
    } -Force

    Add-Member -InputObject $shim -MemberType ScriptMethod -Name SetItemChecked -Value {
        param([int]$Index,[bool]$Checked)
        if ($Index -lt 0 -or $Index -ge $this.__ListBox.Items.Count) { return }
        $cb = $this.__ListBox.Items[$Index]
        if ($cb -isnot [System.Windows.Controls.CheckBox]) { return }
        $newVal = [bool]$Checked
        if ([bool]$cb.IsChecked -eq $newVal) { return }
        $cb.IsChecked = $newVal
    } -Force

    Add-Member -InputObject $shim -MemberType ScriptMethod -Name __RaiseItemCheck -Value {
        param([int]$Index, [bool]$IsChecked)
        if ($this.__Suspend -gt 0) { return }
        $handlers = @($this.__Handlers)
        if (-not $handlers -or $handlers.Count -eq 0) { return }

        $e = [pscustomobject]@{
            Index = $Index
            NewValue = if ($IsChecked) { [System.Windows.Forms.CheckState]::Checked } else { [System.Windows.Forms.CheckState]::Unchecked }
            CurrentValue = if ($IsChecked) { [System.Windows.Forms.CheckState]::Checked } else { [System.Windows.Forms.CheckState]::Unchecked }
        }

        foreach ($h in $handlers) {
            if (-not $h) { continue }
            try {
                & $h $this $e
            } catch {
                try { Gui-Log ("⚠️ ItemCheck-handler fel: " + $_.Exception.Message) 'Warn' } catch {}
            }
        }
    } -Force

    Add-Member -InputObject $shim -MemberType ScriptMethod -Name SetFiles -Value {
        param([object[]]$Files)
        $lb = $this.__ListBox
        $style = $null
        try { $style = $lb.TryFindResource('ListItemCheckBoxStyle') } catch {}

        $this.BeginUpdate()
        try {
            $lb.Items.Clear()
            foreach ($f in @($Files)) {
                if (-not $f) { continue }
                $fi = $f
                if ($fi -isnot [System.IO.FileInfo]) {
                    try { $fi = Get-Item -LiteralPath $fi } catch { continue }
                }
                if ($fi -isnot [System.IO.FileInfo]) { continue }

                $cb = New-Object System.Windows.Controls.CheckBox
                $cb.Content = $fi.Name
                $cb.Tag = $fi
                $cb.IsChecked = $false
                $cb.ToolTip = $fi.FullName
                $cb.HorizontalContentAlignment = 'Left'
                if ($style) { try { $cb.Style = $style } catch {} }

                $shimRef = $this
                $cb.add_Checked({
                    $box = $this
                    $list = $shimRef.__ListBox
                    $idx = $list.Items.IndexOf($box)
                    if ($idx -ge 0) { $shimRef.__RaiseItemCheck($idx, $true) }
                })
                $cb.add_Unchecked({
                    $box = $this
                    $list = $shimRef.__ListBox
                    $idx = $list.Items.IndexOf($box)
                    if ($idx -ge 0) { $shimRef.__RaiseItemCheck($idx, $false) }
                })

                [void]$lb.Items.Add($cb)
            }
        } finally {
            $this.EndUpdate()
        }
    } -Force

    return $shim
}

function Add-WpfShortcutMenuItem {
    param(
        [Parameter(Mandatory)][System.Windows.Controls.MenuItem]$Parent,
        [Parameter(Mandatory)][string]$Text,
        [Parameter(Mandatory)][string]$Target
    )

    $it = New-Object System.Windows.Controls.MenuItem
    $it.Header = $Text
    $it.Tag = $Target
    try {
        $style = $Parent.TryFindResource('AppMenuItemStyle')
        if ($style) { $it.Style = $style }
    } catch {}

    $it.add_Click({
        param($s,$e)
        $t = [string]$s.Tag
        try {
            if ($t -match '^(?i)https?://') {
                Start-Process -FilePath $t
            }
            elseif (Test-Path -LiteralPath $t) {
                $gi = Get-Item -LiteralPath $t
                if ($gi.PSIsContainer) {
                    Start-Process -FilePath explorer.exe -ArgumentList "`"$t`""
                } else {
                    Start-Process -FilePath $t
                }
            } else {
                Show-AppMessage -Message ("Hittar inte sökvägen:`n{0}" -f $t) -Title 'Genväg' -Icon Warning | Out-Null
            }
        } catch {
            Show-AppMessage -Message ("Kunde inte öppna:`n{0}`n{1}" -f $t, $_.Exception.Message) -Title 'Genväg' -Icon Error | Out-Null
        }
    })

    [void]$Parent.Items.Add($it)
    return $it
}

function Set-WpfToolTips {
    if (-not $script:UI -or -not $script:UI.Controls) { return }
    try {
        $script:UI.Controls['TxtLSP'].ToolTip = 'Ange LSP-numret utan "#" och klicka på Sök filer.'
        $script:UI.Controls['BtnLspBrowse'].ToolTip = 'Bläddra efter LSP Worksheet.'
        if ($script:UI.Controls['MiToggleSign']) {
            $script:UI.Controls['MiToggleSign'].ToolTip = 'Visa eller dölj panelen för att lägga till signatur.'
        }
    } catch {}
}

function Initialize-WpfGui {
    param(
        [Parameter(Mandatory)][string]$ScriptVersion,
        [string]$IconPath
    )

    Import-WpfAssemblies

    $xamlPath = Join-Path $script:WpfGuiRoot 'MainWindow.xaml'
    $window = Import-WpfXamlWindow -Path $xamlPath
    if ($window -isnot [System.Windows.Window]) {
        throw 'MainWindow.xaml laddades inte som WPF Window.'
    }

    $named = @{}
    $expectedNames = @(
        'MainWindow','MainMenu','MiArkiv','MiVerktyg','MiSettings','MiHelp','MiAbout','MiScan','MiBuild','MiExit',
        'MiNew','MiOpenRecent','MiScript1','MiScript2','MiScript3','MiScript4','MiScript5','MiToggleSign',
        'MiGenvagar','MiTheme','MiLightTheme','MiDarkTheme','MiShowInstr','MiFAQ','MiHelpDlg','MiOm',
        'PicLogo','LblTitle','LblUpdate','LblExtra','LblLSP','TxtLSP','BtnScan','GrpDl','LblDl','BtnMove4','BtnMove3',
        'LogBorder','OutputBox','GrpPick','LblCsv','LblNeg','LblPos','LblWorksheet','ClbCsv','ClbNeg','ClbPos','ClbLsp',
        'BtnCsvBrowse','BtnNegBrowse','BtnPosBrowse','BtnLspBrowse','BtnCsvAll','BtnCsvNone','BtnNegNone','BtnPosNone','BtnLspNone',
        'GrpSign','TxtSigner','ChkWriteSign','ChkOverwriteSign','BtnBuild',
        'StatusHost','StatusCountText','StatusWorkText','StatusProgress','StatusSpButton','StatusBatchLink',
        'HeaderBorder','SearchBorder','MainContent'
    )
    foreach ($n in $expectedNames) {
        try {
            $ctrl = $window.FindName($n)
            if ($ctrl) { $named[$n] = $ctrl }
        } catch {}
    }

    $script:UI = @{
        IsWpf    = $true
        Window   = $window
        Controls = $named
        Theme    = 'light'
    }

    $window.Title = "IPTCompile – $ScriptVersion"
    if ($named['LblTitle']) { $named['LblTitle'].Text = "IPTCompile – $ScriptVersion" }

    try {
        if ($IconPath -and (Test-Path -LiteralPath $IconPath)) {
            $bmp = New-Object System.Windows.Media.Imaging.BitmapImage
            $bmp.BeginInit()
            $bmp.CacheOption = [System.Windows.Media.Imaging.BitmapCacheOption]::OnLoad
            $bmp.UriSource = New-Object System.Uri($IconPath)
            $bmp.EndInit()
            try { $bmp.Freeze() } catch {}
            if ($named['PicLogo']) { $named['PicLogo'].Source = $bmp }
        }
    } catch {
        try { Gui-Log ("⚠️ Kunde inte ladda ikon: " + $_.Exception.Message) 'Warn' } catch {}
    }

    # Wrappers / kompatibilitetslager för existerande Main.ps1-logik
    $formShim = New-WpfFormShim -Window $window
    $grpSignShim = New-WpfVisibilityShim -Control $named['GrpSign']

    $btnScanShim = New-WpfButtonShim -Control $named['BtnScan']
    $btnBuildShim = New-WpfButtonShim -Control $named['BtnBuild']
    $btnCsvBrowseShim = New-WpfButtonShim -Control $named['BtnCsvBrowse']
    $btnNegBrowseShim = New-WpfButtonShim -Control $named['BtnNegBrowse']
    $btnPosBrowseShim = New-WpfButtonShim -Control $named['BtnPosBrowse']
    $btnLspBrowseShim = New-WpfButtonShim -Control $named['BtnLspBrowse']
    $btnMove3Shim = New-WpfButtonShim -Control $named['BtnMove3']
    $btnMove4Shim = New-WpfButtonShim -Control $named['BtnMove4']
    $btnSpConnectShim = New-WpfButtonShim -Control $named['StatusSpButton']
    $slBatchLinkShim = New-WpfButtonShim -Control $named['StatusBatchLink']

    $chkWriteSignShim = New-WpfCheckBoxShim -Control $named['ChkWriteSign']
    $chkOverwriteSignShim = New-WpfCheckBoxShim -Control $named['ChkOverwriteSign']

    $clbCsvShim = New-WpfCheckedListBoxShim -ListBox $named['ClbCsv']
    $clbNegShim = New-WpfCheckedListBoxShim -ListBox $named['ClbNeg']
    $clbPosShim = New-WpfCheckedListBoxShim -ListBox $named['ClbPos']
    $clbLspShim = New-WpfCheckedListBoxShim -ListBox $named['ClbLsp']

    $slCountShim = New-WpfTextBlockShim -Control $named['StatusCountText']
    $slWorkShim = New-WpfTextBlockShim -Control $named['StatusWorkText']
    $pbWorkShim = New-WpfProgressBarShim -Control $named['StatusProgress']
    $statusShim = New-WpfStatusShim -Control $named['StatusHost']

    $menuShimNames = @(
        'MiArkiv','MiVerktyg','MiSettings','MiHelp','MiAbout','MiScan','MiBuild','MiExit',
        'MiNew','MiOpenRecent','MiScript1','MiScript2','MiScript3','MiScript4','MiScript5','MiToggleSign',
        'MiGenvagar','MiTheme','MiLightTheme','MiDarkTheme','MiShowInstr','MiFAQ','MiHelpDlg','MiOm'
    )
    $menuWrappers = @{}
    foreach ($mn in $menuShimNames) {
        if ($named[$mn] -is [System.Windows.Controls.MenuItem]) {
            $menuWrappers[$mn] = New-WpfMenuItemShim -Control $named[$mn]
        }
    }

    # Exponera scriptvariabler med samma namn som WinForms-versionen använde.
    Set-Variable -Scope Script -Name form -Value $formShim -Force
    Set-Variable -Scope Script -Name grpSign -Value $grpSignShim -Force
    Set-Variable -Scope Script -Name btnScan -Value $btnScanShim -Force
    Set-Variable -Scope Script -Name btnBuild -Value $btnBuildShim -Force
    Set-Variable -Scope Script -Name btnCsvBrowse -Value $btnCsvBrowseShim -Force
    Set-Variable -Scope Script -Name btnNegBrowse -Value $btnNegBrowseShim -Force
    Set-Variable -Scope Script -Name btnPosBrowse -Value $btnPosBrowseShim -Force
    Set-Variable -Scope Script -Name btnLspBrowse -Value $btnLspBrowseShim -Force
    Set-Variable -Scope Script -Name btnMove3 -Value $btnMove3Shim -Force
    Set-Variable -Scope Script -Name btnMove4 -Value $btnMove4Shim -Force
    Set-Variable -Scope Script -Name txtLSP -Value $named['TxtLSP'] -Force
    Set-Variable -Scope Script -Name txtSigner -Value $named['TxtSigner'] -Force
    Set-Variable -Scope Script -Name chkWriteSign -Value $chkWriteSignShim -Force
    Set-Variable -Scope Script -Name chkOverwriteSign -Value $chkOverwriteSignShim -Force
    Set-Variable -Scope Script -Name clbCsv -Value $clbCsvShim -Force
    Set-Variable -Scope Script -Name clbNeg -Value $clbNegShim -Force
    Set-Variable -Scope Script -Name clbPos -Value $clbPosShim -Force
    Set-Variable -Scope Script -Name clbLsp -Value $clbLspShim -Force
    Set-Variable -Scope Script -Name outputBox -Value $named['OutputBox'] -Force
    Set-Variable -Scope Script -Name status -Value $statusShim -Force
    Set-Variable -Scope Script -Name slCount -Value $slCountShim -Force
    Set-Variable -Scope Script -Name slWork -Value $slWorkShim -Force
    Set-Variable -Scope Script -Name pbWork -Value $pbWorkShim -Force
    Set-Variable -Scope Script -Name slBatchLink -Value $slBatchLinkShim -Force
    Set-Variable -Scope Script -Name baseHeight -Value ([double]$window.Height) -Force

    foreach ($mn in $menuWrappers.Keys) {
        $varName = ($mn.Substring(0,1).ToLowerInvariant() + $mn.Substring(1))
        Set-Variable -Scope Script -Name $varName -Value $menuWrappers[$mn] -Force
    }

    # För kompatibilitet med existerande kod som använder $script:btnMove3 / $script:btnSpConnect
    $script:btnMove3 = $btnMove3Shim
    $script:btnSpConnect = $btnSpConnectShim

    # SharePoint statusknapp initial state (motsvarar WinForms-logiken i GUI-bygget)
    if ($global:SpConnected) {
        $script:btnSpConnect.Text = '✅ SP'
        $script:btnSpConnect.ToolTipText = 'SharePoint är anslutet.'
        $script:btnSpConnect.Enabled = $false
    } elseif ($global:SpEnabled) {
        $script:btnSpConnect.Text = '🔌 Anslut SP'
        $script:btnSpConnect.ToolTipText = 'Klicka för att ansluta till SharePoint (tar ~10–15 sek).'
        $script:btnSpConnect.Enabled = $true
    } else {
        $script:btnSpConnect.Text = '⛔ SP av'
        $script:btnSpConnect.ToolTipText = 'SharePoint är avstängt i konfigurationen.'
        $script:btnSpConnect.Enabled = $false
    }

    # SharePoint On-Demand Connect-knapp (samma beteende som WinForms, men med DispatcherTimer-wrapper)
    $script:btnSpConnect.add_Click({
        if (-not $global:SpEnabled) { return }
        if ($global:SpConnected) { return }
        if ($global:SpConnecting) { return }

        $script:btnSpConnect.Text        = '⏳ Ansluter…'
        $script:btnSpConnect.Enabled     = $false
        $script:btnSpConnect.ToolTipText = 'Ansluter till SharePoint – vänta…'

        Show-Splash 'Förbereder SharePoint…'

        $startOk = Start-SPClient -ProgressCallback { param($m) Update-Splash $m }
        if (-not $startOk) {
            Close-Splash
            $script:btnSpConnect.Text        = '❌ SP – retry?'
            $script:btnSpConnect.ToolTipText = "Misslyckades: $($global:SpError)`nKlicka för att försöka igen."
            $script:btnSpConnect.Enabled     = $true
            Gui-Log ('⚠️ SharePoint-förberedelse misslyckades: ' + $global:SpError) 'Warn'
            return
        }

        Update-Splash 'Loggar in…'
        $asyncOk = Connect-SPClientAsync
        if (-not $asyncOk) {
            Close-Splash
            $script:btnSpConnect.Text        = '❌ SP – retry?'
            $script:btnSpConnect.ToolTipText = "Misslyckades: $($global:SpError)`nKlicka för att försöka igen."
            $script:btnSpConnect.Enabled     = $true
            Gui-Log ('⚠️ Kunde inte starta SP-anslutning: ' + $global:SpError) 'Warn'
            return
        }

        $script:spPollTimer = New-WpfTimerShim -Interval 200
        $script:spPollTimer.add_Tick({
            $result = Poll-SPClientAsync
            if ($null -eq $result) { return }

            $script:spPollTimer.Stop()
            $script:spPollTimer.Dispose()
            $script:spPollTimer = $null
            Close-Splash

            if ($result.Ok) {
                $script:btnSpConnect.Text        = '✅ SP'
                $script:btnSpConnect.ToolTipText = 'SharePoint anslutet.'
                $script:btnSpConnect.Enabled     = $false
                Gui-Log '✅ SharePoint anslutet.' 'Info'
            } else {
                $script:btnSpConnect.Text        = '❌ SP – retry?'
                $script:btnSpConnect.ToolTipText = "Misslyckades: $($global:SpError)`nKlicka för att försöka igen."
                $script:btnSpConnect.Enabled     = $true
                Gui-Log ('⚠️ SharePoint-anslutning misslyckades: ' + $global:SpError) 'Warn'
            }
        })
        $script:spPollTimer.Start()
    })

    # Länk i statusrad (WPF-knapp stylad som länk)
    $slBatchLinkShim.add_Click({
        if ($slBatchLinkShim.Enabled -and $slBatchLinkShim.Tag) {
            try { Start-Process -FilePath ([string]$slBatchLinkShim.Tag) } catch {
                Show-AppMessage -Message ("Kunde inte öppna:`n{0}`n{1}" -f $slBatchLinkShim.Tag, $_.Exception.Message) -Title 'Länk' -Icon Error | Out-Null
            }
        }
    })

    # Dev-hotkey + Escape (WPF ersätter WinForms form.KeyDown)
    $window.add_PreviewKeyDown({
        param($s,$e)
        try {
            $key = if ($e.Key -eq [System.Windows.Input.Key]::System) { $e.SystemKey } else { $e.Key }
            $mods = [System.Windows.Input.Keyboard]::Modifiers

            if ($key -eq [System.Windows.Input.Key]::Escape) {
                $s.Close()
                $e.Handled = $true
                return
            }

            $hasCtrl = (($mods -band [System.Windows.Input.ModifierKeys]::Control) -ne 0)
            $hasAlt  = (($mods -band [System.Windows.Input.ModifierKeys]::Alt) -ne 0)
            if ($hasCtrl -and $hasAlt -and $key -eq [System.Windows.Input.Key]::T) {
                if ($script:btnMove3) {
                    $script:btnMove3.Visible = -not $script:btnMove3.Visible
                    try {
                        if ($script:btnMove3.Visible) { Gui-Log 'TEST-knapp synlig (Ctrl+Alt+T för att gömma).' 'Info' }
                        else { Gui-Log 'TEST-knapp dold.' 'Info' }
                    } catch {}
                }
                $e.Handled = $true
            }
        } catch {}
    })

    # Signatur-enable/disable
    $chkWriteSign.add_CheckedChanged({ $chkOverwriteSign.Enabled = $chkWriteSign.Checked })

    # LSP browse (fanns tidigare i WinForms GUI-regionen)
    $btnLspBrowse.Add_Click({
        try {
            $dlg = New-Object Microsoft.Win32.OpenFileDialog
            $dlg.Filter = 'Excel|*.xlsx;*.xlsm|Alla filer|*.*'
            $dlg.Title  = 'Välj LSP Worksheet'
            if ($dlg.ShowDialog() -eq $true) {
                $f = Get-Item -LiteralPath $dlg.FileName
                Add-CLBItems -clb $clbLsp -files @($f) -AutoCheckFirst
                if (Get-Command Update-StatusBar -ErrorAction SilentlyContinue) { Update-StatusBar }
            }
        } catch {
            Gui-Log ('⚠️ LSP-browse fel: ' + $_.Exception.Message) 'Warn'
        }
    })

    # Markera alla/inga (där relevant)
    $named['BtnCsvAll'].add_Click({
        try {
            for ($i=0; $i -lt $clbCsv.Items.Count; $i++) { $clbCsv.SetItemChecked($i, ($i -lt 2)) }
            if ($clbCsv.Items.Count -gt 2) { Gui-Log 'ℹ️ CSV: Markera alla väljer max 2 filer (Original + Resample).' 'Info' }
        } catch {}
        try { Update-BuildEnabled } catch {}
    })
    $named['BtnCsvNone'].add_Click({
        try { for ($i=0; $i -lt $clbCsv.Items.Count; $i++) { $clbCsv.SetItemChecked($i, $false) } } catch {}
        try { Update-BuildEnabled } catch {}
        try { Update-BatchLink } catch {}
    })
    $named['BtnNegNone'].add_Click({
        try { for ($i=0; $i -lt $clbNeg.Items.Count; $i++) { $clbNeg.SetItemChecked($i, $false) } } catch {}
        try { Update-BuildEnabled } catch {}
        try { Update-BatchLink } catch {}
    })
    $named['BtnPosNone'].add_Click({
        try { for ($i=0; $i -lt $clbPos.Items.Count; $i++) { $clbPos.SetItemChecked($i, $false) } } catch {}
        try { Update-BuildEnabled } catch {}
        try { Update-BatchLink } catch {}
    })
    $named['BtnLspNone'].add_Click({
        try { for ($i=0; $i -lt $clbLsp.Items.Count; $i++) { $clbLsp.SetItemChecked($i, $false) } } catch {}
        try { Update-BuildEnabled } catch {}
    })

    # Dynamiska genvägar från Config.ShortcutGroups
    try {
        $miG = $named['MiGenvagar']
        if ($miG) {
            $miG.Items.Clear()
            $ShortcutGroups = Get-ConfigValue -Name 'ShortcutGroups' -Default $null -ConfigOverride $Config
            if (-not $ShortcutGroups) {
                $ShortcutGroups = @{
                    '🗂️ IPT-mappar' = @(
                        @{ Text='📂 IPT - PÅGÅENDE KÖRNINGAR';        Target='N:\QC\QC-1\IPT\2. IPT - PÅGÅENDE KÖRNINGAR' },
                        @{ Text='📂 IPT - KLART FÖR SAMMANSTÄLLNING'; Target='N:\QC\QC-1\IPT\3. IPT - KLART FÖR SAMMANSTÄLLNING' },
                        @{ Text='📂 IPT - KLART FÖR GRANSKNING';      Target='N:\QC\QC-1\IPT\4. IPT - KLART FÖR GRANSKNING' },
                        @{ Text='📂 SPT Macro Assay';                 Target='N:\QC\QC-0\SPT\SPT macros\Assay' }
                    )
                    '📄 Dokument' = @(
                        @{ Text='🧰 Utrustningslista'; Target=$UtrustningListPath },
                        @{ Text='🧪 Kontrollprovsfil'; Target=$RawDataPath }
                    )
                }
            }

            foreach ($grp in $ShortcutGroups.GetEnumerator()) {
                $grpMenu = New-Object System.Windows.Controls.MenuItem
                $grpMenu.Header = [string]$grp.Key
                try {
                    $style = $miG.TryFindResource('AppMenuItemStyle')
                    if ($style) { $grpMenu.Style = $style }
                } catch {}

                foreach ($entry in @($grp.Value)) {
                    Add-WpfShortcutMenuItem -Parent $grpMenu -Text ([string]$entry.Text) -Target ([string]$entry.Target) | Out-Null
                }
                [void]$miG.Items.Add($grpMenu)
            }
        }
    } catch {
        try { Gui-Log ('⚠️ Kunde inte bygga genvägsmeny: ' + $_.Exception.Message) 'Warn' } catch {}
    }

    # Koppla Gui-Log till WPF-loggtextbox
    try { Set-LogOutputControl -Control $named['OutputBox'] } catch {}

    Set-WpfToolTips
    Set-WpfThemeResources -Theme 'light'

    # Exponera fler råa kontroller för WPF-hjälpfunktioner om de behövs
    $script:UI.Wrappers = @{
        Form = $formShim
        ClbCsv = $clbCsvShim
        ClbNeg = $clbNegShim
        ClbPos = $clbPosShim
        ClbLsp = $clbLspShim
        BtnScan = $btnScanShim
        BtnBuild = $btnBuildShim
        BtnSpConnect = $btnSpConnectShim
        SlBatchLink = $slBatchLinkShim
        PbWork = $pbWorkShim
    }

    return $window
}
