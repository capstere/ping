﻿$script:SplashForm = $null
$script:SplashLabel = $null

$global:Splash = $null

function Show-Splash([string]$msg = "Startar…") {
    try { Add-Type -AssemblyName PresentationFramework,PresentationCore,WindowsBase -ErrorAction Stop } catch {}

    try {
        if ($global:Splash -and $global:Splash.Window) {
            Update-Splash $msg
            return
        }

        $w = New-Object System.Windows.Window
        $w.WindowStyle = 'None'
        $w.ResizeMode = 'NoResize'
        $w.ShowInTaskbar = $false
        $w.Topmost = $true
        $w.WindowStartupLocation = 'CenterScreen'
        $w.Width = 420
        $w.Height = 120
        $w.Background = (New-Object System.Windows.Media.SolidColorBrush ([System.Windows.Media.Color]::FromRgb(0,120,215)))

        $grid = New-Object System.Windows.Controls.Grid
        $grid.Margin = '0'

        $lbl = New-Object System.Windows.Controls.TextBlock
        $lbl.Text = ''
        $lbl.Foreground = [System.Windows.Media.Brushes]::White
        $lbl.FontSize = 12
        $lbl.FontWeight = 'SemiBold'
        $lbl.TextAlignment = 'Center'
        $lbl.VerticalAlignment = 'Center'
        $lbl.HorizontalAlignment = 'Center'
        $lbl.TextWrapping = 'Wrap'
        $lbl.Margin = '18'

        $grid.Children.Add($lbl) | Out-Null
        $w.Content = $grid
        $w.Show()

        $global:Splash = @{ Window = $w; Label = $lbl }
        Update-Splash $msg
    } catch {
        try { Write-Host ("[Splash] {0}" -f $msg) } catch {}
    }
}

function Update-Splash([string]$msg) {
    if (-not $global:Splash) { return }
    try {
        $w = $global:Splash.Window
        $lbl = $global:Splash.Label
        if (-not $w -or -not $lbl) { return }

        if ($w.Dispatcher -and -not $w.Dispatcher.CheckAccess()) {
            $null = $w.Dispatcher.Invoke([action]{ $lbl.Text = $msg; try { $w.UpdateLayout() } catch {} })
        } else {
            $lbl.Text = $msg
            try { $w.UpdateLayout() } catch {}
        }
    } catch {}
}

function Close-Splash() {
    if (-not $global:Splash) { return }
    try {
        $w = $global:Splash.Window
        if ($w) {
            if ($w.Dispatcher -and -not $w.Dispatcher.CheckAccess()) {
                $null = $w.Dispatcher.Invoke([action]{ try { $w.Close() } catch {} })
            } else {
                try { $w.Close() } catch {}
            }
        }
    } catch {}
    $global:Splash = $null
}
