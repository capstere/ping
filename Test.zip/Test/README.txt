I zip-filen finns:

MISQAUNT_SampleID_062024MOWA_00_1_05X_Xpert HBV Viral Load #31402 Tests Summary.xlsx ger korrekt MISQUANT i output-report.
MISQAUNT_SampleID_050525Masa_10_1_13X_Xpert_HCV Viral Load #52504 Tests Summary.xlsx ger inte MISQUANT i output-report.
MIQAUNT_ALL_PC2_Xpert HIV-1 Viral Load XC #30301 Tests Summary.xlsx ger inte MISQUANT i output-report.
MISQAUNT_SampleId_071924MATE_06_1_12X and Ct Fail PC2 Original+Replacement_Xpert_HIV-1 Viral Load  #78703 Tests Summary.xlsx ger inte MISQUANT i output-report.
MISQAUNT_SampleId_031225Masa_06_1_11X_Xpert HCV VL Fingerstick #16802 Tests Summary ger inte MISQUANT i output-report.






For Assay:

Sample Type 1 och 2
Log Titer:
=IF('Test Summary'!$B$3="","",IF(COUNTIF('Data - Sample Type 1'!L2,'Data Summary'!$D$126)=1,LOG('Data - Sample Type 1'!BG2),"N/A"))

HCV Ct:
=IF('Test Summary'!$B$3="","",IF(COUNTIF('Data - Sample Type 1'!L2,'Data Summary'!$D$126)=1,'Data - Sample Type 1'!Q2,"N/A"))

IQS-H Ct:
=IF('Test Summary'!$B$3="","",IF(COUNTIF('Data - Sample Type 1'!L2,'Data Summary'!$D$126)=1,'Data - Sample Type 1'!AE2,"N/A"))

IQS-L Ct:
=IF('Test Summary'!$B$3="","",IF(COUNTIF('Data - Sample Type 1'!L2,'Data Summary'!$D$126)=1,'Data - Sample Type 1'!AS2,"N/A"))

Sample Type 0
IQS-H Ct:
=IF('Test Summary'!$B$3="","",IF(COUNTIF('Data - Sample Type 0'!L2,'Data Summary'!$D$21)=1,'Data - Sample Type 0'!AE2,"N/A"))

IQS-L Ct:
=IF('Test Summary'!$B$3="","",IF(COUNTIF('Data - Sample Type 0'!L2,'Data Summary'!$D$21)=1,'Data - Sample Type 0'!AS2,"N/A"))


(Only Assay: HIV-1 Viral Load XC IUO, HIV-1 Viral Load XC RUO and Xpert HIV-1 Viral Load XC)
Sample Type 1 och 2
HIV-1 EPF:
=IF('Test Summary'!$B$3="","",IF(COUNTIF('Data - Sample Type 1'!L2,'Data Summary'!$D$126)=1,'Data - Sample Type 1'!R2,"N/A"))



Är det en PC1 eller en PC2 så finns alltid:
Test Result från rad 10 kolumn L och nedåt i CSV-filen.
HxV Ct från rad 10 och kolumn Q och nedåt i CSV-filen.
IQS-H Ct från rad 10 och kolumn AE och nedåt i CSV-filen. (gäller även PC0 *Negative*)
IQS-L Ct från rad 10 och kolumn AS och nedåt i CSV-filen. (gäller även PC0 *Negative*)
Quantitative Value från rad 10 och kolumn BG och nedåt i CSV-filen. (om du behöver den).

Från Assay Xpert HIV-1 Viral Load XC, HIV-1 Viral Load XC IUO och HIV-1 Viral Load XC RUO hämtar vi även HIV-1 EPF för PC1 och PC2 från CSV-filen från rad 10 och kolumn R.

Baserat på våra konstanter, kan du implementera detta nu?











Absolut – här är en samlad, komplett specifikation av dina konstanter, fältpositioner och beslutsregler så att du (eller teamet) kan implementera/validera allt själv utan mina filer.
________________________________________
1) CSV layout: fasta kolumner (rad 10 och nedåt)
Dessa gäller oavsett rubriknamn i CSV.
(Du skrev uttryckligen att din data är sorterad och att RuleEngine får färdiginlästa rader.)
•	Test Result = kolumn L (från rad 10)
•	HxV Ct (för PC1 och PC2) = kolumn Q
•	IQS H Ct (även PC0/Negative) = kolumn AE
•	IQS L Ct (även PC0/Negative) = kolumn AS
•	Quantitative Value (om du behöver det) = kolumn BG
•	HIV 1 EPF (endast för Xpert HIV 1 Viral Load XC / HIV 1 Viral Load XC IUO/RUO, PC1 & PC2) = kolumn R
Tips (robustisering):
•	Konvertera decimalkomma → punkt före parsing (Replace(',', '.')).
•	Plausibilitetsgräns för Ct: 10–45. Om Ct ligger utanför → behandla Ct som “saknas” (så att per test Ct MISQ inte felaktigt triggas).
________________________________________
2) Härledning av ControlCode (PC kod)
•	ControlCode (PC0/PC1/PC2) kommer från Sample ID.
I dina filer är det tredje segmentet (0/1/2) när man splittrar på _.
Ex: 050525Masa_10_1_13X → ControlCode = "1".
________________________________________
3) Assay namn och matchning
•	Normalisering: Byt _ → ” ” (blanksteg) innan matchning (ex. Xpert_HCV Viral Load ↔ Xpert HCV Viral Load).
•	MatchTyper i banken: 
o	EQUALS – exakt strängjämförelse (efter normalisering).
o	WILDCARD – * blir regex .* (resten Escape()as).
o	REGEX – rå regex mot normaliserat assay.
•	Varning (ditt legacy data): Fler radiga AssayPattern (typ ^(A\nB)$) matchar aldrig enradiga assaysträngar; skriv om till alternation ^(?:A|B)$.
(Jag skickade även en sanerad compiled bank där detta är fixat.)
________________________________________
4) Beslutsregler för MISQUANTITATION (Log Titer)
Gäller när ObservedCall = POS (positiv).
(För NEG/PC0 finns separata regler – inte i scope här.)
4.1 FailMode (per assay/PC kod)
•	DYNAMIC_FROM_CT (PC1/PC2) 
o	Ct används för att beräkna ExpectedLog (linjär interpolation mellan CtMin↔AvgLogMax och CtMax↔AvgLogMin).
o	MISQ om ObservedLog ∉ [ExpectedLog − SDMax, ExpectedLog + SDMax].
o	Ct i sig ger inte per test MISQ (om du inte medvetet kör “strict PC1 Ct”).
o	EPFMin (om angiven) kan fälla per test (t.ex. HIV 1 VL XC).
•	GROUP_AVG_SD 
o	Ingen per test MISQ; gruppfunktioner beräknar medel/SD och sprayar ev. på PC2.
•	OUTSIDE / OUTSIDE_OR_EQUAL 
o	Per test jämförelse mot absoluta Min/Max eller ≤/≥ varianter.
“Strict PC1 Ct” (valfri policy): Om påslagen → MISQ för PC1 direkt när Ct ∉ [CtMin, CtMax], innan logik.
Standard i moderna tolkningsflöden för dina assays: AV (off). Aktivera endast om du uttryckligen vill det.
(Jag levererade en motor med gating där DYNAMIC_FROM_CT inte har per test Ct guard aktiv som standard.)
________________________________________
5) Beräkning: ExpectedLog (gäller DYNAMIC_FROM_CT)
Linjär interpolation från tabellvärden:
Given CtMin, CtMax, AvgLogMin (vid CtMax), AvgLogMax (vid CtMin), SDMax:

expectedLog = AvgLogMax - ((Ct - CtMin) / (CtMax - CtMin)) * (AvgLogMax - AvgLogMin)

Fail if ObservedLog < expectedLog - SDMax   OR   ObservedLog > expectedLog + SDMax
(Valfritt) “Log Titer Min/Max” (om de finns i tabellen) kan användas som ytterstopp utöver ±SD bandet.
________________________________________
6) Assay specifika parametrar (från din tabell)
6.1 Xpert HCV Viral Load / HCV Viral Load RUO (”D51112” arket)
•	PC1: 
o	Ct: 33.0–34.4
o	AvgLog: 1.50–1.90
o	SDMax: 0.17
o	Log band: 1.10–2.30 (ytterstopp)
•	PC2: 
o	Ct: 23.6–24.8
o	AvgLog: 4.25–4.55
o	SDMax: 0.12
(IQS H/L fönster finns i tabellen men används inte i denna per test logik.)
6.2 Xpert HCV VL Fingerstick / HCV VL WB RUO
•	PC1: 
o	Ct: 34.6–37.1
o	AvgLog: 2.29–2.67
o	SDMax: 0.200
6.3 Xpert HIV 1 Viral Load / HIV 1 Viral Load RUO
•	PC1: 
o	Ct: 35.51–37.30
o	AvgLog: 2.07–2.53
o	SDMax: 0.200
6.4 HIV 1 Viral Load XC IUO / RUO / Xpert HIV 1 Viral Load XC
•	PC1: 
o	Ct: 33.7–35.9
o	AvgLog: 2.08–2.52
o	SDMax: 0.20
o	EPFMin: 300 (EPF < 300 ⇒ MISQ)
•	PC2: 
o	Ct: 22.6–23.8
o	AvgLog: 5.54–5.86
o	SDMax: 0.10
o	EPFMin: 583 (EPF < 583 ⇒ MISQ)
6.5 Xpert HBV Viral Load
•	PC1: 
o	Ct: 33.0–35.2
o	AvgLog: 1.26–1.70
o	SDMax: 0.20
o	Log band: 0.88–2.08 (ytterstopp)
•	PC2: 
o	Ct: 19.2–20.8
o	AvgLog: 5.54–5.86
o	SDMax: 0.15
Obs: Namnen kan förekomma med eller utan underscore. Matcha efter normalisering (_→ ) och/eller sanera fler radiga patterns i compiled banken.
________________________________________
7) Tolkningspolicy per assay (rekommenderad)
•	HCV VL (PC1/PC2): DYNAMIC_FROM_CT, strict PC1 Ct = NEJ (off).
→ Per test MISQ först när ObservedLog bryter ExpectedLog ± SD (PC1/PC2).
•	HCV VL Fingerstick / HCV VL WB RUO (PC1): DYNAMIC_FROM_CT, strict PC1 Ct = NEJ.
•	HIV 1 VL (RUO / Xpert) (PC1): DYNAMIC_FROM_CT, strict PC1 Ct = NEJ.
•	HIV 1 VL XC (PC1/PC2): DYNAMIC_FROM_CT, strict PC1 Ct = NEJ, EPFMin aktiv (300/583).
•	HBV VL (PC1/PC2): DYNAMIC_FROM_CT, strict PC1 Ct = NEJ, ytterband (0.88–2.08) för PC1.
(Vill du verkligen ha per test MISQ på Ct för PC1 – slå på “strict” per assay. Standard är av.)
________________________________________
8) Snabbkontroll mot din kända batch (HCV VL PC1)
•	För Xpert HCV Viral Load PC1 ska endast 050525Masa_10_1_13X bli MISQ.
Skälet: ObservedLog ≈ 1.20 (”HCV DETECTED 16 IU/mL (log 1.20)”) ligger utanför ExpectedLog ± 0.17 givet dess Ct.
•	Övriga PC1 med log ~1.65–1.90 ska bli OK (förutsatt att deras Ct ≈ 33–34).
•	Ct i sig ger inte MISQ i denna policy (om inte “strict PC1 Ct” aktiveras).
________________________________________
9) Minimalt “check steg” i din kod (pseudologik)
# 1) Läs fält via kolumnbokstäver:
TestResult := Col[L]
Ct        := (PC1/PC2 -> Col[Q]) ; (PC0 -> Col[AE]/Col[AS])
EPF       := (HIV-1 VL XC PC1/PC2 -> Col[R]; annars tomt)
QuantVal  := Col[BG] (om behövs)

# 2) Normalisera Assay (underscore->space), hämta ControlCode från Sample ID.

# 3) Välj regel via AssayPattern & ControlCode -> (FailMode, CtMin, CtMax, AvgLogMin, AvgLogMax, SDMax, EPFMin, LogBandMin/Max)

# 4) DYNAMIC_FROM_CT:
if Ct saknas -> returnera OK (eller hoppa logik, beror på din policy)
ExpectedLog := interp(CtMin,CtMax, AvgLogMax@CtMin, AvgLogMin@CtMax, Ct)
Fail := (ObservedLog < ExpectedLog - SDMax) OR (ObservedLog > ExpectedLog + SDMax)
if EPFMin finns: Fail := Fail OR (EPF < EPFMin)
if Fail => MISQ else OK

# 5) OUTSIDE / OUTSIDE_OR_EQUAL: jämför mot Min/Max.
# 6) GROUP_AVG_SD: per-test = no-op; hanteras i gruppfunktioner.
________________________________________
10) Vanliga fel (och hur du undviker dem)
1.	Ct läses från fel kolumn (t.ex. Max Pressure ≈ 50–60) → “Ct out of spec” på allt.
Lösning: Lås Ct till kolumn Q (PC1/PC2) och validera 10–45.
2.	EPF fel källa (HIV 1 XC) → EPF MISQ tappar/feltriggas.
Lösning: Läs EPF från kolumn R endast för HIV 1 VL XC (PC1/PC2).
3.	AssayPattern fler radigt REGEX → matchar aldrig.
Lösning: Ersätt ^(A\nB)$ med ^(?:A|B)$ i compiled banken. (Jag skickade en sanerad compiled bank.)
4.	Strict Ct på PC1 oavsiktligt påslagen
→ Alla Ct som glider utanför [CtMin,CtMax] ger MISQ, även när log är OK.
Lösning: Håll strict PC1 Ct = NEJ för assays där du förväntar log baserat beslut.
________________________________________
11) Om du vill återanvända mina senaste filer
•	RuleEngine_updated.ps1 – hel motor med kolumnläsning + fail gating + robust matchning.
(Använd den som referens eller lyft endast de sektioner du vill.)
•	RuleBank.compiled.ps1 – compiled med fixade AssayPattern.
________________________________________
Säg bara till om du vill att jag:
•	gör en minimal patch som enbart lägger till kolumnläsning (L/Q/AE/AS/R/BG) i din nuvarande motor utan att röra något annat,
•	lägger in en RuleTrace (per test: vald regel, Ct, ExpectedLog, ±SD, EPF, orsak) för snabb felsökning,
•	eller stänger/öppnar strict Ct per assay (flagga i banken) så du kan styra policyn utan att ändra kod.
Jag vet att detta var segt – men med listan ovan har du allt du behöver för att få exakt samma beslutslogik som i din tabell, reproducerbart och robust.




















Ja – det här hjälper massor. Tack! 🙌
Nedan sammanfattar jag alla konstanter/regler och ger dig en drop in PowerShell patch som följer exakt dina Excel formler/kolumner. Du kan lägga in den i din befintliga motor (EPPlus 4.5.3.3, CSV redan inläst) och köra utan att röra resten av flödet.
________________________________________
✅ Dina konstanter (sammanfattning)
CSV layout (rad 10 och nedåt; oberoende av rubriktext)
•	Test Result: kolumn L
•	HxV Ct (PC1 & PC2): kolumn Q
•	IQS H Ct (även PC0/Negative): kolumn AE
•	IQS L Ct (även PC0/Negative): kolumn AS
•	Quantitative Value (om/när du vill använda den): kolumn BG
•	HIV 1 EPF (endast för Xpert HIV 1 Viral Load XC / HIV 1 Viral Load XC IUO / HIV 1 Viral Load XC RUO, PC1 & PC2): kolumn R
Ct plausibilitet: behandla Ct < 10 eller > 45 som saknas (för att aldrig råka tolka t.ex. Max Pressure ~50–60 som Ct).
PC kod (ControlCode)
•	Hämtas ur Sample ID som tredje segmentet efter _.
Ex: 050525Masa_10_1_13X ⇒ PC1.
Assay matchning
•	Normalisera alltid Assay genom att ersätta _ → mellanslag.
•	Stöd för EQUALS / WILDCARD / REGEX.
•	Fler radiga compiled‐mönster ^(A\nB)$ ska skrivas om till ^(?:A|B)$ (annars matchar de inte enradiga assaysträngar).
MISQUANTITATION (Log Titer) – beslutsregler
•	Kör endast när ObservedCall = POS.
•	FailMode = DYNAMIC_FROM_CT (PC1/PC2) 
o	Ct används för att räkna ExpectedLog via linjär interpolation:
ExpectedLog = AvgLogMax@CtMin − ((Ct − CtMin)/(CtMax − CtMin)) * (AvgLogMax − AvgLogMin)
o	MISQ om ObservedLog ∉ [ExpectedLog − SDMax, ExpectedLog + SDMax].
o	EPFMin (om finns) kan dessutom fälla (HIV 1 VL XC: PC1=300, PC2=583).
o	Strict PC1 Ct: AV som standard (annars MISQ enbart p.g.a. Ct övertramp, vilket du inte vill för HCV VL PC1).
•	FailMode = GROUP_AVG_SD 
o	Inga per test vakter; gruppfunktioner sprayar ev. avvikelser på PC2.
•	FailMode = OUTSIDE/OUTSIDE_OR_EQUAL 
o	Per test jämförelse mot absoluta min/max.
HCV VL PC1 i din batch: endast 050525Masa_10_1_13X ska bli MISQ (p.g.a. låg log), övriga OK.
Det förutsätter att Ct läses från Q (≈33–34), inte från t.ex. Max Pressure (~50–60).
________________________________________
🔧 Drop in patch (PowerShell) – följ dina Excel formler
Syfte: Läsa fälten från exakt de kolumner du angav (L/Q/AE/AS/R/BG), och skriva tillbaka till radens properties innan dina regler körs.
Placering: Lägg blocket innan din Invoke-RuleEngine i RuleEngine.ps1. Lägg sedan till EN rad i din per rad loop (se steg 2).
# =====================
# 1) Hjälp: kolumnbokstav -> cellvärde (på redan inlästa CSV-radobjekt)
# =====================
function Convert-ColLetterToIndex {
    param([Parameter(Mandatory)][string]$Col)
    $s = ($Col + '').Trim().ToUpperInvariant()
    if (-not $s) { return 0 }
    $n = 0
    foreach ($ch in $s.ToCharArray()) {
        if ($ch -lt 'A' -or $ch -gt 'Z') { continue }
        $n = ($n * 26) + ([int][byte][char]$ch - [int][byte][char]'A' + 1)
    }
    return $n
}

function Get-CellByLetter {
    param([Parameter(Mandatory)][object]$Row, [Parameter(Mandatory)][string]$Col)
    $idx = Convert-ColLetterToIndex -Col $Col
    if ($idx -le 0) { return '' }
    try {
        $props = @($Row.PSObject.Properties | Select-Object -ExpandProperty Name)
        if ($props.Count -ge $idx) {
            $name = $props[$idx - 1]
            try { return ($Row.$name + '') } catch { return ((Get-RowField -Row $Row -FieldName $name) + '') }
        }
    } catch {}
    return ''
}

# =====================
# 2) Fältläsning enligt dina Excel-formler/kolumner
# =====================
function Get-ControlCodeFromSampleIdBasic {
    param([Parameter(Mandatory)][string]$SampleId)
    if (-not $SampleId) { return '' }
    $parts = $SampleId.Split('_')
    if ($parts.Count -ge 3) {
        $cc = ($parts[2] + '').Trim()
        if ($cc -match '^\d+
Steg 2 – anropa normaliseringen:
Leta upp innersta per rad loopen i din Invoke-RuleEngine (t.ex. foreach ($row in $group) { ... }) och lägg överst i loopen:
try { Normalize-RowFields-ByColumns -Row $row } catch {}
``
Efter detta kör dina befintliga regler med korrekta 'Test Result', 'Ct', 'EndPt' osv. – precis som dina Excel formler visar.
________________________________________
🧪 Snabb egen validering (rekommenderad)
1.	Kör Xpert HCV VL PC1 på din batch.
2.	Kontrollera att Ct ≈ 33–34 (från Q) och inte ~50–60.
3.	Verifiera att endast 050525Masa_10_1_13X blir MISQ (p.g.a. log utanför ExpectedLog ± SD).
4.	För HIV 1 VL XC PC1/PC2: EPF hämtas från R; MISQ om EPF < 300/583 (eller log utanför band).
________________________________________
Vanligaste orsakerna när “allt blir MISQ (Ct out of spec)”
•	Ct råkade läsas från fel kolumn (t.ex. Max Pressure) → låser vi nu till Q och validerar 10..45.
•	Fler radiga AssayPattern i compiled banken → skriv om till ^(?:A|B)$.
•	“Strict PC1 Ct” råkade vara PÅ → Stäng av för assays där du vill ha log baserat MISQ.
________________________________________
Vill du att jag också lägger in en RuleTrace (per rad: vald regel, Ct, ExpectedLog, ±SD, EPF, orsak) så du ser varför beslutet togs, rad för rad? Det är 5–7 rader extra i Apply-* som jag kan skicka – säg bara till. ) { return $cc }
    }
    return ''
}

function Get-TestResult-BySpec       { param([object]$Row) return (Get-CellByLetter -Row $Row -Col 'L') }   # Test Result = L
function Get-QuantValue-BySpec       { param([object]$Row) return (Get-CellByLetter -Row $Row -Col 'BG') }  # Quant Value = BG (valfritt)
function Get-EPF-FromR               { param([object]$Row) return (Get-CellByLetter -Row $Row -Col 'R') }   # EPF = R (HIV-1 XC PC1/PC2)

function Get-Ct-BySpec {
    param([object]$Row, [string]$ControlCode)
    $raw = ''
    switch ($ControlCode) {
        '1' { $raw = Get-CellByLetter -Row $Row -Col 'Q' }  # PC1: HxV Ct (Q)
        '2' { $raw = Get-CellByLetter -Row $Row -Col 'Q' }  # PC2: HxV Ct (Q)
        '0' {
            $raw = Get-CellByLetter -Row $Row -Col 'AE'     # PC0: IQS-H Ct (AE)
            if (-not $raw) { $raw = Get-CellByLetter -Row $Row -Col 'AS' } # fallback IQS-L Ct (AS)
        }
        default { $raw = Get-CellByLetter -Row $Row -Col 'Q' }
    }
    # Plausibilitet 10..45 → annars returnera tomt (skydd mot t.ex. Max Pressure)
    try {
        $tmp = (($raw + '').Trim().Replace(',', '.'))
        if ($tmp) {
            $d = [double]$tmp
            if ($d -ge 10 -and $d -le 45) { return $tmp }
        }
    } catch {}
    return ''
}

function Needs-EPF-FromR {
    param([string]$Assay, [string]$ControlCode)
    if ($ControlCode -notin @('1','2')) { return $false }
    $a = (($Assay + '') -replace '_',' ').ToUpperInvariant()
    # Gäller för: Xpert HIV-1 Viral Load XC, HIV-1 Viral Load XC IUO, HIV-1 Viral Load XC RUO
    return ($a -match 'HIV-1 VIRAL LOAD XC')
}

# =====================
# 3) Normalisering av varje rad före regelkörning
# =====================
function Normalize-RowFields-ByColumns {
    param([Parameter(Mandatory)][object]$Row)

    $sid   = ((Get-RowField -Row $Row -FieldName 'Sample ID') + '')
    $assay = ((Get-RowField -Row $Row -FieldName 'Assay') + '')
    $cc    = Get-ControlCodeFromSampleIdBasic -SampleId $sid

    # Test Result (L)
    $tr = Get-TestResult-BySpec -Row $Row
    if ($tr) { try { $Row.'Test Result' = $tr } catch { $Row | Add-Member -NotePropertyName 'Test Result' -NotePropertyValue $tr -Force } }

    # Ct (Q för PC1/PC2; AE/AS för PC0)
    $ct = Get-Ct-BySpec -Row $Row -ControlCode $cc
    if ($ct) { try { $Row.'Ct' = $ct } catch { $Row | Add-Member -NotePropertyName 'Ct' -NotePropertyValue $ct -Force } }

    # EPF (R för HIV 1 VL XC PC1/PC2)
    if (Needs-EPF-FromR -Assay $assay -ControlCode $cc) {
        $epf = Get-EPF-FromR -Row $Row
        if ($epf) { try { $Row.'EndPt' = $epf } catch { $Row | Add-Member -NotePropertyName 'EndPt' -NotePropertyValue $epf -Force } }
    }

    # (Valfritt) Quantitative Value från BG – kan användas som fallback
    $qv = Get-QuantValue-BySpec -Row $Row
    if ($qv) { try { $Row.'Quantitative Value' = $qv } catch { $Row | Add-Member -NotePropertyName 'Quantitative Value' -NotePropertyValue $qv -Force } }
}
Steg 2 – anropa normaliseringen:
Leta upp innersta per rad loopen i din Invoke-RuleEngine (t.ex. foreach ($row in $group) { ... }) och lägg överst i loopen:
{{1-raw-markdown-7156cc28-c687-42a4-8435-22aba50bf56c}}
Efter detta kör dina befintliga regler med korrekta 'Test Result', 'Ct', 'EndPt' osv. – precis som dina Excel formler visar.
________________________________________
🧪 Snabb egen validering (rekommenderad)
1.	Kör Xpert HCV VL PC1 på din batch.
2.	Kontrollera att Ct ≈ 33–34 (från Q) och inte ~50–60.
3.	Verifiera att endast 050525Masa_10_1_13X blir MISQ (p.g.a. log utanför ExpectedLog ± SD).
4.	För HIV 1 VL XC PC1/PC2: EPF hämtas från R; MISQ om EPF < 300/583 (eller log utanför band).
________________________________________
Vanligaste orsakerna när “allt blir MISQ (Ct out of spec)”
•	Ct råkade läsas från fel kolumn (t.ex. Max Pressure) → låser vi nu till Q och validerar 10..45.
•	Fler radiga AssayPattern i compiled banken → skriv om till ^(?:A|B)$.
•	“Strict PC1 Ct” råkade vara PÅ → Stäng av för assays där du vill ha log baserat MISQ.
________________________________________
Vill du att jag också lägger in en RuleTrace (per rad: vald regel, Ct, ExpectedLog, ±SD, EPF, orsak) så du ser varför beslutet togs, rad för rad? Det är 5–7 rader extra i Apply-* som jag kan skicka – säg bara till.
































Kort svar: 3 av 4 blir garanterat MISQUANT med din nuvarande patchade motor och bank. Den fjärde (HCV VL PC1 med Ct = 35,7) blir inte MISQUANT om vi tillåter linjär extrapolering utanför Ct intervallet och inte kör “strict PC1 Ct”. För att få 4/4 enligt din etikettering behöver vi antingen:
	A) slå på strict PC1 Ct för just Xpert_HCV Viral Load (PC1), eller
	B) klampa Ct till [CtMin, CtMax] innan ExpectedLog beräknas i DYNAMIC_FROM_CT.
Allt nedan bygger på de uppdaterade filer jag skickade (motor + compiled bank) och på dina egna specifikationer.
________________________________________
Varje rad, med beräkning → beslut
Notation: PC1 intervall tas från din tabell. ExpectedLog beräknas linjärt mellan (CtMin→AvgLogMax) och (CtMax→AvgLogMin), och beslut tas mot ExpectedLog ± SDMax. (Precis så är DYNAMIC_FROM_CT implementerad i motorn.)
1) Xpert HBV Viral Load – PC1
Rad: POS_00_1_05X
Input: Ct = 33,6 (inom 33,0–35,2), log = 2,08
Param (PC1): AvgLog 1,26–1,70; SDMax 0,20.
ExpectedLog:
f=(33,6-33,0)/(35,2-33,0)≈0,273,E=1,70-f⋅(1,70-1,26)≈1,58
Band: ├ "\[" 1,38ⓜ,ⓜ,1,78]. Observed 2,08 > 1,78 ⇒ MISQ (hög log).
Motorn kommer att sätta MISQUANTITATION (Log titer outside spec).
________________________________________
2) Xpert_HCV Viral Load – PC1
Rad: 050525Masa_10_1_13X
Input: Ct = 35,7 (UTANFÖR 33,0–34,4), log = 1,20
Param (PC1): AvgLog 1,50–1,90; SDMax 0,17.
	Nuvarande motor (extrapolering, strict OFF):
f=(35,7-33,0)/(34,4-33,0)≈1,93,E=1,90-f⋅(1,90-1,50)≈1,13
Band: ├ "\[" 0,96ⓜ,ⓜ,1,30]. Observed 1,20 ligger INOM bandet ⇒ inte MISQ.
	Vad krävs för MISQ (enligt din etikett):
Välj Ett av följande:
	A) Strict PC1 Ct ON för HCV PC1 ⇒ MISQ (Ct out of spec) direkt när Ct ∉ [33,0–34,4]. (Motorn stödjer strict i DYNAMIC_FROM_CT, default OFF.)
	B) Klampa Ct till intervallet: använd Ct_"model"=min⁡(max⁡(Ct,CtMin),CtMax). Då Ct_"model"=34,4, E=1,50, band ├ "\[" 1,33ⓜ,1,67], Observed 1,20 < 1,33 ⇒ MISQ.
Slutsats: Med nuvarande motor (strict OFF, ingen klamp) blir denna inte MISQ. För att få 4/4 enligt dina etiketter: slå på strict eller lägg in klamp i DYNAMIC_FROM_CT.
________________________________________
3) Xpert HCV VL Fingerstick – PC1
Rad: 031225Masa_06_1_11X
Input: Ct = 39,4 (UTANFÖR 34,6–37,1), log = 2,00
Param (PC1): AvgLog 2,29–2,67; SDMax 0,200.
	Utan klamp (extrapolering): 
f=(39,4-34,6)/(37,1-34,6)≈1,92,E=2,67-f⋅(2,67-2,29)≈1,56
Band: ├ "\[" 1,36ⓜ,ⓜ,1,76]. Observed 2,00 > 1,76 ⇒ MISQ (hög log).
(Med klamp skulle ├ E∈"\[" 2,29,2,67]och band ≈ ├ "\[" 2,09ⓜ,2,87]; då 2,00 hamnar under bandet ⇒ fortfarande MISQ men med motsatt riktning. Båda fallen ger MISQ.)
________________________________________
4) Xpert HIV 1 Viral Load XC – PC1
Rad: 112824ELIF_04_1_17+
Input: Ct = 34,9 (inom 33,7–35,9), EPF = 389 (≥ 300 OK), log = 2,91
Param (PC1): AvgLog 2,08–2,52; SDMax 0,20; EPFMin=300.
f=(34,9-33,7)/(35,9-33,7)≈0,545,E=2,52-f⋅(2,52-2,08)≈2,28
Band: ├ "\[" 2,08ⓜ,ⓜ,2,48]. Observed 2,91 > 2,48 ⇒ MISQ (hög log). (EPF är över tröskeln, så EPF fäller inte.) Motorn detekterar detta.
________________________________________
Svar på din fråga
	HBV VL PC1 → MISQ (ja).
	HCV VL PC1 (Ct = 35,7) → inte MISQ med nuvarande motor (extrapolering + strict OFF). För MISQ enligt din etikett, aktivera strict PC1 Ct eller lägg in Ct klamp i DYNAMIC_FROM_CT. (Se patch nedan.)
	HCV VL Fingerstick PC1 → MISQ (ja).
	HIV 1 VL XC PC1 → MISQ (ja). EPF läses från kolumn R (PC1/PC2) enligt din spec.
Med andra ord: 3/4 direkt – 4/4 så fort vi slår på strict Ct för just HCV PC1 eller inför Ct klamp.
________________________________________
Minimal kodändring (rekommenderad: Ct klamp i DYNAMIC_FROM_CT)
För att följa “ingen per test Ct MISQ” men ändå undvika extrapolering (som i ditt case gav falskt OK), klampa Ct till specifikationsfönstret innan ExpectedLog beräknas:
# I Apply-LogTiterQuantSpec, i grenen $mode -eq 'DYNAMIC_FROM_CT':
# ... efter att $dCtMin, $dCtMax, $ctVal, $dAvgMin, $dAvgMax, $dSDMax är satta

# Klampa Ct till intervallet (ingen per-test MISQ på Ct; vi använder klampat Ct ENBART i modellen)
$ctForModel = $ctVal
if ($ctForModel -lt $dCtMin) { $ctForModel = $dCtMin }
elseif ($ctForModel -gt $dCtMax) { $ctForModel = $dCtMax }

# Beräkna ExpectedLog med klampat Ct
$expectedLog = $dAvgMax - (($ctForModel - $dCtMin) / ($dCtMax - $dCtMin)) * ($dAvgMax - $dAvgMin)

# Beslut som tidigare:
if ($logVal -lt ($expectedLog - $dSDMax) -or $logVal -gt ($expectedLog + $dSDMax)) { $fail = $true }
Den här mikro patchen gör att din HCV VL PC1 (Ct = 35,7) blir MISQ (Observed 1,20 < 1,33), utan att införa strict Ct MISQ.
Alternativet är att slå på strict PC1 Ct för Xpert_HCV Viral Load (PC1) – då blir den MISQ p.g.a. “Ct out of spec”. Båda vägarna ger 4/4.
________________________________________
Var detta implementeras i dina filer
	Motorns logik och gating (DYNAMIC_FROM_CT, EPF, m.m.) finns redan i RuleEngine_patched.txt som du fick. Lägg in Ct klampen i funktionen Apply-LogTiterQuantSpec enligt blocket ovan.
	Compiled banken du fick är sanerad för fler radiga AssayPattern → korrekt matchning mot Xpert HCV VL, HCV VL RUO, HIV 1 VL XC, HBV VL osv.
Vill du att jag skickar en ny RuleEngine_patched.txt där klampen redan är inlagd (och/eller en version med strict PC1 Ct = ON endast för HCV PC1)? Säg bara hur du vill ha policyn, så genererar jag filen exakt därefter.

