function Test-UiVar { param([object]$o) return ($null -ne $o) }

function Get-DataSheets { param([OfficeOpenXml.ExcelPackage]$Pkg)
    $all = @($Pkg.Workbook.Worksheets | Where-Object { $_.Name -ne "Worksheet Instructions" })
    if ($all.Count -gt 1) { return $all | Select-Object -Skip 1 } else { return @() }
}

function Test-SignatureFormat {
    param([string]$Text)
    $raw = ($Text + '')
    $trim = $raw.Trim()
    $parts = $trim -split '\s*,\s*'
    $name = if ($parts.Count -ge 1) { $parts[0] } else { '' }
    $sign = if ($parts.Count -ge 2) { $parts[1] } else { '' }
    $date = if ($parts.Count -ge 3) { $parts[2] } else { '' }
    $dateOk = $false
    if ($date) { if ($date -match '^\d{4}-\d{2}-\d{2}$' -or $date -match '^\d{8}$') { $dateOk = $true } }
    [pscustomobject]@{ Raw=$raw; Name=$name; Sign=$sign; Date=$date; Parts=$parts.Count; DateOk=$dateOk; LooksOk=($name -ne '' -and $sign -ne '') }
}

function Confirm-SignatureInput { param([string]$Text)
    $info = Test-SignatureFormat $Text
    $hint = @()
    if (-not $info.Name) { $hint += '• Namn verkar saknas' }
    if (-not $info.Sign) { $hint += '• Signatur verkar saknas' }
    $msg = "Har du skrivit korrekt 'Print Full Name, Sign, and Date'?
Text: $($info.Raw)
Tolkning:
  • Namn   : $($info.Name)
  • Sign   : $($info.Sign)
  • Datum  : $($info.Date)
" + ($(if ($hint.Count){ "Obs:`n  " + ($hint -join "`n  ") } else { "Ser bra ut." }))
    $res = [System.Windows.Forms.MessageBox]::Show($msg, "Bekräfta signatur", 'YesNo', 'Question')
    return ($res -eq 'Yes')
}

function Normalize-Signature {
    param([string]$s)
    if (-not $s) { return '' }
    $x = $s.Trim().ToLowerInvariant()
    $x = [regex]::Replace($x, '\s+', ' ')
    $x = $x -replace '\s*,\s*', ','
    return $x
}
 
function Get-SignatureSetForDataSheets {
    param([OfficeOpenXml.ExcelPackage]$Pkg)
    $result = [pscustomobject]@{
        RawFirst  = $null
        NormSet   = New-Object 'System.Collections.Generic.HashSet[string]'
        Occ       = @{}
        RawByNorm = @{} 
    }
    if (-not $Pkg) { return $result }

    foreach ($ws in ($Pkg.Workbook.Worksheets | Where-Object { $_.Name -ne 'Worksheet Instructions' })) {
        $h3 = ($ws.Cells['H3'].Text + '').Trim()
        if ($h3 -match '^[0-9]') {
            $raw = ($ws.Cells['B47'].Text + '').Trim()
            if ($raw) {
                $norm = Normalize-Signature $raw
                [void]$result.NormSet.Add($norm)
                if (-not $result.RawFirst) { $result.RawFirst = $raw }
                if (-not $result.Occ.ContainsKey($norm)) {
                    $result.Occ[$norm] = New-Object 'System.Collections.Generic.List[string]'
                }
                if (-not $result.RawByNorm.ContainsKey($norm)) {
                    $result.RawByNorm[$norm] = $raw
                }
                [void]$result.Occ[$norm].Add($ws.Name)
            }
        } elseif ([string]::IsNullOrWhiteSpace($h3) -or $h3 -match '^(?i)(N\/?A|NA|Tomt( innehåll)?)$') {
            break
        }
    }
    return $result
}

function UrlEncode([string]$s){ try { [System.Uri]::EscapeDataString($s) } catch { $s } }

function Get-BatchNumberFromSealFile([string]$Path){
    if (-not (Test-Path -LiteralPath $Path)) { return $null }
    if (-not (Load-EPPlus)) { return $null }
    $pkg = $null
    try {
        $pkg = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($Path))
        foreach ($ws in (Get-DataSheets $pkg)) {
            $txt = ($ws.Cells['D2'].Text + '').Trim()   # Batchnummer från D2
            if ($txt) { return $txt }
        }
    } catch {
        Gui-Log "⚠️ Kunde inte läsa Batch # från Seal-fil: $($_.Exception.Message)" 'Warn'
    } finally { if ($pkg) { try { $pkg.Dispose() } catch {} } }
    return $null
}

function Update-BatchLink {
    # Skydd: avbryt om UI inte är initierat ännu
    if (-not (Get-Variable -Name slBatchLink -Scope Script -ErrorAction SilentlyContinue) -and -not (Get-Variable -Name slBatchLink -Scope Global -ErrorAction SilentlyContinue)) { return }
    try {
        $selNeg = Get-CheckedFilePath $clbNeg
        $selPos = Get-CheckedFilePath $clbPos
        $bnNeg  = if ($selNeg) { Get-BatchNumberFromSealFile $selNeg } else { $null }
        $bnPos  = if ($selPos) { Get-BatchNumberFromSealFile $selPos } else { $null }
        $lsp    = $txtLSP.Text.Trim()
        $mismatch = ($bnNeg -and $bnPos -and ($bnNeg -ne $bnPos))
        if ($mismatch) {
            $slBatchLink.Text        = 'SharePoint: mismatch'
            $slBatchLink.Enabled     = $false
            $slBatchLink.Tag         = $null
            $slBatchLink.ToolTipText = "NEG: $bnNeg  |  POS: $bnPos"
            return
        }
        $batch = if ($bnPos) { $bnPos } elseif ($bnNeg) { $bnNeg } else { $null }
        if ($batch) {
            $url = $SharePointBatchLinkTemplate -replace '\{BatchNumber\}', (UrlEncode $batch) -replace '\{LSP\}', (UrlEncode $lsp)

            $slBatchLink.Text        = "SharePoint: $batch"
            $slBatchLink.Enabled     = $true
            $slBatchLink.Tag         = $url
            $slBatchLink.ToolTipText = $url
        } else {
            $slBatchLink.Text        = 'SharePoint: —'
            $slBatchLink.Enabled     = $false
            $slBatchLink.Tag         = $null
            $slBatchLink.ToolTipText = 'Direktlänk aktiveras när Batch# hittas i sökt LSP.'
        }
    } catch {
        Gui-Log "⚠️ Kunde inte uppdatera SharePoint-länk: $($_.Exception.Message)" 'Warn'
    }
}

# =============================================================
# Worksheet-signatur  (Sammanställning / Granskning)
# =============================================================

function Confirm-WorksheetSignInput {
    param([string]$FullName, [string]$SignDate, [string[]]$Targets)
    $targetList = ($Targets | ForEach-Object { "  • $_" }) -join "`n"
    $msg = "Signera Worksheet med följande uppgifter?`n`n" +
           "  Namn  : $FullName`n" +
           "  Datum : $SignDate`n`n" +
           "Flikar som påverkas:`n$targetList"
    $res = [System.Windows.Forms.MessageBox]::Show($msg, 'Bekräfta Worksheet-signatur', 'YesNo', 'Question')
    return ($res -eq 'Yes')
}

function Write-WorksheetSignatures {
<#
.SYNOPSIS
  Skriver namn och datum i signaturfält i en Worksheet-fil.
.PARAMETER Pkg
  Öppet EPPlus-paket för Worksheet-filen.
.PARAMETER FullName
  Förnamn Efternamn att skriva in.
.PARAMETER SignDate
  Datumsträng att skriva in.
.PARAMETER Mode
  'Sammanstallning' – skriver Recorded By / Performed By-fält.
  'Granskning'      – skriver PQC Reviewed By-fält.
.OUTPUTS
  PSCustomObject med .Written (string[]) och .Skipped (string[]).
#>
    param(
        [Parameter(Mandatory)][OfficeOpenXml.ExcelPackage]$Pkg,
        [Parameter(Mandatory)][string]$FullName,
        [Parameter(Mandatory)][string]$SignDate,
        [Parameter(Mandatory)][ValidateSet('Sammanstallning','Granskning')][string]$Mode
    )

    # Definitioner: varje entry beskriver exakt vilka kolumner som ska sökas och skrivas.
    #   LabelCol      = kolumn som innehåller namnlabel  (Recorded By: / Performed By: etc.)
    #   Labels        = vilka strängar som matchar (exakt match, Trim)
    #   NameCol       = kolumn att skriva namn i
    #   DateLabelCol  = kolumn som innehåller "Date:"-label
    #   DateCol       = kolumn att skriva datum i
    #   Offset        = 0 = samma rad som label;  -1 = raden ovanför label

    if ($Mode -eq 'Sammanstallning') {
        $defs = @(
            @{ Sheet='Test Summary';                LabelCol=2;  Labels=@('Recorded By:');                  NameCol=3;  DateLabelCol=9;  DateCol=10; Offset=0  }
            @{ Sheet='Data Summary';                LabelCol=1;  Labels=@('Recorded By:');                  NameCol=2;  DateLabelCol=3;  DateCol=4;  Offset=0  }
            @{ Sheet='Extra Data Summary';          LabelCol=1;  Labels=@('Recorded By:');                  NameCol=2;  DateLabelCol=3;  DateCol=4;  Offset=0  }
            @{ Sheet='Resample Date Summary';       LabelCol=1;  Labels=@('Recorded By:');                  NameCol=2;  DateLabelCol=3;  DateCol=4;  Offset=0  }
            @{ Sheet='Seal Test Failure Count';     LabelCol=11; Labels=@('Performed By:','Recorded By:');  NameCol=12; DateLabelCol=11; DateCol=12; Offset=-1 }
            @{ Sheet='Statistical Process Control'; LabelCol=11; Labels=@('Performed By:','Recorded By:');  NameCol=12; DateLabelCol=11; DateCol=12; Offset=-1 }
            @{ Sheet='Vacuum Seal Data';            LabelCol=2;  Labels=@('Recorded By:');                  NameCol=3;  DateLabelCol=4;  DateCol=6;  Offset=0  }
        )
    } else {
        # Granskning – enbart Test Summary
        $defs = @(
            @{ Sheet='Test Summary'; LabelCol=2; Labels=@('PQC Reviewed By:'); NameCol=3; DateLabelCol=9; DateCol=10; Offset=0 }
        )
    }

    $written = [System.Collections.Generic.List[string]]::new()
    $skipped = [System.Collections.Generic.List[string]]::new()

    foreach ($def in $defs) {
        $ws = $Pkg.Workbook.Worksheets[$def.Sheet]
        if (-not $ws) { $skipped.Add($def.Sheet); continue }

        $dim = $ws.Dimension
        if (-not $dim) { $skipped.Add($def.Sheet); continue }
        $maxRow = $dim.End.Row

        $nameWritten = $false
        $dateWritten = $false

        # --- 1. Sök namnlabel och skriv namn ---
        for ($r = 1; $r -le $maxRow; $r++) {
            $cellText = ($ws.Cells[$r, $def.LabelCol].Text + '').Trim()
            $matched = $false
            foreach ($lbl in $def.Labels) {
                if ($cellText -eq $lbl) { $matched = $true; break }
            }
            if (-not $matched) { continue }

            $nameTargetRow = $r + $def.Offset
            if ($nameTargetRow -ge 1) {
                $ws.Cells[$nameTargetRow, $def.NameCol].Style.Numberformat.Format = '@'
                $ws.Cells[$nameTargetRow, $def.NameCol].Value = $FullName
                $nameWritten = $true
            }
            # --- 2. Sök 'Date:' separat i DateLabelCol (rad kan variera mellan assays)
 → Sök "Date:" separat i DateLabelCol ---
        if (-not $dateWritten) {
            for ($r = 1; $r -le $maxRow; $r++) {
                $cellText = ($ws.Cells[$r, $def.DateLabelCol].Text + '').Trim()
                if ($cellText -eq 'Date:') {
                    $dateTargetRow = $r + $def.Offset
                    if ($dateTargetRow -ge 1) {
                        $ws.Cells[$dateTargetRow, $def.DateCol].Style.Numberformat.Format = '@'
                        $ws.Cells[$dateTargetRow, $def.DateCol].Value = $SignDate
                        $dateWritten = $true
                    }
                    break
                }
            }
        }

        if ($nameWritten -or $dateWritten) {
            $detail = @()
            if ($nameWritten) { $detail += 'namn' }
            if ($dateWritten) { $detail += 'datum' }
            $written.Add("$($def.Sheet) ($($detail -join '+'))")
        } else {
            $skipped.Add($def.Sheet)
        }
    }

    return [pscustomobject]@{ Written=@($written); Skipped=@($skipped) }
}
