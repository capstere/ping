﻿function Test-UiVar { param([object]$o) return ($null -ne $o) }

function Get-DataSheets { param([OfficeOpenXml.ExcelPackage]$Pkg)
    $all = @($Pkg.Workbook.Worksheets | Where-Object { $_.Name -ne "Worksheet Instructions" })
    if ($all.Count -gt 1) { return $all | Select-Object -Skip 1 } else { return @() }
}

function Test-SignatureFormat {
    param([string]$Text)
    $raw = ($Text + '')
    $trim = $raw.Trim()
    $parts = $trim -split '\s*,\s*'
    $name = if ($parts.Count -ge 1) { $parts[0] } else { '' }
    $sign = if ($parts.Count -ge 2) { $parts[1] } else { '' }
    $date = if ($parts.Count -ge 3) { $parts[2] } else { '' }
    $dateOk = $false
    if ($date) { if ($date -match '^\d{4}-\d{2}-\d{2}$' -or $date -match '^\d{8}$') { $dateOk = $true } }
    [pscustomobject]@{ Raw=$raw; Name=$name; Sign=$sign; Date=$date; Parts=$parts.Count; DateOk=$dateOk; LooksOk=($name -ne '' -and $sign -ne '') }
}

function Confirm-SignatureInput { param([string]$Text)
    $info = Test-SignatureFormat $Text
    $hint = @()
    if (-not $info.Name) { $hint += 'Namn verkar saknas' }
    if (-not $info.Sign) { $hint += 'Signatur verkar saknas' }
    $sep = [string]::new([char]0x2500, 34)
    $status = if ($hint.Count) { "OBS: " + ($hint -join ', ') } else { "Ser bra ut." }
    $msg = "SEAL TEST  —  Bekräfta signatur`n" +
           "$sep`n`n" +
           "  Namn       $($info.Name)`n" +
           "  Signatur   $($info.Sign)`n" +
           "  Datum      $($info.Date)`n`n" +
           "$sep`n" +
           "$status`n`n" +
           "Vill du fortsätta?"
    $res = [System.Windows.Forms.MessageBox]::Show($msg, 'Seal Test-signatur', 'YesNo', 'Question')
    return ($res -eq 'Yes')
}

function Normalize-Signature {
    param([string]$s)
    if (-not $s) { return '' }
    $x = $s.Trim().ToLowerInvariant()
    $x = [regex]::Replace($x, '\s+', ' ')
    $x = $x -replace '\s*,\s*', ','
    return $x
}
 
function Get-SignatureSetForDataSheets {
    param([OfficeOpenXml.ExcelPackage]$Pkg)
    $result = [pscustomobject]@{
        RawFirst  = $null
        NormSet   = New-Object 'System.Collections.Generic.HashSet[string]'
        Occ       = @{}
        RawByNorm = @{} 
    }
    if (-not $Pkg) { return $result }

    foreach ($ws in ($Pkg.Workbook.Worksheets | Where-Object { $_.Name -ne 'Worksheet Instructions' })) {
        $h3 = ($ws.Cells['H3'].Text + '').Trim()
        if ($h3 -match '^[0-9]') {
            $raw = ($ws.Cells['B47'].Text + '').Trim()
            if ($raw) {
                $norm = Normalize-Signature $raw
                [void]$result.NormSet.Add($norm)
                if (-not $result.RawFirst) { $result.RawFirst = $raw }
                if (-not $result.Occ.ContainsKey($norm)) {
                    $result.Occ[$norm] = New-Object 'System.Collections.Generic.List[string]'
                }
                if (-not $result.RawByNorm.ContainsKey($norm)) {
                    $result.RawByNorm[$norm] = $raw
                }
                [void]$result.Occ[$norm].Add($ws.Name)
            }
        } elseif ([string]::IsNullOrWhiteSpace($h3) -or $h3 -match '^(?i)(N\/?A|NA|Tomt( innehåll)?)$') {
            break
        }
    }
    return $result
}

function UrlEncode([string]$s){ try { [System.Uri]::EscapeDataString($s) } catch { $s } }

function Get-BatchNumberFromSealFile([string]$Path){
    if (-not (Test-Path -LiteralPath $Path)) { return $null }
    if (-not (Load-EPPlus)) { return $null }
    $pkg = $null
    try {
        $pkg = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($Path))
        foreach ($ws in (Get-DataSheets $pkg)) {
            $txt = ($ws.Cells['D2'].Text + '').Trim()   # Batchnummer från D2
            if ($txt) { return $txt }
        }
    } catch {
        Gui-Log "⚠️ Kunde inte läsa Batch # från Seal-fil: $($_.Exception.Message)" 'Warn'
    } finally { if ($pkg) { try { $pkg.Dispose() } catch {} } }
    return $null
}

function Update-BatchLink {
    # Skydd: avbryt om UI inte är initierat ännu
    if (-not (Get-Variable -Name slBatchLink -Scope Script -ErrorAction SilentlyContinue) -and -not (Get-Variable -Name slBatchLink -Scope Global -ErrorAction SilentlyContinue)) { return }
    try {
        $selNeg = Get-CheckedFilePath $clbNeg
        $selPos = Get-CheckedFilePath $clbPos
        $bnNeg  = if ($selNeg) { Get-BatchNumberFromSealFile $selNeg } else { $null }
        $bnPos  = if ($selPos) { Get-BatchNumberFromSealFile $selPos } else { $null }
        $lsp    = $txtLSP.Text.Trim()
        $mismatch = ($bnNeg -and $bnPos -and ($bnNeg -ne $bnPos))
        if ($mismatch) {
            $slBatchLink.Text        = 'SharePoint: mismatch'
            $slBatchLink.Enabled     = $false
            $slBatchLink.Tag         = $null
            $slBatchLink.ToolTipText = "NEG: $bnNeg  |  POS: $bnPos"
            return
        }
        $batch = if ($bnPos) { $bnPos } elseif ($bnNeg) { $bnNeg } else { $null }
        if ($batch) {
            $url = $SharePointBatchLinkTemplate -replace '\{BatchNumber\}', (UrlEncode $batch) -replace '\{LSP\}', (UrlEncode $lsp)

            $slBatchLink.Text        = "SharePoint: $batch"
            $slBatchLink.Enabled     = $true
            $slBatchLink.Tag         = $url
            $slBatchLink.ToolTipText = $url
        } else {
            $slBatchLink.Text        = 'SharePoint: —'
            $slBatchLink.Enabled     = $false
            $slBatchLink.Tag         = $null
            $slBatchLink.ToolTipText = 'Direktlänk aktiveras när Batch# hittas i sökt LSP.'
        }
    } catch {
        Gui-Log "⚠️ Kunde inte uppdatera SharePoint-länk: $($_.Exception.Message)" 'Warn'
    }
}

# =============================================================
# Worksheet-signatur  (Sammanställning / Granskning)
# =============================================================

function Confirm-WorksheetSignInput {
    param([string]$FullName, [string]$SignDate, [string[]]$Targets)
    $sep = [string]::new([char]0x2500, 34)
    $targetList = ($Targets | ForEach-Object { "    $_" }) -join "`n"
    $msg = "WORKSHEET  —  Bekräfta signatur`n" +
           "$sep`n`n" +
           "  Namn     $FullName`n" +
           "  Datum    $SignDate`n`n" +
           "$sep`n" +
           "Flikar som signeras:`n$targetList`n`n" +
           "Vill du fortsätta?"
    $res = [System.Windows.Forms.MessageBox]::Show($msg, 'Worksheet-signatur', 'YesNo', 'Question')
    return ($res -eq 'Yes')
}

# =============================================================
# GDP-SAFE: Forensik och verifiering
# =============================================================

function Save-ForensicSnapshot {
    <#
    .SYNOPSIS
        Kopierar workbook + skriver forensisk loggfil vid signeringsfel.
    #>
    param(
        [Parameter(Mandatory=$true)][string]$SourcePath,
        [Parameter(Mandatory=$true)][string]$Reason,
        [Parameter(Mandatory=$false)][string]$AuditDir,
        [Parameter(Mandatory=$false)][hashtable]$Details = @{}
    )
    try {
        if (-not $AuditDir) { $AuditDir = Join-Path $PSScriptRoot 'audit' }
        $forensicDir = Join-Path $AuditDir 'forensics'
        if (-not (Test-Path -LiteralPath $forensicDir)) {
            New-Item -ItemType Directory -Path $forensicDir -Force | Out-Null
        }

        $ts = (Get-Date).ToString('yyyyMMdd_HHmmss')
        $leaf = Split-Path $SourcePath -Leaf
        $snapName = "${ts}_${env:USERNAME}_${leaf}"
        $snapPath = Join-Path $forensicDir $snapName

        # Kopiera workbook
        if (Test-Path -LiteralPath $SourcePath) {
            Copy-Item -LiteralPath $SourcePath -Destination $snapPath -Force -ErrorAction Stop
        }

        # Skriv forensisk logg
        $logPath = Join-Path $forensicDir "${ts}_${env:USERNAME}_forensic.log"
        $logLines = @(
            "FORENSIC SIGNATURE LOG"
            "======================"
            "Tidpunkt:    $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
            "Användare:   $env:USERNAME"
            "Dator:       $env:COMPUTERNAME"
            "Källfil:     $SourcePath"
            "Snapshot:    $snapPath"
            "Orsak:       $Reason"
        )
        foreach ($k in $Details.Keys) {
            $logLines += "${k}: $($Details[$k])"
        }
        Set-Content -LiteralPath $logPath -Value ($logLines -join "`r`n") -Encoding UTF8

        return $snapPath
    } catch {
        # Forensik-sparande ska aldrig krascha signeringsflödet
        try { Gui-Log "⚠️ Kunde inte spara forensisk snapshot: $($_.Exception.Message)" 'Warn' } catch {}
        return $null
    }
}

function Verify-SealTestSignatures {
    <#
    .SYNOPSIS
        GDP-säker read-back: öppnar Seal Test-fil med EPPlus och verifierar
        att B47 matchar förväntat värde i alla aktiva datablad.
    .RETURNS
        PSCustomObject med OK, SheetsChecked, Mismatches
    #>
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [Parameter(Mandatory=$true)][string]$ExpectedText,
        [Parameter(Mandatory=$true)][string]$SignatureCell,
        [Parameter(Mandatory=$true)][string]$ActiveCheckCell,
        [Parameter(Mandatory=$true)][int]$ExpectedWritten
    )

    $result = [pscustomobject]@{
        OK             = $false
        SheetsChecked  = 0
        SheetsVerified = 0
        Mismatches     = New-Object System.Collections.Generic.List[string]
        Error          = $null
    }

    if (-not (Test-Path -LiteralPath $Path)) {
        $result.Error = "Filen finns inte: $Path"
        return $result
    }

    $pkg = $null
    try {
        $pkg = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($Path))
        foreach ($ws in $pkg.Workbook.Worksheets) {
            if ($ws.Name -eq 'Worksheet Instructions') { continue }
            $h3 = ($ws.Cells[$ActiveCheckCell].Text + '').Trim()
            if ($h3 -match '^[0-9]') {
                $result.SheetsChecked++
                $actual = ($ws.Cells[$SignatureCell].Text + '').Trim()
                if ($actual -eq $ExpectedText) {
                    $result.SheetsVerified++
                } else {
                    [void]$result.Mismatches.Add("$($ws.Name): Förväntade='$ExpectedText' Faktisk='$actual'")
                }
            }
            elseif ([string]::IsNullOrWhiteSpace($h3) -or $h3 -match '^(?i)(N\/?A|NA|Tomt( innehåll)?)$') {
                break
            }
        }

        if ($result.Mismatches.Count -eq 0 -and $result.SheetsVerified -ge $ExpectedWritten) {
            $result.OK = $true
        }
    } catch {
        $result.Error = $_.Exception.Message
    } finally {
        try { if ($pkg) { $pkg.Dispose() } } catch {}
    }
    return $result
}

function Verify-WorksheetSignatures {
    <#
    .SYNOPSIS
        GDP-säker read-back för Worksheet-signaturer.
        Använder EPPlus (samma motor som Seal Test-verifiering).
        OpenXML SDK:s read-only ChildElements-enumeration är opålitlig
        för read-back — EPPlus läser cellvärden korrekt varje gång.
    .PARAMETER Path
        Sökväg till Worksheet-filen.
    .PARAMETER WrittenCells
        Lista med PSCustomObject: Sheet (fliknamn), Row (int), Col (bokstav), Value (förväntat)
    .RETURNS
        PSCustomObject med OK, CellsChecked, CellsVerified, Mismatches, Error
    #>
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [Parameter(Mandatory=$true)][object[]]$WrittenCells
    )

    $result = [pscustomobject]@{
        OK             = $false
        CellsChecked   = 0
        CellsVerified  = 0
        Mismatches     = New-Object System.Collections.Generic.List[string]
        Error          = $null
    }

    if (-not $WrittenCells -or $WrittenCells.Count -eq 0) {
        $result.OK = $true
        return $result
    }

    if (-not (Test-Path -LiteralPath $Path)) {
        $result.Error = "Filen finns inte: $Path"
        return $result
    }

    $pkg = $null
    try {
        $pkg = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($Path))

        foreach ($wc in $WrittenCells) {
            $result.CellsChecked++
            $ws = $pkg.Workbook.Worksheets[$wc.Sheet]
            if (-not $ws) {
                [void]$result.Mismatches.Add("$($wc.Sheet) $($wc.Col)$($wc.Row): Fliken hittades inte")
                continue
            }

            $cellAddr = "$($wc.Col)$($wc.Row)"
            $actual = ($ws.Cells[$cellAddr].Text + '').Trim()
            $expected = ($wc.Value + '').Trim()

            if ($actual -eq $expected) {
                $result.CellsVerified++
            } else {
                [void]$result.Mismatches.Add("$($wc.Sheet) ${cellAddr}: Förväntade='$expected' Faktisk='$actual'")
            }
        }

        $result.OK = ($result.Mismatches.Count -eq 0 -and $result.CellsVerified -eq $WrittenCells.Count)
    } catch {
        $result.Error = $_.Exception.Message
    } finally {
        try { if ($pkg) { $pkg.Dispose() } } catch {}
    }
    return $result
}


# Write-WorksheetSignatures (EPPlus) har ersatts av Invoke-WorksheetSignature_OpenXml i OpenXmlHelpers.ps1