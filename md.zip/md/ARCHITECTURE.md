# ARCHITECTURE

## Huvudflöde (GUI)

```text
WinForms (Main.ps1)
  -> Läser UI-state
  -> New-RunContext (Core/Context)
  -> Invoke-BuildPipeline (Core/BuildPipeline)
     -> Stage-ResolveInputs
     -> Stage-Validate
     -> Stage-LoadData
     -> Stage-RunRules
     -> Stage-WriteReport
     -> Stage-ApplySignatures
     -> Stage-Finalize
  -> Core/Pipeline (CSV selection, worksheet-signering orchestration)
  -> DataHelpers (CSV import, EPPlus)
  -> RuleEngine + RuleBank (klassning)
  -> OpenXmlHelpers / SignatureHelpers (signering + verifiering)
  -> EPPlus outputskrivning
  -> Logging/Audit
```

## Pipeline Stages (Canon)

```text
Invoke-BuildPipeline
  +-- Stage-ResolveInputs
  +-- Stage-Validate
  +-- Stage-LoadData
  +-- Stage-RunRules
  +-- Stage-WriteReport
  +-- Stage-ApplySignatures
  `-- Stage-Finalize
```

## Huvudflöde (Headless)

```text
tools/run_build_headless.ps1
  -> New-RunContext (Headless=true)
  -> Invoke-BuildPipeline (samma canon stage-väg som GUI)
  -> output_*.xlsx + audit_*.csv

tools/run_regression.ps1 -Mode Build
  -> run_build_headless.ps1 för valda case
  -> asserts på output/audit/celler
  -> skriver alltid RegressionReport.md/json (även vid bootstrap-fel)
```

## Modulansvar (nuvarande)

- `Main.ps1`: UI + orkestrering.
- `Modules/Core/Pipeline.ps1`: core logik flyttad från Main i FAS 2.
- `Modules/Core/Context.ps1`: `RunContext`-modell + validering.
- `Modules/Core/BuildPipeline.ps1`: central build-entrypoint (GUI + headless).
- `Modules/OpenXmlHelpers.ps1`: OpenXML signeringsplan/invoke/verifiering.
- `Modules/DataHelpers.ps1`: EPPlus load, CSV read/parse, snapshot, utility.
- `Modules/RuleEngine.ps1`: RuleBank + klassningsmotor.
- `Modules/SignatureHelpers.ps1`: signaturdialog/verifieringshelpers.
- `Modules/Logging.ps1`: GUI-logg, strukturerad logg, audit entry.
- `Modules/Config.ps1`: env/config/path-resolution.
- `Modules/SharePointClient.ps1`: SP/PnP-klient.
- `Modules/UiStyling.ps1`, `Modules/Splash.ps1`: UI-stöd.

## FAS 2-flytt (genomförd)

```text
Main.ps1 (före)
  - Test-IsResampleCsv
  - Inline CSV primary/resample klassificering
  - Inline worksheet-signeringsplan (Samm/Gransk)
  - Inline worksheet-signeringsinvoke per mode

Main.ps1 (efter)
  - Kallar Core/Pipeline:
      Resolve-CsvSelection
      Get-WorksheetSignDialogTargets_OpenXml
      Invoke-WorksheetSigningModes_OpenXml
```

## DRY-källa för worksheet-signering

```text
OpenXmlHelpers.ps1
  Get-WorksheetSignatureTargets_OpenXml        <-- source of truth targets
  Resolve-WorksheetSignatureRows_OpenXml       <-- source of truth row-resolver
  Get-WorksheetSignaturePlan_OpenXml           <-- använder båda
  Invoke-WorksheetSignature_OpenXml            <-- använder båda
```

## Kända återstående förbättringar

- ReportWriter är ännu inte brutits ut till egen Excel-modul.
