# IPTCompile Dead Code Removal — Refactoring Report

**Date:** 2026-02-11  
**Total lines removed:** 220 (7014 → 6794 across 4 files)  
**Behavior change:** None  

---

## Applied Patches

### Patch 1 — Remove `Test-UiVar` (SignatureHelpers.ps1)
**Lines removed:** 2  
**Evidence:** Defined on line 1, **0 call sites** in entire repository.  
**Diff:**
```diff
-function Test-UiVar { param([object]$o) return ($null -ne $o) }
-
 function Get-DataSheets ...
```

---

### Patch 2 — Remove `_SvDeviation` and `_SvSuffixCheck` (RuleEngine.ps1)
**Lines removed:** 25  
**Evidence:** Both defined but **0 call sites**. Prepared Swedish translation functions that were never wired into `Write-RuleEngineDebugSheet` or any other output path. Sibling `_SvRuleFlags` IS used (2 call sites) and was preserved.  
**Diff:**
```diff
 # HJÄLPFUNKTIONER
 # ============================================================================

-# Svensk översättning av Deviation
-function _SvDeviation([string]$d) {
-    $t = (($d + '')).Trim().ToUpperInvariant()
-    switch ($t) {
-        'OK'       { return 'OK' }
-        'FP'       { return 'Falskt positiv' }
-        ... (12 lines)
-    }
-}
-
-# Svensk översättning av SuffixCheck
-function _SvSuffixCheck([string]$s) {
-    $t = (($s + '')).Trim().ToUpperInvariant()
-    switch ($t) {
-        'OK'      { return 'OK' }
-        ... (9 lines)
-    }
-}
-
 # Svensk översättning av RuleFlags
 function _SvRuleFlags([string]$s) {   # ← preserved (used)
```

---

### Patch 3 — Remove `$OtherScriptPath` (Config.ps1)
**Lines removed:** 1  
**Evidence:** Assigned empty string `''` on line 106, **0 references** anywhere in the repository. `$Script1Path`, `$Script2Path`, `$Script3Path` are the active script path variables.  
**Diff:**
```diff
 $RawDataPath = ...
-$OtherScriptPath = ''
-
 $Script1Path = ...
```

---

### Patch 4 — Remove `Write-SPSheet-Safe` (Main.ps1)
**Lines removed:** 192  
**Evidence:** Defined behind a `Get-Command` guard (line 1081), **0 call sites** in entire repository. This function was superseded by `Write-SPBlockIntoInformation` which writes SP info into the existing 'Information' sheet rather than creating a separate worksheet. `Write-SPBlockIntoInformation` has 3 call sites (lines 1305, 3393, 3496) and was preserved.  
**Diff:** (abbreviated — full function removed)
```diff
 })
 
-
-
-if (-not (Get-Command Write-SPSheet-Safe -ErrorAction SilentlyContinue)) {
-    function Write-SPSheet-Safe {
-        param(
-            [OfficeOpenXml.ExcelPackage]$Pkg,
-            [object]$Rows,
-            [string[]]$DesiredOrder,
-            [string]$Batch
-        )
-        ... (~188 lines of SharePoint Info sheet creation)
-        return $true
-    }
-}
-
 # --- Write SharePoint Info block into 'Information' sheet ---
```

---

## Suspected Dead (NOT removed — insufficient confidence)

| Item | File | Reason kept |
|------|------|-------------|
| `$global:IPT_LOG_MIRROR_DIR` | Config.ps1:297-299 | Set but never read inside repo. However, Run.ps1 sets `IPT_NETWORK_ROOT` env vars and external log-mirroring may read this global. |
| `$global:IPT_LOG_ROOT_EFFECTIVE` | Config.ps1:276,286,290 | Diagnostic global. May be consumed by external monitoring tools. |
| `$global:IPT_LOG_ROOT_SOURCE` | Config.ps1:277,287,291 | Same as above. |

---

## Notes on Duplication (not addressed)

The `miScript1/2/3` click handlers (Main.ps1 lines ~742-779) are nearly identical 12-line blocks differing only in the path variable and error message text. A helper function could deduplicate this, but:
- Error messages differ per handler (Script3 uses `"..."` placeholder text)
- Extracting a helper changes the closure binding pattern
- Risk outweighs the ~24-line saving

Recommendation: Leave as-is; optionally unify in a future larger refactoring pass.

---

## How to Verify

1. **Syntax check** — PowerShell parse validation:
   ```powershell
   $null = [System.Management.Automation.PSParser]::Tokenize((Get-Content Main.ps1 -Raw), [ref]$null)
   $null = [System.Management.Automation.PSParser]::Tokenize((Get-Content Modules\RuleEngine.ps1 -Raw), [ref]$null)
   $null = [System.Management.Automation.PSParser]::Tokenize((Get-Content Modules\Config.ps1 -Raw), [ref]$null)
   $null = [System.Management.Automation.PSParser]::Tokenize((Get-Content Modules\SignatureHelpers.ps1 -Raw), [ref]$null)
   ```

2. **Functional smoke test** — Run the full flow:
   - Launch Main.ps1
   - Enter an LSP number → Sök filer → verify files populate
   - Click "Skapa rapport" → verify report opens in Excel with:
     - ✅ Information sheet (with SP Info block from `Write-SPBlockIntoInformation`)
     - ✅ Seal Test Info sheet
     - ✅ CSV-Sammanfattning (with `_SvRuleFlags` translations intact)
     - ✅ Signatur functionality (if enabled)

3. **Negative check** — Confirm nothing references removed items:
   ```powershell
   Select-String -Path *.ps1,Modules\*.ps1 -Pattern 'Test-UiVar|_SvDeviation|_SvSuffixCheck|OtherScriptPath|Write-SPSheet-Safe' -SimpleMatch
   # Should return zero matches
   ```
