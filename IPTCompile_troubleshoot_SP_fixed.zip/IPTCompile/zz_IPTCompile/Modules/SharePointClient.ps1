<#
NOTE:
  This file is dot-sourced by Main.ps1. Do NOT enable Set-StrictMode here,
  because it would affect the whole WinForms app and can break existing code.
#>

<###################################################################################################
SharePointClient.ps1

Syfte:
  - PnP.PowerShell (Connect-PnPOnline / Get-PnPListItem / Get-PnPConnection) är runspace-bundet.
  - Om anslutning sker i en BackgroundWorker/runspace och hämtning sker i en annan, ”syns” inte anslutningen.

Lösning:
  - Skapa en dedikerad single-thread runspace och kör ALLA SharePoint/PnP-anrop där.
  - UI-tråden (WinForms) gör aldrig Get/Connect-PnP direkt; den anropar Invoke-SPClient.

Designmål:
  - Minimal påverkan på övrig kod.
  - Trådsäker: en i taget (låst), ingen parallell PnP-körning.
  - Robust feltext: Exception.ToString().
###################################################################################################>

# --- Intern state (module scope) ---
$script:SP_Runspace  = $null
$script:SP_Lock      = New-Object object
$script:SP_Started   = $false
$script:SP_Connected = $false
$script:SP_LastError = $null

function Start-SPClient {
    [CmdletBinding()]
    param(
        [Parameter()][switch]$Force
    )

    if ($script:SP_Started -and -not $Force) { return }

    Stop-SPClient -ErrorAction SilentlyContinue

    $rs = [System.Management.Automation.Runspaces.RunspaceFactory]::CreateRunspace()
    # PnP kan använda COM i vissa delar; STA är safest i WinForms-miljö.
    $rs.ApartmentState = [System.Threading.ApartmentState]::STA
    $rs.ThreadOptions  = [System.Management.Automation.Runspaces.PSThreadOptions]::ReuseThread
    $rs.Open()

    $script:SP_Runspace  = $rs
    $script:SP_Started   = $true
    $script:SP_Connected = $false
    $script:SP_LastError = $null
}

function Stop-SPClient {
    [CmdletBinding()]
    param()

    [System.Threading.Monitor]::Enter($script:SP_Lock)
    try {
        $script:SP_Connected = $false
        $script:SP_LastError = $null

        if ($script:SP_Runspace) {
            try { $script:SP_Runspace.Close() } catch {}
            try { $script:SP_Runspace.Dispose() } catch {}
        }
        $script:SP_Runspace = $null
        $script:SP_Started  = $false
    }
    finally {
        [System.Threading.Monitor]::Exit($script:SP_Lock)
    }
}

function Get-SPClientStatus {
    [CmdletBinding()]
    param()

    [pscustomobject]@{
        Started   = [bool]$script:SP_Started
        Connected = [bool]$script:SP_Connected
        LastError = $script:SP_LastError
    }
}

function Invoke-SPClient {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)][scriptblock]$ScriptBlock,
        [Parameter()][object[]]$Arguments = @(),
        [Parameter()][int]$TimeoutSeconds = 0
    )

    if (-not $script:SP_Started -or -not $script:SP_Runspace) {
        Start-SPClient
    }

    [System.Threading.Monitor]::Enter($script:SP_Lock)
    try {
        $ps = $null
        try {
            $ps = [System.Management.Automation.PowerShell]::Create()
            $ps.Runspace = $script:SP_Runspace
            $null = $ps.AddScript($ScriptBlock.ToString())
            foreach ($a in $Arguments) { $null = $ps.AddArgument($a) }

            if ($TimeoutSeconds -gt 0) {
                $async = $ps.BeginInvoke()
                if (-not $async.AsyncWaitHandle.WaitOne([TimeSpan]::FromSeconds($TimeoutSeconds))) {
                    try { $ps.Stop() } catch {}
                    throw "SP-runspace timeout efter $TimeoutSeconds s"
                }
                $result = $ps.EndInvoke($async)
            } else {
                $result = $ps.Invoke()
            }

            if ($ps.HadErrors) {
                $err = ($ps.Streams.Error | Select-Object -First 1)
                if ($err) { throw $err.Exception }
                throw "Okänt fel i SP-runspace"
            }

            return $result
        }
        finally {
            if ($ps) { try { $ps.Dispose() } catch {} }
        }
    }
    finally {
        [System.Threading.Monitor]::Exit($script:SP_Lock)
    }
}

function Ensure-PnPModule {
    [CmdletBinding()]
    param()

    $sb = {
        $ProgressPreference = 'SilentlyContinue'
        try { $null = Get-PackageProvider -Name 'NuGet' -ForceBootstrap -ErrorAction SilentlyContinue } catch {}

        if (-not (Get-Module -Name 'PnP.PowerShell')) {
            try {
                Import-Module PnP.PowerShell -ErrorAction Stop
            } catch {
                Install-Module PnP.PowerShell -MaximumVersion 1.12.0 -Scope CurrentUser -Force -AllowClobber -ErrorAction Stop
                Import-Module PnP.PowerShell -ErrorAction Stop
            }
        }
        $true
    }

    try {
        $null = Invoke-SPClient -ScriptBlock $sb
        return $true
    } catch {
        $script:SP_LastError = $_.Exception.ToString()
        return $false
    }
}

function Connect-SPClient {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)][string]$Url,
        [Parameter(Mandatory=$true)][string]$Tenant,
        [Parameter(Mandatory=$true)][string]$ClientId,
        [Parameter(Mandatory=$true)][string]$CertificateBase64Encoded
    )

    $script:SP_LastError = $null

    if (-not (Ensure-PnPModule)) {
        $script:SP_Connected = $false
        return [pscustomobject]@{ Ok=$false; Err=$script:SP_LastError }
    }

    $sb = {
        param($pUrl,$pTenant,$pClientId,$pCert)
        Connect-PnPOnline -Url $pUrl -Tenant $pTenant -ClientId $pClientId -CertificateBase64Encoded $pCert -ErrorAction Stop
        $true
    }

    try {
        $null = Invoke-SPClient -ScriptBlock $sb -Arguments @($Url,$Tenant,$ClientId,$CertificateBase64Encoded)
        $script:SP_Connected = $true
        $script:SP_LastError = $null
        return [pscustomobject]@{ Ok=$true; Err=$null }
    } catch {
        $script:SP_Connected = $false
        $script:SP_LastError = $_.Exception.ToString()
        return [pscustomobject]@{ Ok=$false; Err=$script:SP_LastError }
    }
}

function Test-SPClientConnection {
    [CmdletBinding()]
    param()

    if (-not $script:SP_Started) { return $false }
    if (-not $script:SP_Connected) { return $false }

    $sb = {
        try {
            $null = Get-PnPConnection
            return $true
        } catch {
            return $false
        }
    }

    try {
        $r = Invoke-SPClient -ScriptBlock $sb
        return [bool]($r | Select-Object -First 1)
    } catch {
        return $false
    }
}
