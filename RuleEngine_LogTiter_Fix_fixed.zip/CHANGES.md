# RuleEngine LogTiter/MISQ — Ändringssammanfattning

## Ändrade filer

| Fil | Status | Radantal |
|-----|--------|----------|
| Modules/RuleEngine.ps1 | ÄNDRAD | 3995 (var 4005) |
| RuleBank/RuleBank.compiled.ps1 | OFÖRÄNDRAD | 491 |

## Åtgärd 1: DYNAMIC_FROM_CT aktiverad (KRITISK)

**Problem:** `Apply-LogTiterQuantSpec` läste `Min/Max` innan `FailMode`. DYNAMIC_FROM_CT-regler har `Min=''`/`Max=''` → hoppades över → dödkod.

**Fix:** FailMode läses FÖRE Min/Max. Tre kodvägar:

```
FailMode = DYNAMIC_FROM_CT:
  → Kräver Ct, CtMin, CtMax, AvgLogMin, AvgLogMax, SDMax
  → ExpectedLog = AvgLogMax - ((Ct - CtMin)/(CtMax - CtMin)) × (AvgLogMax - AvgLogMin)
  → MISQ om |logVal - ExpectedLog| > SDMax
  → Om fält saknas → no decision (continue)

FailMode = GROUP_AVG_SD:
  → Hoppas över (hanteras av Get-GroupMisqInfoForControlCode2/1)

FailMode = OUTSIDE / OUTSIDE_OR_EQUAL:
  → Kräver Min/Max (befintlig logik, oförändrad)
```

**Nytt parameter:** `-Ct` (valfritt, `$false`-default). Anropet uppdaterat att hämta Ct från raden.

**Guardrail:** Om Ct saknas → `continue`. Om CtMin/CtMax/AvgLogMin/AvgLogMax/SDMax saknas → `continue`. Om CtMax == CtMin → `continue` (divisionsskydd).

## Åtgärd 2: Dangling kod borttagen

**Borttaget:** `GroupFlags = $allGroupFlags.ToArray()` efter `return $ws` (sista raden i filen). Dead code som aldrig kördes. GroupFlags skickas korrekt via `Add-Member` på rad 2003.

## Åtgärd 3: Self-healing dubletter borttagna

**Borttaget:** ~65 rader inline-kopior av `Try-ExtractLogTiter` och `Apply-LogTiterQuantSpec` (rad 1378–1441). Dessa kördes aldrig — `Get-Command`-checken hittade alltid de fullständiga funktionerna (definierade längre ner i filen).

**Kommentar kvar:** Förklarar varför de togs bort.

## Åtgärd 5: Ct-outliers i PC2 MisqSet

**Problem:** Om en Ct föll utanför [CtMin, CtMax] → hela gruppen flaggades, men det specifika replikatet hamnade inte i `MisqSet` (bara om log OCKSÅ triggade).

**Fix:** Ny sektion (3) efter SD-outlier-logiken:
```powershell
# 3) If Ct guard failed -> mark the specific replicates whose Ct is outside [CtMin, CtMax]
if ($ctFail -and $ctMin -ne $null -and $ctMax -ne $null) {
    foreach ($sid in $bk.CtBySid.Keys) {
        $ctV = [double]$bk.CtBySid[$sid]
        if ($ctV -lt $ctMin -or $ctV -gt $ctMax) {
            $result.MisqSet[$sid] = $true
        }
    }
}
```

Bara de replikat vars Ct faktiskt är utanför intervallet markeras.

## Ej ändrat (designval bekräftat)

- **PC1 GROUP_AVG_SD:** Ger bara flags (ingen MisqSet). Avsiktligt.
- **RuleBank.compiled.ps1:** Oförändrad — alla DYNAMIC_FROM_CT-regler hade redan CtMin/CtMax/AvgLogMin/AvgLogMax/SDMax.
- **Load-RuleBank schema:** `_RequireColumns` kräver bara baseline-kolumner. Nya fält hämtas via `Get-RowField` + `Try-ParseDouble` (null-safe).

## Bakåtkompatibilitet

| Scenario | Resultat |
|----------|----------|
| Ingen QuantSpec-regel matchar | Identiskt — `$out` returneras oförändrat |
| Ct saknas i raden | DYNAMIC_FROM_CT → `continue` (no decision) |
| Log saknas i Test Result | `Try-ExtractLogTiter` → `$null` → tidig return |
| Min/Max tomma + FailMode=OUTSIDE | `continue` (som tidigare) |
| DYNAMIC_FROM_CT + alla fält finns | **NY:** beräknar ExpectedLog ± SDMax, ev MISQ |
| GROUP_AVG_SD i Apply-LogTiterQuantSpec | `continue` (ny explicit skip) |
