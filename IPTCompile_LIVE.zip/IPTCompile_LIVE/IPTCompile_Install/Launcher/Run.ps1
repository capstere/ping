﻿Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

function Get-ScriptDir {
    if ($PSScriptRoot) { return $PSScriptRoot }
    if ($PSCommandPath) { return (Split-Path -LiteralPath $PSCommandPath -Parent) }
    return (Get-Location).Path
}

function Read-FirstNonEmptyLine([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path)) { return $null }
    foreach ($line in [System.IO.File]::ReadAllLines($Path)) {
        $t = ($line + '').Trim()
        if ($t) {
            if ($t.StartsWith('"') -and $t.EndsWith('"') -and $t.Length -ge 2) {
                $t = $t.Substring(1, $t.Length - 2)
            }
            return $t.Trim()
        }
    }
    return $null
}

function Write-RunLog {
    param(
        [string]$LocalAuditDir,
        [string]$Message,
        [ValidateSet('INFO','WARN','ERROR')][string]$Level = 'INFO'
    )
    $ts = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
    $line = '[{0}] [{1}] {2}' -f $ts, $Level, $Message
    Write-Host $line
    try {
        if ($LocalAuditDir) {
            if (-not (Test-Path -LiteralPath $LocalAuditDir)) {
                New-Item -Path $LocalAuditDir -ItemType Directory -Force | Out-Null
            }
            Add-Content -LiteralPath (Join-Path $LocalAuditDir 'Run.log') -Value $line -Encoding UTF8
        }
    } catch { }
}

function Invoke-RobocopyUpdate {
    param(
        [Parameter(Mandatory=$true)][string]$Source,
        [Parameter(Mandatory=$true)][string]$Dest,
        [string[]]$ExcludeDirs,
        [string[]]$ExcludeFiles,
        [string]$LogFile
    )

    $args = New-Object System.Collections.Generic.List[string]
    $args.Add("`"$Source`"")
    $args.Add("`"$Dest`"")
    $args.Add('/E')
    $args.Add('/R:2')
    $args.Add('/W:1')
    $args.Add('/XO')
    $args.Add('/FFT')
    $args.Add('/XJ')
    $args.Add('/NP')
    $args.Add('/NFL')
    $args.Add('/NDL')

    foreach ($xd in ($ExcludeDirs | Where-Object { $_ })) {
        $args.Add('/XD')
        $args.Add("`"$(Join-Path $Source $xd)`"")
    }

    foreach ($xf in ($ExcludeFiles | Where-Object { $_ })) {
        $args.Add('/XF')
        $args.Add("`"$xf`"")
    }

    if ($LogFile) {
        $args.Add("/LOG:`"$LogFile`"")
    }

    $p = Start-Process -FilePath 'robocopy.exe' -ArgumentList $args.ToArray() -Wait -PassThru -WindowStyle Hidden
    return $p.ExitCode
}

function Get-PowerShellExe {
    $sysnative = Join-Path $env:WINDIR 'sysnative\WindowsPowerShell\v1.0\powershell.exe'
    if ([Environment]::Is64BitOperatingSystem -and -not [Environment]::Is64BitProcess -and (Test-Path -LiteralPath $sysnative)) {
        return $sysnative
    }
    return (Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe')
}

# ---- Main ----
$localRoot   = Get-ScriptDir
$localAudit  = Join-Path $localRoot '_LocalLauncherAudit'
$sourceFile  = Join-Path $localRoot 'LauncherSource.txt'
$netRoot     = Read-FirstNonEmptyLine -Path $sourceFile

Write-RunLog -LocalAuditDir $localAudit -Level INFO -Message ("Run start. LocalRoot={0}" -f $localRoot)

# --- Performance mode: keep runtime logs local (fast), but keep audit root on network ---
# Project root (network) from SourcePath.txt (copied by Install.bat).
$projectSourceFile = Join-Path $localRoot 'SourcePath.txt'
$projectRoot = Read-FirstNonEmptyLine -Path $projectSourceFile
if ($projectRoot) {
    $projectRoot = $projectRoot.Trim().TrimEnd('\')
    $env:IPT_NETWORK_ROOT = $projectRoot
}

# Force log root to local cache for performance. (Config.ps1 honors IPT_LOG_ROOT.)
$cacheRoot = 'C:\IPTCompile'
$env:IPT_LOG_ROOT = (Join-Path $cacheRoot 'Loggar')
$env:IPT_LOG_MODE = 'LOCAL_FIRST'

try {
    Write-RunLog -LocalAuditDir $localAudit -Level INFO -Message ("Env set. IPT_NETWORK_ROOT={0} | IPT_LOG_ROOT={1}" -f ($env:IPT_NETWORK_ROOT + ''), ($env:IPT_LOG_ROOT + ''))
} catch {}


# Self-update (best-effort)
if ($netRoot -and (Test-Path -LiteralPath $netRoot)) {

    # Förhindra krock vid samtidig start
    $mutexName = 'Local\IPTCompile_LauncherUpdate'
    $mutex = $null
    $haveMutex = $false

    try {
        $mutex = New-Object System.Threading.Mutex($false, $mutexName)
        $haveMutex = $mutex.WaitOne(5000)
        if (-not $haveMutex) {
            Write-RunLog -LocalAuditDir $localAudit -Level WARN -Message "Launcher update lock busy; hoppar över self-update."
        } else {
            $logFile = Join-Path $localAudit 'robocopy_launcher_update.log'
            $excludeDirs  = @('_LocalLauncherAudit','_LauncherAudit','Loggar','audit')
            $excludeFiles = @('Run.ps1','LauncherSource.txt')

            Write-RunLog -LocalAuditDir $localAudit -Level INFO -Message ("Self-update: {0} -> {1}" -f $netRoot, $localRoot)
            $rc = Invoke-RobocopyUpdate -Source $netRoot -Dest $localRoot -ExcludeDirs $excludeDirs -ExcludeFiles $excludeFiles -LogFile $logFile
            Write-RunLog -LocalAuditDir $localAudit -Level INFO -Message ("Self-update robocopy exit code={0} (0-7 OK, 8+ fel). Log={1}" -f $rc, $logFile)

            if ($rc -ge 8) {
                Write-RunLog -LocalAuditDir $localAudit -Level WARN -Message "Self-update misslyckades; fortsätter med befintlig lokal launcher."
            }
        }
    } catch {
        Write-RunLog -LocalAuditDir $localAudit -Level WARN -Message ("Self-update exception; fortsätter. {0}" -f $_.Exception.Message)
    } finally {
        if ($mutex) {
            if ($haveMutex) { try { $mutex.ReleaseMutex() } catch { } }
            $mutex.Dispose()
        }
    }
} else {
    Write-RunLog -LocalAuditDir $localAudit -Level WARN -Message "LauncherSource.txt saknas/ogiltig; hoppar över self-update."
}

# Kör den riktiga launchern (lokal)
$launcherPs1 = Join-Path $localRoot 'Launcher.ps1'
if (-not (Test-Path -LiteralPath $launcherPs1)) {
    Write-RunLog -LocalAuditDir $localAudit -Level ERROR -Message ("Saknar lokal Launcher.ps1: {0}" -f $launcherPs1)
    exit 20
}

$exe = Get-PowerShellExe
Write-RunLog -LocalAuditDir $localAudit -Level INFO -Message ("Startar Launcher.ps1: {0}" -f $launcherPs1)

& $exe -NoProfile -ExecutionPolicy Bypass -File $launcherPs1
$rc = $LASTEXITCODE

# Best-effort: mirror local logs to network after the tool exits
try {
    if ($projectRoot -and (Test-Path -LiteralPath $projectRoot)) {
        $srcLog = ($env:IPT_LOG_ROOT + '').Trim()
        $dstLog = Join-Path $projectRoot 'Loggar'
        if ($srcLog -and (Test-Path -LiteralPath $srcLog)) {
            if (-not (Test-Path -LiteralPath $dstLog)) { New-Item -ItemType Directory -Path $dstLog -Force | Out-Null }
            $logFile = Join-Path $localAudit 'robocopy_log_mirror.log'
            Write-RunLog -LocalAuditDir $localAudit -Level INFO -Message ("Mirroring logs: {0} -> {1}" -f $srcLog, $dstLog)

            $args = New-Object System.Collections.Generic.List[string]
            $args.Add("`"$srcLog`"")
            $args.Add("`"$dstLog`"")
            $args.Add('/E')
            $args.Add('/R:2')
            $args.Add('/W:1')
            $args.Add('/XO')
            $args.Add('/FFT')
            $args.Add('/XJ')
            $args.Add('/NP')
            $args.Add('/NFL')
            $args.Add('/NDL')
            $args.Add("/LOG:`"$logFile`"")

            $p = Start-Process -FilePath 'robocopy.exe' -ArgumentList $args.ToArray() -Wait -PassThru -WindowStyle Hidden
            $rrc = $p.ExitCode
            Write-RunLog -LocalAuditDir $localAudit -Level INFO -Message ("Log mirror robocopy exit code={0} (0-7 OK, 8+ fel). Log={1}" -f $rrc, $logFile)
        }
    }
} catch {
    try { Write-RunLog -LocalAuditDir $localAudit -Level WARN -Message ("Log mirror failed: {0}" -f $_.Exception.Message) } catch {}
}

exit $rc
