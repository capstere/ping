Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

function Get-ScriptDir {
    if ($PSScriptRoot) { return $PSScriptRoot }
    if ($PSCommandPath) { return (Split-Path -LiteralPath $PSCommandPath -Parent) }
    return (Get-Location).Path
}

function Read-FirstNonEmptyLine([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path)) { return $null }
    foreach ($line in [System.IO.File]::ReadAllLines($Path)) {
        $t = ($line + '').Trim()
        if ($t) {
            if ($t.StartsWith('"') -and $t.EndsWith('"') -and $t.Length -ge 2) {
                $t = $t.Substring(1, $t.Length - 2)
            }
            return $t.Trim()
        }
    }
    return $null
}

function Write-RunLog {
    param(
        [string]$LocalAuditDir,
        [string]$Message,
        [ValidateSet('INFO','WARN','ERROR')][string]$Level = 'INFO'
    )
    $ts = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
    $line = '[{0}] [{1}] {2}' -f $ts, $Level, $Message
    Write-Host $line
    try {
        if ($LocalAuditDir) {
            if (-not (Test-Path -LiteralPath $LocalAuditDir)) {
                New-Item -Path $LocalAuditDir -ItemType Directory -Force | Out-Null
            }
            Add-Content -LiteralPath (Join-Path $LocalAuditDir 'Run.log') -Value $line -Encoding UTF8
        }
    } catch { }
}

function Invoke-RobocopyUpdate {
    param(
        [Parameter(Mandatory=$true)][string]$Source,
        [Parameter(Mandatory=$true)][string]$Dest,
        [string[]]$ExcludeDirs,
        [string[]]$ExcludeFiles,
        [string]$LogFile
    )

    $roboArgs = New-Object System.Collections.Generic.List[string]
    $roboArgs.Add("`"$Source`"")
    $roboArgs.Add("`"$Dest`"")
    $roboArgs.Add('/E')
    $roboArgs.Add('/R:2')
    $roboArgs.Add('/W:1')
    $roboArgs.Add('/XO')
    $roboArgs.Add('/FFT')
    $roboArgs.Add('/XJ')
    $roboArgs.Add('/NP')
    $roboArgs.Add('/NFL')
    $roboArgs.Add('/NDL')

    foreach ($xd in ($ExcludeDirs | Where-Object { $_ })) {
        $roboArgs.Add('/XD')
        $roboArgs.Add("`"$(Join-Path $Source $xd)`"")
    }

    foreach ($xf in ($ExcludeFiles | Where-Object { $_ })) {
        $roboArgs.Add('/XF')
        $roboArgs.Add("`"$xf`"")
    }

    if ($LogFile) {
        $roboArgs.Add("/LOG:`"$LogFile`"")
    }

    $p = Start-Process -FilePath 'robocopy.exe' -ArgumentList $roboArgs.ToArray() -Wait -PassThru -WindowStyle Hidden
    return $p.ExitCode
}

function Get-PowerShellExe {
    $sysnative = Join-Path $env:WINDIR 'sysnative\WindowsPowerShell\v1.0\powershell.exe'
    if ([Environment]::Is64BitOperatingSystem -and -not [Environment]::Is64BitProcess -and (Test-Path -LiteralPath $sysnative)) {
        return $sysnative
    }
    return (Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe')
}

# ---- Main ----
$localRoot   = Get-ScriptDir
$localAudit  = Join-Path $localRoot '_LocalLauncherAudit'
$sourceFile  = Join-Path $localRoot 'LauncherSource.txt'
$netRoot     = Read-FirstNonEmptyLine -Path $sourceFile

Write-RunLog -LocalAuditDir $localAudit -Level INFO -Message ("Run start. LocalRoot={0}" -f $localRoot)

# --- Performance mode: keep runtime logs local (fast), but keep audit root on network ---
# Project root (network) from SourcePath.txt (copied by Install.bat).
$projectSourceFile = Join-Path $localRoot 'SourcePath.txt'
$projectRoot = Read-FirstNonEmptyLine -Path $projectSourceFile
if ($projectRoot) {
    $projectRoot = $projectRoot.Trim().TrimEnd('\')
    $env:IPT_NETWORK_ROOT = $projectRoot
}

# Force log root to local cache for performance. (Config.ps1 honors IPT_LOG_ROOT.)
$cacheRoot = 'C:\IPTCompile'
$env:IPT_LOG_ROOT = (Join-Path $cacheRoot 'Loggar')
$env:IPT_LOG_MODE = 'LOCAL_FIRST'

try {
    Write-RunLog -LocalAuditDir $localAudit -Level INFO -Message ("Env set. IPT_NETWORK_ROOT={0} | IPT_LOG_ROOT={1}" -f ($env:IPT_NETWORK_ROOT + ''), ($env:IPT_LOG_ROOT + ''))
} catch {}



function Normalize-Text([string]$s) {
    return (($s + '') -replace '\uFEFF','').Trim()
}

# Self-update (best-effort)
if ($netRoot -and (Test-Path -LiteralPath $netRoot)) {

    # Optional: skip self-update if LauncherVersion.txt matches
    $launcherVerNetPath = Join-Path $netRoot 'LauncherVersion.txt'
    $launcherVerLocPath = Join-Path $localRoot 'LauncherVersion.txt'
    $doSelfUpdate = $true
    if (Test-Path -LiteralPath $launcherVerNetPath) {
        $vNetL = Normalize-Text (Read-FirstNonEmptyLine -Path $launcherVerNetPath)
        $vLocL = Normalize-Text (Read-FirstNonEmptyLine -Path $launcherVerLocPath)
        if ($vNetL -and $vLocL -and ($vNetL -eq $vLocL)) {
            $doSelfUpdate = $false
            Write-RunLog -LocalAuditDir $localAudit -Level INFO -Message ('Launcher self-update: up-to-date (LauncherVersion.txt={0}); hoppar över.' -f $vLocL)
        } else {
            Write-RunLog -LocalAuditDir $localAudit -Level INFO -Message ('Launcher self-update: behöver uppdatera. vNet={0} vLoc={1}' -f ($vNetL + ''), ($vLocL + ''))
        }
    }


    if (-not $doSelfUpdate) {
        # no-op
    } else {

    # Förhindra krock vid samtidig start
    $mutexName = 'Local\IPTCompile_LauncherUpdate'
    $mutex = $null
    $haveMutex = $false

    try {
        $mutex = New-Object System.Threading.Mutex($false, $mutexName)
        $haveMutex = $mutex.WaitOne(5000)
        if (-not $haveMutex) {
            Write-RunLog -LocalAuditDir $localAudit -Level WARN -Message "Launcher update lock busy; hoppar över self-update."
        } else {
            $logFile = Join-Path $localAudit 'robocopy_launcher_update.log'
            $excludeDirs  = @('_LocalLauncherAudit','_LauncherAudit','Loggar','audit')
            $excludeFiles = @('Run.ps1','LauncherSource.txt')

            Write-RunLog -LocalAuditDir $localAudit -Level INFO -Message ("Self-update: {0} -> {1}" -f $netRoot, $localRoot)
            $rc = Invoke-RobocopyUpdate -Source $netRoot -Dest $localRoot -ExcludeDirs $excludeDirs -ExcludeFiles $excludeFiles -LogFile $logFile
            Write-RunLog -LocalAuditDir $localAudit -Level INFO -Message ("Self-update robocopy exit code={0} (0-7 OK, 8+ fel). Log={1}" -f $rc, $logFile)

            if ($rc -ge 8) {
                Write-RunLog -LocalAuditDir $localAudit -Level WARN -Message "Self-update misslyckades; fortsätter med befintlig lokal launcher."
            }
        }
    } catch {
        Write-RunLog -LocalAuditDir $localAudit -Level WARN -Message ("Self-update exception; fortsätter. {0}" -f $_.Exception.Message)
    } finally {
        if ($mutex) {
            if ($haveMutex) { try { $mutex.ReleaseMutex() } catch { } }
            $mutex.Dispose()
        }
    }
    }
} else {
    Write-RunLog -LocalAuditDir $localAudit -Level WARN -Message "LauncherSource.txt saknas/ogiltig; hoppar över self-update."
}

# Kör den riktiga launchern (lokal)
$launcherPs1 = Join-Path $localRoot 'Launcher.ps1'
if (-not (Test-Path -LiteralPath $launcherPs1)) {
    Write-RunLog -LocalAuditDir $localAudit -Level ERROR -Message ("Saknar lokal Launcher.ps1: {0}" -f $launcherPs1)
    exit 20
}

$exe = Get-PowerShellExe
Write-RunLog -LocalAuditDir $localAudit -Level INFO -Message ("Startar Launcher.ps1: {0}" -f $launcherPs1)

& $exe -NoProfile -ExecutionPolicy Bypass -File $launcherPs1
$rc = $LASTEXITCODE

# Best-effort: mirror local logs to network after the tool exits
# Optimization: only run robocopy if there are new/changed log files since last successful mirror.
try {
    if ($projectRoot -and (Test-Path -LiteralPath $projectRoot)) {
        $srcLog = ($env:IPT_LOG_ROOT + '').Trim()
        $dstLog = Join-Path $projectRoot 'Loggar'

        if ($srcLog -and (Test-Path -LiteralPath $srcLog)) {

            # Determine newest file timestamp in local log root
            $latestUtc = $null
            try {
                $latestUtc = Get-ChildItem -LiteralPath $srcLog -Recurse -File -ErrorAction SilentlyContinue |
                    Sort-Object LastWriteTimeUtc -Descending |
                    Select-Object -First 1 -ExpandProperty LastWriteTimeUtc
            } catch { $latestUtc = $null }

            if (-not $latestUtc) {
                Write-RunLog -LocalAuditDir $localAudit -Level INFO -Message "Log mirror: inga lokala loggfiler att spegla."
            } else {
                $statePath = Join-Path $localAudit 'log_mirror_state.txt'
                $lastMirroredTicks = 0L
                try {
                    if (Test-Path -LiteralPath $statePath) {
                        $raw = (Get-Content -LiteralPath $statePath -ErrorAction Stop | Select-Object -First 1)
                        [void][Int64]::TryParse(($raw + '').Trim(), [ref]$lastMirroredTicks)
                    }
                } catch { $lastMirroredTicks = 0L }

                if ($latestUtc.Ticks -le $lastMirroredTicks) {
                    Write-RunLog -LocalAuditDir $localAudit -Level INFO -Message ("Log mirror: inga nya loggar sedan senaste spegling ({0})." -f ([DateTime]::new($lastMirroredTicks,[DateTimeKind]::Utc).ToString('yyyy-MM-dd HH:mm:ss')))
                } else {
                    if (-not (Test-Path -LiteralPath $dstLog)) { New-Item -ItemType Directory -Path $dstLog -Force | Out-Null }
                    $logFile = Join-Path $localAudit 'robocopy_log_mirror.log'
                    Write-RunLog -LocalAuditDir $localAudit -Level INFO -Message ("Mirroring logs: {0} -> {1}" -f $srcLog, $dstLog)

                    $roboArgs = New-Object System.Collections.Generic.List[string]
                    $roboArgs.Add("`"$srcLog`"")
                    $roboArgs.Add("`"$dstLog`"")
                    $roboArgs.Add('/E')
                    $roboArgs.Add('/R:2')
                    $roboArgs.Add('/W:1')
                    $roboArgs.Add('/XO')
                    $roboArgs.Add('/FFT')
                    $roboArgs.Add('/XJ')
                    $roboArgs.Add('/NP')
                    $roboArgs.Add('/NFL')
                    $roboArgs.Add('/NDL')
                    $roboArgs.Add("/LOG:`"$logFile`"")

                    $p = Start-Process -FilePath 'robocopy.exe' -ArgumentList $roboArgs.ToArray() -Wait -PassThru -WindowStyle Hidden
                    $rrc = $p.ExitCode
                    Write-RunLog -LocalAuditDir $localAudit -Level INFO -Message ("Log mirror robocopy exit code={0} (0-7 OK, 8+ fel). Log={1}" -f $rrc, $logFile)

                    if ($rrc -lt 8) {
                        try { Set-Content -LiteralPath $statePath -Value ([string]$latestUtc.Ticks) -Encoding ASCII } catch { }
                    }
                }
            }
        }
    }
} catch {
    try { Write-RunLog -LocalAuditDir $localAudit -Level WARN -Message ("Log mirror failed: {0}" -f $_.Exception.Message) } catch {}
}

exit $rc