﻿#region Importering och config
if ([Threading.Thread]::CurrentThread.ApartmentState -ne 'STA') {
    $exe = Join-Path $PSHome 'powershell.exe'
    $scriptPath = if ($PSCommandPath) { $PSCommandPath } else { $MyInvocation.MyCommand.Path }
    Start-Process -FilePath $exe -ArgumentList "-NoProfile -STA -ExecutionPolicy Bypass -File `"$scriptPath`""
    exit
}

# ---- Soft spärr ---
$BlockedUsers = @(
    # Lägg in i lower-case:
    # 'jesper.fredriksson'
    # 'namn.efternamn',
    # 'domain\namn.efternamn'
)

function Test-IsBlockedUser {
    param([string[]]$DenyList)

    $u1 = (($env:USERNAME + '').Trim()).ToLowerInvariant()
    $u2 = ((($env:USERDOMAIN + '') + '\' + ($env:USERNAME + '')).Trim()).ToLowerInvariant()

    $deny = @($DenyList | ForEach-Object { (($_ + '').Trim()).ToLowerInvariant() }) | Where-Object { $_ }
    return ($deny -contains $u1) -or ($deny -contains $u2)
}

if (Test-IsBlockedUser -DenyList $BlockedUsers) {
    try {
        [System.Windows.Forms.MessageBox]::Show(
            "Tyvärr – skriptet är avstängt för dig.",
            "IPTCompile",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Stop
        ) | Out-Null
    } catch {
        Write-Host "Tyvärr – skriptet är avstängt för dig." -ForegroundColor Red
    }
    exit 1
}

Add-Type -AssemblyName System.Windows.Forms
try { [System.Windows.Forms.Application]::EnableVisualStyles() } catch {}
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.ComponentModel
try {
    Add-Type -AssemblyName 'Microsoft.VisualBasic' -ErrorAction SilentlyContinue
} catch {}

$scriptPath = if ($PSCommandPath) { $PSCommandPath } else { $MyInvocation.MyCommand.Path }
$ScriptRootPath = [System.IO.Path]::GetDirectoryName([System.IO.Path]::GetFullPath($scriptPath))
$installLock = Join-Path $ScriptRootPath '.install.lock'
if (Test-Path -LiteralPath $installLock) {
    $msg = "Install/uppdatering pågår (lock-fil finns): $installLock`nStarta om IPTCompile när uppdateringen är klar."
    try { [System.Windows.Forms.MessageBox]::Show($msg,'IPTCompile') | Out-Null } catch { Write-Host $msg }
    exit 2
}
$PSScriptRoot = $ScriptRootPath
try {
    $cwd = (Get-Location).Path
    Write-Host ("[EXEC] Script={0} | ScriptRoot={1} | CWD={2}" -f $scriptPath, $ScriptRootPath, $cwd)
} catch {}
$modulesRoot = Join-Path $ScriptRootPath 'Modules'

$libRoot = Join-Path $ScriptRootPath 'Lib'
$global:ModulesRoot = $modulesRoot
$global:LibRoot     = $libRoot
# Konstanter: bladnamn, cellreferenser.
# Om jag ändrar i mallen!
$Layout = @{
    # Cellreferenser
    SignatureCell        = 'B47'       # Seal Test signaturcell
    SealActiveCheckCell  = 'H3'        # Cell som avgör om Seal-flik är aktiv
    AssayNameCell        = 'D10'       # Assay-namn i output
    SpInfoStartCell      = 'E1'        # SharePoint info start i Run Information

    # Bladnamn i output-mallen
    SheetRunInfo         = 'Run Information'
    SheetDataSummary     = 'Data Summary'
    SheetResampleSummary = 'Resample Data Summary'
    SheetSealTestInfo    = 'Seal Test Info'
    SheetStfSummary      = 'STF Summary'
    SheetQcSummary       = 'QC Summary'
    SheetKontrollmaterial= 'Kontrollmaterial'
    SheetUtrustning      = 'Utrustningslista'
}

. (Join-Path $modulesRoot 'Config.ps1') -ScriptRoot $ScriptRootPath

function Test-SingleInstanceThrottleLock {
    param(
        [Parameter(Mandatory=$true)][string]$LockPath,
        [int]$TtlSec = 30
    )
    $result = [pscustomobject]@{
        Blocked = $false
        Reason  = ''
    }

    try {
        if (-not (Test-Path -LiteralPath $LockPath)) { return $result }
    } catch {
        return $result
    }

    try {
        $lockItem = Get-Item -LiteralPath $LockPath -ErrorAction Stop
        $ageSec = [Math]::Max(0, [int](([DateTime]::UtcNow - $lockItem.LastWriteTimeUtc).TotalSeconds))
        if ($ageSec -lt [Math]::Max(1, [int]$TtlSec)) {
            $result.Blocked = $true
            $result.Reason = ("Aktiv lock ({0}s < {1}s)." -f $ageSec, [int]$TtlSec)
            return $result
        }
        try { Remove-Item -LiteralPath $LockPath -Force -ErrorAction Stop } catch {}
    } catch {
        # Fail-open: blockera inte start vid lock-läsfel.
    }
    return $result
}

function Set-SingleInstanceThrottleLock {
    param([Parameter(Mandatory=$true)][string]$LockPath)
    try {
        $lockDir = Split-Path -Path $LockPath -Parent
        if ($lockDir -and -not (Test-Path -LiteralPath $lockDir)) {
            New-Item -ItemType Directory -Path $lockDir -Force | Out-Null
        }
        Set-Content -LiteralPath $LockPath -Value ([DateTime]::Now.ToString('yyyy-MM-dd HH:mm:ss')) -Encoding UTF8 -Force
        return $true
    } catch {
        return $false
    }
}

function Clear-SingleInstanceThrottleLock {
    param([string]$LockPath)
    if (-not $LockPath) { return }
    try { if (Test-Path -LiteralPath $LockPath) { Remove-Item -LiteralPath $LockPath -Force -ErrorAction Stop } } catch {}
}

$script:SingleInstanceLockPath = $null
try {
    $singleGuardEnabled = Get-ConfigFlag -Name 'SingleInstanceGuardEnabled' -Default $false -ConfigOverride $Config
    $singleGuardTtl = [int](Get-ConfigValue -Name 'SingleInstanceGuardTtlSec' -Default 30 -ConfigOverride $Config)
    if ($singleGuardTtl -lt 1) { $singleGuardTtl = 30 }
    if ($singleGuardEnabled) {
        $script:SingleInstanceLockPath = Join-Path $env:TEMP 'IPTCompile.main.launch.lock'
        $lockState = Test-SingleInstanceThrottleLock -LockPath $script:SingleInstanceLockPath -TtlSec $singleGuardTtl
        if ($lockState.Blocked) {
            try { Write-Host ("Already starting: {0}" -f $lockState.Reason) } catch {}
            exit 0
        }
        $setOk = Set-SingleInstanceThrottleLock -LockPath $script:SingleInstanceLockPath
        if (-not $setOk) {
            try { Write-Host 'IPTCompile single-instance lock kunde inte sättas (fortsätter fail-open).' } catch {}
        }
    }
} catch {
    try { Write-Host ("IPTCompile single-instance guard fel (fortsätter fail-open): {0}" -f $_.Exception.Message) } catch {}
}

. (Join-Path $modulesRoot 'Splash.ps1')
. (Join-Path $modulesRoot 'SharePointClient.ps1')
. (Join-Path $modulesRoot 'UiStyling.ps1')
. (Join-Path $modulesRoot 'Logging.ps1')
. (Join-Path (Join-Path $modulesRoot 'Core') 'Log.ps1')

try {
    $netRoot = ($env:IPT_NETWORK_ROOT + '').Trim()
    $iptRoot = ($global:IPT_ROOT_EFFECTIVE + '').Trim()
    $iptSrc  = ($global:IPT_ROOT_SOURCE + '').Trim()
    $logPath = ($global:LogPath + '').Trim()
    $jsonl   = ($global:StructuredLogPath + '').Trim()

    if (-not $netRoot) { $netRoot = '<empty>' }
    if (-not $iptRoot) { $iptRoot = '<empty>' }
    if (-not $iptSrc)  { $iptSrc  = '<empty>' }
    if (-not $logPath) { $logPath = '<empty>' }
    if (-not $jsonl)   { $jsonl   = '<empty>' }

    $msg = "Sanity: IPT_NETWORK_ROOT=$netRoot | IPT_ROOT_EFFECTIVE=$iptRoot | IPT_ROOT_SOURCE=$iptSrc | LogPath=$logPath | StructuredLogPath=$jsonl"
    try { Gui-Log -Text $msg -Severity 'Info' -Category 'SANITY' } catch { Write-Host $msg }
} catch { }

. (Join-Path $modulesRoot 'DataHelpers.ps1')
if (-not (Get-Command Excel-GetCellText -ErrorAction SilentlyContinue)) {
    throw "DataHelpers.ps1 laddades inte korrekt: Excel-GetCellText saknas. (Troligen avbruten import p.g.a. fel tidigare i filen.)"
}
. (Join-Path (Join-Path $modulesRoot 'Core') 'Pipeline.ps1')
. (Join-Path (Join-Path $modulesRoot 'Core') 'Context.ps1')
. (Join-Path (Join-Path $modulesRoot 'Core') 'BuildPipeline.ps1')
. (Join-Path $modulesRoot 'SignatureHelpers.ps1')
. (Join-Path $modulesRoot 'OpenXmlHelpers.ps1')
. (Join-Path $modulesRoot 'RuleEngine.ps1')

$global:SpEnabled = Get-ConfigFlag -Name 'EnableSharePoint' -Default $true -ConfigOverride $Config
$global:SpAutoConnect = if ($global:SpEnabled) {
    Get-ConfigFlag -Name 'EnableSharePointAutoConnect' -Default $true -ConfigOverride $Config
} else { $false }

$global:StartupReady = $true
$configStatus = $null

try {

    $configStatus = Test-Config
    if ($configStatus) {
        foreach ($err in $configStatus.Errors) { Gui-Log "❌ Konfig-fel: $err" 'Error' }
        foreach ($warn in $configStatus.Warnings) { Gui-Log "⚠️ Konfig-varning: $warn" 'Warn' }
        if (-not $configStatus.Ok) {
            $global:StartupReady = $false
            try { [System.Windows.Forms.MessageBox]::Show("Startkontroll misslyckades. Se logg för detaljer.","Startkontroll") | Out-Null } catch {}
        }
    }
} catch { Gui-Log "❌ Test-Config misslyckades: $($_.Exception.Message)" 'Error'; $global:StartupReady = $false }

$Host.UI.RawUI.WindowTitle = "Startar…"
Show-Splash "Laddar PowerShell…"
$env:PNPPOWERSHELL_UPDATECHECK = 'Off'

$global:SpConnected = $false
$global:SpError     = $null

if ($global:SpAutoConnect) {
    # Autokoppling: starta SPClient-runspace + importera PnP + anslut (synkront under splash)
    $spStartOk = Start-SPClient -ProgressCallback { param($m) Update-Splash $m }
    if ($spStartOk) {
        Update-Splash 'Ansluter till SharePoint…'
        $spConnOk = Connect-SPClient -ProgressCallback { param($m) Update-Splash $m }
        if ($spConnOk) {
            $global:SpConnected = $true
        } else {
            $msg = "Connect-PnPOnline misslyckades: $($global:SpError)"
            Update-Splash $msg
        }
    } else {
        $msg = "PnP-import misslyckades: $($global:SpError)"
        Update-Splash $msg
    }
} elseif (-not $global:SpEnabled) {
    $global:SpError = 'SharePoint avstängt i Config'
    try { Gui-Log "ℹ️ SharePoint är avstängt i konfigurationen." 'Info' } catch {}
} else {
    # SpEnabled = true men AutoConnect = false → snabbstart, SPClient startas vid knapptryck
    $global:SpError = $null
    try { Gui-Log "ℹ️ SharePoint: manuell anslutning (klicka '🔌 Anslut SP' vid behov)." 'Info' } catch {}
}
try { $null = Ensure-EPPlus -Version '4.5.3.3' } catch { Gui-Log "⚠️ EPPlus-förkontroll misslyckades: $($_.Exception.Message)" 'Warn' }
#endregion Importering och config

#region GUI 

Update-Splash "Startar…"
Close-Splash
$form = New-Object System.Windows.Forms.Form
$form.Text = "IPTCompile – $ScriptVersion"
$form.AutoScaleMode = 'Dpi'
$form.Size = New-Object System.Drawing.Size(980,860)
$form.MinimumSize = New-Object System.Drawing.Size(980,860)
$form.StartPosition = 'CenterScreen'
$form.BackColor = [System.Drawing.Color]::WhiteSmoke
$form.AutoScroll  = $false
$form.MaximizeBox = $false
$form.Padding     = New-Object System.Windows.Forms.Padding(8)
$form.Font        = New-Object System.Drawing.Font('Segoe UI',10)
$form.KeyPreview = $true
$form.add_KeyDown({
    if ($_.KeyCode -eq [System.Windows.Forms.Keys]::Escape) {
        if ($script:BuildInProgress) {
            $_.Handled = $true
            Gui-Log '⚠️ Rapportgenerering pågår – avbryt inte.' 'Warn'
            return
        }
        $form.Close(); return
    }
    # Hemlig dev-toggle: Ctrl + Alt + T
    try {
        if ($_.Control -and $_.Alt -and ($_.KeyCode -eq [System.Windows.Forms.Keys]::T)) {
            if ($script:btnMove3) {
                $script:btnMove3.Visible = -not $script:btnMove3.Visible
                try {
                    if ($script:btnMove3.Visible) { Gui-Log "TEST-knapp synlig." 'Info' }
                    else                          { Gui-Log "TEST-knapp dold." 'Info' }
                } catch {}
            }
            $_.Handled = $true
        }
    } catch {}
})

# ---------- Menyrad ----------
$menuStrip = New-Object System.Windows.Forms.MenuStrip
$menuStrip.Dock='Top'; $menuStrip.GripStyle='Hidden'
$menuStrip.ImageScalingSize = New-Object System.Drawing.Size(20,20)
$menuStrip.Padding = New-Object System.Windows.Forms.Padding(8,6,0,6)
$menuStrip.Font = New-Object System.Drawing.Font('Segoe UI',10)
$miArkiv   = New-Object System.Windows.Forms.ToolStripMenuItem('🗂️ Arkiv')
$miVerktyg = New-Object System.Windows.Forms.ToolStripMenuItem('🛠️ Verktyg')
$miSettings= New-Object System.Windows.Forms.ToolStripMenuItem('⚙️ Inställningar')
$miHelp    = New-Object System.Windows.Forms.ToolStripMenuItem('📖 Instruktioner')
$miAbout   = New-Object System.Windows.Forms.ToolStripMenuItem('ℹ️ Om')
$miCopyLog = New-Object System.Windows.Forms.ToolStripMenuItem('📋 Kopiera logg')
$miScan  = New-Object System.Windows.Forms.ToolStripMenuItem('🔍 Sök filer')
$miBuild = New-Object System.Windows.Forms.ToolStripMenuItem('✅ Skapa rapport')
$miExit  = New-Object System.Windows.Forms.ToolStripMenuItem('❌ Avsluta')

# Rensa ev. gamla undermenyer
$miArkiv.DropDownItems.Clear()
$miVerktyg.DropDownItems.Clear()
$miSettings.DropDownItems.Clear()
$miHelp.DropDownItems.Clear()

# ----- Arkiv -----
$miNew         = New-Object System.Windows.Forms.ToolStripMenuItem('🆕 Nytt')
$miOpenRecent  = New-Object System.Windows.Forms.ToolStripMenuItem('📂 Öppna senaste rapport')
$miArkiv.DropDownItems.AddRange(@(
    $miNew,
    $miOpenRecent,
    (New-Object System.Windows.Forms.ToolStripSeparator),
    $miExit
))

$miCopyLog.add_Click({
    try {
        $logText = ''
        foreach ($item in $logBox.Items) { $logText += "$item`r`n" }
        if ($logText) {
            [System.Windows.Forms.Clipboard]::SetText($logText)
            Gui-Log "📋 Logg kopierad till urklipp ($($logBox.Items.Count) rader)." 'Info'
        }
    } catch { Gui-Log "⚠️ Kunde inte kopiera logg: $($_.Exception.Message)" 'Warn' }
})

# ----- Verktyg -----
$miScript1   = New-Object System.Windows.Forms.ToolStripMenuItem('📜 Kontrollprovsfil-skript')
$miScript2   = New-Object System.Windows.Forms.ToolStripMenuItem('📜 Aktivera Kontrollprovsfil')
$miScript3   = New-Object System.Windows.Forms.ToolStripMenuItem('📅 Ändra datum på filer')
$miScript4   = New-Object System.Windows.Forms.ToolStripMenuItem('🗂️ AutoMappscript Control')
$miScript5   = New-Object System.Windows.Forms.ToolStripMenuItem('📄 AutoMappscript Dashboard')
$miToggleSignSamm   = New-Object System.Windows.Forms.ToolStripMenuItem('✅ Aktivera signering (Sammanställning)')
$miToggleSignGransk = New-Object System.Windows.Forms.ToolStripMenuItem('✅ Aktivera signering (Granskning)')
$miVerktyg.DropDownItems.AddRange(@(
    $miScript1,
    $miScript2,
    $miScript3,
    $miScript4,
    $miScript5,
    (New-Object System.Windows.Forms.ToolStripSeparator),
    $miToggleSignSamm,
    $miToggleSignGransk
))

# Config-gated: dölj signeringsmenyval om avstängt i Config
$miToggleSignSamm.Visible   = (Get-ConfigFlag -Name 'EnableSignSammanstallning' -Default $true)
$miToggleSignGransk.Visible = (Get-ConfigFlag -Name 'EnableSignGranskning' -Default $true)

# ----- Inställningar -----
$miTheme = New-Object System.Windows.Forms.ToolStripMenuItem('🎨 Tema')
$miLightTheme = New-Object System.Windows.Forms.ToolStripMenuItem('☀️ Ljust (default)')
$miDarkTheme  = New-Object System.Windows.Forms.ToolStripMenuItem('🌙 Mörkt')
$miTheme.DropDownItems.AddRange(@($miLightTheme,$miDarkTheme))
[void]$miSettings.DropDownItems.Add($miTheme)

# ----- Instruktioner -----
$miShowInstr   = New-Object System.Windows.Forms.ToolStripMenuItem('📖 Visa instruktioner')
$miFAQ         = New-Object System.Windows.Forms.ToolStripMenuItem('❓ FAQ')
$miHelpDlg     = New-Object System.Windows.Forms.ToolStripMenuItem('🆘 Hjälp')
$miHelp.DropDownItems.AddRange(@($miShowInstr,$miFAQ,$miHelpDlg))

$miGenvagar = New-Object System.Windows.Forms.ToolStripMenuItem('🔗 Genvägar')
$ShortcutGroups = Get-ConfigValue -Name 'ShortcutGroups' -Default $null -ConfigOverride $Config
if (-not $ShortcutGroups) {
    # Reservväg om config saknar genvägar
    $ShortcutGroups = @{
        '🗂️ IPT-mappar' = @(
            @{ Text='📂 IPT - PÅGÅENDE KÖRNINGAR';        Target='N:\QC\QC-1\IPT\2. IPT - PÅGÅENDE KÖRNINGAR' },
            @{ Text='📂 IPT - KLART FÖR SAMMANSTÄLLNING'; Target='N:\QC\QC-1\IPT\3. IPT - KLART FÖR SAMMANSTÄLLNING' },
            @{ Text='📂 IPT - KLART FÖR GRANSKNING';      Target='N:\QC\QC-1\IPT\4. IPT - KLART FÖR GRANSKNING' },
            @{ Text='📂 SPT Macro Assay';                 Target='N:\QC\QC-0\SPT\SPT macros\Assay' }
        )
        '📄 Dokument' = @(
            @{ Text='🧰 Utrustningslista';    Target=$UtrustningListPath },
            @{ Text='🧪 Kontrollprovsfil';    Target=$RawDataPath }
        )
        '🌐 Länkar' = @(
            @{ Text='⚡ IPT App';              Target='https://apps.powerapps.com/play/e/default-771c9c47-7f24-44dc-958e-34f8713a8394/a/fd340dbd-bbbf-470b-b043-d2af4cb62c83' },
            @{ Text='🌐 MES';                  Target='http://mes.cepheid.pri/camstarportal/?domain=CEPHEID.COM' },
            @{ Text='🌐 CSV Uploader';         Target='http://auw2wgxtpap01.cepaws.com/Welcome.aspx' },
            @{ Text='🌐 BMRAM';                Target='https://cepheid62468.coolbluecloud.com/' },
            @{ Text='🌐 Agile';                Target='https://agileprod.cepheid.com/Agile/default/login-cms.jsp' }
        )
    }
}

foreach ($grp in $ShortcutGroups.GetEnumerator()) {

    $grpMenu = New-Object System.Windows.Forms.ToolStripMenuItem($grp.Key)
    foreach ($entry in $grp.Value) { Add-ShortcutItem -Parent $grpMenu -Text $entry.Text -Target $entry.Target }
    [void]$miGenvagar.DropDownItems.Add($grpMenu)

}

$miOm = New-Object System.Windows.Forms.ToolStripMenuItem('ℹ️ Om det här verktyget'); [void]$miAbout.DropDownItems.Add($miOm)
$menuStrip.Items.AddRange(@($miArkiv,$miVerktyg,$miGenvagar,$miSettings,$miHelp,$miAbout))
$form.MainMenuStrip=$menuStrip

# ---------- Rubrik ----------
$panelHeader = New-Object System.Windows.Forms.Panel
$panelHeader.Dock='Top'; $panelHeader.Height=82
$panelHeader.BackColor=[System.Drawing.Color]::SteelBlue
$panelHeader.Padding = New-Object System.Windows.Forms.Padding(10,8,10,8)

$picLogo = New-Object System.Windows.Forms.PictureBox
$picLogo.Dock = 'Left'
$picLogo.Width = 50
$picLogo.BorderStyle = 'FixedSingle'
$picLogo.SizeMode = 'Zoom'
if (Test-Path -LiteralPath $ikonSokvag) { $picLogo.Image = [System.Drawing.Image]::FromFile($ikonSokvag) }

$panelText = New-Object System.Windows.Forms.Panel
$panelText.Dock = 'Fill'
$panelText.BackColor = $panelHeader.BackColor

$lblTitle = New-Object System.Windows.Forms.Label
$lblTitle.Text = "IPTCompile – $ScriptVersion"
$lblTitle.ForeColor = [System.Drawing.Color]::White
$lblTitle.Font = New-Object System.Drawing.Font('Segoe UI Semibold',13)
$lblTitle.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
$lblTitle.Dock = 'Top'
$lblTitle.Height = 36
$lblTitle.Padding = New-Object System.Windows.Forms.Padding(8,0,0,0)

$lblUpdate = New-Object System.Windows.Forms.Label
$lblUpdate.Text      = 'IPT Rapport-generator – sammanställning och granskning'
$lblUpdate.ForeColor = [System.Drawing.Color]::FromArgb(200,210,230)
$lblUpdate.Font      = New-Object System.Drawing.Font('Segoe UI',8)
$lblUpdate.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
$lblUpdate.Dock      = 'Top'
$lblUpdate.Height    = 16
$lblUpdate.Padding   = New-Object System.Windows.Forms.Padding(8,0,0,0)

$lblExtra = New-Object System.Windows.Forms.Label
$lblExtra.Text = 'Summering, kontrollmaterial, utrustningsblad, SharePoint-info etc. Under konstruktion.'
$lblExtra.ForeColor = [System.Drawing.Color]::FromArgb(200,210,230)
$lblExtra.Font = New-Object System.Drawing.Font('Segoe UI',8)
$lblExtra.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
$lblExtra.Dock = 'Top'
$lblExtra.Height = 14
$lblExtra.Padding = New-Object System.Windows.Forms.Padding(8,1,0,0)

$panelText.Controls.Add($lblExtra)
$panelText.Controls.Add($lblUpdate)
$panelText.Controls.Add($lblTitle)

$panelHeader.Controls.Add($panelText)
$panelHeader.Controls.Add($picLogo)

$panelHeader.Add_Resize({
    $innerH = $panelHeader.Height - $panelHeader.Padding.Top - $panelHeader.Padding.Bottom
    $picLogo.Height = $innerH
    $picLogo.Width  = $innerH 
})

$form.add_FormClosed({
    try { if ($picLogo.Image) { $picLogo.Image.Dispose() } } catch {}
    try { if ($script:SingleInstanceLockPath) { Clear-SingleInstanceThrottleLock -LockPath $script:SingleInstanceLockPath } } catch {}
})
$form.add_Shown({
    try {
        if ($script:btnMove3) { $script:btnMove3.Visible = $false }
        $form.Top -= 70
    } catch {}
    try { Apply-UserDefaults } catch {}
})

# ---------- Sök-rad ----------
$tlSearch = New-Object System.Windows.Forms.TableLayoutPanel
$tlSearch.Dock='Top'; $tlSearch.AutoSize=$true; $tlSearch.AutoSizeMode='GrowAndShrink'
$tlSearch.Padding = New-Object System.Windows.Forms.Padding(0,10,0,8)
$tlSearch.ColumnCount=3
[void]$tlSearch.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::AutoSize)))
[void]$tlSearch.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent,100)))
[void]$tlSearch.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute,130)))

$lblLSP = New-Object System.Windows.Forms.Label
$lblLSP.Text='LSP:'; $lblLSP.Anchor='Left'; $lblLSP.AutoSize=$true
$lblLSP.Margin = New-Object System.Windows.Forms.Padding(0,6,8,0)
$txtLSP = New-Object System.Windows.Forms.TextBox
$txtLSP.Dock='Fill'
$txtLSP.Margin = New-Object System.Windows.Forms.Padding(0,2,10,2)
# G2: Placeholder/cue-banner så användaren ser förväntat format
try {
    $null = Add-Type -Name 'WinUser_CueBanner' -Namespace 'IPT' -PassThru -MemberDefinition '
        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        public static extern IntPtr SendMessage(IntPtr hWnd, int msg, IntPtr wParam, string lParam);
    '
    $txtLSP.add_HandleCreated({
        [IPT.WinUser_CueBanner]::SendMessage($this.Handle, 0x1501, [IntPtr]::Zero, 'T.ex. 38401') | Out-Null
    })
} catch {}
$btnScan = New-Object System.Windows.Forms.Button
$btnScan.Text='Sök filer'; $btnScan.Dock='Fill'; Set-AccentButton $btnScan -Primary
$btnScan.Margin= New-Object System.Windows.Forms.Padding(0,2,0,2)

$tlSearch.Controls.Add($lblLSP,0,0)
$tlSearch.Controls.Add($txtLSP,1,0)

# ---------- Flytta nedladdade filer (Camstar -> Downloads -> N:) ----------
$grpDl = New-Object System.Windows.Forms.GroupBox
$grpDl.Text = 'Flytta nedladdade filer från "Downloads" vid granskning'
$grpDl.Dock = 'Top'
$grpDl.Padding = New-Object System.Windows.Forms.Padding(10,8,10,10)
$grpDl.AutoSize = $true
$grpDl.AutoSizeMode = [System.Windows.Forms.AutoSizeMode]::GrowAndShrink

$tlDl = New-Object System.Windows.Forms.TableLayoutPanel
$tlDl.Dock = 'Top'
$tlDl.AutoSize = $true
$tlDl.AutoSizeMode = [System.Windows.Forms.AutoSizeMode]::GrowAndShrink
$tlDl.ColumnCount = 3
$tlDl.RowCount = 1
$tlDl.Margin = New-Object System.Windows.Forms.Padding(0,0,0,0)
$tlDl.Padding = New-Object System.Windows.Forms.Padding(0,0,0,0)

# Kolumner: [Text tar allt] [KLART normal] [TEST liten]
[void]$tlDl.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 100)))
[void]$tlDl.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute, 240)))
[void]$tlDl.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute, 90)))
[void]$tlDl.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::AutoSize)))

$lblDl = New-Object System.Windows.Forms.Label
$lblDl.Text = 'Matchar LSP i filnamn och flyttar från Downloads till rätt granskningsmapp.'
$lblDl.Dock = 'Fill'
$lblDl.AutoSize = $false
$lblDl.AutoEllipsis = $true
$lblDl.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
$lblDl.Margin = New-Object System.Windows.Forms.Padding(0,0,10,0)

# KLART först (närmast texten)
$btnMove4 = New-Object System.Windows.Forms.Button
$btnMove4.Text = 'KLART FÖR GRANSKNING'
$btnMove4.Width = 240
$btnMove4.Height = 30
$btnMove4.Anchor = [System.Windows.Forms.AnchorStyles]::Right
$btnMove4.Margin = New-Object System.Windows.Forms.Padding(0,0,6,0)
Set-AccentButton $btnMove4

# TEST längst till höger (liten + dold)
$btnMove3 = New-Object System.Windows.Forms.Button
$btnMove3.Text = 'TEST'
$btnMove3.Width = 90
$btnMove3.Height = 30
$btnMove3.Anchor = [System.Windows.Forms.AnchorStyles]::Right
$btnMove3.Margin = New-Object System.Windows.Forms.Padding(0,0,0,0)
$btnMove3.Visible = $false
Set-AccentButton $btnMove3
$script:btnMove3 = $btnMove3

$tlDl.Controls.Add($lblDl, 0, 0)
$tlDl.Controls.Add($btnMove4, 1, 0)
$tlDl.Controls.Add($btnMove3, 2, 0)

$grpDl.Controls.Add($tlDl)
$tlSearch.Controls.Add($btnScan,2,0)

$pLog = New-Object System.Windows.Forms.Panel
$pLog.Dock='Top'; $pLog.Height=100; $pLog.Padding=New-Object System.Windows.Forms.Padding(0,0,0,8)

$outputBox = New-Object System.Windows.Forms.TextBox
$outputBox.Multiline=$true; $outputBox.ScrollBars='Vertical'; $outputBox.ReadOnly=$true
$outputBox.BackColor='White'; $outputBox.Dock='Fill'
$outputBox.Font = New-Object System.Drawing.Font('Segoe UI',9)
$pLog.Controls.Add($outputBox)
try { Set-LogOutputControl -Control $outputBox } catch {}
try {
    Set-AppLogSink -GuiLogScriptBlock {
        param($level, $message, $context)
        $sev = switch (($level + '').ToLowerInvariant()) {
            'error' { 'Error' }
            'warn'  { 'Warn'  }
            default { 'Info'  }
        }
        $cat = if (($level + '').ToLowerInvariant() -eq 'debug') { 'DEBUG' } else { 'CORE' }
        try { Gui-Log -Text ($message + '') -Severity $sev -Category $cat } catch {}
    } -EnableHostEcho:$false | Out-Null
} catch {}

$grpPick = New-Object System.Windows.Forms.GroupBox
$grpPick.Text='Välj filer för rapport'
$grpPick.Dock='Top'
$grpPick.Padding = New-Object System.Windows.Forms.Padding(10,12,10,14)
$grpPick.AutoSize=$false
$grpPick.Height = (78*3) + $grpPick.Padding.Top + $grpPick.Padding.Bottom +15

$tlPick = New-Object System.Windows.Forms.TableLayoutPanel
$tlPick.Dock='Fill'; $tlPick.ColumnCount=3; $tlPick.RowCount=3
$tlPick.GrowStyle=[System.Windows.Forms.TableLayoutPanelGrowStyle]::FixedSize
[void]$tlPick.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::AutoSize)))
[void]$tlPick.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent,100)))
[void]$tlPick.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute,100)))
for($i=0;$i -lt 3;$i++){ [void]$tlPick.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute,78))) }

function New-ListRow {
    param([string]$labelText,[ref]$lbl,[ref]$clb,[ref]$btn)
    $lbl.Value = New-Object System.Windows.Forms.Label
    $lbl.Value.Text=$labelText
    $lbl.Value.Anchor='Left'
    $lbl.Value.AutoSize=$true
    $lbl.Value.Margin=New-Object System.Windows.Forms.Padding(0,12,6,0)
    $clb.Value = New-Object System.Windows.Forms.CheckedListBox
    $clb.Value.Dock='Fill'
    $clb.Value.Margin=New-Object System.Windows.Forms.Padding(0,6,8,6)
    $clb.Value.Height=70
    $clb.Value.IntegralHeight=$false
    $clb.Value.CheckOnClick = $true
    $clb.Value.DisplayMember = 'Name'

    $btn.Value = New-Object System.Windows.Forms.Button
    $btn.Value.Text='Bläddra…'
    $btn.Value.Dock='Fill'
    $btn.Value.Margin=New-Object System.Windows.Forms.Padding(0,6,0,6)
    Set-AccentButton $btn.Value
}

$lblCsv=$null;$clbCsv=$null;$btnCsvBrowse=$null
New-ListRow -labelText 'CSV-fil:' -lbl ([ref]$lblCsv) -clb ([ref]$clbCsv) -btn ([ref]$btnCsvBrowse)
$lblNeg=$null;$clbNeg=$null;$btnNegBrowse=$null
New-ListRow -labelText 'Seal Test Neg:' -lbl ([ref]$lblNeg) -clb ([ref]$clbNeg) -btn ([ref]$btnNegBrowse)
$lblPos=$null;$clbPos=$null;$btnPosBrowse=$null
New-ListRow -labelText 'Seal Test Pos:' -lbl ([ref]$lblPos) -clb ([ref]$clbPos) -btn ([ref]$btnPosBrowse)

try {
    if ($tlPick.RowCount -lt 4) {
        $tlPick.RowCount = 4
        for ($i=$tlPick.RowStyles.Count; $i -lt 4; $i++) {
            $null = $tlPick.RowStyles.Add( (New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 78)) )
        }
        $grpPick.Height = (78*4) + $grpPick.Padding.Top + $grpPick.Padding.Bottom + 15
    }
} catch {}

$lblLsp = $null; $clbLsp = $null; $btnLspBrowse = $null
New-ListRow -labelText 'Worksheet:' -lbl ([ref]$lblLsp) -clb ([ref]$clbLsp) -btn ([ref]$btnLspBrowse)

$tlPick.Controls.Add($lblLsp,  0, 3)
$tlPick.Controls.Add($clbLsp,  1, 3)
$tlPick.Controls.Add($btnLspBrowse, 2, 3)

$clbLsp.add_ItemCheck({
    param($s,$e)
    if ($e.NewValue -eq [System.Windows.Forms.CheckState]::Checked) {
        for ($i=0; $i -lt $s.Items.Count; $i++) {
            if ($i -ne $e.Index) { $s.SetItemChecked($i, $false) }
        }
    }
})

$btnLspBrowse.Add_Click({
    try {
        $dlg = New-Object System.Windows.Forms.OpenFileDialog
        $dlg.Filter = "Excel|*.xlsx;*.xlsm|Alla filer|*.*"
        $dlg.Title  = "Välj LSP Worksheet"
        if ($dlg.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
            $f = Get-Item -LiteralPath $dlg.FileName
            Add-CLBItems -clb $clbLsp -files @($f) -AutoCheckFirst
            if (Get-Command Update-StatusBar -ErrorAction SilentlyContinue) { Update-StatusBar }
        }
    } catch {
        Gui-Log ("⚠️ LSP-browse fel: " + $_.Exception.Message) 'Warn'
    }
})

# Lägg in i tabellen
$tlPick.Controls.Add($lblCsv,0,0); $tlPick.Controls.Add($clbCsv,1,0); $tlPick.Controls.Add($btnCsvBrowse,2,0)
$tlPick.Controls.Add($lblNeg,0,1); $tlPick.Controls.Add($clbNeg,1,1); $tlPick.Controls.Add($btnNegBrowse,2,1)
$tlPick.Controls.Add($lblPos,0,2); $tlPick.Controls.Add($clbPos,1,2); $tlPick.Controls.Add($btnPosBrowse,2,2)
$grpPick.Controls.Add($tlPick)

# ---------- Signering: Sammanställning ----------
$grpSignSamm = New-Object System.Windows.Forms.GroupBox
$grpSignSamm.Text = 'Signering — Sammanställning'
$grpSignSamm.Dock = 'Top'
$grpSignSamm.Padding = New-Object System.Windows.Forms.Padding(10,8,10,10)
$grpSignSamm.AutoSize = $false
$grpSignSamm.Height = 140

$tlSignSamm = New-Object System.Windows.Forms.TableLayoutPanel
$tlSignSamm.Dock = 'Fill'; $tlSignSamm.ColumnCount = 2; $tlSignSamm.RowCount = 4
[void]$tlSignSamm.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::AutoSize)))
[void]$tlSignSamm.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent,100)))
for ($i = 0; $i -lt 4; $i++) {
    [void]$tlSignSamm.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute,26)))
}

$lblSammName = New-Object System.Windows.Forms.Label
$lblSammName.Text = 'Full Name:'; $lblSammName.Anchor = 'Left'; $lblSammName.AutoSize = $true
$txtSammName = New-Object System.Windows.Forms.TextBox
$txtSammName.Dock = 'Fill'; $txtSammName.Margin = New-Object System.Windows.Forms.Padding(6,2,0,2)

$lblSammDate = New-Object System.Windows.Forms.Label
$lblSammDate.Text = 'Date:'; $lblSammDate.Anchor = 'Left'; $lblSammDate.AutoSize = $true
$txtSammDate = New-Object System.Windows.Forms.TextBox
$txtSammDate.Dock = 'Fill'; $txtSammDate.Margin = New-Object System.Windows.Forms.Padding(6,2,0,2)

$lblSealTestSign = New-Object System.Windows.Forms.Label
$lblSealTestSign.Text = 'SIGN:'; $lblSealTestSign.Anchor = 'Left'; $lblSealTestSign.AutoSize = $true
$txtSealTestSign = New-Object System.Windows.Forms.TextBox
$txtSealTestSign.Dock = 'Fill'; $txtSealTestSign.Margin = New-Object System.Windows.Forms.Padding(6,2,0,2)

$chkSealTest = New-Object System.Windows.Forms.CheckBox
$chkSealTest.Text = ' Seal Test (NEG+POS)'; $chkSealTest.AutoSize = $true; $chkSealTest.Margin = New-Object System.Windows.Forms.Padding(0,2,12,2)
$chkWsSamm = New-Object System.Windows.Forms.CheckBox
$chkWsSamm.Text = ' Worksheet (Sammanst.)'; $chkWsSamm.AutoSize = $true; $chkWsSamm.Margin = New-Object System.Windows.Forms.Padding(0,2,12,2)
$chkSignOverwrite = New-Object System.Windows.Forms.CheckBox
$chkSignOverwrite.Text = ' Aktivera Signering'; $chkSignOverwrite.AutoSize = $true; $chkSignOverwrite.Margin = New-Object System.Windows.Forms.Padding(0,2,0,2)
$chkSignOverwrite.ForeColor = [System.Drawing.Color]::FromArgb(180,80,80)
$chkSignOverwrite.Tag = 'Skriver över befintlig signatur i Seal Test + Worksheet (Sammanställning)'

$flpSammChk = New-Object System.Windows.Forms.FlowLayoutPanel
$flpSammChk.Dock = 'Fill'; $flpSammChk.FlowDirection = 'LeftToRight'; $flpSammChk.WrapContents = $false
$flpSammChk.AutoSize = $true; $flpSammChk.Margin = New-Object System.Windows.Forms.Padding(0)
$flpSammChk.Controls.Add($chkSealTest)
$flpSammChk.Controls.Add($chkWsSamm)
$flpSammChk.Controls.Add($chkSignOverwrite)

$tlSignSamm.Controls.Add($lblSammName,0,0);    $tlSignSamm.Controls.Add($txtSammName,1,0)
$tlSignSamm.Controls.Add($lblSammDate,0,1);    $tlSignSamm.Controls.Add($txtSammDate,1,1)
$tlSignSamm.Controls.Add($lblSealTestSign,0,2);$tlSignSamm.Controls.Add($txtSealTestSign,1,2)
$tlSignSamm.Controls.Add($flpSammChk,0,3);     $tlSignSamm.SetColumnSpan($flpSammChk,2)
$grpSignSamm.Controls.Add($tlSignSamm)
$grpSignSamm.Visible = $false

# ---------- Signering: Granskning ----------
$grpSignGransk = New-Object System.Windows.Forms.GroupBox
$grpSignGransk.Text = 'Signering — Granskning'
$grpSignGransk.Dock = 'Top'
$grpSignGransk.Padding = New-Object System.Windows.Forms.Padding(10,8,10,10)
$grpSignGransk.AutoSize = $false
$grpSignGransk.Height = 110

$tlSignGransk = New-Object System.Windows.Forms.TableLayoutPanel
$tlSignGransk.Dock = 'Fill'; $tlSignGransk.ColumnCount = 2; $tlSignGransk.RowCount = 3
[void]$tlSignGransk.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::AutoSize)))
[void]$tlSignGransk.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent,100)))
for ($i = 0; $i -lt 3; $i++) {
    [void]$tlSignGransk.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute,26)))
}

$lblGranskName = New-Object System.Windows.Forms.Label
$lblGranskName.Text = 'Full Name:'; $lblGranskName.Anchor = 'Left'; $lblGranskName.AutoSize = $true
$txtGranskName = New-Object System.Windows.Forms.TextBox
$txtGranskName.Dock = 'Fill'; $txtGranskName.Margin = New-Object System.Windows.Forms.Padding(6,2,0,2)

$lblGranskDate = New-Object System.Windows.Forms.Label
$lblGranskDate.Text = 'Date:'; $lblGranskDate.Anchor = 'Left'; $lblGranskDate.AutoSize = $true
$txtGranskDate = New-Object System.Windows.Forms.TextBox
$txtGranskDate.Dock = 'Fill'; $txtGranskDate.Margin = New-Object System.Windows.Forms.Padding(6,2,0,2)

$chkWsGransk = New-Object System.Windows.Forms.CheckBox
$chkWsGransk.Text = ' Worksheet (Granskning)'; $chkWsGransk.AutoSize = $true; $chkWsGransk.Margin = New-Object System.Windows.Forms.Padding(0,2,12,2)
$chkGranskOverwrite = New-Object System.Windows.Forms.CheckBox
$chkGranskOverwrite.Text = ' Aktivera överskrivning'; $chkGranskOverwrite.AutoSize = $true; $chkGranskOverwrite.Margin = New-Object System.Windows.Forms.Padding(0,2,0,2)
$chkGranskOverwrite.Tag = 'Skriver över befintlig granskning i Worksheet'
$chkGranskOverwrite.ForeColor = [System.Drawing.Color]::FromArgb(180,80,80)

$flpGranskChk = New-Object System.Windows.Forms.FlowLayoutPanel
$flpGranskChk.Dock = 'Fill'; $flpGranskChk.FlowDirection = 'LeftToRight'; $flpGranskChk.WrapContents = $false
$flpGranskChk.AutoSize = $true; $flpGranskChk.Margin = New-Object System.Windows.Forms.Padding(0)
$flpGranskChk.Controls.Add($chkWsGransk)
$flpGranskChk.Controls.Add($chkGranskOverwrite)

$tlSignGransk.Controls.Add($lblGranskName,0,0); $tlSignGransk.Controls.Add($txtGranskName,1,0)
$tlSignGransk.Controls.Add($lblGranskDate,0,1); $tlSignGransk.Controls.Add($txtGranskDate,1,1)
$tlSignGransk.Controls.Add($flpGranskChk,0,2);  $tlSignGransk.SetColumnSpan($flpGranskChk,2)
$grpSignGransk.Controls.Add($tlSignGransk)
$grpSignGransk.Visible = $false

$baseHeight = $form.Height

# ---------- Primärknapp ----------

$btnBuild = New-Object System.Windows.Forms.Button
$btnBuild.Text='Skapa rapport'; $btnBuild.Dock='Top'; $btnBuild.Height=40
$btnBuild.Margin = New-Object System.Windows.Forms.Padding(0,16,0,8)
$btnBuild.Enabled=$false; Set-AccentButton $btnBuild -Primary

# ---------- Statusrad ----------
$status = New-Object System.Windows.Forms.StatusStrip
$status.SizingGrip=$false; $status.Dock='Bottom'; $status.Font=New-Object System.Drawing.Font('Segoe UI',9)
$status.ShowItemToolTips = $true
$slCount = New-Object System.Windows.Forms.ToolStripStatusLabel; $slCount.Text='0 filer valda'; $slCount.Spring=$false
$slWork  = New-Object System.Windows.Forms.ToolStripStatusLabel
$slWork.Text   = ''
$slWork.Spring = $true

$pbWork = New-Object System.Windows.Forms.ToolStripProgressBar
$pbWork.Visible = $false
$pbWork.Style   = 'Marquee'
$pbWork.MarqueeAnimationSpeed = 30
$pbWork.AutoSize = $false
$pbWork.Width    = 140

$slSpacer= New-Object System.Windows.Forms.ToolStripStatusLabel; $slSpacer.Spring=$true

# --- Klickbar SharePoint-länk ---
$slBatchLink = New-Object System.Windows.Forms.ToolStripStatusLabel
$slBatchLink.IsLink   = $true
$slBatchLink.Text     = 'SharePoint: —'
$slBatchLink.Enabled  = $false
$slBatchLink.Tag      = $null
$slBatchLink.ToolTipText = 'Direktlänk aktiveras när Batch# hittas i filer.'
$slBatchLink.add_Click({
    if ($this.Enabled -and $this.Tag) {
        try { Start-Process -FilePath ([string]$this.Tag) } catch {
            [System.Windows.Forms.MessageBox]::Show("Kunde inte öppna:`n$($this.Tag)`n$($_.Exception.Message)","Länk") | Out-Null
        }
    }
})

# --- SharePoint On-Demand Connect-knapp ---
$script:btnSpConnect = New-Object System.Windows.Forms.ToolStripButton
$script:btnSpConnect.DisplayStyle = 'Text'
$script:btnSpConnect.Font = New-Object System.Drawing.Font('Segoe UI',9,[System.Drawing.FontStyle]::Bold)

if ($global:SpConnected) {
    $script:btnSpConnect.Text = '✅ SP'
    $script:btnSpConnect.ToolTipText = 'SharePoint är anslutet.'
    $script:btnSpConnect.Enabled = $false
} elseif ($global:SpEnabled) {
    $script:btnSpConnect.Text = '🔌 Anslut SP'
    $script:btnSpConnect.ToolTipText = 'Klicka för att ansluta till SharePoint (tar ~10–15 sek).'
    $script:btnSpConnect.Enabled = $true
} else {
    $script:btnSpConnect.Text = '⛔ SP av'
    $script:btnSpConnect.ToolTipText = 'SharePoint är avstängt i konfigurationen.'
    $script:btnSpConnect.Enabled = $false
}

$script:btnSpConnect.add_Click({
    if (-not $global:SpEnabled) { return }
    if ($global:SpConnected) { return }
    if ($global:SpConnecting) { return }

    # Uppdatera knappen
    $this.Text        = '⏳ Ansluter…'
    $this.Enabled     = $false
    $this.ToolTipText = 'Ansluter till SharePoint – vänta…'

    Show-Splash 'Förbereder SharePoint…'

    # Steg 1: Starta SPClient-runspace synkront (snabbt, ~1-2 sek)
    #         PnP import sker här; om det misslyckas avbryt direkt.
    $startOk = Start-SPClient -ProgressCallback { param($m) Update-Splash $m }
    if (-not $startOk) {
        Close-Splash
        $script:btnSpConnect.Text        = '❌ SP – retry?'
        $script:btnSpConnect.ToolTipText = "Misslyckades: $($global:SpError)`nKlicka för att försöka igen."
        $script:btnSpConnect.Enabled     = $true
        Gui-Log ("⚠️ SharePoint-förberedelse misslyckades: " + $global:SpError) 'Warn'
        return
    }

    # Steg 2: Starta Connect-PnPOnline asynkront (kör i SPClient-runspacen)
    Update-Splash 'Loggar in…'
    $asyncOk = Connect-SPClientAsync
    if (-not $asyncOk) {
        Close-Splash
        $script:btnSpConnect.Text        = '❌ SP – retry?'
        $script:btnSpConnect.ToolTipText = "Misslyckades: $($global:SpError)`nKlicka för att försöka igen."
        $script:btnSpConnect.Enabled     = $true
        Gui-Log ("⚠️ Kunde inte starta SP-anslutning: " + $global:SpError) 'Warn'
        return
    }

    # Steg 3: Timer som pollar var 200 ms tills async är klart
    $script:spPollTimer = New-Object System.Windows.Forms.Timer
    $script:spPollTimer.Interval = 200
    $script:spPollTimer.add_Tick({
        $result = Poll-SPClientAsync
        if ($null -eq $result) { return }   # Fortfarande igång

        # Klart — stoppa timer och splash
        $script:spPollTimer.Stop()
        $script:spPollTimer.Dispose()
        $script:spPollTimer = $null
        Close-Splash

        if ($result.Ok) {
            $script:btnSpConnect.Text        = '✅ SP'
            $script:btnSpConnect.ToolTipText = 'SharePoint anslutet.'
            $script:btnSpConnect.Enabled     = $false
            Gui-Log '✅ SharePoint anslutet.' 'Info'
        } else {
            $script:btnSpConnect.Text        = '❌ SP – retry?'
            $script:btnSpConnect.ToolTipText = "Misslyckades: $($global:SpError)`nKlicka för att försöka igen."
            $script:btnSpConnect.Enabled     = $true
            Gui-Log ("⚠️ SharePoint-anslutning misslyckades: " + $global:SpError) 'Warn'
        }
    })
    $script:spPollTimer.Start()
})

$status.Items.AddRange(@($slCount,$slWork,$pbWork,$script:btnSpConnect,$slBatchLink))
$tsc = New-Object System.Windows.Forms.ToolStripContainer
$tsc.Dock = 'Fill'
$tsc.LeftToolStripPanelVisible  = $false
$tsc.RightToolStripPanelVisible = $false

$form.SuspendLayout()
$form.Controls.Clear()
$form.Controls.Add($tsc)

# Meny högst upp
$tsc.TopToolStripPanel.Controls.Add($menuStrip)
$form.MainMenuStrip = $menuStrip

# Status längst ner
$tsc.BottomToolStripPanel.Controls.Add($status)

# Content i mitten
$content = New-Object System.Windows.Forms.Panel
$content.Dock='Fill'
$content.BackColor = $form.BackColor
$tsc.ContentPanel.Controls.Add($content)

# Dock=Top: nedersta först
$content.SuspendLayout()
$content.Controls.Add($btnBuild)
$content.Controls.Add($grpSignGransk)
$content.Controls.Add($grpSignSamm)
$content.Controls.Add($grpPick)
$content.Controls.Add($pLog)
$content.Controls.Add($grpDl)
$content.Controls.Add($tlSearch)
$content.Controls.Add($panelHeader)
$content.ResumeLayout()
$form.ResumeLayout()
$form.PerformLayout()
$form.AcceptButton = $btnScan

#endregion GUI-bygge

#region Hjälpfunktioner (UI-logik, filval, validering)


function Get-UserProfileFromConfig {
    param([hashtable]$Config)

    $u = (($env:USERNAME + '').Trim()).ToLowerInvariant()
    if (-not $u) { return $null }

    $users = $null
    try { $users = $Config.Users } catch { $users = $null }

    if ($users -and ($users -is [System.Collections.IDictionary]) -and $users.Contains($u)) {
        $p = $users[$u]
        return [pscustomobject]@{
            Username         = $u
            FullName         = (($p.FullName + '').Trim())
            SealTestInitials = (($p.SealTestInitials + '').Trim())
        }
    }
    return $null
}

function Apply-UserDefaults {
    try {
        if (-not $script:UserProfile) { $script:UserProfile = Get-UserProfileFromConfig -Config $Config }
        $p = $script:UserProfile
        if (-not $p) { return }

        # Sammanställning: Full Name + Seal Test initialer
        if ($txtSammName -and -not (($txtSammName.Text + '').Trim())) { $txtSammName.Text = $p.FullName }
        if ($txtSealTestSign -and -not (($txtSealTestSign.Text + '').Trim())) { $txtSealTestSign.Text = $p.SealTestInitials }

        # Granskning: Full Name
        if ($txtGranskName -and -not (($txtGranskName.Text + '').Trim())) { $txtGranskName.Text = $p.FullName }
    } catch {}
}



function Add-CLBItems {
    param([System.Windows.Forms.CheckedListBox]$clb,[System.IO.FileInfo[]]$files,[switch]$AutoCheckFirst)
    $clb.BeginUpdate()
    $clb.Items.Clear()
    foreach($f in $files){
        if ($f -isnot [System.IO.FileInfo]) { try { $f = Get-Item -LiteralPath $f } catch { continue } }
        [void]$clb.Items.Add($f, $false)
    }
    $clb.EndUpdate()
    if ($AutoCheckFirst -and $clb.Items.Count -gt 0) { $clb.SetItemChecked(0,$true) }
    Update-StatusBar
}

function Get-CheckedFilePath { param([System.Windows.Forms.CheckedListBox]$clb)
    if (-not $clb) { return $null }
    for($i=0;$i -lt $clb.Items.Count;$i++){
        if ($clb.GetItemChecked($i)) {
            $fi = [System.IO.FileInfo]$clb.Items[$i]
            return $fi.FullName
        }
    }
    return $null
}

function Get-AllCheckedFilePaths { param([System.Windows.Forms.CheckedListBox]$clb)
    if (-not $clb) { return @() }
    $paths = New-Object 'System.Collections.Generic.List[string]'
    for($i=0;$i -lt $clb.Items.Count;$i++){
        if ($clb.GetItemChecked($i)) {
            $fi = [System.IO.FileInfo]$clb.Items[$i]
            [void]$paths.Add($fi.FullName)
        }
    }
    return @($paths.ToArray())
}

function Clear-GUI {
    $txtLSP.Text = ''
    $txtSammName.Text = ''; $txtSammDate.Text = ''; $txtSealTestSign.Text = ''
    $chkSealTest.Checked = $false; $chkWsSamm.Checked = $false; $chkSignOverwrite.Checked = $false
    $txtGranskName.Text = ''; $txtGranskDate.Text = ''
    $chkWsGransk.Checked = $false; $chkGranskOverwrite.Checked = $false

    # Nollställ ALLA build-relaterade cacher (förhindra cross-kontaminering mellan körningar)
    $script:RobalDateShort          = $null
    $script:RuleEngineShadow        = $null
    $script:RuleEngineShadowRes     = $null
    $script:RuleEngineCsvObjs       = $null
    $script:RuleEngineCsvObjsRes    = $null
    $script:RuleBankCache           = $null
    $script:CsvLinesPrimary         = $null
    $script:CsvLinesResample        = $null
    $script:QcReminderB3            = $null

    Add-CLBItems -clb $clbCsv -files @()
    Add-CLBItems -clb $clbNeg -files @()
    Add-CLBItems -clb $clbPos -files @()
    Add-CLBItems -clb $clbLsp -files @()
    $outputBox.Clear()
    Update-BuildEnabled
    Gui-Log "🧹 Fönstret rensat." 'Info'
    Update-BatchLink
    try { Apply-UserDefaults } catch {}
}

$onExclusive = {
    $clb = $this
    if ($_.NewValue -eq [System.Windows.Forms.CheckState]::Checked) {
        for ($i=0; $i -lt $clb.Items.Count; $i++) {
            if ($i -ne $_.Index -and $clb.GetItemChecked($i)) { $clb.SetItemChecked($i, $false) }
        }
    }
    $clb.BeginInvoke([Action]{ Update-BuildEnabled }) | Out-Null
}

# CSV: tillåt max 2 valda (primär + resample)
$onCsvMax2 = {
    $clb = $this
    if ($_.NewValue -eq [System.Windows.Forms.CheckState]::Checked) {
        $checkedCount = 0
        for ($i=0; $i -lt $clb.Items.Count; $i++) {
            if ($i -ne $_.Index -and $clb.GetItemChecked($i)) { $checkedCount++ }
        }
        if ($checkedCount -ge 2) {
            # Redan 2 valda → avmarkera äldsta (första hittade)
            for ($i=0; $i -lt $clb.Items.Count; $i++) {
                if ($i -ne $_.Index -and $clb.GetItemChecked($i)) { $clb.SetItemChecked($i, $false); break }
            }
        }
    }
    $clb.BeginInvoke([Action]{ Update-BuildEnabled }) | Out-Null
}
$clbCsv.add_ItemCheck($onCsvMax2)
$clbNeg.add_ItemCheck($onExclusive)
$clbPos.add_ItemCheck($onExclusive)

function Get-SelectedFileCount {
    $n = 0

    # CSV kan vara 1–2 filer vid resample
    try {
        if ($clbCsv -and $clbCsv.CheckedItems) { $n += [int]$clbCsv.CheckedItems.Count }
        elseif (Get-CheckedFilePath $clbCsv) { $n++ }
    } catch {
        if (Get-CheckedFilePath $clbCsv) { $n++ }
    }

    if (Get-CheckedFilePath $clbNeg) { $n++ }
    if (Get-CheckedFilePath $clbPos) { $n++ }
    if (Get-CheckedFilePath $clbLsp) { $n++ }
    return $n
}

function Update-StatusBar { $slCount.Text = "$(Get-SelectedFileCount) filer valda" }

function Invoke-UiPump {
    try { [System.Windows.Forms.Application]::DoEvents() } catch {}
}

function Set-UiBusy {
    param(
        [Parameter(Mandatory)][bool]$Busy,
        [string]$Message = ''
    )
    try {
        if ($Busy) {
            $slWork.Text = $Message
            $pbWork.Visible = $true
            $pbWork.Style   = 'Marquee'
            $form.Cursor = [System.Windows.Forms.Cursors]::WaitCursor
            $btnScan.Enabled  = $false
            $btnBuild.Enabled = $false
        } else {
            $pbWork.Visible = $false
            $pbWork.Style   = 'Blocks'
            $pbWork.Value   = 0
            $slWork.Text = ''
            $form.Cursor = [System.Windows.Forms.Cursors]::Default
            $btnScan.Enabled = $true
            Update-BuildEnabled
        }
        $status.Refresh()
        $form.Refresh()
        Invoke-UiPump
    } catch {}
}

function Set-UiStep {
    param(
        [Parameter(Mandatory)][int]$Percent,
        [string]$Message = ''
    )
    try {
        if ($Percent -lt 0) { $Percent = 0 }
        if ($Percent -gt 100) { $Percent = 100 }
        $slWork.Text = $Message
        $pbWork.Visible = $true
        $pbWork.Style   = 'Blocks'
        $pbWork.Minimum = 0
        $pbWork.Maximum = 100
        if ($pbWork.Value -ne $Percent) { $pbWork.Value = $Percent }
        $status.Refresh()
        $form.Refresh()
        Invoke-UiPump
    } catch {}
}


function Update-BuildEnabled {
    $btnBuild.Enabled = ((Get-CheckedFilePath $clbNeg) -and (Get-CheckedFilePath $clbPos))
    Update-StatusBar
}

$script:LastScanResult = $null
$script:RobalDateShort = $null   # Auto-populated from SP 'ROBAL - Actual start date/time' during build

# Skydd mot återinträde (DoEvents kan annars ge nästlade klick)
$script:ScanInProgress  = $false
$script:BuildInProgress = $false

function Get-BatchLinkInfo {
    param(
        [string]$SealPosPath,
        [string]$SealNegPath,
        [string]$Lsp
    )

    $batch = $null
    try { if ($SealPosPath) { $batch = Get-BatchNumberFromSealFile $SealPosPath } } catch {}
    if (-not $batch) {
        try { if ($SealNegPath) { $batch = Get-BatchNumberFromSealFile $SealNegPath } } catch {}
    }

    $batchEsc = if ($batch) { [uri]::EscapeDataString($batch) } else { '' }
    $lspEsc   = if ($Lsp)   { [uri]::EscapeDataString($Lsp) }   else { '' }

    $url = if ($SharePointBatchLinkTemplate) {
        ($SharePointBatchLinkTemplate -replace '\{BatchNumber\}', $batchEsc) -replace '\{LSP\}', $lspEsc
    } else {
        "https://danaher.sharepoint.com/sites/CEP-Sweden-Production-Management/Lists/Cepheid%20%20Production%20orders/AllItems.aspx?view=7&q=$batchEsc"
    }
    $linkText = if ($batch) { "Öppna $batch" } else { 'Ingen batch funnen' }

    return [pscustomobject]@{
        Batch    = $batch
        Url      = $url
        LinkText = $linkText
    }
}

function Assert-StartupReady {
    if ($global:StartupReady) { return $true }
    Gui-Log "❌ Startkontroll misslyckades. Åtgärda konfigurationsfel innan du fortsätter." 'Error'
    return $false
}

function Find-LspFolder {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)] [string]$Lsp,
        [Parameter(Mandatory)] [string[]]$Roots
    )

    $lspRaw = ($Lsp + '').Trim()
    if (-not $lspRaw) { return $null }

    # Tillåt att användaren skriver t.ex. "#38401" eller "38401" eller "LSP 38401".
    $lspDigits = ($lspRaw -replace '\D', '')
    if (-not $lspDigits) { return $null }

    # Matcha som "eget tal": undvik att 3840 matchar 38401 osv.
    $rxToken = "(?<!\d)#?\s*$lspDigits(?!\d)"

    # Snabb väg: använd -Filter först (fil-systemet kan optimera) + matcha med rxToken för att undvika falska träffar.
    $filters = @("*$lspDigits*", "*#$lspDigits*")

    foreach ($root in $Roots) {
        if (-not $root) { continue }
        if (-not (Test-Path -LiteralPath $root)) { continue }

        # 1) Försök hitta i översta nivån (vanligaste fallet)
        foreach ($f in $filters) {
            try {
                $hit = Get-ChildItem -LiteralPath $root -Directory -Filter $f -ErrorAction SilentlyContinue |
                       Where-Object { $_.Name -match $rxToken } |
                       Select-Object -First 1
                if ($hit) { return $hit }
            } catch {}
        }

        # 2) Försök med -Recurse + -Filter
        foreach ($f in $filters) {
            try {
                $hit = Get-ChildItem -LiteralPath $root -Directory -Recurse -Filter $f -ErrorAction SilentlyContinue |
                       Where-Object { $_.Name -match $rxToken } |
                       Select-Object -First 1
                if ($hit) { return $hit }
            } catch {}
        }

        # 3) Reservväg
        try {
            $hit = Get-ChildItem -LiteralPath $root -Directory -Recurse -ErrorAction SilentlyContinue |
                   Where-Object { $_.Name -match $rxToken } |
                   Select-Object -First 1
            if ($hit) { return $hit }
        } catch {}
    }

    return $null
}

function Get-DefaultDownloadsPath {
    try {
        # Försök använda känd mapp (Shell)
        $d = [Environment]::GetFolderPath('UserProfile')
        if ($d) {
            $cand = Join-Path $d 'Downloads'
            if (Test-Path -LiteralPath $cand) { return $cand }
        }
    } catch {}
    try {
        $cand = Join-Path $env:USERPROFILE 'Downloads'
        if (Test-Path -LiteralPath $cand) { return $cand }
    } catch {}
    return $null
}

function Get-DownloadsPathEffective {
    $cfg = Get-ConfigValue -Name 'DownloadsDir' -Default '' -ConfigOverride $Config
    $cfg = ($cfg + '').Trim()
    if ($cfg) {
        try { if (Test-Path -LiteralPath $cfg) { return $cfg } } catch {}
    }
    return (Get-DefaultDownloadsPath)
}

function Get-LspDigitsFromString {
    param([Parameter(Mandatory=$true)][string]$Text)

    $s = ($Text + '')
    if (-not $s) { return $null }

    # Primär: LSP + exakt 5 siffror
    if ($s -match '(?i)(?<!\d)LSP\D*(\d{5})(?!\d)') { return $matches[1] }

    # Sekundär: bara en fristående 5-siffrig token (t.ex. "#38401" eller " 38401 ")
    if ($s -match '(?i)(?<!\d)#?\s*(\d{5})(?!\d)') { return $matches[1] }

    return $null
}

function Get-UniqueDestinationPath {
    param(
        [Parameter(Mandatory=$true)][string]$DestinationDir,
        [Parameter(Mandatory=$true)][string]$FileName
    )

    $base = [System.IO.Path]::GetFileNameWithoutExtension($FileName)
    $ext  = [System.IO.Path]::GetExtension($FileName)
    $cand = Join-Path $DestinationDir ($base + $ext)
    if (-not (Test-Path -LiteralPath $cand)) { return $cand }

    for ($i=1; $i -le 50; $i++) {
        $cand = Join-Path $DestinationDir ("{0} ({1}){2}" -f $base, $i, $ext)
        if (-not (Test-Path -LiteralPath $cand)) { return $cand }
    }

    $stamp = (Get-Date).ToString('yyyyMMdd_HHmmss')
    return (Join-Path $DestinationDir ("{0} ({1}){2}" -f $base, $stamp, $ext))
}

function Show-ListSelectionDialog {
    param(
       [Parameter(Mandatory=$true)][string]$Title,
        [Parameter(Mandatory=$true)][string]$Prompt,
        [Parameter(Mandatory=$true)][string[]]$Items
    )
    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text = $Title
    $dlg.StartPosition = 'CenterParent'
    $dlg.Size = New-Object System.Drawing.Size(520,420)
    $dlg.MinimumSize = New-Object System.Drawing.Size(520,420)
    $dlg.MaximizeBox = $false
    $dlg.MinimizeBox = $false
    $dlg.FormBorderStyle = 'FixedDialog'
    $dlg.Font = New-Object System.Drawing.Font('Segoe UI',10)

    $lbl = New-Object System.Windows.Forms.Label
    $lbl.Text = $Prompt
    $lbl.Dock = 'Top'
    $lbl.Height = 44
    $lbl.Padding = New-Object System.Windows.Forms.Padding(10,10,10,0)

    $list = New-Object System.Windows.Forms.ListBox
    $list.Dock = 'Fill'
    $list.IntegralHeight = $false
    $list.SelectionMode = 'One'
    [void]$list.Items.AddRange($Items)

    $panelBtns = New-Object System.Windows.Forms.Panel
    $panelBtns.Dock = 'Bottom'
    $panelBtns.Height = 52
    $panelBtns.Padding = New-Object System.Windows.Forms.Padding(10,8,10,8)

    $btnOk = New-Object System.Windows.Forms.Button
    $btnOk.Text = 'OK'
    $btnOk.Width = 90
    $btnOk.Anchor = 'Right'
    $btnOk.DialogResult = [System.Windows.Forms.DialogResult]::OK

    $btnCancel = New-Object System.Windows.Forms.Button
    $btnCancel.Text = 'Avbryt'
    $btnCancel.Width = 90
    $btnCancel.Anchor = 'Right'
    $btnCancel.DialogResult = [System.Windows.Forms.DialogResult]::Cancel

    $btnCancel.Location = New-Object System.Drawing.Point(($panelBtns.Width - 100), 10)

    $panelBtns.Controls.Add($btnCancel)
    $panelBtns.Controls.Add($btnOk)

    $btnOk.Location = New-Object System.Drawing.Point(($dlg.ClientSize.Width - 210), 10)
    $btnCancel.Location = New-Object System.Drawing.Point(($dlg.ClientSize.Width - 110), 10)

    $dlg.AcceptButton = $btnOk
    $dlg.CancelButton = $btnCancel

    $dlg.Controls.Add($list)
    $dlg.Controls.Add($panelBtns)
    $dlg.Controls.Add($lbl)

    $list.add_DoubleClick({ if ($list.SelectedItem) { $dlg.DialogResult = [System.Windows.Forms.DialogResult]::OK; $dlg.Close() } })

    $res = $dlg.ShowDialog($form)
    if ($res -ne [System.Windows.Forms.DialogResult]::OK) { return $null }
    if (-not $list.SelectedItem) { return $null }
    return [string]$list.SelectedItem
}

function Show-FileMoveSelectionDialog {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)][string]$Title,
        [Parameter(Mandatory=$true)][string]$Prompt,
        [Parameter(Mandatory=$true)][System.IO.FileInfo[]]$Files,
        [Parameter(Mandatory=$false)][string[]]$DefaultCheckedExtensions = @('.csv','.xlsx','.xlsm','.pdf')
    )

    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text = $Title
    $dlg.StartPosition = 'CenterParent'
    $dlg.Size = New-Object System.Drawing.Size(780,520)
    $dlg.MinimumSize = New-Object System.Drawing.Size(780,520)
    $dlg.MaximizeBox = $false
    $dlg.MinimizeBox = $false
    $dlg.FormBorderStyle = 'FixedDialog'
    $dlg.Font = New-Object System.Drawing.Font('Segoe UI',10)

    $lbl = New-Object System.Windows.Forms.Label
    $lbl.Text = $Prompt
    $lbl.Dock = 'Top'
    $lbl.Height = 54
    $lbl.Padding = New-Object System.Windows.Forms.Padding(10,10,10,0)

    $clb = New-Object System.Windows.Forms.CheckedListBox
    $clb.Dock = 'Fill'
    $clb.IntegralHeight = $false
    $clb.CheckOnClick = $true
    $clb.DisplayMember = 'Display'

    # Bygg items med tydlig rad: filnamn + datum + storlek
    $items = New-Object System.Collections.Generic.List[object]
    foreach ($f in ($Files | Sort-Object LastWriteTime -Descending)) {
       $ts = ''
        try { $ts = $f.LastWriteTime.ToString('yyyy-MM-dd HH:mm') } catch { $ts = '' }
        $kb = ''
        try { $kb = [Math]::Round(($f.Length / 1KB),0) } catch { $kb = '' }
        $items.Add([pscustomobject]@{
            File    = $f
            Display = ("{0}    ({1}, {2} KB)" -f $f.Name, $ts, $kb)
        })
    }
    [void]$clb.Items.AddRange($items.ToArray())

    # Default-check: endast "säkra" filtyper (användaren kan checka i fler)
    $defaultExt = @($DefaultCheckedExtensions | ForEach-Object { (''+$_).ToLowerInvariant() })
    for ($i=0; $i -lt $clb.Items.Count; $i++) {
        try {
            $it = $clb.Items[$i]
            $ext = ''
            try { $ext = [string]$it.File.Extension } catch { $ext = '' }
            $isDefault = $false
            if ($ext) { $isDefault = $defaultExt -contains $ext.ToLowerInvariant() }
            $clb.SetItemChecked($i, $isDefault)
        } catch {}
    }

    $panelBtns = New-Object System.Windows.Forms.Panel
    $panelBtns.Dock = 'Bottom'
    $panelBtns.Height = 62
    $panelBtns.Padding = New-Object System.Windows.Forms.Padding(10,8,10,8)

    $btnAll = New-Object System.Windows.Forms.Button
    $btnAll.Text = 'Markera alla'
    $btnAll.Width = 120
    $btnAll.Height = 34

    $btnNone = New-Object System.Windows.Forms.Button
    $btnNone.Text = 'Avmarkera alla'
    $btnNone.Width = 140
    $btnNone.Height = 34

    $btnOk = New-Object System.Windows.Forms.Button
    $btnOk.Text = 'Flytta valda'
    $btnOk.Width = 120
    $btnOk.Height = 34
    $btnOk.DialogResult = [System.Windows.Forms.DialogResult]::OK

    $btnCancel = New-Object System.Windows.Forms.Button
    $btnCancel.Text = 'Avbryt'
    $btnCancel.Width = 100
    $btnCancel.Height = 34
    $btnCancel.DialogResult = [System.Windows.Forms.DialogResult]::Cancel

    $btnAll.Location    = New-Object System.Drawing.Point(10, 12)
    $btnNone.Location   = New-Object System.Drawing.Point(140, 12)
    $btnOk.Location     = New-Object System.Drawing.Point(($dlg.ClientSize.Width - 250), 12)
    $btnCancel.Location = New-Object System.Drawing.Point(($dlg.ClientSize.Width - 120), 12)

    $panelBtns.Controls.Add($btnAll)
    $panelBtns.Controls.Add($btnNone)
    $panelBtns.Controls.Add($btnOk)
    $panelBtns.Controls.Add($btnCancel)

    $dlg.AcceptButton = $btnOk
    $dlg.CancelButton = $btnCancel

    $btnAll.Add_Click({
        for ($i=0; $i -lt $clb.Items.Count; $i++) { try { $clb.SetItemChecked($i, $true) } catch {} }
    })
    $btnNone.Add_Click({
        for ($i=0; $i -lt $clb.Items.Count; $i++) { try { $clb.SetItemChecked($i, $false) } catch {} }
    })

    $dlg.Controls.Add($clb)
    $dlg.Controls.Add($panelBtns)
    $dlg.Controls.Add($lbl)

    $res = $dlg.ShowDialog($form)
    if ($res -ne [System.Windows.Forms.DialogResult]::OK) { return $null }

    $selected = New-Object System.Collections.Generic.List[System.IO.FileInfo]
    foreach ($obj in $clb.CheckedItems) {
        try { if ($obj -and $obj.File) { $selected.Add([System.IO.FileInfo]$obj.File) } } catch {}
    }
    return @($selected)
}

function Move-DownloadedLspFiles {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)][ValidateSet('3','4')][string]$TargetStage
    )

    if (-not (Assert-StartupReady)) { return }
    if ($script:BuildInProgress -or $script:ScanInProgress) {
        Gui-Log "⚠️ Vänta tills pågående operation är klar." 'Warn'
        return
    }

    $downloads = Get-DownloadsPathEffective
    if (-not $downloads -or -not (Test-Path -LiteralPath $downloads)) {
        Gui-Log "❌ Kunde inte hitta Downloads-mappen. (Konfig: DownloadsDir)" 'Error'
        return
    }

    $stageRoot = if ($TargetStage -eq '3') {
        Get-ConfigValue -Name 'Stage3RootPath' -Default (Resolve-IptPath (Join-Path $script:DefaultIptRoot '3. IPT - KLART FÖR SAMMANSTÄLLNING')) -ConfigOverride $Config
    } else {
        Get-ConfigValue -Name 'Stage4RootPath' -Default (Resolve-IptPath (Join-Path $script:DefaultIptRoot '4. IPT - KLART FÖR GRANSKNING')) -ConfigOverride $Config
    }

    if (-not $stageRoot -or -not (Test-Path -LiteralPath $stageRoot)) {
        Gui-Log "❌ Stage-rotmappen saknas: $stageRoot" 'Error'
        return
    }

    # Hämta alla filer i Downloads
    $all = @()
    try { $all = @(Get-ChildItem -LiteralPath $downloads -File -ErrorAction SilentlyContinue) } catch {}
    if (-not $all -or $all.Count -eq 0) {
        Gui-Log "ℹ️ Inga filer i Downloads." 'Info'
        return
    }

    # Gruppera efter LSP-nummer i filnamn
    $groups = @{}
    foreach ($f in $all) {
        $lsp = $null
        try { $lsp = Get-LspDigitsFromString -Text $f.Name } catch { $lsp = $null }
        if (-not $lsp) { continue }
        if (-not $groups.ContainsKey($lsp)) { $groups[$lsp] = New-Object System.Collections.ArrayList }
        [void]$groups[$lsp].Add($f)
    }

    if ($groups.Keys.Count -eq 0) {
        Gui-Log "ℹ️ Hittade inga filer i Downloads med LSP##### i filnamn." 'Info'
        return
    }

    # Välj LSP: prioritera textfältets värde, sedan automatisk om bara en grupp
    $typed = ($txtLSP.Text + '').Trim()
    $typedDigits = if ($typed) { ($typed -replace '\D','') } else { '' }

    $selectedLsp = $null
    if ($typedDigits -and $groups.ContainsKey($typedDigits)) {
        $selectedLsp = $typedDigits
    } elseif ($groups.Keys.Count -eq 1) {
        $selectedLsp = @($groups.Keys)[0]
    } else {
        $opts = @($groups.Keys | Sort-Object)
        $picked = Show-ListSelectionDialog -Title 'Välj LSP' -Prompt 'Flera LSP hittades i Downloads. Välj vilket som ska flyttas:' -Items $opts
        if (-not $picked) { Gui-Log 'ℹ️ Avbrutet.' 'Info'; return }
        $selectedLsp = $picked
    }

    $files = @(foreach ($item in $groups[$selectedLsp]) { $item })
    if (-not $files -or $files.Count -eq 0) {
        Gui-Log "ℹ️ Inga filer att flytta för LSP$selectedLsp." 'Info'
        return
    }

    # Utöka kandidatlistan: inkludera PDF:er i Downloads som innehåller vissa nyckelord i filnamnet
    # (oavsett om de råkar innehålla LSP-numret eller inte). Detta påverkar ENDAST listning/val i dialogen.
    try {
        $pdfKeywords = @('Additional','QC','Data','SE','LFI')
        $pdfKeywordsLower = @($pdfKeywords | ForEach-Object { (''+$_).ToLowerInvariant() })

        $pdfExtra = New-Object System.Collections.Generic.List[object]
        $pdfAll = Get-ChildItem -LiteralPath $downloads -Filter '*.pdf' -File -ErrorAction SilentlyContinue
        foreach ($p in $pdfAll) {
            $n = ''
            try { $n = ('' + $p.Name).ToLowerInvariant() } catch { $n = '' }
            if (-not $n) { continue }
            $hit = $false
            foreach ($kw in $pdfKeywordsLower) {
                if ($n.Contains($kw)) { $hit = $true; break }
            }
            if ($hit) { [void]$pdfExtra.Add($p) }
        }

        if ($pdfExtra -and $pdfExtra.Count -gt 0) {
            # Merge + dedupe på FullName
            $map = @{}
            foreach ($f in @($files + @($pdfExtra.ToArray()))) {
                try { if ($f -and $f.FullName) { $map[$f.FullName] = $f } } catch {}
            }
            $files = @($map.Values)
        }
    } catch {}

    # Säkerhet: be användaren bekräfta exakt vilka filer som ska flyttas.
    # Default: markera bara typiska Camstar/IPT-filer (csv/xlsx/xlsm/xls). Allt annat kräver aktivt val.
    $pickTitle = if ($TargetStage -eq '3') { 'Flytta till mappen JESP-TEST' } else { 'Flytta till din LSP-mapp i KLART FÖR GRANSKNING' }
    $pickPrompt = "Filer hittades i Downloads för LSP: $selectedLsp. Markera filer som du vill ska flyttas till LSP: $selectedLsp.`n(Auto-markerar matchande filer.)"
    $pickedFiles = Show-FileMoveSelectionDialog -Title $pickTitle -Prompt $pickPrompt -Files $files
    if (-not $pickedFiles -or $pickedFiles.Count -eq 0) {
        Gui-Log "ℹ️ Inga filer valdes – avbryter flytt." 'Info'
        return
   }

    # Spara vilka som inte valdes (för logg)
    $notSelected = New-Object System.Collections.Generic.List[string]
    try {
        $selSet = @{}
        foreach ($pf in $pickedFiles) { try { $selSet[$pf.FullName] = $true } catch {} }
        foreach ($ff in $files) { try { if (-not $selSet.ContainsKey($ff.FullName)) { [void]$notSelected.Add($ff.Name) } } catch {} }
    } catch {}

    $files = @($pickedFiles)

    # Immediate GUI-logg: visa direkt att flytt påbörjas (innan IO börjar)
    try {
        Gui-Log ("⏳ Filer flyttas nu... avvakta. (Valda: {0})" -f $files.Count) 'Info' 'USER'
    } catch {}

    $destFolder = Find-LspFolder -Lsp $selectedLsp -Roots @($stageRoot)
    if (-not $destFolder) {
        Gui-Log "❌ Hittade ingen LSP-mapp för $selectedLsp under: $stageRoot" 'Error'
        return
    }

    Gui-Log ("📥 Downloads: {0}" -f $downloads) 'Info' 'PROGRESS'
    Gui-Log ("📂 Destination: {0}" -f $destFolder.FullName) 'Info' 'PROGRESS'

    $moved   = New-Object System.Collections.Generic.List[string]
    $failed  = New-Object System.Collections.Generic.List[string]
    $skipped = New-Object System.Collections.Generic.List[string]

    foreach ($f in $files | Sort-Object LastWriteTime -Descending) {
        # Kontrollera om filen är låst (öppen i Excel/Preview etc.)
        $lockedAbort = $false
        while ($true) {
            $isLocked = $false
            try { $isLocked = Core-TestFileLocked $f.FullName } catch {}
            if (-not $isLocked) { break }

            $res = Show-CloseFileToContinueDialog -Path $f.FullName -ExtraHint 'Stäng filen i Excel, OneDrive-preview eller Utforskaren.'
            if ($res -ne [System.Windows.Forms.DialogResult]::Retry) {
                $skipped.Add($f.Name)
                $lockedAbort = $true
                break
            }
            Start-Sleep -Milliseconds 200
        }
        if ($lockedAbort) { continue }

        try {
            $target = Get-UniqueDestinationPath -DestinationDir $destFolder.FullName -FileName $f.Name
            Move-Item -LiteralPath $f.FullName -Destination $target -Force
            $moved.Add((Split-Path -Leaf $target))
        } catch {
            $failed.Add(("{0} -> {1}" -f $f.Name, $_.Exception.Message))
        }
    }

    # Skriv loggfil i destinationen
    try {
        $logName = "MoveLog_LSP{0}_{1}.txt" -f $selectedLsp, (Get-Date).ToString('yyyyMMdd_HHmmss')
        $logPath = Join-Path $destFolder.FullName $logName
        $lines = New-Object System.Collections.Generic.List[string]
        $lines.Add(("Timestamp: {0}" -f (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')))
        $lines.Add(("User: {0}" -f $env:USERNAME))
        $lines.Add(("From: {0}" -f $downloads))
        $lines.Add(("To: {0}" -f $destFolder.FullName))
        $lines.Add('')
        $lines.Add('Moved:')
        foreach ($n in $moved) { $lines.Add("  - $n") }
        if ($skipped.Count -gt 0) {
            $lines.Add('')
            $lines.Add('Skipped (locked):')
            foreach ($s in $skipped) { $lines.Add("  - $s") }
        }
        if ($failed.Count -gt 0) {
            $lines.Add('')
            $lines.Add('Failed:')
            foreach ($e in $failed) { $lines.Add("  - $e") }
        }
        [System.IO.File]::WriteAllLines($logPath, $lines.ToArray(), [System.Text.Encoding]::UTF8)
    } catch {}

    # Summering i GUI-loggen
    if ($moved.Count -gt 0) {
        Gui-Log ("✅ Flyttade {0} fil(er) för LSP{1} till stage {2}." -f $moved.Count, $selectedLsp, $TargetStage) 'Info' 'USER'
    } else {
        Gui-Log ("⚠️ Inga filer flyttades för LSP{0}." -f $selectedLsp) 'Warn' 'USER'
    }
    if ($skipped.Count -gt 0) {
        Gui-Log ("ℹ️ {0} fil(er) hoppades över (låsta)." -f $skipped.Count) 'Info' 'USER'
    }
    if ($failed.Count -gt 0) {
        Gui-Log ("⚠️ {0} fil(er) kunde inte flyttas. Se MoveLog i destinationen." -f $failed.Count) 'Warn' 'USER'
    }

    if ($notSelected -and $notSelected.Count -gt 0) {
        Gui-Log ("ℹ️ {0} fil(er) var matchade på LSP men valdes inte: {1}" -f $notSelected.Count, (($notSelected | Select-Object -First 5) -join ', ')) 'Info' 'USER'
    }

    # Fyll LSP-fältet om det var tomt och trigga rescan så listorna visar de nya filerna
    if ($moved.Count -gt 0) {
        if (-not ($txtLSP.Text + '').Trim()) {
            $txtLSP.Text = $selectedLsp
        }
        $script:LastScanResult = $null
        try { $btnScan.PerformClick() } catch {}
    }
}

#endregion Hjälpfunktioner

#region Händelsehanterare (meny, knappar, tema, scan, build)
$miScan.add_Click({ $btnScan.PerformClick() })
$miBuild.add_Click({ if ($btnBuild.Enabled) { $btnBuild.PerformClick() } })
$miExit.add_Click({ $form.Close() })
$miNew.add_Click({ Clear-GUI })

$miOpenRecent.add_Click({
    if ($global:LastReportPath -and (Test-Path -LiteralPath $global:LastReportPath)) {
        try { Start-Process -FilePath $global:LastReportPath } catch {
            [System.Windows.Forms.MessageBox]::Show("Kunde inte öppna rapporten:\n$($_.Exception.Message)","Öppna senaste rapport") | Out-Null
        }
    } else {
        [System.Windows.Forms.MessageBox]::Show("Ingen rapport har genererats i denna session.","Öppna senaste rapport") | Out-Null
    }
})

# Skript1..5 – gemensam startfunktion
function Invoke-ExternalScript {
    param([string]$Path, [string]$Label)
    if ([string]::IsNullOrWhiteSpace($Path)) {
        [System.Windows.Forms.MessageBox]::Show("Ange sökvägen till $Label i konfigurationen.", $Label) | Out-Null; return
    }
    if (-not (Test-Path -LiteralPath $Path)) {
        [System.Windows.Forms.MessageBox]::Show("Filen hittades inte:`n$Path", $Label) | Out-Null; return
    }
    $ext = [System.IO.Path]::GetExtension($Path).ToLowerInvariant()
    switch ($ext) {
        '.ps1' { Start-Process -FilePath powershell.exe -ArgumentList "-ExecutionPolicy Bypass -File `"$Path`"" }
        '.bat' { Start-Process -FilePath cmd.exe -ArgumentList "/c `"$Path`"" }
        '.lnk' { Start-Process -FilePath $Path }
        default { try { Start-Process -FilePath $Path } catch { [System.Windows.Forms.MessageBox]::Show("Kunde inte öppna filen:`n$Path", $Label) | Out-Null } }
    }
}
$miScript1.add_Click({ Invoke-ExternalScript -Path $Script1Path -Label 'Skript 1' })
$miScript2.add_Click({ Invoke-ExternalScript -Path $Script2Path -Label 'Skript 2' })
$miScript3.add_Click({ Invoke-ExternalScript -Path $Script3Path -Label 'Skript 3' })
$miScript4.add_Click({ Invoke-ExternalScript -Path $Script4Path -Label 'Skript 4' })
$miScript5.add_Click({ Invoke-ExternalScript -Path $Script5Path -Label 'Skript 5' })

$miToggleSignSamm.add_Click({
    $lsp = $txtLSP.Text.Trim()
    if (-not $lsp) {
        Gui-Log "⚠️ Ange och sök ett LSP först innan du aktiverar signering." 'Warn'
        return
    }
    $grpSignSamm.Visible = -not $grpSignSamm.Visible
    if ($grpSignSamm.Visible) {
        $miToggleSignSamm.Text = '❌ Dölj signering (Sammanställning)'
        # Dölj Granskning automatiskt
        if ($grpSignGransk.Visible) {
            $grpSignGransk.Visible = $false
            $chkWsGransk.Checked = $false; $chkGranskOverwrite.Checked = $false
            $miToggleSignGransk.Text = '✅ Aktivera signering (Granskning)'
        }
        # Auto-populate Date från ROBAL om tillgänglig och fältet är tomt
        if (-not $txtSammDate.Text.Trim() -and $script:RobalDateShort) {
            $txtSammDate.Text = $script:RobalDateShort
        }
    } else {
        # Nollställ allt för att förhindra oavsiktlig signering vid nästa build
        $chkSealTest.Checked = $false; $chkWsSamm.Checked = $false; $chkSignOverwrite.Checked = $false
        $miToggleSignSamm.Text = '✅ Aktivera signering (Sammanställning)'
    }
    # Räkna om formulärhöjd
    $extra = 0
    if ($grpSignSamm.Visible)   { $extra += $grpSignSamm.Height + 10 }
    if ($grpSignGransk.Visible) { $extra += $grpSignGransk.Height + 10 }
    $form.Height = $baseHeight + $extra
})

$miToggleSignGransk.add_Click({
    $lsp = $txtLSP.Text.Trim()
    if (-not $lsp) {
        Gui-Log "⚠️ Ange och sök ett LSP först innan du aktiverar signering." 'Warn'
        return
    }
    $grpSignGransk.Visible = -not $grpSignGransk.Visible
    if ($grpSignGransk.Visible) {
        $miToggleSignGransk.Text = '❌ Dölj signering (Granskning)'
        # Dölj Sammanställning automatiskt
        if ($grpSignSamm.Visible) {
            $grpSignSamm.Visible = $false
            $chkSealTest.Checked = $false; $chkWsSamm.Checked = $false; $chkSignOverwrite.Checked = $false
            $miToggleSignSamm.Text = '✅ Aktivera signering (Sammanställning)'
        }
    } else {
        $chkWsGransk.Checked = $false; $chkGranskOverwrite.Checked = $false
        $miToggleSignGransk.Text = '✅ Aktivera signering (Granskning)'
    }
    $extra = 0
    if ($grpSignSamm.Visible)   { $extra += $grpSignSamm.Height + 10 }
    if ($grpSignGransk.Visible) { $extra += $grpSignGransk.Height + 10 }
    $form.Height = $baseHeight + $extra
})

# Enter-tangent i signeringsfält → trigga "Skapa rapport"
$_enterHandler = {
    if ($_.KeyCode -eq 'Return') {
        $_.SuppressKeyPress = $true
        $btnBuild.PerformClick()
    }
}
$txtSammName.add_KeyDown($_enterHandler)
$txtSammDate.add_KeyDown($_enterHandler)
$txtSealTestSign.add_KeyDown($_enterHandler)
$txtGranskName.add_KeyDown($_enterHandler)
$txtGranskDate.add_KeyDown($_enterHandler)

function Set-Theme {
    param([string]$Theme)
    $global:CurrentTheme = $Theme

    # Datadriven temadefinition – lägg till kontroller här, inte dubbla if/else-block
    $isDark = ($Theme -eq 'dark')
    $bg      = if ($isDark) { [System.Drawing.Color]::FromArgb(35,35,35) }   else { [System.Drawing.Color]::WhiteSmoke }
    $header  = if ($isDark) { [System.Drawing.Color]::DarkSlateBlue }        else { [System.Drawing.Color]::SteelBlue }
    $logBg   = if ($isDark) { [System.Drawing.Color]::FromArgb(45,45,45) }   else { [System.Drawing.Color]::White }
    $boxBg   = if ($isDark) { [System.Drawing.Color]::FromArgb(55,55,55) }   else { [System.Drawing.Color]::White }
    $fg      = if ($isDark) { [System.Drawing.Color]::White }                else { [System.Drawing.Color]::Black }

    # Bakgrundsfärg (ärver $bg)
    foreach ($c in @($form, $content, $grpPick, $grpSignSamm, $grpSignGransk, $flpSammChk, $flpGranskChk, $grpDl, $tlSearch)) {
        if ($c) { $c.BackColor = $bg }
    }
    # Specialfärger
    $panelHeader.BackColor = $header
    $pLog.BackColor        = $logBg
    $outputBox.BackColor   = $boxBg
    $outputBox.ForeColor   = $fg

    # Textfärg (ärver $fg)
    foreach ($c in @($lblLSP, $lblCsv, $lblNeg, $lblPos, $lblLsp, $grpPick, $grpSignSamm, $grpSignGransk, $grpDl, $pLog, $tlSearch)) {
        if ($c) { $c.ForeColor = $fg }
    }
}

$miLightTheme.add_Click({ Set-Theme 'light' })
$miDarkTheme.add_Click({ Set-Theme 'dark' })

# Instruktioner
$miShowInstr.add_Click({
    $msg = @"
SNABBGUIDE

SAMMANSTÄLLNING
Förberedelse: skapa filen "Stort Test Summary".

1) Ange LSP och klicka på "Sök filer" eller använd "Bläddra...".
   OBS: LSP-mappen ska ligga i: 3. IPT – KLART FÖR SAMMANSTÄLLNING
2) Klicka på "Skapa rapport".

GRANSKNING
Förberedelse: ladda ned dokument från MES.

1) Klicka på "KLART FÖR GRANSKNING". Filerna flyttas och läses in automatiskt.
   OBS: LSP-mappen ska ligga i: 4. IPT – KLART FÖR GRANSKNING
2) Klicka på "Skapa rapport".

"@
    [System.Windows.Forms.MessageBox]::Show($msg,"Instruktioner") | Out-Null
})

$miFAQ.Add_Click({
    $faq = @"
VANLIGA FRÅGOR (FAQ)

Vad gör skriptet?
• Skapar en Excel‑rapport för det LSP du söker. Rapporten öppnas automatiskt efter körning.

Vilka indata krävs?
• LSP och korrekt placering av mappar.

Vilka flikar finns i Excel‑rapporten?
• Run Information + SharePoint‑info (om SharePoint är aktiverat)
• Seal Test‑info
• STF Summary (flaggar minusvärden under $MinusThresholdMg mg)
• Utrustningslista
• Kontrollmaterial
• QC Summary

Var sparas rapporten?
• Endast temporärt i din:
$env:TEMP

Vanliga fel och åtgärder
• "Hittar inte LSP" / "Inga filer funna" → Kontrollera att mappen finns i:
    2. IPT - KLART FÖR SAMMANSTÄLLNING
    3. IPT - KLART FÖR GRANSKNING

Version: $ScriptVersion
"@
    [System.Windows.Forms.MessageBox]::Show($faq,"Vanliga frågor") | Out-Null
})

$miHelpDlg.add_Click({
    $helpForm = New-Object System.Windows.Forms.Form
    $helpForm.Text = 'Skicka meddelande'
    $helpForm.Size = New-Object System.Drawing.Size(400,300)
    $helpForm.StartPosition = 'CenterParent'
    $helpForm.Font = $form.Font
    $helpBox = New-Object System.Windows.Forms.TextBox
    $helpBox.Multiline = $true
    $helpBox.ScrollBars = 'Vertical'
    $helpBox.Dock = 'Fill'
    $helpBox.Font = New-Object System.Drawing.Font('Segoe UI',9)
    $helpBox.Margin = New-Object System.Windows.Forms.Padding(10)
    $panelButtons = New-Object System.Windows.Forms.FlowLayoutPanel
    $panelButtons.Dock = 'Bottom'
    $panelButtons.FlowDirection = 'RightToLeft'
    $panelButtons.Padding = New-Object System.Windows.Forms.Padding(10)
    $btnSend = New-Object System.Windows.Forms.Button
    $btnSend.Text = 'Skicka'
    $btnCancel = New-Object System.Windows.Forms.Button
    $btnCancel.Text = 'Avbryt'
    $panelButtons.Controls.Add($btnSend)
    $panelButtons.Controls.Add($btnCancel)
    $helpForm.Controls.Add($helpBox)
    $helpForm.Controls.Add($panelButtons)
    $btnSend.Add_Click({
        $msg = $helpBox.Text.Trim()
        if (-not $msg) { [System.Windows.Forms.MessageBox]::Show('Skriv ett meddelande innan du skickar.','Hjälp') | Out-Null; return }
        try {
            $helpDir = (Get-ConfigValue -Name 'HelpFeedbackDir' -Default (Join-Path $PSScriptRoot 'help') -ConfigOverride $null)
            if (-not (Test-Path -LiteralPath $helpDir)) { New-Item -ItemType Directory -Path $helpDir -Force | Out-Null }
            $ts   = (Get-Date).ToString('yyyyMMdd_HHmmss')
            $user = ($env:USERNAME + '').Trim()
            if (-not $user) { $user = 'unknown' }
            $file = Join-Path $helpDir ("help_{0}_{1}.txt" -f $user, $ts)

            $body = @(
                "User: $user"
                "Computer: $($env:COMPUTERNAME)"
                "Time: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
                ''
                $msg
            ) -join "`r`n"
             Set-Content -Path $file -Value $body -Encoding UTF8
             [System.Windows.Forms.MessageBox]::Show('Meddelandet skickades. Tack!','Hjälp') | Out-Null
             $helpForm.Close()
         } catch {
            [System.Windows.Forms.MessageBox]::Show("Kunde inte skicka meddelandet:\n$($_.Exception.Message)",'Hjälp') | Out-Null
        }
    })
    $btnCancel.Add_Click({ $helpForm.Close() })
    $helpForm.ShowDialog() | Out-Null
})

# Om
$miOm.add_Click({
    [System.Windows.Forms.MessageBox]::Show(
        ("IPTCompile $ScriptVersion`n`n" +
         "Rapportgenerator för IPT-dokumentation.`n" +
         "Detta är endast ett hjälpmedel och`nersätter inte någon IPT-process.`n`n" +
         "Av: JESP"),
        'Om IPTCompile',
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Information
    ) | Out-Null
})

# Flytta nedladdade filer (LSP##### i filnamn)
$script:DevUnlocked = $false
$script:DevUnlockPassword = 'jesper'

function Assert-DevUnlocked {
    if ($script:DevUnlocked) { return $true }

    $pwd = $null
    try {
        $pwd = [Microsoft.VisualBasic.Interaction]::InputBox(
            "TEST-knappen är låst.`nAnge lösenord för att låsa upp (session):",
            'Utvecklarlås',
            ''
        )
    } catch {
        try {
            [System.Windows.Forms.MessageBox]::Show(
                "Kunde inte visa lösenordsruta. TEST avbröts.",
                'Utvecklarlås',
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Warning
            ) | Out-Null
        } catch {}
        return $false
    }

    if (($pwd + '') -eq $script:DevUnlockPassword) {
        $script:DevUnlocked = $true
        try { Gui-Log "🔓 TEST upplåst för denna session." 'Info' } catch {}
        return $true
    }

    try {
        [System.Windows.Forms.MessageBox]::Show(
            'Fel lösenord. TEST avbröts.',
            'Utvecklarlås',
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Information
        ) | Out-Null
    } catch {}
    return $false
}

$btnMove3.Add_Click({
    if (-not (Assert-DevUnlocked)) { return }
    Move-DownloadedLspFiles -TargetStage '3'
})
$btnMove4.Add_Click({ Move-DownloadedLspFiles -TargetStage '4' })

$btnScan.Add_Click({
    if (-not (Assert-StartupReady)) { return }

    $lspInput = ($txtLSP.Text + '').Trim()
    if (-not $lspInput) { Gui-Log "⚠️ Ange ett LSP-nummer" 'Warn'; return }

    # Normalisera: använd endast siffrorna som nyckel (tillåt '#38401', 'LSP 38401' osv.)
    $lsp = ($lspInput -replace '\D', '')
    if (-not $lsp) { Gui-Log "⚠️ Ange ett giltigt LSP-nummer (siffror)" 'Warn'; return }

    if ($script:BuildInProgress) { Gui-Log "⚠️ Rapportgenerering pågår – vänta tills den är klar." 'Warn'; return }
    if ($script:ScanInProgress)  { Gui-Log "⚠️ Sökning pågår redan – vänta." 'Warn'; return }
    $script:ScanInProgress = $true

    Gui-Log -Text ("🔎 Söker filer för {0}…" -f $lsp) -Severity Info -Category USER -Immediate

    try {
        # Återanvänd cache om LSP + mappen fortfarande finns
        if ($script:LastScanResult -and $script:LastScanResult.Lsp -eq $lsp -and
            $script:LastScanResult.Folder -and (Test-Path -LiteralPath $script:LastScanResult.Folder)) {

            Gui-Log -Text ("♻️ Återanvänder senaste sökresultatet för {0}." -f $lsp) -Severity Info -Category USER
            Add-CLBItems -clb $clbCsv -files $script:LastScanResult.Csv -AutoCheckFirst
            Add-CLBItems -clb $clbNeg -files $script:LastScanResult.Neg -AutoCheckFirst
            Add-CLBItems -clb $clbPos -files $script:LastScanResult.Pos -AutoCheckFirst
            Add-CLBItems -clb $clbLsp -files $script:LastScanResult.LspFiles -AutoCheckFirst
            Update-BuildEnabled
            Update-BatchLink
            return
        }

        $folder = Find-LspFolder -Lsp $lsp -Roots $RootPaths
        if (-not $folder) {
            Gui-Log "❌ Ingen LSP-mapp hittad för $lsp" 'Warn'
            if ($env:IPT_ROOT) { Gui-Log "ℹ️ IPT_ROOT=$($env:IPT_ROOT)" 'Info' 'DEBUG' }
            $rootInfo = $RootPaths | ForEach-Object { "{0} ({1})" -f $_, $(if (Test-Path -LiteralPath $_) { "OK" } else { "MISSING" }) }
            Gui-Log -Text ("Sökvägar som provats: " + ($rootInfo -join " | ")) -Severity Info -Category USER
            return
        }

        if (-not (Test-Path -LiteralPath $folder.FullName)) {
            Gui-Log "❌ LSP-mappen hittades men finns inte längre: $($folder.FullName)" 'Warn'
            $rootInfo = $RootPaths | ForEach-Object { "{0} ({1})" -f $_, $(if (Test-Path -LiteralPath $_) { "OK" } else { "MISSING" }) }
            Gui-Log -Text ("Sökvägar som provats: " + ($rootInfo -join " | ")) -Severity Info -Category USER
            return
        }
        Gui-Log -Text ("📂 Mapp: {0}" -f $folder.Name) -Severity Info -Category USER

        # Plocka filer EN gång
        $files = Get-ChildItem -LiteralPath $folder.FullName -File -ErrorAction SilentlyContinue

        $candCsv = @($files | Where-Object { $_.Extension -ieq '.csv' -and ( $_.Name -match [regex]::Escape($lsp) -or $_.Length -gt 100kb ) } | Sort-Object LastWriteTime -Descending)
        $candNeg = @($files | Where-Object { $_.Name -match '(?i)Neg.*\.xls[xm]$' -and $_.Name -match [regex]::Escape($lsp) } | Sort-Object LastWriteTime -Descending)
        $candPos = @($files | Where-Object { $_.Name -match '(?i)Pos.*\.xls[xm]$' -and $_.Name -match [regex]::Escape($lsp) } | Sort-Object LastWriteTime -Descending)
        $candLsp = @($files | Where-Object {
            ($_.Name -match '(?i)worksheet') -and ($_.Name -match [regex]::Escape($lsp)) -and ($_.Extension -match '^(\.xlsx|\.xlsm|\.xls)$')
        } | Sort-Object LastWriteTime -Descending)

        Add-CLBItems -clb $clbCsv -files $candCsv -AutoCheckFirst
        Add-CLBItems -clb $clbNeg -files $candNeg -AutoCheckFirst
        Add-CLBItems -clb $clbPos -files $candPos -AutoCheckFirst
        Add-CLBItems -clb $clbLsp -files $candLsp -AutoCheckFirst

        if ($candCsv.Count -eq 0) { Gui-Log "ℹ️ Ingen CSV hittad (endast .csv visas)." 'Info' }
        if ($candNeg.Count -eq 0) { Gui-Log "⚠️ Ingen Seal NEG hittad." 'Warn' }
        if ($candPos.Count -eq 0) { Gui-Log "⚠️ Ingen Seal POS hittad." 'Warn' }
        if ($candLsp.Count -eq 0) { Gui-Log "ℹ️ Ingen LSP Worksheet hittad." 'Info' }

        Update-BuildEnabled
        Update-BatchLink

        # Cachea FileInfo-objekt
        $script:LastScanResult = [pscustomobject]@{
            Lsp      = $lsp
            Folder   = $folder.FullName
            Csv      = @($candCsv)
            Neg      = @($candNeg)
            Pos      = @($candPos)
            LspFiles = @($candLsp)
        }

        Gui-Log -Text "✅ Filer laddade." -Severity Info -Category USER
    }
    catch {
        Gui-Log ("❌ Filsökning misslyckades: " + $_.Exception.Message) 'Error'
    }
    finally {
        $script:ScanInProgress = $false
    }
})

$btnCsvBrowse.Add_Click({
    $dlg = $null
    try {
        $dlg = New-Object System.Windows.Forms.OpenFileDialog
        $dlg.Filter = "CSV|*.csv|Alla filer|*.*"
        $dlg.Multiselect = $true
        if ($dlg.ShowDialog() -eq 'OK') {
            $paths = @($dlg.FileNames)  # kan vara 1 eller flera
            if ($paths.Count -gt 2) {
                Gui-Log "⚠️ Du valde $($paths.Count) CSV-filer. Endast de 2 första används (CSV + ev. Resample)." 'Warn'
                $paths = $paths[0..1]
            }

            $files = New-Object 'System.Collections.Generic.List[System.IO.FileInfo]'
            foreach ($p in $paths) {
                if (-not [string]::IsNullOrWhiteSpace($p)) {
                    [void]$files.Add((Get-Item -LiteralPath $p))
                }
            }

            if ($files.Count -gt 0) {
                Add-CLBItems -clb $clbCsv -files @($files.ToArray()) -AutoCheckFirst
            }
            Update-BuildEnabled
            Update-BatchLink
        }
    } finally { if ($dlg) { try { $dlg.Dispose() } catch {} } }
})

$btnNegBrowse.Add_Click({
    $dlg = $null
    try {
        $dlg = New-Object System.Windows.Forms.OpenFileDialog
        $dlg.Filter = "Excel|*.xlsx;*.xlsm|Alla filer|*.*"
        if ($dlg.ShowDialog() -eq 'OK') {
            $f = Get-Item -LiteralPath $dlg.FileName
            Add-CLBItems -clb $clbNeg -files @($f) -AutoCheckFirst
            Update-BuildEnabled
            Update-BatchLink
        }
    } finally { if ($dlg) { try { $dlg.Dispose() } catch {} } }
})

$btnPosBrowse.Add_Click({
    $dlg = $null
    try {
        $dlg = New-Object System.Windows.Forms.OpenFileDialog
        $dlg.Filter = "Excel|*.xlsx;*.xlsm|Alla filer|*.*"
        if ($dlg.ShowDialog() -eq 'OK') {
            $f = Get-Item -LiteralPath $dlg.FileName
            Add-CLBItems -clb $clbPos -files @($f) -AutoCheckFirst
            Update-BuildEnabled
            Update-BatchLink
        }
    } finally { if ($dlg) { try { $dlg.Dispose() } catch {} } }
})

# --- Hjälp: Konvertera A1-adress (t.ex. 'E1') till rad/kolumn (EPPlus-säkert) ---
if (-not (Get-Command Convert-A1ToRowCol -ErrorAction SilentlyContinue)) {
    function Convert-A1ToRowCol {
        param(
            [string]$A1,
            [int]$DefaultRow = 1,
            [int]$DefaultCol = 5
        )

        if ([string]::IsNullOrWhiteSpace($A1)) {
            return [pscustomobject]@{ Row = $DefaultRow; Col = $DefaultCol }
        }

        $s = ($A1 + '').Trim().ToUpper()
        # Tillåt valfritt bladprefix som 'Information!E1' (vi använder bara adressdelen)
        if ($s -match '^(?:[^!]+!)?([A-Z]+)(\d+)$') {
            $letters = $matches[1]
            $row = [int]$matches[2]
            $col = 0
            foreach ($ch in $letters.ToCharArray()) {
                $col = ($col * 26) + ([int][char]$ch - [int][char]'A' + 1)
            }
            if ($row -lt 1) { $row = $DefaultRow }
            if ($col -lt 1) { $col = $DefaultCol }
            return [pscustomobject]@{ Row = $row; Col = $col }
        }

        return [pscustomobject]@{ Row = $DefaultRow; Col = $DefaultCol }
    }
}

# --- Hjälp: Skanna Data Summary-blad efter alla konfigurerade statusmönster ---
if (-not (Get-Command Get-DataSummaryFindings -ErrorAction SilentlyContinue)) {
    function Get-DataSummaryFindings {
        param(
            [Parameter(Mandatory=$true)][object[]]$ExcelPackages,
            [Parameter(Mandatory=$false)][string]$AssayName = '',
            [Parameter(Mandatory=$false)][string]$SheetName = 'Data Summary'
        )

        # --- Bygg aktiv regeluppsättning utifrån assay ---
        $rules = New-Object System.Collections.Generic.List[object]
        try {
            if ($global:IPTConstants -and $global:IPTConstants.DataSummaryRules) {
                foreach ($rule in $global:IPTConstants.DataSummaryRules) {
                    $scope = ($rule.Scope + '').Trim()
                    if ($scope -ieq 'All') {
                        [void]$rules.Add($rule); continue
                    }
                    # Assay-specifikt scope: kontrollera matchande lista
                    if ($AssayName) {
                        $scopeKey = $scope + 'Assays'   # t.ex. 'Hpv' → 'HpvAssays'
                        $assayList = @()
                        if ($global:IPTConstants.ContainsKey($scopeKey)) {
                            $assayList = @($global:IPTConstants[$scopeKey])
                        }
                        $matched = $false
                        foreach ($a in $assayList) {
                            if ($AssayName -imatch [regex]::Escape($a)) { $matched = $true; break }
                        }
                        if ($matched) { [void]$rules.Add($rule) }
                    }
                }
            }
        } catch {}

        # Reservväg: om inga regler laddades, använd universella mönster
        if ($rules.Count -eq 0) {
            foreach ($fallbackRule in @(
                @{ Pattern = '*MINOR VISUAL*';      Severity = 'Minor'; Label = 'Minor Functional (Visual)' }
                @{ Pattern = '*MAJOR VISUAL*';      Severity = 'Major'; Label = 'Major Functional (Visual)' }
                @{ Pattern = '*BARCODE FAIL*';      Severity = 'Major'; Label = 'Major Functional (Barcode Scan)' }
                @{ Pattern = '*DELAMINATION*';      Severity = 'Minor'; Label = 'Minor Functional (Delamination)' }
                @{ Pattern = '*MISQUANTITATION*';   Severity = 'Major'; Label = 'Misquantitation' }
                @{ Pattern = '*MAJOR FUNCTIONAL*';  Severity = 'Major'; Label = 'Major Functional' }
                @{ Pattern = '*MINOR FUNCTIONAL*';  Severity = 'Minor'; Label = 'Minor Functional' }
            )) { [void]$rules.Add($fallbackRule) }
        }

        $results = New-Object System.Collections.Generic.List[object]
        $rowMin = 10; $rowMax = 340
        try { $rowMin = Get-Threshold -Key 'DataSummaryRowMin' -Default 10 } catch {}
        try { $rowMax = Get-Threshold -Key 'DataSummaryRowMax' -Default 340 } catch {}

        foreach ($pkg in $ExcelPackages) {
            if (-not $pkg -or -not $pkg.Workbook) { continue }
            $dataSummaryWs = $null
            foreach ($ws in $pkg.Workbook.Worksheets) {
                if ($ws.Name -ieq $SheetName) { $dataSummaryWs = $ws; break }
            }
            if (-not $dataSummaryWs) { continue }

            for ($row = $rowMin; $row -le $rowMax; $row++) {
                try {
                    $status = Excel-GetSafeCellText -Ws $dataSummaryWs -Row $row -Col 3
                    if (-not $status) { continue }

                    # Matcha mot aktiva regler (första träff vinner)
                    $matchedRule = $null
                    foreach ($rule in $rules) {
                        if ($status -ilike $rule.Pattern) { $matchedRule = $rule; break }
                    }
                    if (-not $matchedRule) { continue }

                    $sampleId = Excel-GetSafeCellText -Ws $dataSummaryWs -Row $row -Col 1
                    $comment  = Excel-GetSafeCellText -Ws $dataSummaryWs -Row $row -Col 5
                    if (-not $sampleId) { continue }

                    [void]$results.Add([pscustomobject]@{
                        SampleId = $sampleId
                        Type     = $matchedRule.Label       # t.ex. 'Major Functional (Visual)'
                        Severity = $matchedRule.Severity    # 'Major' eller 'Minor'
                        Comment  = $comment
                        Source   = $SheetName               # 'Data Summary' eller 'Resample Data Summary'
                    })
                } catch {}
            }
        }
        return @($results.ToArray())
    }
}

if (-not (Get-Command Write-SPBlockIntoInformation -ErrorAction SilentlyContinue)) {
    function Write-SPBlockIntoInformation {
        param(
            [Parameter(Mandatory)][OfficeOpenXml.ExcelPackage]$Pkg,
            [Parameter()][object[]]$Rows,
            [Parameter()][string]$Batch,
            [Parameter()][string]$TargetSheetName = 'Run Information',
            [Parameter()][int]$StartRow = 1,
            [Parameter()][int]$StartCol = 5 # E = 5
        )

        if (-not $Pkg) { return $false }
        $Rows = @($Rows)

        $ws = $Pkg.Workbook.Worksheets[$TargetSheetName]
        if (-not $ws) { return $false }

        $labelCol = $StartCol
        $valueCol = $StartCol + 1

        # Harmoniserade färger (matchar CSV Sammanfattning)
        $HeaderBg   = [System.Drawing.Color]::FromArgb(68, 84, 106)    # Mörkblå
        $HeaderFg   = [System.Drawing.Color]::White
        $SectionBg  = [System.Drawing.Color]::FromArgb(217, 225, 242)  # Ljusblå
        $SectionFg  = [System.Drawing.Color]::FromArgb(0, 32, 96)      # Mörkblå text
        $BorderColor = [System.Drawing.Color]::FromArgb(68, 84, 106)

        # Rensa tidigare block (bara i block-ytan, påverkar inte A-D)
        try {
            $clearRows = 120
            $rngClear = $ws.Cells[$StartRow, $labelCol, ($StartRow + $clearRows - 1), $valueCol]
            $rngClear.Clear()
        } catch {}

        # Huvudrubrik
        $ws.Cells[$StartRow, $labelCol].Value = "SharePoint Info"
        $ws.Cells[$StartRow, $valueCol].Value = ""
        $ws.Cells[$StartRow, $labelCol, $StartRow, $valueCol].Merge = $true
        $ws.Cells[$StartRow, $labelCol].Style.Font.Bold = $true
        $ws.Cells[$StartRow, $labelCol].Style.Font.Size = 14
        $ws.Cells[$StartRow, $labelCol].Style.Font.Name = "Calibri"
        $ws.Cells[$StartRow, $labelCol].Style.Font.Color.SetColor($HeaderFg)
        $ws.Cells[$StartRow, $labelCol].Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
        $ws.Cells[$StartRow, $labelCol].Style.Fill.BackgroundColor.SetColor($HeaderBg)
        $ws.Cells[$StartRow, $labelCol].Style.HorizontalAlignment = [OfficeOpenXml.Style.ExcelHorizontalAlignment]::Left
        $ws.Cells[$StartRow, $labelCol].Style.VerticalAlignment   = [OfficeOpenXml.Style.ExcelVerticalAlignment]::Center
        $ws.Row($StartRow).Height = 22

        $r = $StartRow + 1

        if (-not $Rows -or $Rows.Count -eq 0 -or $Rows[0] -eq $null) {
            # Tom data
            $ws.Cells[$r, $labelCol].Value = "Batch"
            $ws.Cells[$r, $valueCol].Value = $Batch
            $r++
            $ws.Cells[$r, $labelCol].Value = "Status"
            $ws.Cells[$r, $valueCol].Value = "SharePoint avstängt för optimering."
            $lastRow = $r
        } else {
            foreach ($row in $Rows) {
                $ws.Cells[$r, $labelCol].Value = $row.Rubrik
                # Normalisera värdet (tar bort NBSP/tabbar/extra whitespace som kan få kolumnen att se "bred" ut)
                $val = $row.'Värde'
                $valN = Normalize-HeaderText (($val + ''))
                $valN = ($valN -replace '\s+', ' ').Trim()
                $ws.Cells[$r, $valueCol].Value = $valN
                $r++
            }
            $lastRow = $r - 1
        }

        # Styling rubrik-kolumn
        try {
            $labelRange = $ws.Cells[($StartRow + 1), $labelCol, $lastRow, $labelCol]
            $labelRange.Style.Font.Bold = $true
            $labelRange.Style.Font.Name = "Calibri"
            $labelRange.Style.Font.Size = 10
            $labelRange.Style.Font.Color.SetColor($SectionFg)
            $labelRange.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
            $labelRange.Style.Fill.BackgroundColor.SetColor($SectionBg)

            # Styling värde-kolumn
            $valueRange = $ws.Cells[($StartRow + 1), $valueCol, $lastRow, $valueCol]
            $valueRange.Style.Font.Name = "Calibri"
            $valueRange.Style.Font.Size = 10
            $valueRange.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
            $valueRange.Style.Fill.BackgroundColor.SetColor([System.Drawing.Color]::White)
            $valueRange.Style.WrapText = $true
            $valueRange.Style.VerticalAlignment = [OfficeOpenXml.Style.ExcelVerticalAlignment]::Top
            $valueRange.Style.HorizontalAlignment = [OfficeOpenXml.Style.ExcelHorizontalAlignment]::Left

            # Borders kring block
            $rng = $ws.Cells[$StartRow, $labelCol, $lastRow, $valueCol]
            $rng.Style.Border.Top.Style    = [OfficeOpenXml.Style.ExcelBorderStyle]::Thin
            $rng.Style.Border.Bottom.Style = [OfficeOpenXml.Style.ExcelBorderStyle]::Thin
            $rng.Style.Border.Left.Style   = [OfficeOpenXml.Style.ExcelBorderStyle]::Thin
            $rng.Style.Border.Right.Style  = [OfficeOpenXml.Style.ExcelBorderStyle]::Thin
            $rng.Style.Border.Top.Color.SetColor($BorderColor)
            $rng.Style.Border.Bottom.Color.SetColor($BorderColor)
            $rng.Style.Border.Left.Color.SetColor($BorderColor)
            $rng.Style.Border.Right.Color.SetColor($BorderColor)
        } catch {}

        # Kolumnbredd (endast block-kolumnerna)
        try { $ws.Column($labelCol).Width = 30 } catch {}
        try { $ws.Column($valueCol).Width = 35 } catch {}
        try { $ws.Column($valueCol).Style.ShrinkToFit = $false } catch {}

        return $true
    }
}

# ============================
# ===== RAPPORTLOGIK =========
# ============================

function Show-CloseFileToContinueDialog {
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [string]$ExtraHint = ''
    )

    $leaf = $Path
    try { $leaf = Split-Path $Path -Leaf } catch {}

    $msg = "Stäng fil:`n`n$leaf`n`nFör att fortsätta."
    if ($ExtraHint) { $msg += "`n`nTips: $ExtraHint" }

   try {
        return [System.Windows.Forms.MessageBox]::Show(
            $msg,
            'Filen är öppen',
            [System.Windows.Forms.MessageBoxButtons]::RetryCancel,
            [System.Windows.Forms.MessageBoxIcon]::Warning
        )
    } catch {
        return [System.Windows.Forms.DialogResult]::Cancel
    }
}

function Ensure-FilesClosedOrCancel {
    param(
        [Parameter(Mandatory=$true)][string[]]$Paths,
        [string]$Hint = 'Om filen inte är öppen i Excel: stäng förhandsvisning i Explorer, eller OneDrive/Preview som kan låsa filen.'
    )

    $clean = @($Paths | Where-Object { $_ -and (Test-Path -LiteralPath $_) } | Select-Object -Unique)
    if (-not $clean -or $clean.Count -eq 0) { return $true }

    while ($true) {
        $locked = $null
        foreach ($p in $clean) {
            try {
                if (Core-TestFileLocked $p) { $locked = $p; break }
            } catch {}
        }

        if (-not $locked) { return $true }

        $res = Show-CloseFileToContinueDialog -Path $locked -ExtraHint $Hint
        if ($res -ne [System.Windows.Forms.DialogResult]::Retry) { return $false }
        Start-Sleep -Milliseconds 200
    }
}

$btnBuild.Add_Click({
    #region Build: Rapportgenerering (huvudloop)
    try {
        $useLocalCache = Get-ConfigFlag -Name 'UseLocalCache' -Default $false -ConfigOverride $Config
        $headlessAllowSigning = Get-ConfigFlag -Name 'HeadlessAllowSigning' -Default $false -ConfigOverride $Config
        $script:LastRunContext = New-RunContext `
            -Lsp ($txtLSP.Text + '') `
            -CsvPaths @(Get-AllCheckedFilePaths $clbCsv) `
            -WorksheetPath (Get-CheckedFilePath $clbLsp) `
            -SealNegPath (Get-CheckedFilePath $clbNeg) `
            -SealPosPath (Get-CheckedFilePath $clbPos) `
            -TemplatePath (Join-Path $PSScriptRoot 'output_template-v4.xlsx') `
            -OutputDir $env:TEMP `
            -AuditDir (Join-Path $PSScriptRoot 'audit') `
            -DoSealTest ([bool]$chkSealTest.Checked) `
            -DoWsSamm ([bool]$chkWsSamm.Checked) `
            -DoWsGransk ([bool]$chkWsGransk.Checked) `
            -OverwriteSamm ([bool]$chkSignOverwrite.Checked) `
            -OverwriteGransk ([bool]$chkGranskOverwrite.Checked) `
            -SammName ($txtSammName.Text + '') `
            -SammDate ($txtSammDate.Text + '') `
            -SammSign ($txtSealTestSign.Text + '') `
            -GranskName ($txtGranskName.Text + '') `
            -GranskDate ($txtGranskDate.Text + '') `
            -Headless:$false `
            -UseLocalCache:$useLocalCache `
            -HeadlessAllowSigning:$headlessAllowSigning `
            -OpenOutput:$true `
            -Metadata @{ ProjectRoot = $PSScriptRoot }
    } catch {
        Gui-Log ("❌ Kunde inte skapa RunContext: " + $_.Exception.Message) 'Error'
        return
    }

    $uiHooks = @{
        Confirm = {
            param($message, $title)
            try {
                $res = [System.Windows.Forms.MessageBox]::Show(($message + ''), $(if ($title) { ($title + '') } else { 'Bekräfta' }), 'YesNo', 'Question')
                return ($res -eq 'Yes')
            } catch {
                return $false
            }
        }
        RetryFileLock = {
            param($paths, $hint)
            try {
                return (Ensure-FilesClosedOrCancel -Paths @($paths) -Hint ($hint + ''))
            } catch {
                return $false
            }
        }
        OpenFile = {
            param($path)
            try { if ($path -and (Test-Path -LiteralPath $path)) { Start-Process -FilePath $path | Out-Null } } catch {}
        }
        Progress = {
            param($text)
            try {
                if ($text) { Gui-Log -Text ("🔧 Build stage: " + ($text + '')) -Severity 'Info' -Category 'PROGRESS' }
            } catch {}
        }
    }

    $pipelineResult = Invoke-BuildPipeline -Context $script:LastRunContext -UiHooks $uiHooks
    if (-not $pipelineResult.Success) {
        foreach ($err in @($pipelineResult.Errors)) {
            if ($err) { Gui-Log ("❌ BuildPipeline: " + ($err + '')) 'Error' }
        }
        foreach ($warn in @($pipelineResult.Warnings)) {
            if ($warn) { Gui-Log ("⚠️ BuildPipeline: " + ($warn + '')) 'Warn' }
        }
    }
    #endregion Build: Rapportgenerering (huvudloop)
})

#endregion Händelsehanterare (meny, knappar, tema, scan, build)

# === Verktygstips ===
$toolTip = New-Object System.Windows.Forms.ToolTip
$toolTip.SetToolTip($chkSignOverwrite, $chkSignOverwrite.Tag)
$toolTip.SetToolTip($chkGranskOverwrite, $chkGranskOverwrite.Tag)
$toolTip.AutoPopDelay = 8000
$toolTip.InitialDelay = 500
$toolTip.ReshowDelay  = 500
$toolTip.ShowAlways   = $true
$toolTip.SetToolTip($txtLSP, 'Ange LSP-numret utan och klicka på Sök filer.')
$toolTip.SetToolTip($btnScan, 'Sök efter LSP och lista tillgängliga filer.')
$toolTip.SetToolTip($clbCsv,  'Välj 1 eller 2 CSV-filer (CSV + Resampling-CSV).')
$toolTip.SetToolTip($clbNeg,  'Välj Seal Test Neg-fil.')
$toolTip.SetToolTip($clbPos,  'Välj Seal Test Pos-fil.')
$toolTip.SetToolTip($btnCsvBrowse, 'Bläddra efter en CSV-fil.')
$toolTip.SetToolTip($btnNegBrowse, 'Bläddra efter Seal Test Neg-fil.')
$toolTip.SetToolTip($btnPosBrowse, 'Bläddra efter Seal Test Pos-fil.')
$toolTip.SetToolTip($txtSammName, 'Sammanställning: Förnamn Efternamn (t.ex. Jesper Fredriksson).')
$toolTip.SetToolTip($txtSammDate, 'Sammanställning: Datum.')
$toolTip.SetToolTip($txtSealTestSign, 'Seal Test: SIGN (t.ex. JESP).')
$toolTip.SetToolTip($chkSealTest, 'Signatur appliceras på Seal Test-flikar.')
$toolTip.SetToolTip($chkWsSamm, 'Signerar Worksheet (Recorded By / Performed By-fält).')
$tipOverwriteSammDefault = 'Aktiverar signaturer skrivs till (Sammanställning).'
$tipOverwriteGranskDefault = 'Aktiverar signaturer skrivs till (Granskning).'
$toolTip.SetToolTip($chkSignOverwrite, $tipOverwriteSammDefault)
$toolTip.SetToolTip($chkGranskOverwrite, $tipOverwriteGranskDefault)
$toolTip.SetToolTip($txtGranskName, 'Granskning: Förnamn Efternamn (t.ex. Jesper Fredriksson).')
$toolTip.SetToolTip($txtGranskDate, 'Granskning: Datum.')
$toolTip.SetToolTip($chkWsGransk, 'Signerar Worksheet (PQC Reviewed By i Test Summary).')
$miToggleSignSamm.ToolTipText = 'Visa eller dölj signering (Sammanställning): Seal Test + Worksheet.'
$miToggleSignGransk.ToolTipText = 'Visa eller dölj signering (Granskning): Worksheet PQC Review.'
$toolTip.SetToolTip($btnBuild, 'Skapa och öppna rapporten baserat på de valda filerna.')
$toolTip.SetToolTip($clbLsp,  'Välj LSP Worksheet.')
$toolTip.SetToolTip($btnMove3, 'Flytta matchade filer från Downloads till TEST-mapp.')
$toolTip.SetToolTip($btnMove4, 'Flytta matchade filer från Downloads till mappen i KLART FÖR GRANSKNING.')

$script:OverwriteUiState = @{
    Sign = @{
        BackColor = $chkSignOverwrite.BackColor
        ForeColor = $chkSignOverwrite.ForeColor
        Font      = $chkSignOverwrite.Font
        Tooltip   = $tipOverwriteSammDefault
    }
    Gransk = @{
        BackColor = $chkGranskOverwrite.BackColor
        ForeColor = $chkGranskOverwrite.ForeColor
        Font      = $chkGranskOverwrite.Font
        Tooltip   = $tipOverwriteGranskDefault
    }
    WarnBackColor = [System.Drawing.Color]::FromArgb(255, 249, 196)
    BoldFont      = New-Object System.Drawing.Font($chkSignOverwrite.Font, ([System.Drawing.FontStyle]::Bold))
}

function Update-OverwriteVerificationUI {
    $reqSamm = [bool]($chkSealTest.Checked -or $chkWsSamm.Checked)
    $reqGransk = [bool]$chkWsGransk.Checked

    if ($reqSamm -and (-not $chkSignOverwrite.Checked)) {
        $chkSignOverwrite.BackColor = $script:OverwriteUiState.WarnBackColor
        $chkSignOverwrite.ForeColor = $script:OverwriteUiState.Sign.ForeColor
        $chkSignOverwrite.Font = $script:OverwriteUiState.BoldFont
        $toolTip.SetToolTip($chkSignOverwrite, 'OBLIGATORISKT: Kryssa i för att skapa rapport med signering (Sammanställning).')
    } else {
        $chkSignOverwrite.BackColor = $script:OverwriteUiState.Sign.BackColor
        $chkSignOverwrite.ForeColor = $script:OverwriteUiState.Sign.ForeColor
        $chkSignOverwrite.Font = $script:OverwriteUiState.Sign.Font
        $toolTip.SetToolTip($chkSignOverwrite, $script:OverwriteUiState.Sign.Tooltip)
    }

    if ($reqGransk -and (-not $chkGranskOverwrite.Checked)) {
        $chkGranskOverwrite.BackColor = $script:OverwriteUiState.WarnBackColor
        $chkGranskOverwrite.ForeColor = $script:OverwriteUiState.Gransk.ForeColor
        $chkGranskOverwrite.Font = $script:OverwriteUiState.BoldFont
        $toolTip.SetToolTip($chkGranskOverwrite, 'OBLIGATORISKT: Kryssa i för att skapa rapport med signering (Granskning).')
    } else {
        $chkGranskOverwrite.BackColor = $script:OverwriteUiState.Gransk.BackColor
        $chkGranskOverwrite.ForeColor = $script:OverwriteUiState.Gransk.ForeColor
        $chkGranskOverwrite.Font = $script:OverwriteUiState.Gransk.Font
        $toolTip.SetToolTip($chkGranskOverwrite, $script:OverwriteUiState.Gransk.Tooltip)
    }
}

$chkSealTest.add_CheckedChanged({ Update-OverwriteVerificationUI })
$chkWsSamm.add_CheckedChanged({ Update-OverwriteVerificationUI })
$chkWsGransk.add_CheckedChanged({ Update-OverwriteVerificationUI })
$chkSignOverwrite.add_CheckedChanged({ Update-OverwriteVerificationUI })
$chkGranskOverwrite.add_CheckedChanged({ Update-OverwriteVerificationUI })
Update-OverwriteVerificationUI

# P3: Debounce – kör Update-BatchLink 400ms efter senaste tangenttryck (undviker Excel-IO vid varje tangent)
$script:batchLinkTimer = New-Object System.Windows.Forms.Timer
$script:batchLinkTimer.Interval = 400
$script:batchLinkTimer.add_Tick({
    $script:batchLinkTimer.Stop()
    try { Update-BatchLink } catch {}
})
$txtLSP.add_TextChanged({
    $script:batchLinkTimer.Stop()
    $script:batchLinkTimer.Start()
})

#region Huvudkörning / Orkestrering
# =============== SLUT ===============
function Enable-DoubleBuffer {
    $pi = [Windows.Forms.Control].GetProperty('DoubleBuffered',[Reflection.BindingFlags]'NonPublic,Instance')
    foreach($c in @($content,$pLog,$grpPick,$grpSignSamm,$grpSignGransk,$grpDl)) { if ($c) { $pi.SetValue($c,$true,$null) } }
}
try { Set-Theme 'light' } catch {}
try { Update-OverwriteVerificationUI } catch {}
Enable-DoubleBuffer
Update-BatchLink
[System.Windows.Forms.Application]::Run($form)
try { if ($script:SingleInstanceLockPath) { Clear-SingleInstanceThrottleLock -LockPath $script:SingleInstanceLockPath } } catch {}

# Städa SPClient-runspace vid avslut
try { Stop-SPClient } catch {}

try{ Stop-Transcript | Out-Null }catch{}
#endregion Huvudkörning / Orkestrering
