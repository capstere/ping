# Central app-log wrapper för GUI + headless.
# PS 5.1-kompatibel, inga externa beroenden.

if (-not $script:AppLogState) {
    $script:AppLogState = @{
        GuiLogScriptBlock = $null
        FilePath          = $null
        EnableHostEcho    = $true
        LastLevel         = ''
        LastMessage       = ''
        LastContext       = $null
        LastTimestamp     = $null
    }
}

function Set-AppLogSink {
    param(
        [scriptblock]$GuiLogScriptBlock,
        [string]$FilePath,
        [bool]$EnableHostEcho = $true
    )

    if (-not $script:AppLogState) {
        $script:AppLogState = @{}
    }

    if ($PSBoundParameters.ContainsKey('GuiLogScriptBlock')) {
        $script:AppLogState.GuiLogScriptBlock = $GuiLogScriptBlock
    }
    if ($PSBoundParameters.ContainsKey('FilePath')) {
        $script:AppLogState.FilePath = $FilePath
    }
    $script:AppLogState.EnableHostEcho = [bool]$EnableHostEcho

    return Get-AppLogState
}

function Get-AppLogState {
    $st = $script:AppLogState
    if (-not $st) {
        return [pscustomobject]@{
            HasGuiSink     = $false
            FilePath       = $null
            EnableHostEcho = $true
            LastLevel      = ''
            LastMessage    = ''
            LastTimestamp  = $null
        }
    }

    return [pscustomobject]@{
        HasGuiSink     = [bool]($st.GuiLogScriptBlock)
        FilePath       = ($st.FilePath + '')
        EnableHostEcho = [bool]$st.EnableHostEcho
        LastLevel      = ($st.LastLevel + '')
        LastMessage    = ($st.LastMessage + '')
        LastTimestamp  = $st.LastTimestamp
    }
}

function Write-AppLog {
    param(
        [Parameter(Mandatory=$true)]
        [ValidateSet('Info','Warn','Error','Debug')]
        [string]$Level,
        [Parameter(Mandatory=$true)][string]$Message,
        [string]$Context = ''
    )

    $timestamp = (Get-Date)

    try {
        $script:AppLogState.LastLevel = $Level
        $script:AppLogState.LastMessage = $Message
        $script:AppLogState.LastContext = $Context
        $script:AppLogState.LastTimestamp = $timestamp
    } catch {}

    $usedGuiSink = $false
    try {
        if ($script:AppLogState -and $script:AppLogState.GuiLogScriptBlock) {
            & $script:AppLogState.GuiLogScriptBlock $Level $Message $Context
            $usedGuiSink = $true
        }
    } catch {
        $usedGuiSink = $false
    }

    if ($usedGuiSink) { return }

    $line = "[{0}] [{1}] {2}" -f $timestamp.ToString('HH:mm:ss'), $Level.ToUpperInvariant(), $Message
    if ($Context) {
        $line = "$line | $Context"
    }

    $echo = $true
    try {
        if ($script:AppLogState -and $script:AppLogState.ContainsKey('EnableHostEcho')) {
            $echo = [bool]$script:AppLogState.EnableHostEcho
        }
    } catch {}

    if ($echo) {
        switch ($Level) {
            'Error' { Write-Host $line -ForegroundColor Red }
            'Warn'  { Write-Host $line -ForegroundColor Yellow }
            'Debug' { Write-Host $line -ForegroundColor DarkGray }
            default { Write-Host $line }
        }
    }

    $fp = $null
    try {
        if ($script:AppLogState -and $script:AppLogState.FilePath) {
            $fp = ($script:AppLogState.FilePath + '')
        }
    } catch {}

    if ($fp) {
        try {
            $dir = Split-Path -Path $fp -Parent
            if ($dir -and -not (Test-Path -LiteralPath $dir)) {
                New-Item -ItemType Directory -Path $dir -Force | Out-Null
            }
            Add-Content -LiteralPath $fp -Value $line -Encoding UTF8
        } catch {}
    }
}
