Set-StrictMode -Version 2.0

function Core-NewRunContext {
    [CmdletBinding()]
    param(
        [string]$Lsp,
        [string[]]$CsvPaths,
        [string]$CsvPrimaryPath,
        [string]$CsvResamplePath,
        [string]$WorksheetPath,
        [string]$SealNegPath,
        [string]$SealPosPath,
        [string]$TemplatePath,
        [string]$OutputDir,
        [string]$AuditDir,
        [bool]$DoSealTest = $false,
        [bool]$DoWsSamm = $false,
        [bool]$DoWsGransk = $false,
        [bool]$OverwriteSamm = $false,
        [bool]$OverwriteGransk = $false,
        [string]$SammName,
        [string]$SammDate,
        [string]$SammSign,
        [string]$GranskName,
        [string]$GranskDate,
        [bool]$Headless = $false,
        [bool]$UseLocalCache = $false,
        [bool]$HeadlessAllowSigning = $false,
        [string]$RunId,
        [string]$UserName,
        [datetime]$Timestamp,
        [hashtable]$Metadata,
        [bool]$OpenOutput = $true
    )

    if (-not $PSBoundParameters.ContainsKey('UseLocalCache')) {
        try { $UseLocalCache = [bool](Get-ConfigFlag -Name 'UseLocalCache' -Default $false -ConfigOverride $global:Config) } catch { $UseLocalCache = $false }
    }
    if (-not $PSBoundParameters.ContainsKey('HeadlessAllowSigning')) {
        try { $HeadlessAllowSigning = [bool](Get-ConfigFlag -Name 'HeadlessAllowSigning' -Default $false -ConfigOverride $global:Config) } catch { $HeadlessAllowSigning = $false }
    }

    $ts = if ($PSBoundParameters.ContainsKey('Timestamp')) { $Timestamp } else { Get-Date }
    $user = if ($UserName) { $UserName } else { $env:USERNAME }
    $effectiveRunId = ($RunId + '').Trim()
    if (-not $effectiveRunId) {
        $effectiveRunId = ('{0}_{1}' -f (Get-Date -Format 'yyyyMMdd_HHmmss'), ([guid]::NewGuid().ToString('N').Substring(0, 8)))
    }

    $ctx = [ordered]@{
        Lsp             = ($Lsp + '')
        CsvPaths        = @($CsvPaths | Where-Object { $_ -and -not [string]::IsNullOrWhiteSpace($_) })
        CsvPrimaryPath  = ($CsvPrimaryPath + '')
        CsvResamplePath = ($CsvResamplePath + '')
        WorksheetPath   = ($WorksheetPath + '')
        SealNegPath     = ($SealNegPath + '')
        SealPosPath     = ($SealPosPath + '')
        TemplatePath    = ($TemplatePath + '')
        OutputDir       = ($OutputDir + '')
        AuditDir        = ($AuditDir + '')

        DoSealTest      = [bool]$DoSealTest
        DoWsSamm        = [bool]$DoWsSamm
        DoWsGransk      = [bool]$DoWsGransk
        OverwriteSamm   = [bool]$OverwriteSamm
        OverwriteGransk = [bool]$OverwriteGransk

        SammName        = ($SammName + '')
        SammDate        = ($SammDate + '')
        SammSign        = ($SammSign + '')
        GranskName      = ($GranskName + '')
        GranskDate      = ($GranskDate + '')

        Headless        = [bool]$Headless
        UseLocalCache   = [bool]$UseLocalCache
        HeadlessAllowSigning = [bool]$HeadlessAllowSigning
        RunId           = ($effectiveRunId + '')
        OpenOutput      = [bool]$OpenOutput
        UserName        = ($user + '')
        Timestamp       = $ts
        Metadata        = if ($Metadata) { $Metadata } else { @{} }

        Processing      = [ordered]@{
            CacheModeEnabled = [bool]$UseLocalCache
            OriginalPaths    = @{}
            WorkingPaths     = @{}
            RunId            = ($effectiveRunId + '')
        }

        CsvSelection    = $null
    }

    return [pscustomobject]$ctx
}

function New-RunContext {
    [CmdletBinding()]
    param(
        [string]$Lsp,
        [string[]]$CsvPaths,
        [string]$CsvPrimaryPath,
        [string]$CsvResamplePath,
        [string]$WorksheetPath,
        [string]$SealNegPath,
        [string]$SealPosPath,
        [string]$TemplatePath,
        [string]$OutputDir,
        [string]$AuditDir,
        [bool]$DoSealTest = $false,
        [bool]$DoWsSamm = $false,
        [bool]$DoWsGransk = $false,
        [bool]$OverwriteSamm = $false,
        [bool]$OverwriteGransk = $false,
        [string]$SammName,
        [string]$SammDate,
        [string]$SammSign,
        [string]$GranskName,
        [string]$GranskDate,
        [bool]$Headless = $false,
        [bool]$UseLocalCache = $false,
        [bool]$HeadlessAllowSigning = $false,
        [string]$RunId,
        [string]$UserName,
        [datetime]$Timestamp,
        [hashtable]$Metadata,
        [bool]$OpenOutput = $true
    )
    Core-NewRunContext @PSBoundParameters
}

function Core-ValidateRunContext {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]$Context
    )

    $errors = New-Object System.Collections.Generic.List[string]
    $warnings = New-Object System.Collections.Generic.List[string]

    if (-not $Context) {
        [void]$errors.Add('RunContext saknas.')
        return [pscustomobject]@{
            Ok          = $false
            Errors      = @($errors.ToArray())
            Warnings    = @($warnings.ToArray())
            CsvSelection= $null
        }
    }

    $templatePath = ($Context.TemplatePath + '').Trim()
    if ([string]::IsNullOrWhiteSpace($templatePath)) {
        [void]$errors.Add('TemplatePath saknas i RunContext.')
    } elseif (-not (Test-Path -LiteralPath $templatePath)) {
        [void]$errors.Add(("TemplatePath finns inte: {0}" -f $templatePath))
    }

    $sealNeeded = [bool]$Context.DoSealTest
    if ($sealNeeded) {
        if ([string]::IsNullOrWhiteSpace(($Context.SealNegPath + '')) -or -not (Test-Path -LiteralPath $Context.SealNegPath)) {
            [void]$errors.Add('Seal NEG-fil saknas eller finns inte.')
        }
        if ([string]::IsNullOrWhiteSpace(($Context.SealPosPath + '')) -or -not (Test-Path -LiteralPath $Context.SealPosPath)) {
            [void]$errors.Add('Seal POS-fil saknas eller finns inte.')
        }
    }

    $csvSelection = $null
    $csvPaths = @()
    if ($Context.CsvPaths) {
        $csvPaths = @($Context.CsvPaths | Where-Object { $_ -and -not [string]::IsNullOrWhiteSpace($_) })
    }

    if ($csvPaths.Count -eq 0) {
        $cp = ($Context.CsvPrimaryPath + '').Trim()
        $cr = ($Context.CsvResamplePath + '').Trim()
        if ($cp) { $csvPaths += $cp }
        if ($cr) { $csvPaths += $cr }
    }

    if ($csvPaths.Count -gt 0) {
        if (Get-Command Csv-ResolveSelection -ErrorAction SilentlyContinue) {
            try {
                $csvSelection = Csv-ResolveSelection -AllCsvPaths $csvPaths
                if (-not $csvSelection.Ok) {
                    foreach ($e in @($csvSelection.Errors)) { if ($e) { [void]$errors.Add(($e + '')) } }
                }
                foreach ($w in @($csvSelection.Warnings)) { if ($w) { [void]$warnings.Add(($w + '')) } }
            } catch {
                [void]$errors.Add(("Csv-ResolveSelection exception: {0}" -f $_.Exception.Message))
            }
        } else {
            [void]$warnings.Add('Csv-ResolveSelection saknas; CSV-validering begränsad.')
        }
    } else {
        [void]$warnings.Add('Inga CSV-paths i RunContext.')
    }

    if (([bool]$Context.DoWsSamm -or [bool]$Context.DoWsGransk) -and [string]::IsNullOrWhiteSpace(($Context.WorksheetPath + ''))) {
        [void]$errors.Add('WorksheetPath saknas men Worksheet-signering är aktiverad.')
    }
    if (([bool]$Context.DoWsSamm -or [bool]$Context.DoWsGransk) -and ($Context.WorksheetPath) -and -not (Test-Path -LiteralPath $Context.WorksheetPath)) {
        [void]$errors.Add(("WorksheetPath finns inte: {0}" -f $Context.WorksheetPath))
    }

    return [pscustomobject]@{
        Ok          = ($errors.Count -eq 0)
        Errors      = @($errors.ToArray())
        Warnings    = @($warnings.ToArray())
        CsvSelection= $csvSelection
    }
}

function Validate-RunContext {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]$Context
    )
    Core-ValidateRunContext -Context $Context
}
