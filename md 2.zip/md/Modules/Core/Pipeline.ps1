function Csv-TestResampleFile {
    <# Returnerar $true om CSV:n innehåller _RES_ i Sample ID-kolumnen (>=3 träffar). #>
    param([Parameter(Mandatory=$true)][string]$Path)

    try {
        $lines = Get-Content -LiteralPath $Path -TotalCount 30 -ErrorAction Stop
        if (-not $lines -or $lines.Count -le 9) { return $false }

        $delim = Csv-GetDelimiter -Path $Path

        # Rubriken ligger på rad 8 (index 7) i Test Summary-CSV
        $hdr = $null
        try { $hdr = Csv-SplitFields -Line $lines[7] -Delimiter $delim } catch { $hdr = $null }

        $sampleIdIdx = 0
        if ($hdr) {
            for ($i = 0; $i -lt $hdr.Count; $i++) {
                $h = ($hdr[$i] + '').Trim()
                if ($h -imatch '^Sample\s*ID$' -or $h -ieq 'SampleID' -or $h -imatch '^Sample\s*Id$') {
                    $sampleIdIdx = $i
                    break
                }
            }
        }

        $resCount = 0
        for ($r = 9; $r -lt $lines.Count; $r++) {
            $line = $lines[$r]
            if (-not $line -or $line.Trim().Length -eq 0) { continue }

            $fields = $null
            try { $fields = Csv-SplitFields -Line $line -Delimiter $delim } catch { $fields = $null }
            if (-not $fields -or $fields.Count -le $sampleIdIdx) { continue }

            $sid = ($fields[$sampleIdIdx] + '')
            if ($sid -imatch '_RES_') { $resCount++ }
        }

        return ($resCount -ge 3)
    } catch {
        return $false
    }
}
function Test-IsResampleCsv { param([Parameter(Mandatory=$true)][string]$Path) Csv-TestResampleFile -Path $Path }

function Csv-ResolveSelection {
    <#
      Klassificerar valda CSV-filer till Primary/Resample med samma regler som tidigare Main.ps1.
      Returnerar objekt med Ok, PrimaryPath, ResamplePath, HasResample, Errors[], Warnings[].
    #>
    param([string[]]$AllCsvPaths)

    $errors = New-Object System.Collections.Generic.List[string]
    $warnings = New-Object System.Collections.Generic.List[string]

    $selCsv = $null
    $selCsvRes = $null
    $hasResample = $false
    $canAppLog = [bool](Get-Command Write-AppLog -ErrorAction SilentlyContinue)

    function _LogPipe {
        param([string]$Level,[string]$Msg,[string]$Ctx = '')
        if ($canAppLog) {
            try { Write-AppLog -Level $Level -Message $Msg -Context $Ctx } catch {}
        }
    }

    $paths = @()
    if ($AllCsvPaths) {
        $paths = @($AllCsvPaths | Where-Object { $_ -and -not [string]::IsNullOrWhiteSpace(($_ + '')) })
    }

    if ($paths.Count -eq 1) {
        if (Csv-TestResampleFile -Path $paths[0]) {
            $selCsvRes = $paths[0]
            $msg = "❌ Enbart Resampling-CSV vald. Välj även Primary CSV innan rapport kan skapas."
            [void]$errors.Add($msg)
            _LogPipe -Level 'Error' -Msg $msg -Ctx 'CsvSelection'
        } else {
            $selCsv = $paths[0]
            $hasResample = $false
        }
    } elseif ($paths.Count -eq 2) {
        $isRes0 = Csv-TestResampleFile -Path $paths[0]
        $isRes1 = Csv-TestResampleFile -Path $paths[1]

        if ($isRes0 -and -not $isRes1) {
            $selCsvRes = $paths[0]
            $selCsv = $paths[1]
        } elseif ($isRes1 -and -not $isRes0) {
            $selCsv = $paths[0]
            $selCsvRes = $paths[1]
        } elseif (-not $isRes0 -and -not $isRes1) {
            $msg = "❌ Du har valt 2 CSV-filer men ingen Resampling CSV-fil. Avmarkera en fil eller välj korrekt Resampling CSV-fil."
            [void]$errors.Add($msg)
            _LogPipe -Level 'Error' -Msg $msg -Ctx 'CsvSelection'
        } else {
            # Båda har _RES_ – historiskt beteende: fortsätt men varna.
            $selCsv = $paths[0]
            $selCsvRes = $paths[1]
            $msg = "⚠️ Båda CSV har _RES_ i Sample ID – autoväljer Resampling + Original."
            [void]$warnings.Add($msg)
            _LogPipe -Level 'Warn' -Msg $msg -Ctx 'CsvSelection'
        }

        $hasResample = [bool]($isRes0 -or $isRes1)
    } elseif ($paths.Count -gt 2) {
        $msg = ("❌ Du har valt {0} CSV-filer. Välj max 2 (Primary + ev. Resample)." -f $paths.Count)
        [void]$errors.Add($msg)
        _LogPipe -Level 'Error' -Msg $msg -Ctx 'CsvSelection'
    }

    if (-not $hasResample -and $selCsvRes) {
        $hasResample = $true
    }

    return [pscustomobject]@{
        Ok          = ($errors.Count -eq 0)
        PrimaryPath = $selCsv
        ResamplePath= $selCsvRes
        HasResample = [bool]$hasResample
        Errors      = @($errors.ToArray())
        Warnings    = @($warnings.ToArray())
        Selected    = @($paths)
    }
}
function Resolve-CsvSelection { param([string[]]$AllCsvPaths) Csv-ResolveSelection -AllCsvPaths $AllCsvPaths }

function OpenXml-GetWorksheetSignDialogTargets {
    <#
      Bygger dialogtargets (Planned/Skipped) från OpenXML signeringsplan.
      Returnerar objekt med Targets[] och Warnings[].
    #>
    param(
        [Parameter(Mandatory=$true)][string]$WorksheetPath,
        [bool]$DoWsSamm = $false,
        [bool]$DoWsGransk = $false,
        [bool]$HasResample = $false,
        [Parameter(Mandatory=$true)][string]$ModulesRoot
    )

    $targets = New-Object System.Collections.Generic.List[string]
    $warnings = New-Object System.Collections.Generic.List[string]

    if ($DoWsSamm) {
        try {
            $planS = OpenXml-GetWorksheetSignaturePlan -Path $WorksheetPath -Mode 'Sammanstallning' -HasResample $HasResample -ModulesRoot $ModulesRoot
            if ($planS -and $planS.Planned) {
                foreach ($p in $planS.Planned) { [void]$targets.Add("Sammanställning: $p") }
            }
            if ($planS -and $planS.Skipped) {
                foreach ($s in $planS.Skipped) { [void]$targets.Add("Sammanställning (skip): $s") }
            }
        } catch {
            $msg = ("⚠️ Kunde inte läsa signeringsplan (Sammanställning): " + $_.Exception.Message)
            [void]$warnings.Add($msg)
            if (Get-Command Write-AppLog -ErrorAction SilentlyContinue) {
                try { Write-AppLog -Level 'Warn' -Message $msg -Context 'OpenXmlPlan/Sammanstallning' } catch {}
            }
        }
    }

    if ($DoWsGransk) {
        try {
            $planG = OpenXml-GetWorksheetSignaturePlan -Path $WorksheetPath -Mode 'Granskning' -HasResample $HasResample -ModulesRoot $ModulesRoot
            if ($planG -and $planG.Planned) {
                foreach ($p in $planG.Planned) { [void]$targets.Add("Granskning: $p") }
            }
            if ($planG -and $planG.Skipped) {
                foreach ($s in $planG.Skipped) { [void]$targets.Add("Granskning (skip): $s") }
            }
        } catch {
            $msg = ("⚠️ Kunde inte läsa signeringsplan (Granskning): " + $_.Exception.Message)
            [void]$warnings.Add($msg)
            if (Get-Command Write-AppLog -ErrorAction SilentlyContinue) {
                try { Write-AppLog -Level 'Warn' -Message $msg -Context 'OpenXmlPlan/Granskning' } catch {}
            }
        }
    }

    return [pscustomobject]@{
        Targets  = @($targets.ToArray())
        Warnings = @($warnings.ToArray())
    }
}
function Get-WorksheetSignDialogTargets_OpenXml {
    param(
        [Parameter(Mandatory=$true)][string]$WorksheetPath,
        [bool]$DoWsSamm = $false,
        [bool]$DoWsGransk = $false,
        [bool]$HasResample = $false,
        [Parameter(Mandatory=$true)][string]$ModulesRoot
    )
    OpenXml-GetWorksheetSignDialogTargets -WorksheetPath $WorksheetPath -DoWsSamm $DoWsSamm -DoWsGransk $DoWsGransk -HasResample $HasResample -ModulesRoot $ModulesRoot
}

function OpenXml-InvokeWorksheetSigningModes {
    <#
      Kör OpenXML-signering för ett eller flera modes och returnerar samlat resultat.
      Modes[] element: @{ Mode='Sammanstallning|Granskning'; Label='...'; Name='...'; Date='...'; Overwrite=$true/$false }
    #>
    param(
        [Parameter(Mandatory=$true)][string]$WorksheetPath,
        [Parameter(Mandatory=$true)][hashtable[]]$Modes,
        [bool]$HasResample = $false,
        [Parameter(Mandatory=$true)][string]$ModulesRoot
    )

    $modeResults = New-Object System.Collections.Generic.List[pscustomobject]
    $allWrittenCells = New-Object System.Collections.Generic.List[pscustomobject]

    foreach ($m in $Modes) {
        $wsRes = OpenXml-InvokeWorksheetSignature `
            -Path $WorksheetPath `
            -FullName $m.Name `
            -SignDateYmd $m.Date `
            -Mode $m.Mode `
            -HasResample:$HasResample `
            -Overwrite ([bool]$m.Overwrite) `
            -ModulesRoot $ModulesRoot

        $written = @()
        $skipped = @()
        if ($wsRes.Written) { $written = @($wsRes.Written) }
        if ($wsRes.Skipped) { $skipped = @($wsRes.Skipped) }

        if ($wsRes.WrittenCells -and $wsRes.WrittenCells.Count -gt 0) {
            foreach ($wc in $wsRes.WrittenCells) { [void]$allWrittenCells.Add($wc) }
        }

        [void]$modeResults.Add([pscustomobject]@{
            Mode        = ($m.Mode + '')
            Label       = ($m.Label + '')
            Written     = $written
            Skipped     = $skipped
            WrittenCells= if ($wsRes.WrittenCells) { @($wsRes.WrittenCells) } else { @() }
        })
    }

    return [pscustomobject]@{
        ModeResults     = @($modeResults.ToArray())
        AllWrittenCells = @($allWrittenCells.ToArray())
    }
}
function Invoke-WorksheetSigningModes_OpenXml {
    param(
        [Parameter(Mandatory=$true)][string]$WorksheetPath,
        [Parameter(Mandatory=$true)][hashtable[]]$Modes,
        [bool]$HasResample = $false,
        [Parameter(Mandatory=$true)][string]$ModulesRoot
    )
    OpenXml-InvokeWorksheetSigningModes -WorksheetPath $WorksheetPath -Modes $Modes -HasResample $HasResample -ModulesRoot $ModulesRoot
}
