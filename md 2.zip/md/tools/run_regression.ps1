[CmdletBinding()]
param(
    [string]$TestRoot = (Join-Path $PSScriptRoot '..\TEST-LSP'),
    [string]$OutDir = (Join-Path $PSScriptRoot '..\tmp\regression_out'),
    [string]$BaselineDir = '',
    [ValidateSet('Core','Build')][string]$Mode = 'Core'
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

$bootstrapErrors = New-Object System.Collections.Generic.List[string]
function Add-RegressionBootstrapError {
    param([string]$Message)
    [void]$bootstrapErrors.Add(($Message + ''))
    try { Write-Host ("[BOOTSTRAP] " + ($Message + '')) -ForegroundColor Yellow } catch {}
}

function Ensure-RegressionOutDir {
    param([string]$DesiredPath)
    $target = ($DesiredPath + '')
    if (-not $target) { $target = Join-Path $env:TEMP 'regression_out' }
    try {
        if (-not (Test-Path -LiteralPath $target)) {
            New-Item -ItemType Directory -Path $target -Force | Out-Null
        }
        return (Resolve-Path -LiteralPath $target).Path
    } catch {
        $fallback = Join-Path $env:TEMP 'regression_out'
        try {
            if (-not (Test-Path -LiteralPath $fallback)) {
                New-Item -ItemType Directory -Path $fallback -Force | Out-Null
            }
            Add-RegressionBootstrapError ("OutDir '{0}' kunde inte användas, fallback -> '{1}'" -f $target, $fallback)
            return (Resolve-Path -LiteralPath $fallback).Path
        } catch {
            Add-RegressionBootstrapError ("Kunde inte skapa OutDir eller fallback. Exception: {0}" -f $_.Exception.Message)
            return $target
        }
    }
}

function Import-RegressionModules {
    param(
        [Parameter(Mandatory=$true)][string]$ModulesRoot,
        [Parameter(Mandatory=$true)][string]$RepoRoot
    )

    $ok = $true
    $imports = @(
        @{ Path = (Join-Path $ModulesRoot 'Config.ps1'); Args = @('-ScriptRoot', $RepoRoot) },
        @{ Path = (Join-Path $ModulesRoot 'Logging.ps1'); Args = @() },
        @{ Path = (Join-Path $ModulesRoot 'DataHelpers.ps1'); Args = @() },
        @{ Path = (Join-Path $ModulesRoot 'OpenXmlHelpers.ps1'); Args = @() },
        @{ Path = (Join-Path $ModulesRoot 'RuleEngine.ps1'); Args = @() },
        @{ Path = (Join-Path (Join-Path $ModulesRoot 'Core') 'Log.ps1'); Args = @() },
        @{ Path = (Join-Path (Join-Path $ModulesRoot 'Core') 'Pipeline.ps1'); Args = @() },
        @{ Path = (Join-Path (Join-Path $ModulesRoot 'Core') 'Context.ps1'); Args = @() },
        @{ Path = (Join-Path (Join-Path $ModulesRoot 'Core') 'BuildPipeline.ps1'); Args = @() }
    )

    foreach ($imp in $imports) {
        try {
            if (-not (Test-Path -LiteralPath $imp.Path)) {
                Add-RegressionBootstrapError ("Modul saknas: {0}" -f $imp.Path)
                $ok = $false
                continue
            }
            if ((Split-Path -Leaf $imp.Path) -eq 'Config.ps1') {
                . $imp.Path -ScriptRoot $RepoRoot
            } elseif ($imp.Args.Count -gt 0) {
                . $imp.Path @($imp.Args)
            } else {
                . $imp.Path
            }
        } catch {
            Add-RegressionBootstrapError ("Modulimport misslyckades: {0} | {1}" -f $imp.Path, $_.Exception.Message)
            $ok = $false
        }
    }

    return $ok
}

if ($PSVersionTable.PSVersion.Major -ne 5) {
    Add-RegressionBootstrapError ("run_regression.ps1 kräver Windows PowerShell 5.1. Aktuell version: {0}" -f $PSVersionTable.PSVersion)
}

$OutDir = Ensure-RegressionOutDir -DesiredPath $OutDir

$repoRoot = ''
try {
    $repoRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
} catch {
    $repoRoot = (Get-Location).Path
    Add-RegressionBootstrapError ("Kunde inte resolve repoRoot via PSScriptRoot. Fallback till CWD: {0}" -f $repoRoot)
}
$modulesRoot = Join-Path $repoRoot 'Modules'
$ruleBankDir = Join-Path $repoRoot 'RuleBank'
$templatePath = Join-Path $repoRoot 'output_template-v4.xlsx'

$global:ModulesRoot = $modulesRoot
$global:LibRoot = Join-Path $repoRoot 'Lib'

$moduleLoadOk = Import-RegressionModules -ModulesRoot $modulesRoot -RepoRoot $repoRoot

$logFile = Join-Path $OutDir 'regression.log'
if (Get-Command Set-AppLogSink -ErrorAction SilentlyContinue) {
    try { Set-AppLogSink -FilePath $logFile -EnableHostEcho:$true | Out-Null } catch {
        Add-RegressionBootstrapError ("Set-AppLogSink misslyckades: {0}" -f $_.Exception.Message)
    }
}
if (Get-Command Write-AppLog -ErrorAction SilentlyContinue) {
    try { Write-AppLog -Level 'Info' -Message 'Regression run started' -Context ("Mode=" + $Mode + '; TestRoot=' + $TestRoot) } catch {
        Add-RegressionBootstrapError ("Write-AppLog start misslyckades: {0}" -f $_.Exception.Message)
    }
}

function New-RegressionRow {
    param(
        [string]$CaseId,
        [string]$Status,
        [string]$PrimaryCsv,
        [string]$ResampleCsv,
        [string]$Worksheet,
        [int]$RuleRowsPrimary,
        [int]$RuleRowsResample,
        [string]$PlanSamm,
        [string]$PlanGransk,
        [string]$OutputPath,
        [string]$AuditPath,
        [string]$Notes
    )

    return [pscustomobject]@{
        CaseId           = $CaseId
        Status           = $Status
        PrimaryCsv       = $PrimaryCsv
        ResampleCsv      = $ResampleCsv
        Worksheet        = $Worksheet
        RuleRowsPrimary  = $RuleRowsPrimary
        RuleRowsResample = $RuleRowsResample
        PlanSamm         = $PlanSamm
        PlanGransk       = $PlanGransk
        OutputPath       = $OutputPath
        AuditPath        = $AuditPath
        Notes            = $Notes
    }
}

function Run-CoreRegression {
    param(
        [string]$TestRoot,
        [string]$BaselineDir,
        [string]$ModulesRoot,
        [string]$RuleBankDir
    )

    $caseIds = @('31004','32101','33301','34509','95107')
    $expectedResampleTrueCases = @('33301','95107')
    $expectedResampleFalseCases = @('31004','32101','34509')
    $rows = New-Object System.Collections.Generic.List[pscustomobject]
    $anyFail = $false

    $ruleBank = $null
    try {
        $ruleBank = Load-RuleBank -RuleBankDir $ruleBankDir
    } catch {
        throw "Kunde inte läsa RuleBank från '$ruleBankDir': $($_.Exception.Message)"
    }

    foreach ($caseId in $caseIds) {
        $caseDir = Join-Path $TestRoot $caseId
        $status = 'PASS'
        $notes = New-Object System.Collections.Generic.List[string]

        if (-not (Test-Path -LiteralPath $caseDir)) {
            $status = 'FAIL'
            [void]$notes.Add("Case-katalog saknas: $caseDir")
            $anyFail = $true
            [void]$rows.Add((New-RegressionRow -CaseId $caseId -Status $status -PrimaryCsv '' -ResampleCsv '' -Worksheet '' -RuleRowsPrimary 0 -RuleRowsResample 0 -PlanSamm '' -PlanGransk '' -OutputPath '' -AuditPath '' -Notes ($notes -join ' | ')))
            continue
        }

        $allCsv = @(
            Get-ChildItem -LiteralPath $caseDir -Filter '*.csv' -File -ErrorAction SilentlyContinue |
            Where-Object { $_.Name -notmatch '(?i)(^|_)audit_' } |
            Sort-Object Name |
            Select-Object -ExpandProperty FullName
        )

        $worksheetPath = @(
            Get-ChildItem -LiteralPath $caseDir -Filter '*Worksheet*.xlsx' -File -ErrorAction SilentlyContinue |
            Sort-Object Name |
            Select-Object -First 1 -ExpandProperty FullName
        )[0]

        $currentOutputs = @(
            Get-ChildItem -LiteralPath $caseDir -Filter '*output_*.xlsx' -File -ErrorAction SilentlyContinue |
            Sort-Object Name
        )
        $currentAudits = @(
            Get-ChildItem -LiteralPath $caseDir -Filter '*audit_*.csv' -File -ErrorAction SilentlyContinue |
            Sort-Object Name
        )

        if ($BaselineDir) {
            $baseCaseDir = Join-Path $BaselineDir $caseId
            if (Test-Path -LiteralPath $baseCaseDir) {
                $baselineOutputs = @(
                    Get-ChildItem -LiteralPath $baseCaseDir -Filter '*output_*.xlsx' -File -ErrorAction SilentlyContinue |
                    Sort-Object Name
                )
                $baselineAudits = @(
                    Get-ChildItem -LiteralPath $baseCaseDir -Filter '*audit_*.csv' -File -ErrorAction SilentlyContinue |
                    Sort-Object Name
                )
                if ($baselineOutputs.Count -ne $currentOutputs.Count) {
                    [void]$notes.Add(("Baseline compare: output-count {0} -> {1}" -f $baselineOutputs.Count, $currentOutputs.Count))
                }
                if ($baselineAudits.Count -ne $currentAudits.Count) {
                    [void]$notes.Add(("Baseline compare: audit-count {0} -> {1}" -f $baselineAudits.Count, $currentAudits.Count))
                }
            } else {
                [void]$notes.Add("Baseline-katalog saknas för case: $baseCaseDir")
            }
        }

        $csvSel = $null
        try {
            $csvSel = Csv-ResolveSelection -AllCsvPaths $allCsv
        } catch {
            $status = 'FAIL'
            [void]$notes.Add("Resolve-CsvSelection exception: $($_.Exception.Message)")
            $anyFail = $true
        }

        if ($csvSel -and $csvSel.Warnings) {
            foreach ($w in @($csvSel.Warnings)) { [void]$notes.Add($w) }
        }

        if ($csvSel -and (-not $csvSel.Ok)) {
            $status = 'FAIL'
            foreach ($e in @($csvSel.Errors)) { [void]$notes.Add($e) }
            $anyFail = $true
        }

        $ruleRowsPrimary = 0
        $ruleRowsResample = 0

        if ($csvSel -and $csvSel.Ok -and $csvSel.PrimaryPath -and (Test-Path -LiteralPath $csvSel.PrimaryPath)) {
            try {
                $csvRows = Csv-ImportRows -Path $csvSel.PrimaryPath -StartRow 10
                $re = Invoke-RuleEngine -CsvObjects $csvRows -RuleBank $ruleBank -CsvPath $csvSel.PrimaryPath
                $ruleRowsPrimary = @($re.Rows).Count
            } catch {
                $status = 'FAIL'
                [void]$notes.Add("RuleEngine primary exception: $($_.Exception.Message)")
                $anyFail = $true
            }
        }

        if ($csvSel -and $csvSel.Ok -and $csvSel.ResamplePath -and (Test-Path -LiteralPath $csvSel.ResamplePath)) {
            try {
                $csvRowsRes = Csv-ImportRows -Path $csvSel.ResamplePath -StartRow 10
                $reRes = Invoke-RuleEngine -CsvObjects $csvRowsRes -RuleBank $ruleBank -CsvPath $csvSel.ResamplePath
                $ruleRowsResample = @($reRes.Rows).Count
            } catch {
                $status = 'FAIL'
                [void]$notes.Add("RuleEngine resample exception: $($_.Exception.Message)")
                $anyFail = $true
            }
        }

        $planSamm = ''
        $planGransk = ''
        $pS = $null

        if ($worksheetPath -and (Test-Path -LiteralPath $worksheetPath)) {
            try {
                $pS = OpenXml-GetWorksheetSignaturePlan -Path $worksheetPath -Mode 'Sammanstallning' -HasResample:$([bool]($csvSel -and $csvSel.HasResample)) -ModulesRoot $ModulesRoot
                $planSamm = ("Planned={0}; Skipped={1}" -f @($pS.Planned).Count, @($pS.Skipped).Count)
            } catch {
                $status = 'FAIL'
                [void]$notes.Add("Signplan Sammanställning exception: $($_.Exception.Message)")
                $anyFail = $true
            }

            try {
                $pG = OpenXml-GetWorksheetSignaturePlan -Path $worksheetPath -Mode 'Granskning' -HasResample:$([bool]($csvSel -and $csvSel.HasResample)) -ModulesRoot $ModulesRoot
                $planGransk = ("Planned={0}; Skipped={1}" -f @($pG.Planned).Count, @($pG.Skipped).Count)
            } catch {
                $status = 'FAIL'
                [void]$notes.Add("Signplan Granskning exception: $($_.Exception.Message)")
                $anyFail = $true
            }
        } else {
            [void]$notes.Add('Worksheet saknas i testkatalog.')
        }

        $assertFails = New-Object System.Collections.Generic.List[string]
        if ($csvSel -and $csvSel.Ok) {
            if ($expectedResampleTrueCases -contains $caseId) {
                if (-not [bool]$csvSel.HasResample) {
                    [void]$assertFails.Add('HasResample förväntades TRUE men var FALSE.')
                }
            }
            if ($expectedResampleFalseCases -contains $caseId) {
                if ([bool]$csvSel.HasResample) {
                    [void]$assertFails.Add('HasResample förväntades FALSE men var TRUE.')
                }
            }

            if ($csvSel.ResamplePath) {
                try {
                    $resOnly = Csv-ResolveSelection -AllCsvPaths @($csvSel.ResamplePath)
                    if ($resOnly.Ok) {
                        [void]$assertFails.Add('Resampling-only blocker förväntades FAIL men returnerade OK.')
                    } else {
                        $hasExpectedErr = $false
                        foreach ($errTxt in @($resOnly.Errors)) {
                            if (($errTxt + '') -match 'Enbart Resampling-CSV vald') { $hasExpectedErr = $true; break }
                        }
                        if (-not $hasExpectedErr) {
                            [void]$assertFails.Add('Resampling-only blocker saknade förväntat felmeddelande.')
                        }
                    }
                } catch {
                    [void]$assertFails.Add("Resampling-only blocker exception: $($_.Exception.Message)")
                }
            }
        }

        if ($worksheetPath -and $pS) {
            if ($expectedResampleTrueCases -contains $caseId) {
                if (@($pS.Planned) -notcontains 'Resample Data Summary') {
                    [void]$assertFails.Add('Resample Data Summary förväntades i Planned men saknades.')
                }
            }
            if ($expectedResampleFalseCases -contains $caseId) {
                if (@($pS.Skipped) -notcontains 'Resample Data Summary (ej resample)') {
                    [void]$assertFails.Add('Resample Data Summary förväntades som skip (ej resample) men saknades.')
                }
            }
        }

        if ($assertFails.Count -gt 0) {
            $status = 'FAIL'
            $anyFail = $true
            foreach ($af in @($assertFails.ToArray())) {
                [void]$notes.Add("ASSERT FAIL: $af")
            }
        } else {
            [void]$notes.Add('ASSERT PASS')
        }

        $primaryLeaf = if ($csvSel -and $csvSel.PrimaryPath) { Split-Path $csvSel.PrimaryPath -Leaf } else { '' }
        $resLeaf = if ($csvSel -and $csvSel.ResamplePath) { Split-Path $csvSel.ResamplePath -Leaf } else { '' }
        $wsLeaf = if ($worksheetPath) { Split-Path $worksheetPath -Leaf } else { '' }

        [void]$rows.Add((New-RegressionRow -CaseId $caseId -Status $status -PrimaryCsv $primaryLeaf -ResampleCsv $resLeaf -Worksheet $wsLeaf -RuleRowsPrimary $ruleRowsPrimary -RuleRowsResample $ruleRowsResample -PlanSamm $planSamm -PlanGransk $planGransk -OutputPath '' -AuditPath '' -Notes ($notes -join ' | ')))
    }

    return [pscustomobject]@{
        Rows = @($rows.ToArray())
        AnyFail = [bool]$anyFail
    }
}

function Run-BuildRegression {
    param(
        [string]$TestRoot,
        [string]$OutDir,
        [string]$TemplatePath
    )

    $rows = New-Object System.Collections.Generic.List[pscustomobject]
    $anyFail = $false
    $cases = @('32101','33301')

    foreach ($caseId in $cases) {
        $notes = New-Object System.Collections.Generic.List[string]
        $status = 'PASS'
        $outputPath = ''
        $auditPath = ''

        try {
            $buildRes = & (Join-Path $PSScriptRoot 'run_build_headless.ps1') -TestRoot $TestRoot -CaseId $caseId -OutDir (Join-Path $OutDir 'build_mode') -TemplatePath $TemplatePath -PassThru
            if (-not $buildRes) {
                throw 'run_build_headless returnerade tomt resultat.'
            }

            $outputPath = ($buildRes.OutputPath + '')
            $auditPath = ($buildRes.AuditPath + '')
            $buildOutcome = ''
            $buildErrorCode = 1
            $buildErrorCodeName = ''
            $stageStateSummary = ''
            $stageTimingSummary = ''
            $cacheModeSummary = ''
            $publishMethodSummary = ''
            try {
                if ($buildRes.PSObject.Properties['Outcome']) { $buildOutcome = ($buildRes.Outcome + '') }
                if ($buildRes.PSObject.Properties['ErrorCode']) { $buildErrorCode = [int]$buildRes.ErrorCode }
                if ($buildRes.PSObject.Properties['ErrorCodeName']) { $buildErrorCodeName = ($buildRes.ErrorCodeName + '') }
            } catch {
                [void]$notes.Add(("WARN: Kunde inte läsa Outcome/ErrorCode från build-resultat: {0}" -f $_.Exception.Message))
            }

            try {
                $metrics = $null
                if ($buildRes.PSObject.Properties['Metrics']) { $metrics = $buildRes.Metrics }
                if ($metrics) {
                    $stageState = $null
                    $stageTimings = $null
                    try {
                        if ($metrics.Contains('StageState')) { $stageState = $metrics['StageState'] }
                    } catch {}
                    try {
                        if ($metrics.Contains('StageTimings')) { $stageTimings = $metrics['StageTimings'] }
                        elseif ($metrics.Contains('Stages')) { $stageTimings = $metrics['Stages'] }
                    } catch {}

                    $rrExec = ''
                    $rrStatus = ''
                    $sigExec = ''
                    $sigStatus = ''
                    try {
                        if ($stageState -and $stageState['RunRules']) {
                            $rr = $stageState['RunRules']
                            if ($rr.Contains('Executed')) { $rrExec = [string]([bool]$rr['Executed']) }
                            $rrStatus = ($rr['ExecutionStatus'] + '')
                            if (-not $rrStatus) { $rrStatus = ($rr['Status'] + '') }
                        }
                    } catch {}
                    try {
                        if ($stageState -and $stageState['ApplySignatures']) {
                            $sg = $stageState['ApplySignatures']
                            if ($sg.Contains('Executed')) { $sigExec = [string]([bool]$sg['Executed']) }
                            $sigStatus = ($sg['ExecutionStatus'] + '')
                            if (-not $sigStatus) { $sigStatus = ($sg['Status'] + '') }
                        }
                    } catch {}

                    $stageStateSummary = ("RunRules executed={0} status={1}; ApplySignatures executed={2} status={3}" -f ($rrExec + ''), ($rrStatus + ''), ($sigExec + ''), ($sigStatus + ''))
                    [void]$notes.Add(("StageState: {0}" -f $stageStateSummary))

                    try {
                        if ($stageState -and $stageState['CacheInputs']) {
                            $ci = $stageState['CacheInputs']
                            $cacheEnabled = ''
                            $cacheStatus = ''
                            if ($ci.Contains('CacheModeEnabled')) { $cacheEnabled = [string]([bool]$ci['CacheModeEnabled']) }
                            if ($ci.Contains('ExecutionStatus')) { $cacheStatus = ($ci['ExecutionStatus'] + '') }
                            $cacheModeSummary = ("CacheModeEnabled={0} status={1}" -f ($cacheEnabled + ''), ($cacheStatus + ''))
                            [void]$notes.Add(("CacheMode: {0}" -f $cacheModeSummary))
                        }
                    } catch {
                        [void]$notes.Add(("WARN: Kunde inte läsa CacheMode från StageState: {0}" -f $_.Exception.Message))
                    }

                    try {
                        if ($metrics.Contains('PublishMethod')) {
                            $publishMethodSummary = (($metrics['PublishMethod'] + '').Trim())
                            if ($publishMethodSummary) { [void]$notes.Add(("PublishMethod: {0}" -f $publishMethodSummary)) }
                        }
                        if ($metrics.Contains('PublishWarning')) {
                            $pw = (($metrics['PublishWarning'] + '').Trim())
                            if ($pw) { [void]$notes.Add(("PublishWarning: {0}" -f $pw)) }
                        }
                    } catch {
                        [void]$notes.Add(("WARN: Kunde inte läsa PublishMethod från metrics: {0}" -f $_.Exception.Message))
                    }

                    try {
                        if ($stageTimings) {
                            $timingParts = New-Object System.Collections.Generic.List[string]
                            foreach ($k in @($stageTimings.Keys)) {
                                [void]$timingParts.Add(("{0}={1}ms" -f $k, [int]$stageTimings[$k]))
                            }
                            $stageTimingSummary = (@($timingParts) -join '; ')
                            [void]$notes.Add(("StageTimings: {0}" -f $stageTimingSummary))
                        }
                    } catch {
                        [void]$notes.Add(("WARN: Kunde inte serialisera StageTimings: {0}" -f $_.Exception.Message))
                    }
                }
            } catch {
                [void]$notes.Add(("WARN: Kunde inte läsa stage metrics från build-resultat: {0}" -f $_.Exception.Message))
            }

            if (-not [bool]$buildRes.Success) {
                $status = 'FAIL'
                $anyFail = $true
                [void]$notes.Add('BuildPipeline returnerade Success=false.')
                foreach ($e in @($buildRes.Errors)) { if ($e) { [void]$notes.Add(($e + '')) } }
            }
            [void]$notes.Add(("Build result: Outcome={0}, ErrorCode={1}, ErrorCodeName={2}" -f $buildOutcome, $buildErrorCode, ($buildErrorCodeName + '')))
            [void]$notes.Add(("Build paths: OutputPath={0}; AuditPath={1}" -f ($outputPath + ''), ($auditPath + '')))

            if ([string]::IsNullOrWhiteSpace($stageStateSummary)) {
                $status = 'FAIL'
                $anyFail = $true
                [void]$notes.Add('ASSERT FAIL: StageState summary saknas i build-resultat.')
            } else {
                [void]$notes.Add('ASSERT PASS: StageState summary finns.')
            }
            if ([string]::IsNullOrWhiteSpace($stageTimingSummary)) {
                $status = 'FAIL'
                $anyFail = $true
                [void]$notes.Add('ASSERT FAIL: StageTimings saknas i build-resultat.')
            } else {
                [void]$notes.Add('ASSERT PASS: StageTimings finns.')
            }
            if ([string]::IsNullOrWhiteSpace($cacheModeSummary)) {
                [void]$notes.Add('CacheMode: CacheModeEnabled=unavailable')
            }
            if ([string]::IsNullOrWhiteSpace($publishMethodSummary)) {
                $status = 'FAIL'
                $anyFail = $true
                [void]$notes.Add('ASSERT FAIL: PublishMethod saknas i build-resultat.')
            } else {
                [void]$notes.Add('ASSERT PASS: PublishMethod finns.')
            }

            if (-not $outputPath -or -not (Test-Path -LiteralPath $outputPath)) {
                $status = 'FAIL'
                $anyFail = $true
                [void]$notes.Add('ASSERT FAIL: output file saknas.')
            } else {
                [void]$notes.Add('ASSERT PASS: output file exists')
            }

            if (-not $auditPath -or -not (Test-Path -LiteralPath $auditPath)) {
                $status = 'FAIL'
                $anyFail = $true
                [void]$notes.Add('ASSERT FAIL: audit file saknas.')
            } else {
                [void]$notes.Add('ASSERT PASS: audit file exists')
            }

            if ($outputPath -and (Test-Path -LiteralPath $outputPath)) {
                $pkg = $null
                try {
                    $pkg = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($outputPath))
                    $wsInfo = $pkg.Workbook.Worksheets['Run Information']
                    $wsQc = $pkg.Workbook.Worksheets['QC Summary']
                    $qcB3 = ''
                    $qcB3Value = ''
                    try {
                        if ($wsQc) {
                            $qcCell = $wsQc.Cells['B3']
                            $qcB3 = (($qcCell.Text) + '').Trim()
                            $qcB3Value = (($qcCell.Value) + '').Trim()
                        }
                    } catch {
                        [void]$notes.Add(("WARN: Kunde inte läsa QC Summary B3: {0}" -f $_.Exception.Message))
                    }

                    if ([string]::IsNullOrWhiteSpace($qcB3)) {
                        $status = 'FAIL'
                        $anyFail = $true
                        [void]$notes.Add(("ASSERT FAIL: QC Summary B3 är tom. Text='{0}', Value='{1}'" -f ($qcB3 + ''), ($qcB3Value + '')))
                    } else {
                        [void]$notes.Add(("ASSERT PASS: QC Summary B3 har innehåll: '{0}'" -f ($qcB3 + '')))
                    }

                    if ($caseId -eq '32101') {
                        $b19 = ''
                        try { if ($wsInfo) { $b19 = (($wsInfo.Cells['B19'].Text) + '').Trim() } } catch {
                            [void]$notes.Add(("WARN: Kunde inte läsa Run Information B19: {0}" -f $_.Exception.Message))
                        }
                        if ([string]::IsNullOrWhiteSpace($b19)) {
                            $status = 'FAIL'
                            $anyFail = $true
                            [void]$notes.Add('ASSERT FAIL: Run Information B19 är tom (32101).')
                        } else {
                            [void]$notes.Add('ASSERT PASS: Run Information B19 har värde (32101).')
                        }
                    }

                    if ($caseId -eq '33301') {
                        $b15 = ''
                        try { if ($wsInfo) { $b15 = (($wsInfo.Cells['B15'].Text) + '').Trim() } } catch {
                            [void]$notes.Add(("WARN: Kunde inte läsa Run Information B15: {0}" -f $_.Exception.Message))
                        }

                        if ($b15 -notmatch '(?i)Resampling:') {
                            $status = 'FAIL'
                            $anyFail = $true
                            [void]$notes.Add('ASSERT FAIL: resample-källtext saknas i Run Information B15 (33301).')
                        } else {
                            [void]$notes.Add('ASSERT PASS: resample-källtext finns i Run Information B15 (33301).')
                        }
                    }
                } catch {
                    $status = 'FAIL'
                    $anyFail = $true
                    [void]$notes.Add(("ASSERT FAIL: kunde inte verifiera output-xlsx: {0}" -f $_.Exception.Message))
                } finally {
                    try { if ($pkg) { $pkg.Dispose() } } catch {
                        [void]$notes.Add(("WARN: Kunde inte disposa output-xlsx package: {0}" -f $_.Exception.Message))
                    }
                }
            }
        } catch {
            $status = 'FAIL'
            $anyFail = $true
            [void]$notes.Add($_.Exception.Message)
        }

        [void]$rows.Add((New-RegressionRow -CaseId $caseId -Status $status -PrimaryCsv '' -ResampleCsv '' -Worksheet '' -RuleRowsPrimary 0 -RuleRowsResample 0 -PlanSamm '' -PlanGransk '' -OutputPath $outputPath -AuditPath $auditPath -Notes ($notes -join ' | ')))
    }

    return [pscustomobject]@{
        Rows = @($rows.ToArray())
        AnyFail = [bool]$anyFail
    }
}

$rows = @()
$anyFail = $false
$fatalError = ''

try {
    if ($bootstrapErrors.Count -gt 0 -or (-not $moduleLoadOk)) {
        $anyFail = $true
        $fatalError = (($bootstrapErrors | Select-Object -Unique) -join ' | ')
        $rows = @(
            (New-RegressionRow -CaseId '__BOOTSTRAP__' -Status 'FAIL' -PrimaryCsv '' -ResampleCsv '' -Worksheet '' -RuleRowsPrimary 0 -RuleRowsResample 0 -PlanSamm '' -PlanGransk '' -OutputPath '' -AuditPath '' -Notes $fatalError)
        )
    } else {
        if ($Mode -eq 'Core') {
            $result = Run-CoreRegression -TestRoot $TestRoot -BaselineDir $BaselineDir -ModulesRoot $modulesRoot -RuleBankDir $ruleBankDir
        } else {
            $result = Run-BuildRegression -TestRoot $TestRoot -OutDir $OutDir -TemplatePath $templatePath
        }
        $rows = @($result.Rows)
        $anyFail = [bool]$result.AnyFail
    }
} catch {
    $anyFail = $true
    $fatalError = ("Unhandled exception: {0}" -f $_.Exception.Message)
    $rows = @(
        (New-RegressionRow -CaseId '__UNHANDLED__' -Status 'FAIL' -PrimaryCsv '' -ResampleCsv '' -Worksheet '' -RuleRowsPrimary 0 -RuleRowsResample 0 -PlanSamm '' -PlanGransk '' -OutputPath '' -AuditPath '' -Notes $fatalError)
    )
    if (Get-Command Write-AppLog -ErrorAction SilentlyContinue) {
        try { Write-AppLog -Level 'Error' -Message $fatalError -Context 'run_regression' } catch {}
    } else {
        try { Write-Host $fatalError -ForegroundColor Red } catch {}
    }
}

$reportPath = Join-Path $OutDir 'RegressionReport.md'
$jsonPath = Join-Path $OutDir 'RegressionReport.json'

try {
    if (-not (Test-Path -LiteralPath $OutDir)) {
        New-Item -ItemType Directory -Path $OutDir -Force | Out-Null
    }
} catch {
    $anyFail = $true
}

if (-not $rows -or $rows.Count -eq 0) {
    $anyFail = $true
    $rows = @(
        (New-RegressionRow -CaseId '__EMPTY__' -Status 'FAIL' -PrimaryCsv '' -ResampleCsv '' -Worksheet '' -RuleRowsPrimary 0 -RuleRowsResample 0 -PlanSamm '' -PlanGransk '' -OutputPath '' -AuditPath '' -Notes 'Inga regressionrader genererades.')
    )
}

$lines = New-Object System.Collections.Generic.List[string]
[void]$lines.Add('# Regression Report')
[void]$lines.Add('')
[void]$lines.Add(('Mode: {0}' -f $Mode))
[void]$lines.Add(('Date: {0}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')))
[void]$lines.Add(('Host: {0}' -f $env:COMPUTERNAME))
[void]$lines.Add(('PowerShell: {0}' -f $PSVersionTable.PSVersion))
try { [void]$lines.Add(('TestRoot: {0}' -f (Resolve-Path -LiteralPath $TestRoot).Path)) } catch { [void]$lines.Add(('TestRoot: {0}' -f $TestRoot)) }
try { [void]$lines.Add(('OutDir: {0}' -f (Resolve-Path -LiteralPath $OutDir).Path)) } catch { [void]$lines.Add(('OutDir: {0}' -f $OutDir)) }
if ($BaselineDir) { [void]$lines.Add(('BaselineDir: {0}' -f $BaselineDir)) }
if ($bootstrapErrors.Count -gt 0) {
    [void]$lines.Add(('BootstrapErrors: {0}' -f (($bootstrapErrors | Select-Object -Unique) -join ' | ')))
}
[void]$lines.Add('')
[void]$lines.Add('| Case | Status | Primary CSV | Resample CSV | Worksheet | RuleRows Primary | RuleRows Resample | Plan Samm | Plan Gransk | OutputPath | AuditPath | Notes |')
[void]$lines.Add('|---|---|---|---|---|---:|---:|---|---|---|---|---|')
foreach ($r in @($rows)) {
    [void]$lines.Add(("| {0} | {1} | {2} | {3} | {4} | {5} | {6} | {7} | {8} | {9} | {10} | {11} |" -f $r.CaseId, $r.Status, $r.PrimaryCsv, $r.ResampleCsv, $r.Worksheet, $r.RuleRowsPrimary, $r.RuleRowsResample, $r.PlanSamm, $r.PlanGransk, $r.OutputPath, $r.AuditPath, $r.Notes))
}

try {
    Set-Content -LiteralPath $reportPath -Value $lines -Encoding UTF8
} catch {
    $anyFail = $true
    try { Write-Host ("Kunde inte skriva RegressionReport.md: " + $_.Exception.Message) -ForegroundColor Red } catch {}
}
try {
    @($rows) | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $jsonPath -Encoding UTF8
} catch {
    $anyFail = $true
    try { Write-Host ("Kunde inte skriva RegressionReport.json: " + $_.Exception.Message) -ForegroundColor Red } catch {}
}

if (Get-Command Write-AppLog -ErrorAction SilentlyContinue) {
    try { Write-AppLog -Level 'Info' -Message ("Regression report written: " + $reportPath) -Context 'run_regression' } catch {}
    try { Write-AppLog -Level 'Info' -Message ("Regression json written: " + $jsonPath) -Context 'run_regression' } catch {}
}

if ($anyFail) {
    if (Get-Command Write-AppLog -ErrorAction SilentlyContinue) {
        try { Write-AppLog -Level 'Error' -Message 'Regression completed with FAIL' -Context 'run_regression' } catch {}
    }
    exit 1
}
if (Get-Command Write-AppLog -ErrorAction SilentlyContinue) {
    try { Write-AppLog -Level 'Info' -Message 'Regression completed with PASS' -Context 'run_regression' } catch {}
}
exit 0
