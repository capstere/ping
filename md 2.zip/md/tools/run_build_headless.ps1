[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][string]$TestRoot,
    [Parameter(Mandatory=$true)][string]$CaseId,
    [Parameter(Mandatory=$true)][string]$OutDir,
    [string]$TemplatePath = '',
    [switch]$UseLocalCache,
    [switch]$HeadlessAllowSigning,
    [switch]$PassThru
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

if ($PSVersionTable.PSVersion.Major -ne 5) {
    throw "run_build_headless.ps1 kräver Windows PowerShell 5.1. Aktuell version: $($PSVersionTable.PSVersion)"
}

function Import-HeadlessModules {
    param(
        [Parameter(Mandatory=$true)][string]$ModulesRoot,
        [Parameter(Mandatory=$true)][string]$RepoRoot
    )

    $imports = @(
        @{ Path = (Join-Path $ModulesRoot 'Config.ps1'); Args = @('-ScriptRoot', $RepoRoot) },
        @{ Path = (Join-Path $ModulesRoot 'Logging.ps1'); Args = @() },
        @{ Path = (Join-Path $ModulesRoot 'DataHelpers.ps1'); Args = @() },
        @{ Path = (Join-Path $ModulesRoot 'OpenXmlHelpers.ps1'); Args = @() },
        @{ Path = (Join-Path $ModulesRoot 'RuleEngine.ps1'); Args = @() },
        @{ Path = (Join-Path (Join-Path $ModulesRoot 'Core') 'Log.ps1'); Args = @() },
        @{ Path = (Join-Path (Join-Path $ModulesRoot 'Core') 'Pipeline.ps1'); Args = @() },
        @{ Path = (Join-Path (Join-Path $ModulesRoot 'Core') 'Context.ps1'); Args = @() },
        @{ Path = (Join-Path (Join-Path $ModulesRoot 'Core') 'BuildPipeline.ps1'); Args = @() }
    )

    foreach ($imp in $imports) {
        if (-not (Test-Path -LiteralPath $imp.Path)) {
            throw ("Modul saknas: {0}" -f $imp.Path)
        }
        if ((Split-Path -Leaf $imp.Path) -eq 'Config.ps1') {
            . $imp.Path -ScriptRoot $RepoRoot
        } elseif ($imp.Args.Count -gt 0) {
            . $imp.Path @($imp.Args)
        } else {
            . $imp.Path
        }
    }
}

$repoRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$modulesRoot = Join-Path $repoRoot 'Modules'

if (-not $TemplatePath) {
    $TemplatePath = Join-Path $repoRoot 'output_template-v4.xlsx'
}

$global:ModulesRoot = $modulesRoot
$global:LibRoot = Join-Path $repoRoot 'Lib'

Import-HeadlessModules -ModulesRoot $modulesRoot -RepoRoot $repoRoot

$caseDir = Join-Path $TestRoot $CaseId
if (-not (Test-Path -LiteralPath $caseDir)) {
    throw "Case-katalog saknas: $caseDir"
}
if (-not (Test-Path -LiteralPath $TemplatePath)) {
    throw "Template saknas: $TemplatePath"
}
if (-not (Test-Path -LiteralPath $OutDir)) {
    New-Item -ItemType Directory -Path $OutDir -Force | Out-Null
}

$caseOutDir = Join-Path $OutDir $CaseId
if (-not (Test-Path -LiteralPath $caseOutDir)) {
    New-Item -ItemType Directory -Path $caseOutDir -Force | Out-Null
}

$csvAll = @(
    Get-ChildItem -LiteralPath $caseDir -Filter '*.csv' -File -ErrorAction SilentlyContinue |
    Where-Object { $_.Name -notmatch '(?i)(^|_)audit_' } |
    Sort-Object Name |
    Select-Object -ExpandProperty FullName
)

$worksheetPath = @(
    Get-ChildItem -LiteralPath $caseDir -Filter '*Worksheet*.xlsx' -File -ErrorAction SilentlyContinue |
    Sort-Object Name |
    Select-Object -First 1 -ExpandProperty FullName
)[0]

$negPath = @(
    Get-ChildItem -LiteralPath $caseDir -Filter '*.xlsx' -File -ErrorAction SilentlyContinue |
    Where-Object { $_.Name -match '(?i)neg' } |
    Sort-Object Name |
    Select-Object -First 1 -ExpandProperty FullName
)[0]
$posPath = @(
    Get-ChildItem -LiteralPath $caseDir -Filter '*.xlsx' -File -ErrorAction SilentlyContinue |
    Where-Object { $_.Name -match '(?i)pos' } |
    Sort-Object Name |
    Select-Object -First 1 -ExpandProperty FullName
)[0]

$csvSelection = Csv-ResolveSelection -AllCsvPaths $csvAll

$cfgUseLocalCache = $false
$cfgHeadlessAllowSigning = $false
try { $cfgUseLocalCache = [bool](Get-ConfigFlag -Name 'UseLocalCache' -Default $false -ConfigOverride $global:Config) } catch {}
try { $cfgHeadlessAllowSigning = [bool](Get-ConfigFlag -Name 'HeadlessAllowSigning' -Default $false -ConfigOverride $global:Config) } catch {}
$effectiveUseLocalCache = if ($PSBoundParameters.ContainsKey('UseLocalCache')) { [bool]$UseLocalCache } else { [bool]$cfgUseLocalCache }
$effectiveHeadlessAllowSigning = if ($PSBoundParameters.ContainsKey('HeadlessAllowSigning')) { [bool]$HeadlessAllowSigning } else { [bool]$cfgHeadlessAllowSigning }

$ctx = New-RunContext `
    -Lsp $CaseId `
    -CsvPaths $csvAll `
    -CsvPrimaryPath $csvSelection.PrimaryPath `
    -CsvResamplePath $csvSelection.ResamplePath `
    -WorksheetPath $worksheetPath `
    -SealNegPath $negPath `
    -SealPosPath $posPath `
    -TemplatePath $TemplatePath `
    -OutputDir $caseOutDir `
    -AuditDir (Join-Path $caseOutDir 'audit') `
    -DoSealTest:$false `
    -DoWsSamm:$false `
    -DoWsGransk:$false `
    -OverwriteSamm:$false `
    -OverwriteGransk:$false `
    -Headless:$true `
    -UseLocalCache:$effectiveUseLocalCache `
    -HeadlessAllowSigning:$effectiveHeadlessAllowSigning `
    -OpenOutput:$false `
    -Metadata @{ ProjectRoot = $repoRoot }

$result = Invoke-BuildPipeline -Context $ctx

if ($PassThru) {
    return $result
}

$result | ConvertTo-Json -Depth 10 | Write-Output
$exitCode = 1
try {
    if ($result -and $result.PSObject.Properties['ErrorCode']) {
        $exitCode = [int]$result.ErrorCode
    } elseif ($result -and [bool]$result.Success) {
        $exitCode = 0
    }
} catch {
    $exitCode = 1
}

if ($exitCode -lt 0) { $exitCode = 1 }
exit $exitCode
