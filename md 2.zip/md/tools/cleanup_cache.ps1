[CmdletBinding()]
param(
    [string]$CacheRoot = '',
    [int]$MaxAgeDays = 7,
    [int]$KeepLatest = 20,
    [switch]$PassThru
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

if ($PSVersionTable.PSVersion.Major -ne 5) {
    throw "cleanup_cache.ps1 kräver Windows PowerShell 5.1. Aktuell version: $($PSVersionTable.PSVersion)"
}

$repoRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$modulesRoot = Join-Path $repoRoot 'Modules'

. (Join-Path $modulesRoot 'Config.ps1') -ScriptRoot $repoRoot
. (Join-Path (Join-Path $modulesRoot 'Core') 'Log.ps1')
. (Join-Path (Join-Path $modulesRoot 'Core') 'BuildPipeline.ps1')

if (-not $CacheRoot) {
    $CacheRoot = Join-Path $env:TEMP 'IPTCompile\Cache'
}
if ($MaxAgeDays -lt 1) { $MaxAgeDays = 7 }
if ($KeepLatest -lt 1) { $KeepLatest = 20 }

$res = Build-InvokeCacheCleanup -CacheRoot $CacheRoot -MaxAgeDays $MaxAgeDays -KeepLatest $KeepLatest

if ($PassThru) {
    return $res
}

$res | ConvertTo-Json -Depth 10 | Write-Output
if ($res.Ok) { exit 0 }
exit 1
