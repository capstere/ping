# README_DEV

## Nuvarande modulansvar (före/under refaktor)

| Modul | Huvudansvar |
|---|---|
| `Main.ps1` | WinForms-init, UI-händelser, orkestrering av hela rapportflödet |
| `Modules/Config.ps1` | Miljö/paths, scriptversion, central confighämtning |
| `Modules/Logging.ps1` | `Gui-Log`, strukturerad logg, audit-entry helper |
| `Modules/Core/Log.ps1` | Central log-wrapper (`Write-AppLog`) för GUI/headless |
| `Modules/DataHelpers.ps1` | CSV parsing/import, EPPlus-laddning, worksheet-headeranalys, filsnapshot |
| `Modules/OpenXmlHelpers.ps1` | OpenXML-läs/skriv, merge-aware signering, planering/verifiering |
| `Modules/RuleEngine.ps1` | RuleBank-laddning och avvikelseklassning |
| `Modules/SignatureHelpers.ps1` | Signaturdialog/format/verifiering (Seal + Worksheet wrapper) |
| `Modules/SharePointClient.ps1` | PnP/SharePoint anslutning och async runspace-klient |
| `Modules/UiStyling.ps1` | Tema/visuell styling |
| `Modules/Splash.ps1` | Splashscreen |
| `Modules/Core/Pipeline.ps1` | (Ny FAS 2) core orchestration utan UI-kontroller |
| `Modules/Core/Context.ps1` | (Ny FAS 4A) explicit `RunContext` + validering |
| `Modules/Core/BuildPipeline.ps1` | (FAS 5) Canon build-entrypoint med stage-flöde för både GUI/headless |

## 10 största dupliceringar (evidensbaserat)

1. CSV-classifiering (Primary/Resample) låg inline i `Main.ps1` och användes på flera ställen.
   Status: flyttad till `Resolve-CsvSelection` i [Modules/Core/Pipeline.ps1](/Users/jesperfredriksson/Desktop/zz_IPTCompile/Modules/Core/Pipeline.ps1:45), call-site i [Main.ps1](/Users/jesperfredriksson/Desktop/zz_IPTCompile/Main.ps1:2431).
2. Worksheet-signeringsdialogens target-plan byggdes med duplicerad Samm/Gransk-loop.
   Status: flyttad till `Get-WorksheetSignDialogTargets_OpenXml` i [Modules/Core/Pipeline.ps1](/Users/jesperfredriksson/Desktop/zz_IPTCompile/Modules/Core/Pipeline.ps1:111), call-site i [Main.ps1](/Users/jesperfredriksson/Desktop/zz_IPTCompile/Main.ps1:2703).
3. Worksheet-signeringsinvoke kördes mode-för-mode inline i Main.
   Status: flyttad till `Invoke-WorksheetSigningModes_OpenXml` i [Modules/Core/Pipeline.ps1](/Users/jesperfredriksson/Desktop/zz_IPTCompile/Modules/Core/Pipeline.ps1:161), call-site i [Main.ps1](/Users/jesperfredriksson/Desktop/zz_IPTCompile/Main.ps1:2728).
4. OpenXML-targetlista var duplicerad i plan + invoke.
   Status: centraliserad via `Get-WorksheetSignatureTargets_OpenXml` i [Modules/OpenXmlHelpers.ps1](/Users/jesperfredriksson/Desktop/zz_IPTCompile/Modules/OpenXmlHelpers.ps1:633).
5. OpenXML row-resolution (name/date) var duplicerad i plan + invoke.
   Status: centraliserad via `Resolve-WorksheetSignatureRows_OpenXml` i [Modules/OpenXmlHelpers.ps1](/Users/jesperfredriksson/Desktop/zz_IPTCompile/Modules/OpenXmlHelpers.ps1:654).
6. Nätverksdetektering fanns i två helpers (`Test-IsNetworkPathSimple` och `Test-IsNetworkPath`).
   Status: dead-variant borttagen från DataHelpers; kvar i Config [Modules/Config.ps1](/Users/jesperfredriksson/Desktop/zz_IPTCompile/Modules/Config.ps1:61).
7. Equipment-scanning hade dubblerad API-yta (`Get-TestSummaryEquipment` + `Get-TestSummaryEquipmentFromWorksheet`) utan call-sites.
   Status: borttaget i FAS 1 (dead code).
8. Overwrite-tooltip sätts flera gånger i init + state-update.
   Status: kvar (avsiktligt p.g.a. UI-state), evidens i [Main.ps1](/Users/jesperfredriksson/Desktop/zz_IPTCompile/Main.ps1:5764) och [Main.ps1](/Users/jesperfredriksson/Desktop/zz_IPTCompile/Main.ps1:5785).
9. Batchlink-beräkning kallas på flera ställen i Main.
   Status: kvar, evidens i [Main.ps1](/Users/jesperfredriksson/Desktop/zz_IPTCompile/Main.ps1:4282) och [Main.ps1](/Users/jesperfredriksson/Desktop/zz_IPTCompile/Main.ps1:4999).
10. Primary/Resample CSV-sortering använder i praktiken samma logik två gånger.
   Status: kvar, evidens i [Main.ps1](/Users/jesperfredriksson/Desktop/zz_IPTCompile/Main.ps1:2812) och [Main.ps1](/Users/jesperfredriksson/Desktop/zz_IPTCompile/Main.ps1:2840).

## 10 största "Main.ps1-smällar"

1. `btnBuild`-händelsen är en monolit med flera ansvarsområden från [Main.ps1](/Users/jesperfredriksson/Desktop/zz_IPTCompile/Main.ps1:2376) till sent i filen.
2. Samma flöde hanterar inputval, snapshot, signering, rule-engine, outputskrivning, audit och öppning av fil.
3. Fil-låshantering med UI-dialoger och retry-logik är hårt kopplad till pipeline i [Main.ps1](/Users/jesperfredriksson/Desktop/zz_IPTCompile/Main.ps1:2351).
4. Hög global state-användning (`$script:*`, `$global:*`) genom hela körningen.
5. Inbyggda lokala hjälpfunktioner mitt i build-flödet (`_SignSealTestSheets`, `_GetPerSheetValueObjects`, `_AggregateStatus`).
6. Signeringslogik och verifiering blandas med UI-bekräftelse i samma block.
7. Direkt läsning av UI-kontroller i businessflödet gör headless-körning svår.
8. Logik för primary/resample låg tidigare inline i event-kod (nu flyttad men större block återstår).
9. Mixed concerns mellan SharePoint-status, audit och resultatpresentation i samma scriptfil.
10. Begränsad testbarhet eftersom ingen tydlig headless entrypoint till full build finns ännu.

## Föreslagen mappstruktur (mål)

```text
Modules/
  Core/
    Pipeline.ps1
    BuildPipeline.ps1
    Regression.ps1
  UI/
    WinForms.Main.ps1
    UiStyling.ps1
    Splash.ps1
  Excel/
    EpplusHelpers.ps1
    ReportWriter.ps1
  OpenXml/
    OpenXmlHelpers.ps1
  Rules/
    RuleEngine.ps1
  Infra/
    Config.ps1
    Logging.ps1
    SharePointClient.ps1
    SignatureHelpers.ps1
```

## Entry points

- GUI: [Main.ps1](/Users/jesperfredriksson/Desktop/zz_IPTCompile/Main.ps1)
- Headless regression (core dry-run): [tools/run_regression.ps1](/Users/jesperfredriksson/Desktop/zz_IPTCompile/tools/run_regression.ps1)
- Headless single-case build: [tools/run_build_headless.ps1](/Users/jesperfredriksson/Desktop/zz_IPTCompile/tools/run_build_headless.ps1)

## Canon Entrypoints (FAS 6)

- GUI entry: `Main.ps1` -> `Invoke-BuildPipeline -Context ... -UiHooks ...`
- Headless build entry: `tools/run_build_headless.ps1` -> `Invoke-BuildPipeline -Context ...`
- Regression entry:
  - `tools/run_regression.ps1 -Mode Core`
  - `tools/run_regression.ps1 -Mode Build`

## UiHooks (kort)

- `Invoke-BuildPipeline` accepterar optional `UiHooks` hashtable:
  - `Confirm`
  - `RetryFileLock`
  - `OpenFile`
  - `Progress`
- GUI skickar riktiga hooks.
- Headless skickar `null`/inga hooks, pipeline kör utan WinForms-beroenden.

## Output & loggar

- Build-mode regression:
  - `tmp/regression_out/RegressionReport.md`
  - `tmp/regression_out/RegressionReport.json`
  - `tmp/regression_out/regression.log`
- Headless build (per case):
  - `<OutDir>/<CaseId>/*output*.xlsx`
  - `<OutDir>/<CaseId>/audit/*audit*.csv`

## FAS 3A (loggning)

- `Write-AppLog` är nu central ingång för core/headless.
- GUI-läge kopplar sink till `Gui-Log` via `Set-AppLogSink`.
- Headless regression använder `Write-AppLog` till host + fil (`regression.log`).

## FAS 3B (namnstandard)

- OpenXML canon-namn införda: `OpenXml-GetWorksheetSignaturePlan`, `OpenXml-InvokeWorksheetSignature`, `OpenXml-GetWorksheetSignatureTargets`, `OpenXml-ResolveWorksheetSignatureRows`.
- Gamla OpenXML-namn behålls som compat-wrappers för bakåtkompatibilitet.
- Pipeline använder canon CSV/OpenXML-funktioner internt (`Csv-*`, `OpenXml-*`).

## FAS 3C (DRY)

- Skip-sheet-regler är centraliserade i `Core-TestWorksheetSkipSheet` och används via wrappers (`Test-IsWorksheetHeaderSkipSheet`, `Test-IsSealTestSkipSheet`).
- Seal/header-loopar i `Main.ps1`, `SignatureHelpers.ps1` och `DataHelpers.ps1` använder samma regelkälla.
- `tools/run_regression.ps1` har explicita asserts för resample-detektion, signeringsplan och resampling-only-blocker.

## FAS 4A (Context + BuildPipeline)

- `New-RunContext`/`Validate-RunContext` införda i `Modules/Core/Context.ps1`.
- `Invoke-BuildPipeline` införd i `Modules/Core/BuildPipeline.ps1`.
- `Main.ps1` bygger nu ett `RunContext` i början av build-flödet (`$script:LastRunContext`) som bas för nästa tunningssteg.

## FAS 4B/FAS4C (headless + tunn Main)

- `tools/run_regression.ps1` stödjer nu:
  - `-Mode Core` (tidigare dry-run)
  - `-Mode Build` (headless build för utvalda case + output/audit/cell asserts)
- `Main.ps1`-knappen `Skapa rapport` anropar nu `Invoke-BuildPipeline` med `UiHooks` (`Confirm`, `RetryFileLock`, `OpenFile`, `Progress`) i stället för inline-monolit.

## FAS 5 (Canon pipeline utan LegacyRunner)

- `Invoke-BuildPipeline` kör nu explicit stage-följd:
  - `Stage-ResolveInputs`
  - `Stage-Validate`
  - `Stage-LoadData`
  - `Stage-RunRules`
  - `Stage-WriteReport`
  - `Stage-ApplySignatures`
  - `Stage-Finalize`
- LegacyRunner-path är borttagen från pipeline-ingången. GUI och headless använder samma canon-entrypoint.
- `tools/run_build_headless.ps1` returnerar nu pipeline-`ErrorCode` som process-exit-code.
- `tools/run_regression.ps1 -Mode Build` verifierar nu alltid:
  - output-fil finns
  - audit-fil finns
  - `QC Summary!B3` har innehåll

## FAS 6 (Self-check + stabilisering)

- `BuildPipeline` stage-kontrakt konsoliderat:
  - enhetlig stage-shape (`Ok`, `Status`, `Stage`, `Data`, `Errors`, `Warnings`, `Metrics`)
  - stage-state lagras per stage i `Result.Metrics['StageState']`
- `BuildPipeline` har nu explicit `Build-GetUiHookOrDefault` för säkrare optional hooks.
- `tools/run_regression.ps1` är hardenad:
  - bootstrap-fel fångas och skrivs i rapporten i stället för abrupt stopp
  - rapportfiler skrivs alltid när scriptet kan starta
  - build-notes inkluderar `Outcome`, `ErrorCode`, `OutputPath`, `AuditPath`
  - `QC Summary!B3`-assert visar faktisk celltext/cellvalue vid fail

## FAS 7 (Robusthet + miljöoptimering)

- Canon pipeline har nu explicit cache-stage:
  - `Stage-CacheInputs` mellan `Validate` och `LoadData`
  - opt-in via `UseLocalCache=true`
  - kopierar inputs till `%TEMP%\\IPTCompile\\Cache\\<RunId>`
  - headless output skrivs lokalt och publiceras atomiskt till slutlig output-katalog
- Stage honesty:
  - `Stage-RunRules` rapporterar nu `RulesDelegated` (inte falskt "done")
  - `Stage-ApplySignatures` rapporterar `Delegated/Skipped/Executed` tydligt
  - headless-signering kan aktiveras opt-in med `HeadlessAllowSigning=true`
- Stage metrics:
  - `Result.Metrics.StageState` + `Result.Metrics.StageTimings` (ms per stage)
  - regressionrapporten skriver StageState + StageTimings-notes
- Audit schema är konsekvent även vid blocker/fel:
  - `Outcome`, `ErrorCode`, `Reason`, `HasResample`, `CacheModeEnabled`
  - stage-summary för `RunRules`/`ApplySignatures`
  - `OriginalPaths` + `WorkingPaths`
- GUI anti-dubbelstart (opt-in):
  - `SingleInstanceGuardEnabled=true` + `SingleInstanceGuardTtlSec` i config
  - lockfile i `%TEMP%`, fail-open vid lockfel

## FAS 8 (Hardening)

- Cache hygiene:
  - automatisk cache cleanup i pipeline-start (fail-open)
  - standardpolicy: `CacheCleanupMaxAgeDays=7` och `CacheCleanupKeepLatest=20`
  - styrning via config: `EnableCacheCleanup`
  - manuellt verktyg: `tools/cleanup_cache.ps1`
- Publish correctness:
  - publish i cacheläge sker via tempfil i mål-katalog + rename i samma katalog (`AtomicRenameInTarget`)
  - fallback: `FallbackCopy` med varning i metrics/audit
- Headless signering:
  - om `HeadlessAllowSigning=true` och fil är låst sätts `ErrorCodeName=LockedFile` och tydlig reason
- Regression build-notes:
  - inkluderar `CacheMode` samt `PublishMethod`
  - assert på att `PublishMethod` finns

### Körkommandon (PS 5.1)

```powershell
# Core-regression
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\\tools\\run_regression.ps1 -Mode Core

# Build-regression (headless)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\\tools\\run_regression.ps1 -Mode Build

# Enskild headless build
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\\tools\\run_build_headless.ps1 -TestRoot .\\TEST-LSP -CaseId 33301 -OutDir .\\tmp\\headless_build

# Headless build med opt-in local cache/signering
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\\tools\\run_build_headless.ps1 -TestRoot .\\TEST-LSP -CaseId 33301 -OutDir .\\tmp\\headless_build -UseLocalCache -HeadlessAllowSigning

# Rensa cache manuellt
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\\tools\\cleanup_cache.ps1
```
