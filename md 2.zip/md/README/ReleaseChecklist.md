# ReleaseChecklist

1. Kör headless core-regression:
   `powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\tools\run_regression.ps1 -Mode Core`
   - Verifiera `exit code = 0`.
2. Kör headless build-regression:
   `powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\tools\run_regression.ps1 -Mode Build`
   - Verifiera `exit code = 0`.
3. Verifiera att följande filer skapats/uppdaterats:
   - `tmp\regression_out\RegressionReport.md`
   - `tmp\regression_out\RegressionReport.json`
   - `tmp\regression_out\regression.log`
4. Öppna `RegressionReport.md` och kontrollera att alla case i aktuell mode är `PASS`.
5. Öppna build-case output (`32101`, `33301`) och verifiera:
   - output-fil finns
   - audit-fil finns
   - `QC Summary!B3` är ifylld
6. Kör GUI-build för ett case utan resample (t.ex. `32101`) via `Main.ps1`.
7. Kör GUI-build för ett case med resample (t.ex. `33301` eller `95107`) via `Main.ps1`.
8. Verifiera i GUI-logg att signerings-/overwriteblockeringar beter sig som tidigare (ingen semantikförändring).
9. Verifiera att build-resultat från GUI fortfarande skriver audit och öppnar output-fil enligt tidigare beteende.
10. Kör snabb kontroll på docs innan release:
    - `README_DEV.md`
    - `ARCHITECTURE.md`
    - `CHANGELOG_REFRACTOR.md`
    - `SelfCheckReport.md`
