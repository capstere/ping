# SelfCheckReport (FAS 6)

## Scope

Fokus i FAS 6 var stabilisering och konsistens (ingen ny feature, ingen layoutändring).

## Vad som kontrollerades

1. Modulimport-ordning i:
   - `Main.ps1`
   - `tools/run_regression.ps1`
   - `tools/run_build_headless.ps1`
2. Stage-kontrakt i `Modules/Core/BuildPipeline.ps1`.
3. UiHooks-säkerhet (`UiHooks = $null` ska vara säkert).
4. Regression-harness robusthet (rapportfiler och felmeddelanden).
5. Kvarvarande legacy-referenser i runtime-kod.

## Vad som ändrades

## 1) BuildPipeline stage-kontrakt och diagnostik

- Infört `Build-WriteDiagnosticWarn` för låg-risk varningslogg i canon-delar.
- Infört `Build-GetUiHookOrDefault` för säkrare optional hooks.
- Stage-resultat standardiserat via `Build-NewStageResult`:
  - `Ok`, `Reason`, `Status`, `Stage`, `Data`, `Errors`, `Warnings`, `Metrics`.
- Infört `Build-NewStageData` för konsekvent stage-data shape.
- `Invoke-BuildPipeline` lagrar stage-state per stage i `Result.Metrics['StageState']`.

## 2) UiHooks / headless-säkerhet

- Optional hook-upplock via helper i stället för spridd null-check.
- Inga nya WinForms-anrop i headless path.

## 3) Regression-harness hardening

- `tools/run_regression.ps1`:
  - bootstrap-fel fångas och dokumenteras i rapportrad `__BOOTSTRAP__` i stället för abrupt stop.
  - rapportskrivning (`RegressionReport.md/.json`) görs även vid fail-path när scriptet startar.
  - Build-mode NOTES inkluderar: `Outcome`, `ErrorCode`, `OutputPath`, `AuditPath`.
  - `QC Summary!B3`-assert inkluderar faktisk celltext/cellvalue vid fail.
- `tools/run_build_headless.ps1`:
  - modulimport konsoliderad i intern `Import-HeadlessModules` med samma ordning som regression-scriptet.

## 4) Dokumentation

- Uppdaterat:
  - `README_DEV.md`
  - `ARCHITECTURE.md`
- Tillagt:
  - `ReleaseChecklist.md`
  - `SelfCheckReport.md`

## Verifieringsläge i denna miljö

PowerShell saknas i denna körmiljö (`powershell.exe`/`pwsh` ej tillgängligt), därför kunde ingen faktisk regression köras här.

Exakt kommando för Jesper:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\tools\run_regression.ps1 -Mode Build
```

Förväntat:
- `exit code 0` vid PASS
- uppdaterad `tmp\regression_out\RegressionReport.md`
- tydliga NOTES per testcase vid fail
