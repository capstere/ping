# CHANGELOG_REFRACTOR

## FAS 7 - Robusthet + miljöoptimering (genomförd)

### `Modules/Core/BuildPipeline.ps1`

- Ny stage: `Stage-CacheInputs` (opt-in `UseLocalCache`)
  - kopierar inputs till `%TEMP%\IPTCompile\Cache\<RunId>\inputs`
  - håller `OriginalPaths` och `WorkingPaths` i `Context.Processing`
  - validerar fil-lås på original före kopiering och på working copies efter kopiering
- Headless output-publicering:
  - lokal write i cache-output
  - atomisk publish till slutlig output-katalog via tempfil + rename
- Stage honesty:
  - `Stage-RunRules` returnerar nu `RulesDelegated`
  - `Stage-ApplySignatures` returnerar `Delegated/Skipped/Executed/Failed` med `Executed`-flagga
  - headless-signering stöds opt-in via `HeadlessAllowSigning`
- Stage metrics:
  - `Result.Metrics.StageTimings` (ms per stage) + `StageState`
- Audit hardening:
  - finalize skriver alltid pipeline-audit med konsekvent schema
  - inkluderar `Outcome`, `ErrorCode`, `Reason`, `HasResample`, `CacheModeEnabled`, stage-summary, paths

### `Modules/Core/Context.ps1`

- `RunContext` utökad med:
  - `UseLocalCache`
  - `HeadlessAllowSigning`
  - `RunId`
  - `Processing`-state (`CacheModeEnabled`, `OriginalPaths`, `WorkingPaths`)
- Defaults hämtas säkert från config (`Get-ConfigFlag`) när värden inte skickas in.

### `Modules/Config.ps1`

- Nya opt-in flaggor:
  - `UseLocalCache = $false`
  - `HeadlessAllowSigning = $false`
  - `SingleInstanceGuardEnabled = $false`
  - `SingleInstanceGuardTtlSec = 30`

### `Main.ps1`

- Ny opt-in single-instance throttle:
  - lockfile i `%TEMP%\IPTCompile.main.launch.lock`
  - TTL-styrd blockering vid snabb dubbelstart
  - fail-open vid lockfel
  - lock rensas vid form close/exit

### `tools/run_build_headless.ps1`

- Nya switches:
  - `-UseLocalCache`
  - `-HeadlessAllowSigning`
- Om switch inte sätts används config-defaults.

### `tools/run_regression.ps1`

- Build-mode notes inkluderar nu:
  - `StageState` (RunRules/ApplySignatures executed + status)
  - `StageTimings`
- Nya asserts:
  - StageState summary måste finnas
  - StageTimings måste finnas

## FAS 4A - Context + BuildPipeline (genomförd)

### Nya moduler

- `Modules/Core/Context.ps1`
  - `Core-NewRunContext` + wrapper `New-RunContext`
  - `Core-ValidateRunContext` + wrapper `Validate-RunContext`
- `Modules/Core/BuildPipeline.ps1`
  - `Invoke-BuildPipeline`
  - Resultat-/audit-helpers för pipelinekörning

### Main-integration (minimal)

- `Main.ps1` dot-sourcar nu `Core/Context.ps1` och `Core/BuildPipeline.ps1`.
- `btnBuild` bygger ett explicit `RunContext` (`$script:LastRunContext`) innan befintligt build-flöde.

## FAS 4B - Headless build tools (genomförd)

### Nya/uppdaterade verktyg

- Nytt script: `tools/run_build_headless.ps1`
  - Bygger `RunContext` från `TEST-LSP/<CaseId>`
  - Kör `Invoke-BuildPipeline` i headless-läge
  - Returnerar exit 0/1 och kan ge `-PassThru` resultatobjekt
- `tools/run_regression.ps1` stödjer nu `-Mode Core|Build`
  - `Mode Build` kör headless build och asserts för output/audit/celler

## FAS 4C - Main thinning (genomförd)

### Flyttad build-monolit

- Tidigare `btnBuild`-monolit i `Main.ps1` är flyttad till:
  - `Build-WriteReportCanonical` i `Modules/Core/BuildPipeline.ps1`
- `Main.ps1` är nu tunn orchestration:
  - bygger `RunContext`
  - anropar `Invoke-BuildPipeline` med `UiHooks`

## FAS 5A - Stage-by-stage canon pipeline (genomförd)

- `Modules/Core/BuildPipeline.ps1`
  - stage-resultat har nu tydlig `Data`-payload (`Build-NewStageResult`)
  - `Invoke-BuildPipeline` kör en sammanhängande stage-sekvens utan early-return som hoppar över stage-state
  - stage-state och timings läggs i `Result.Metrics`
  - `Stage-Finalize` undviker dubbel öppning av output när GUI-stage redan hanterat `OpenFile`

## FAS 5B - LegacyRunner borttagen (genomförd)

- LegacyRunner-path/call-sites borttagna från canon-byggvägen.
- `Main.ps1` använder endast `Invoke-BuildPipeline -UiHooks`.
- Canon-funktionsnamn för GUI-kompatibel writer: `Build-WriteReportCanonical`.

## FAS 5C - Headless hardening + regression asserts (genomförd)

- `tools/run_build_headless.ps1`
  - process-exit-code mappas nu från `Result.ErrorCode` (0=OK, 1=Failed, 2=Blocked)
- `tools/run_regression.ps1 -Mode Build`
  - bygger noter med `Outcome` + `ErrorCode`
  - assertar alltid:
    - output-fil finns
    - audit-fil finns
    - `QC Summary!B3` är ej tom
  - exit 1 vid assert-fail (oförändrat krav, nu med tydligare byggasserts)

## FAS 6 - Self-check + städ + stabilisering (genomförd)

- `Modules/Core/BuildPipeline.ps1`
  - konsoliderat stage-kontrakt (`Stage`, `Data`, `Errors`, `Warnings`, `Metrics`)
  - stage-state lagras per stage i `Result.Metrics['StageState']`
  - infört `Build-GetUiHookOrDefault` för robust optional UiHooks
  - infört låg-risk varningsdiagnostik i canonical-delar (`Build-WriteDiagnosticWarn`)
- `tools/run_regression.ps1`
  - bootstrap-fel samlas och skrivs i regressionrapport i stället för abrupt stop
  - rapportfiler skrivs även vid fail-path när scriptet startar
  - build-notes visar `Outcome`, `ErrorCode`, `OutputPath`, `AuditPath`
  - `QC Summary!B3`-assert visar faktisk text/value vid fail
- `tools/run_build_headless.ps1`
  - modulimport konsoliderad i intern helper med samma ordning som regression-scriptet
- Ny dokumentation:
  - `ReleaseChecklist.md`
  - `SelfCheckReport.md`

## FAS 3B - Namnstandard + compat-wrappers (genomförd)

### OpenXML (nya canon-namn)

- `OpenXml-GetWorksheetSignatureTargets`
- `OpenXml-ResolveWorksheetSignatureRows`
- `OpenXml-GetWorksheetSignaturePlan`
- `OpenXml-InvokeWorksheetSignature`

### OpenXML compat-wrappers (gamla namn kvar)

- `Get-WorksheetSignatureTargets_OpenXml` -> `OpenXml-GetWorksheetSignatureTargets`
- `Resolve-WorksheetSignatureRows_OpenXml` -> `OpenXml-ResolveWorksheetSignatureRows`
- `Get-WorksheetSignaturePlan_OpenXml` -> `OpenXml-GetWorksheetSignaturePlan`
- `Invoke-WorksheetSignature_OpenXml` -> `OpenXml-InvokeWorksheetSignature`

### Call-site uppdateringar

- `Modules/Core/Pipeline.ps1` använder nu canon-funktionerna `OpenXml-*` internt.
- `tools/run_regression.ps1` använder nu `OpenXml-GetWorksheetSignaturePlan`.
- `Modules/Core/Pipeline.ps1` använder `Csv-GetDelimiter`/`Csv-SplitFields` (canon) i stället för legacy-alias.

## FAS 3C - DRY cleanup (genomförd)

### Skip-sheet-regler centraliserade

- Ny central funktion i `Modules/DataHelpers.ps1`:
  - `Core-TestWorksheetSkipSheet -Context Header|SealTest`
- Wrappers:
  - `Test-IsWorksheetHeaderSkipSheet` (Header-context)
  - `Test-IsSealTestSkipSheet` (SealTest-context)
- Uppdaterade call-sites:
  - `Main.ps1`
  - `Modules/SignatureHelpers.ps1`
  - `Modules/DataHelpers.ps1` (header/seal-header extraction)

### Regression-asserts utökade

- `tools/run_regression.ps1` innehåller nu explicita asserts för:
  - `HasResample` i 33301/95107
  - planerad `Resample Data Summary` vid RES-case
  - `skip (ej resample)` när RES saknas
  - blocker för resampling-only selection
- Scriptet sätter `Status=FAIL` och `exit 1` vid assert-fel.

## FAS 3A - Central log wrapper (genomförd)

### Ny modul

- `Modules/Core/Log.ps1`
  - `Write-AppLog -Level -Message -Context`
  - `Set-AppLogSink -GuiLogScriptBlock -FilePath`
  - `Get-AppLogState`

### Inkoppling

- `Main.ps1` laddar `Core/Log.ps1` och registrerar GUI-sink som routar till `Gui-Log`.
- `tools/run_regression.ps1` laddar `Core/Log.ps1` och loggar via `Write-AppLog` (host + `regression.log`).
- `Modules/Core/Pipeline.ps1` loggar CSV-selektionsfel/varningar och plan-läsfel via `Write-AppLog`.

## FAS 1 - Dead code removal (genomförd)

### Borttaget (0 interna call-sites efter repo-sök)

- `Resolve-LocalFirstFile` från `Modules/Config.ps1`.
- `Get-TestSummaryEquipment` från `Modules/DataHelpers.ps1`.
- `Get-TestSummaryEquipmentFromWorksheet` från `Modules/DataHelpers.ps1`.
- `Test-IsNetworkPath` från `Modules/DataHelpers.ps1`.
- `Get-OutSheetName` från `Modules/DataHelpers.ps1`.
- `Is-FeatureEnabled` från `Modules/DataHelpers.ps1`.
- `Is-VlAssay` från `Modules/DataHelpers.ps1`.

### Kvar som compat-wrappers (avsiktligt)

- `Get-MergeCellMap_OpenXml` i `Modules/OpenXmlHelpers.ps1`.
- `Set-OpenXmlCellText` i `Modules/OpenXmlHelpers.ps1`.

Motivering: dessa två har historiskt använts i äldre OpenXML-flöden och behålls tills explicit API-brytning beslutas.

## FAS 2 - Modulisering från Main (genomförd)

### Ny modul

- `Modules/Core/Pipeline.ps1` (ny)
  - `Test-IsResampleCsv`
  - `Resolve-CsvSelection`
  - `Get-WorksheetSignDialogTargets_OpenXml`
  - `Invoke-WorksheetSigningModes_OpenXml`

### Flyttad/ersatt logik i Main

- Inline CSV-classifiering ersatt med `Resolve-CsvSelection`.
- Inline bygg av worksheet-dialogtargets ersatt med `Get-WorksheetSignDialogTargets_OpenXml`.
- Inline invoke-loop för worksheet-signering ersatt med `Invoke-WorksheetSigningModes_OpenXml`.
- `Test-IsResampleCsv` borttagen från `Main.ps1` och används nu från Core-modul.

### Import-ordning uppdaterad

- `Main.ps1` laddar nu `Modules/Core/Pipeline.ps1`.

## Regression harness (headless)

- Nytt script: `tools/run_regression.ps1`.
- Körbar i PS 5.1 utan WinForms.
- Kör core dry-run per testcase: CSV-validering, RuleEngine-körning, OpenXML signeringsplan.
- Skriver `RegressionReport.md` + `RegressionReport.json`.
