Set-StrictMode -Version 2.0

if (-not (Test-Path variable:script:BuildPipelineProjectRoot) -or -not $script:BuildPipelineProjectRoot) {
    $script:BuildPipelineProjectRoot = $null
}

function Build-WriteDiagnosticWarn {
    param(
        [Parameter(Mandatory=$true)][string]$Message,
        [string]$Context = 'BuildPipeline',
        [System.Exception]$Exception = $null
    )

    $msg = ($Message + '')
    if ($Exception -and $Exception.Message) {
        $msg = "$msg | $($Exception.Message)"
    }

    if (Get-Command Write-AppLog -ErrorAction SilentlyContinue) {
        try { Write-AppLog -Level 'Warn' -Message $msg -Context $Context } catch {}
    }
}

function Build-WriteDiagnosticInfo {
    param(
        [Parameter(Mandatory=$true)][string]$Message,
        [string]$Context = 'BuildPipeline'
    )
    if (Get-Command Write-AppLog -ErrorAction SilentlyContinue) {
        try { Write-AppLog -Level 'Info' -Message ($Message + '') -Context $Context } catch {}
    }
}

function Build-WriteDiagnosticDebug {
    param(
        [Parameter(Mandatory=$true)][string]$Message,
        [string]$Context = 'BuildPipeline'
    )
    if (Get-Command Write-AppLog -ErrorAction SilentlyContinue) {
        try { Write-AppLog -Level 'Debug' -Message ($Message + '') -Context $Context } catch {}
    }
}

function Build-ResolveProjectRoot {
    param($Context)

    try {
        if ($Context -and $Context.Metadata -and $Context.Metadata.ContainsKey('ProjectRoot')) {
            $p = ($Context.Metadata['ProjectRoot'] + '').Trim()
            if ($p) { return $p }
        }
    } catch {
        Build-WriteDiagnosticWarn -Message 'Context.Metadata.ProjectRoot kunde inte läsas' -Context 'Build.ResolveProjectRoot' -Exception $_.Exception
    }

    try {
        if ($global:ModulesRoot) {
            $m = ($global:ModulesRoot + '').Trim()
            if ($m) { return (Split-Path -Path $m -Parent) }
        }
    } catch {
        Build-WriteDiagnosticWarn -Message 'global ModulesRoot kunde inte användas' -Context 'Build.ResolveProjectRoot' -Exception $_.Exception
    }

    try {
        $here = $PSScriptRoot
        if ($here) { return (Resolve-Path (Join-Path $here '..\\..')).Path }
    } catch {
        Build-WriteDiagnosticWarn -Message 'PSScriptRoot fallback misslyckades' -Context 'Build.ResolveProjectRoot' -Exception $_.Exception
    }

    return (Get-Location).Path
}

function Build-NewResult {
    param([bool]$Success = $false)
    return [pscustomobject]@{
        Success    = [bool]$Success
        Outcome    = ''
        ErrorCode  = 1
        ErrorCodeName = ''
        OutputPath = ''
        AuditPath  = ''
        Warnings   = New-Object System.Collections.Generic.List[string]
        Errors     = New-Object System.Collections.Generic.List[string]
        Metrics    = [ordered]@{}
    }
}

function Build-ObjectHasProperty {
    param(
        [Parameter(Mandatory=$true)]$Object,
        [Parameter(Mandatory=$true)][string]$PropertyName
    )
    if ($null -eq $Object) { return $false }
    try {
        return (@($Object.PSObject.Properties.Match($PropertyName)).Count -gt 0)
    } catch {
        return $false
    }
}

function Build-GetSafeCount {
    param($Object)
    if ($null -eq $Object) { return 0 }
    try { return @($Object).Count } catch { return 0 }
}

function Build-TestRuleBankForEngine {
    param(
        [Parameter(Mandatory=$true)]$RuleBank,
        [string]$Context = 'Build.RuleBank'
    )

    $typeName = '<null>'
    try { if ($RuleBank) { $typeName = $RuleBank.GetType().FullName } } catch {}

    $keys = ''
    try {
        if ($RuleBank -is [System.Collections.IDictionary]) {
            $keys = (@($RuleBank.Keys) -join ',')
        } else {
            $keys = (@($RuleBank.PSObject.Properties | ForEach-Object { $_.Name }) -join ',')
        }
    } catch {}
    Build-WriteDiagnosticDebug -Message ("RuleBank loaded type={0}; keys={1}" -f $typeName, $keys) -Context $Context

    if (-not (Build-ObjectHasProperty -Object $RuleBank -PropertyName 'ErrorCodes')) {
        Gui-Log ("⚠️ Regelmotor: RuleBank invalid type={0} (saknar ErrorCodes) – hoppar över." -f $typeName) 'Warn'
        Build-WriteDiagnosticWarn -Message ("RuleBank invalid type={0}; missing ErrorCodes" -f $typeName) -Context $Context
        return $false
    }
    return $true
}

function Build-WriteAuditFile {
    param(
        [Parameter(Mandatory=$true)]$Context,
        [Parameter(Mandatory=$true)]$Result,
        [string]$Status = 'OK'
    )

    $auditDir = ($Context.AuditDir + '').Trim()
    if (-not $auditDir) {
        try {
            if ($global:IPT_NETWORK_ROOT -and (Test-Path -LiteralPath $global:IPT_NETWORK_ROOT)) {
                $auditDir = Join-Path $global:IPT_NETWORK_ROOT 'audit'
            }
        } catch {
            Build-WriteDiagnosticWarn -Message 'Kunde inte läsa IPT_NETWORK_ROOT för audit-katalog' -Context 'Build.WriteAudit' -Exception $_.Exception
        }
    }
    if (-not $auditDir) {
        $auditDir = Join-Path $env:TEMP 'audit'
    }

    if (-not (Test-Path -LiteralPath $auditDir)) {
        New-Item -ItemType Directory -Path $auditDir -Force | Out-Null
    }

    $ts = Get-Date
    $nowTs = $ts.ToString('yyyyMMdd_HHmmss')
    $safeUser = ($Context.UserName + '')
    if (-not $safeUser) { $safeUser = $env:USERNAME }

    $stageState = $null
    $stageTimings = $null
    if ($Result -and $Result.Metrics) {
        try { if ($Result.Metrics.Contains('StageState')) { $stageState = $Result.Metrics['StageState'] } } catch {}
        try {
            if ($Result.Metrics.Contains('StageTimings')) { $stageTimings = $Result.Metrics['StageTimings'] }
            elseif ($Result.Metrics.Contains('Stages')) { $stageTimings = $Result.Metrics['Stages'] }
        } catch {}
    }

    $hasResample = $false
    try {
        if ($Context.CsvSelection -and $Context.CsvSelection.PSObject.Properties['HasResample']) {
            $hasResample = [bool]$Context.CsvSelection.HasResample
        }
    } catch {}

    $proc = $null
    try { $proc = Build-EnsureContextProcessingState -Context $Context } catch { $proc = $null }
    $cacheModeEnabled = $false
    if ($proc) {
        try { $cacheModeEnabled = [bool]$proc['CacheModeEnabled'] } catch { $cacheModeEnabled = $false }
    } else {
        try { $cacheModeEnabled = [bool]$Context.UseLocalCache } catch { $cacheModeEnabled = $false }
    }

    $runRulesExecuted = $null
    $runRulesStatus = ''
    $applyExecuted = $null
    $applyStatus = ''
    try {
        if ($stageState -and $stageState['RunRules']) {
            $rr = $stageState['RunRules']
            if ($rr.Contains('Executed')) { $runRulesExecuted = [bool]$rr['Executed'] }
            $runRulesStatus = ($rr['ExecutionStatus'] + '')
            if (-not $runRulesStatus) { $runRulesStatus = ($rr['Status'] + '') }
        }
    } catch {}
    try {
        if ($stageState -and $stageState['ApplySignatures']) {
            $as = $stageState['ApplySignatures']
            if ($as.Contains('Executed')) { $applyExecuted = [bool]$as['Executed'] }
            $applyStatus = ($as['ExecutionStatus'] + '')
            if (-not $applyStatus) { $applyStatus = ($as['Status'] + '') }
        }
    } catch {}

    $reason = ''
    try {
        if ($Result.Errors -and $Result.Errors.Count -gt 0) { $reason = ($Result.Errors[0] + '') }
        elseif ($Result.Warnings -and $Result.Warnings.Count -gt 0) { $reason = ($Result.Warnings[0] + '') }
    } catch {}

    $timingText = ''
    try {
        if ($stageTimings) {
            $timingParts = New-Object System.Collections.Generic.List[string]
            foreach ($k in @($stageTimings.Keys)) {
                $v = [int]$stageTimings[$k]
                [void]$timingParts.Add(("{0}={1}ms" -f $k, $v))
            }
            $timingText = (@($timingParts) -join '; ')
        }
    } catch {}

    $origMap = $null
    $workMap = $null
    try {
        if ($proc) {
            $origMap = $proc['OriginalPaths']
            $workMap = $proc['WorkingPaths']
        }
    } catch {}
    if (-not $origMap) { $origMap = Build-GetPathMap -Context $Context }
    if (-not $workMap) { $workMap = Build-GetPathMap -Context $Context }

    $warningsText = ''
    $errorsText = ''
    try { $warningsText = (@($Result.Warnings | Where-Object { $_ }) -join ' || ') } catch {}
    try { $errorsText = (@($Result.Errors | Where-Object { $_ }) -join ' || ') } catch {}

    $publishMethod = ''
    $publishWarning = ''
    try {
        if ($Result.Metrics.Contains('PublishMethod')) { $publishMethod = ($Result.Metrics['PublishMethod'] + '') }
        if ($Result.Metrics.Contains('PublishWarning')) { $publishWarning = ($Result.Metrics['PublishWarning'] + '') }
    } catch {}

    $auditObj = [pscustomobject]@{
        DatumTid                = $ts.ToString('yyyy-MM-dd HH:mm:ss')
        Anvandare               = $safeUser
        LSP                     = ($Context.Lsp + '')
        Outcome                 = ($Status + '')
        ErrorCode               = [int]$Result.ErrorCode
        ErrorCodeName           = ($Result.ErrorCodeName + '')
        Reason                  = ($reason + '')
        Headless                = [bool]$Context.Headless
        HasResample             = [bool]$hasResample
        CacheModeEnabled        = [bool]$cacheModeEnabled
        RunRulesExecuted        = if ($null -eq $runRulesExecuted) { '' } else { [bool]$runRulesExecuted }
        RunRulesStatus          = ($runRulesStatus + '')
        ApplySignaturesExecuted = if ($null -eq $applyExecuted) { '' } else { [bool]$applyExecuted }
        ApplySignaturesStatus   = ($applyStatus + '')
        PublishMethod           = ($publishMethod + '')
        PublishWarning          = ($publishWarning + '')
        OutputPath              = ($Result.OutputPath + '')
        AuditPath               = ''
        OriginalPaths           = (Build-FormatPathMap -PathMap $origMap)
        WorkingPaths            = (Build-FormatPathMap -PathMap $workMap)
        StageTimings            = ($timingText + '')
        Warnings                = ($warningsText + '')
        Errors                  = ($errorsText + '')
    }

    $auditFile = Join-Path $auditDir ("{0}_audit_{1}.csv" -f $safeUser, $nowTs)
    $auditObj.AuditPath = $auditFile
    $auditObj | Export-Csv -Path $auditFile -NoTypeInformation -Encoding UTF8
    return $auditFile
}

function Build-TestFilesUnlockedHeadless {
    param([string[]]$Paths)
    $clean = @($Paths | Where-Object { $_ -and (Test-Path -LiteralPath $_) } | Select-Object -Unique)
    foreach ($p in $clean) {
        try {
            if (Core-TestFileLocked -Path $p) { return $false }
        } catch {
            Build-WriteDiagnosticWarn -Message ("Fil-låskontroll misslyckades för: {0}" -f $p) -Context 'Build.FileLock'
            return $false
        }
    }
    return $true
}

function Build-GetFirstLockedPath {
    param([string[]]$Paths)
    $clean = @($Paths | Where-Object { $_ -and (Test-Path -LiteralPath $_) } | Select-Object -Unique)
    foreach ($p in $clean) {
        try {
            if (Core-TestFileLocked -Path $p) { return ($p + '') }
        } catch {
            Build-WriteDiagnosticWarn -Message ("Fil-låskontroll misslyckades för: {0}" -f $p) -Context 'Build.FileLock' -Exception $_.Exception
            return ($p + '')
        }
    }
    return ''
}

function Build-NewStageResult {
    param(
        [bool]$Ok = $true,
        [string]$Reason = '',
        [string]$Status = 'OK',
        [hashtable]$Data,
        [string]$Stage = '',
        [string[]]$Errors = @(),
        [string[]]$Warnings = @(),
        [hashtable]$Metrics = $null
    )
    if (-not $Data) { $Data = @{} }
    if (-not $Metrics) { $Metrics = @{} }
    [pscustomobject]@{
        Ok     = [bool]$Ok
        Reason = ($Reason + '')
        Status = ($Status + '')
        Stage  = ($Stage + '')
        Data   = $Data
        Errors = @($Errors)
        Warnings = @($Warnings)
        Metrics = $Metrics
    }
}

function Build-NewStageData {
    param(
        [Parameter(Mandatory=$true)][string]$Stage,
        [hashtable]$Patch
    )

    $data = [ordered]@{
        Stage             = ($Stage + '')
        CsvSelection      = $null
        HasResample       = $null
        EpplusLoaded      = $null
        ReportSuccess     = $null
        OutputPath        = ''
        AuditPath         = ''
        SignaturesApplied = $null
        Executed          = $null
        ExecutionStatus   = ''
        CacheModeEnabled  = $null
        OriginalPaths     = $null
        WorkingPaths      = $null
        StageNote         = ''
    }
    if ($Patch) {
        foreach ($k in @($Patch.Keys)) { $data[$k] = $Patch[$k] }
    }
    return $data
}

function Build-GetPathMap {
    param([Parameter(Mandatory=$true)]$Context)
    return [ordered]@{
        CsvPrimary = (($Context.CsvPrimaryPath + '').Trim())
        CsvResample = (($Context.CsvResamplePath + '').Trim())
        Worksheet = (($Context.WorksheetPath + '').Trim())
        SealNeg = (($Context.SealNegPath + '').Trim())
        SealPos = (($Context.SealPosPath + '').Trim())
        Template = (($Context.TemplatePath + '').Trim())
    }
}

function Build-FormatPathMap {
    param($PathMap)
    if (-not $PathMap) { return '' }
    if (-not ($PathMap -is [System.Collections.IDictionary])) {
        $tmp = [ordered]@{}
        try { foreach ($p in @($PathMap.PSObject.Properties)) { $tmp[$p.Name] = $p.Value } } catch {}
        $PathMap = $tmp
    }
    $parts = New-Object System.Collections.Generic.List[string]
    foreach ($k in @($PathMap.Keys)) {
        $v = ($PathMap[$k] + '').Trim()
        if ($v) { [void]$parts.Add(("{0}={1}" -f $k, $v)) }
    }
    return (@($parts) -join '; ')
}

function Build-EnsureContextProcessingState {
    param([Parameter(Mandatory=$true)]$Context)
    if (-not $Context.PSObject.Properties['Processing']) {
        Add-Member -InputObject $Context -NotePropertyName 'Processing' -NotePropertyValue ([ordered]@{}) -Force
    }
    if (-not $Context.Processing) { $Context.Processing = [ordered]@{} }
    if (-not ($Context.Processing -is [System.Collections.IDictionary])) {
        $procMap = [ordered]@{}
        try {
            foreach ($p in @($Context.Processing.PSObject.Properties)) { $procMap[$p.Name] = $p.Value }
        } catch {}
        $Context.Processing = $procMap
    }
    if (-not $Context.Processing.Contains('OriginalPaths')) { $Context.Processing['OriginalPaths'] = @{} }
    if (-not $Context.Processing.Contains('WorkingPaths')) { $Context.Processing['WorkingPaths'] = @{} }
    if (-not $Context.Processing.Contains('CacheModeEnabled')) { $Context.Processing['CacheModeEnabled'] = $false }
    return $Context.Processing
}

function Build-GetCacheRoot {
    param([Parameter(Mandatory=$true)]$Context)
    $root = ''
    try {
        $proc = Build-EnsureContextProcessingState -Context $Context
        if ($proc -and $proc.Contains('CacheRoot')) {
            $root = ($proc['CacheRoot'] + '').Trim()
        }
    } catch {}
    if (-not $root) {
        $root = Join-Path $env:TEMP 'IPTCompile\Cache'
    }
    return $root
}

function Build-InvokeCacheCleanup {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)][string]$CacheRoot,
        [int]$MaxAgeDays = 7,
        [int]$KeepLatest = 20
    )

    if ($MaxAgeDays -lt 1) { $MaxAgeDays = 7 }
    if ($KeepLatest -lt 1) { $KeepLatest = 20 }

    $res = [pscustomobject]@{
        Ok           = $true
        CacheRoot    = ($CacheRoot + '')
        Deleted      = New-Object System.Collections.Generic.List[string]
        Failed       = New-Object System.Collections.Generic.List[string]
        DeletedCount = 0
        FailedCount  = 0
        TotalSeen    = 0
        Note         = ''
    }

    try {
        if (-not (Test-Path -LiteralPath $CacheRoot)) {
            $res.Note = 'CacheRoot saknas, inget att rensa.'
            Build-WriteDiagnosticDebug -Message ("Cache cleanup: root saknas ({0})" -f $CacheRoot) -Context 'Build.CacheCleanup'
            return $res
        }

        $dirs = @(
            Get-ChildItem -LiteralPath $CacheRoot -Directory -ErrorAction Stop |
            Sort-Object LastWriteTimeUtc -Descending
        )
        $res.TotalSeen = $dirs.Count
        $now = [DateTime]::UtcNow

        $index = 0
        foreach ($d in $dirs) {
            $index++
            $ageDays = [int]([Math]::Floor(($now - $d.LastWriteTimeUtc).TotalDays))
            $tooOld = ($ageDays -ge $MaxAgeDays)
            $overKeep = ($index -gt $KeepLatest)
            if (-not ($tooOld -or $overKeep)) { continue }

            try {
                Remove-Item -LiteralPath $d.FullName -Recurse -Force -ErrorAction Stop
                [void]$res.Deleted.Add($d.FullName)
                $res.DeletedCount++
                Build-WriteDiagnosticDebug -Message ("Cache cleanup removed: {0} (age={1}d, index={2})" -f $d.FullName, $ageDays, $index) -Context 'Build.CacheCleanup'
            } catch {
                [void]$res.Failed.Add(("{0} | {1}" -f $d.FullName, $_.Exception.Message))
                $res.FailedCount++
                Build-WriteDiagnosticWarn -Message ("Cache cleanup kunde inte ta bort: {0}" -f $d.FullName) -Context 'Build.CacheCleanup' -Exception $_.Exception
            }
        }

        $res.Note = ("Seen={0}; Deleted={1}; Failed={2}; MaxAgeDays={3}; KeepLatest={4}" -f $res.TotalSeen, $res.DeletedCount, $res.FailedCount, $MaxAgeDays, $KeepLatest)
        Build-WriteDiagnosticInfo -Message ("Cache cleanup summary: {0}" -f $res.Note) -Context 'Build.CacheCleanup'
    } catch {
        $res.Ok = $false
        $res.Note = ("Cache cleanup exception: {0}" -f $_.Exception.Message)
        Build-WriteDiagnosticWarn -Message 'Cache cleanup exception' -Context 'Build.CacheCleanup' -Exception $_.Exception
    }

    return $res
}

function Build-GetUiHookOrDefault {
    param(
        [hashtable]$UiHooks,
        [string]$Name,
        [scriptblock]$Default = { $null }
    )

    if (-not $UiHooks) { return $Default }
    if (-not $UiHooks.ContainsKey($Name)) { return $Default }

    $candidate = $UiHooks[$Name]
    if ($candidate -is [scriptblock]) { return $candidate }
    return $Default
}

function Build-InvokeUiHook {
    param(
        [hashtable]$UiHooks,
        [string]$Name,
        [object[]]$Arguments
    )

    $sb = Build-GetUiHookOrDefault -UiHooks $UiHooks -Name $Name -Default { $null }
    if (-not ($sb -is [scriptblock])) { return $null }

    try {
        if ($Arguments) { return (& $sb @Arguments) }
        return (& $sb)
    } catch {
        Build-WriteDiagnosticWarn -Message ("UiHook '{0}' kastade exception" -f $Name) -Context 'Build.UiHook' -Exception $_.Exception
        return $null
    }
}

function Stage-ResolveInputs {
    param(
        [Parameter(Mandatory=$true)]$Context,
        [Parameter(Mandatory=$true)]$Result,
        [hashtable]$UiHooks
    )

    [void](Build-InvokeUiHook -UiHooks $UiHooks -Name 'Progress' -Arguments @('ResolveInputs'))

    if (-not $Context.CsvSelection) {
        $paths = @()
        if ($Context.CsvPaths) {
            $paths = @($Context.CsvPaths | Where-Object { $_ -and -not [string]::IsNullOrWhiteSpace($_) })
        }
        if ($paths.Count -eq 0) {
            $cp = ($Context.CsvPrimaryPath + '').Trim()
            $cr = ($Context.CsvResamplePath + '').Trim()
            if ($cp) { $paths += $cp }
            if ($cr) { $paths += $cr }
        }

        if ($paths.Count -gt 0 -and (Get-Command Csv-ResolveSelection -ErrorAction SilentlyContinue)) {
            try {
                $Context.CsvSelection = Csv-ResolveSelection -AllCsvPaths $paths
            } catch {
                Build-WriteDiagnosticWarn -Message 'Csv-ResolveSelection misslyckades i Stage-ResolveInputs' -Context 'Build.Stage.ResolveInputs' -Exception $_.Exception
            }
        }
    }

    $hasResample = $false
    try {
        if ($Context.CsvSelection -and $Context.CsvSelection.PSObject.Properties['HasResample']) {
            $hasResample = [bool]$Context.CsvSelection.HasResample
        }
        if ($Context.CsvSelection -and $Context.CsvSelection.PSObject.Properties['PrimaryPath']) {
            $pp = ($Context.CsvSelection.PrimaryPath + '').Trim()
            if ($pp) { $Context.CsvPrimaryPath = $pp }
        }
        if ($Context.CsvSelection -and $Context.CsvSelection.PSObject.Properties['ResamplePath']) {
            $rp = ($Context.CsvSelection.ResamplePath + '').Trim()
            if ($rp) { $Context.CsvResamplePath = $rp }
        }
    } catch {
        Build-WriteDiagnosticWarn -Message 'HasResample kunde inte extraheras från CsvSelection' -Context 'Build.Stage.ResolveInputs' -Exception $_.Exception
    }

    return (Build-NewStageResult -Ok:$true -Status 'Resolved' -Stage 'ResolveInputs' -Data (Build-NewStageData -Stage 'ResolveInputs' -Patch @{ CsvSelection = $Context.CsvSelection; HasResample = [bool]$hasResample; Executed = $true; ExecutionStatus = 'Executed' }))
}

function Stage-Validate {
    param(
        [Parameter(Mandatory=$true)]$Context,
        [Parameter(Mandatory=$true)]$Result,
        [hashtable]$UiHooks
    )

    [void](Build-InvokeUiHook -UiHooks $UiHooks -Name 'Progress' -Arguments @('Validate'))

    $validation = Validate-RunContext -Context $Context
    foreach ($w in @($validation.Warnings)) {
        if ($w) { [void]$Result.Warnings.Add(($w + '')) }
    }
    if ($validation.CsvSelection) {
        try { $Context.CsvSelection = $validation.CsvSelection } catch {
            Build-WriteDiagnosticWarn -Message 'Kunde inte skriva tillbaka CsvSelection till Context i Validate' -Context 'Build.Stage.Validate' -Exception $_.Exception
        }
        try {
            $pp = ($validation.CsvSelection.PrimaryPath + '').Trim()
            $rp = ($validation.CsvSelection.ResamplePath + '').Trim()
            if ($pp) { $Context.CsvPrimaryPath = $pp }
            if ($rp) { $Context.CsvResamplePath = $rp }
        } catch {
            Build-WriteDiagnosticWarn -Message 'Kunde inte skriva tillbaka Primary/Resample paths till Context i Validate' -Context 'Build.Stage.Validate' -Exception $_.Exception
        }
    }
    if (-not $validation.Ok) {
        foreach ($e in @($validation.Errors)) {
            if ($e) { [void]$Result.Errors.Add(($e + '')) }
        }
        return (Build-NewStageResult -Ok:$false -Reason 'ValidationFailed' -Status 'Blocked' -Stage 'Validate' -Data (Build-NewStageData -Stage 'Validate' -Patch @{ CsvSelection = $Context.CsvSelection; Executed = $true; ExecutionStatus = 'FailedValidation' }) -Errors @($validation.Errors) -Warnings @($validation.Warnings))
    }

    if (([bool]$Context.DoSealTest -or [bool]$Context.DoWsSamm) -and (-not [bool]$Context.OverwriteSamm)) {
        [void]$Result.Errors.Add('Overwrite måste vara aktiverad för Sammanställning/Seal Test.')
    }
    if ([bool]$Context.DoWsGransk -and (-not [bool]$Context.OverwriteGransk)) {
        [void]$Result.Errors.Add('Overwrite måste vara aktiverad för Granskning.')
    }

    if ($Result.Errors.Count -gt 0) {
        return (Build-NewStageResult -Ok:$false -Reason 'ValidationFailed' -Status 'Blocked' -Stage 'Validate' -Data (Build-NewStageData -Stage 'Validate' -Patch @{ CsvSelection = $Context.CsvSelection; Executed = $true; ExecutionStatus = 'FailedValidation' }) -Errors @($Result.Errors))
    }

    return (Build-NewStageResult -Ok:$true -Status 'Validated' -Stage 'Validate' -Data (Build-NewStageData -Stage 'Validate' -Patch @{ CsvSelection = $Context.CsvSelection; Executed = $true; ExecutionStatus = 'Executed' }))
}

function Build-CopyFileToLocalCache {
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [Parameter(Mandatory=$true)][string]$CacheRoot,
        [Parameter(Mandatory=$true)][string]$Key
    )

    $src = ($Path + '').Trim()
    if (-not $src) { return '' }
    if (-not (Test-Path -LiteralPath $src)) { return $src }

    if (-not (Test-Path -LiteralPath $CacheRoot)) {
        New-Item -ItemType Directory -Path $CacheRoot -Force | Out-Null
    }

    $leaf = Split-Path -Path $src -Leaf
    $dst = Join-Path $CacheRoot ("{0}__{1}" -f ($Key + ''), $leaf)
    Copy-Item -LiteralPath $src -Destination $dst -Force
    try {
        $srcInfo = Get-Item -LiteralPath $src -ErrorAction Stop
        (Get-Item -LiteralPath $dst -ErrorAction Stop).LastWriteTimeUtc = $srcInfo.LastWriteTimeUtc
    } catch {
        Build-WriteDiagnosticWarn -Message ("Kunde inte synka LastWriteTime på cache-fil: {0}" -f $dst) -Context 'Build.Stage.CacheInputs' -Exception $_.Exception
    }
    return $dst
}

function Stage-CacheInputs {
    param(
        [Parameter(Mandatory=$true)]$Context,
        [Parameter(Mandatory=$true)]$Result,
        [hashtable]$UiHooks
    )

    [void](Build-InvokeUiHook -UiHooks $UiHooks -Name 'Progress' -Arguments @('CacheInputs'))

    $proc = Build-EnsureContextProcessingState -Context $Context
    $origMap = Build-GetPathMap -Context $Context
    $proc['OriginalPaths'] = $origMap

    if (-not [bool]$Context.UseLocalCache) {
        $proc['CacheModeEnabled'] = $false
        $proc['WorkingPaths'] = $origMap
        return (Build-NewStageResult -Ok:$true -Status 'CacheDisabled' -Stage 'CacheInputs' -Data (Build-NewStageData -Stage 'CacheInputs' -Patch @{
            CacheModeEnabled = $false
            OriginalPaths = $origMap
            WorkingPaths = $origMap
            ExecutionStatus = 'Disabled'
            Executed = $false
            StageNote = 'UseLocalCache=false'
        }))
    }

    $existingOriginal = @()
    foreach ($k in @($origMap.Keys)) {
        $p = ($origMap[$k] + '').Trim()
        if ($p -and (Test-Path -LiteralPath $p)) { $existingOriginal += $p }
    }

    if (-not (Build-TestFilesUnlockedHeadless -Paths $existingOriginal)) {
        $retried = [bool](Build-InvokeUiHook -UiHooks $UiHooks -Name 'RetryFileLock' -Arguments @(@($existingOriginal), 'CacheInputs: en eller flera källfiler är låsta.'))
        if (-not $retried -or -not (Build-TestFilesUnlockedHeadless -Paths $existingOriginal)) {
            $lockedPath = Build-GetFirstLockedPath -Paths $existingOriginal
            $msg = if ($lockedPath) {
                "CacheInputs blockerad: låst originalfil '$lockedPath'."
            } else {
                'CacheInputs blockerad: minst en originalfil är låst.'
            }
            [void]$Result.Errors.Add($msg)
            $Result.ErrorCodeName = 'LockedFile'
            $Result.Metrics['LockedPath'] = ($lockedPath + '')
            return (Build-NewStageResult -Ok:$false -Reason 'CacheInputsLocked' -Status 'Blocked' -Stage 'CacheInputs' -Data (Build-NewStageData -Stage 'CacheInputs' -Patch @{
                CacheModeEnabled = $true
                OriginalPaths = $origMap
                WorkingPaths = $origMap
                ExecutionStatus = 'BlockedLocked'
                Executed = $false
                StageNote = $msg
                LockedPath = ($lockedPath + '')
            }) -Errors @($msg))
        }
    }

    $runId = (($Context.RunId + '').Trim())
    if (-not $runId) { $runId = ('{0}_{1}' -f (Get-Date -Format 'yyyyMMdd_HHmmss'), ([guid]::NewGuid().ToString('N').Substring(0, 8))) }
    try { $Context.RunId = $runId } catch {}

    $cacheRoot = Join-Path (Join-Path $env:TEMP 'IPTCompile\Cache') $runId
    $cacheInputsRoot = Join-Path $cacheRoot 'inputs'
    $cacheOutputRoot = Join-Path $cacheRoot 'output'
    if (-not (Test-Path -LiteralPath $cacheInputsRoot)) { New-Item -ItemType Directory -Path $cacheInputsRoot -Force | Out-Null }
    if (-not (Test-Path -LiteralPath $cacheOutputRoot)) { New-Item -ItemType Directory -Path $cacheOutputRoot -Force | Out-Null }

    $workMap = [ordered]@{}
    try {
        foreach ($k in @($origMap.Keys)) {
            $workMap[$k] = Build-CopyFileToLocalCache -Path ($origMap[$k] + '') -CacheRoot $cacheInputsRoot -Key ($k + '')
        }
    } catch {
        $msg = ("CacheInputs misslyckades: {0}" -f $_.Exception.Message)
        [void]$Result.Warnings.Add($msg)
        Build-WriteDiagnosticWarn -Message $msg -Context 'Build.Stage.CacheInputs' -Exception $_.Exception
        $proc['CacheModeEnabled'] = $false
        $proc['WorkingPaths'] = $origMap
        return (Build-NewStageResult -Ok:$true -Status 'CacheFallbackOriginal' -Stage 'CacheInputs' -Data (Build-NewStageData -Stage 'CacheInputs' -Patch @{
            CacheModeEnabled = $false
            OriginalPaths = $origMap
            WorkingPaths = $origMap
            ExecutionStatus = 'FallbackOriginal'
            Executed = $false
            StageNote = $msg
        }) -Warnings @($msg))
    }

    $existingWorking = @()
    foreach ($k in @($workMap.Keys)) {
        $p = ($workMap[$k] + '').Trim()
        if ($p -and (Test-Path -LiteralPath $p)) { $existingWorking += $p }
    }
    if (-not (Build-TestFilesUnlockedHeadless -Paths $existingWorking)) {
        $lockedPath = Build-GetFirstLockedPath -Paths $existingWorking
        $msg = if ($lockedPath) {
            "CacheInputs blockerad: låst arbetskopia '$lockedPath'."
        } else {
            'CacheInputs blockerad: minst en arbetskopia är låst.'
        }
        [void]$Result.Errors.Add($msg)
        $Result.ErrorCodeName = 'LockedFile'
        $Result.Metrics['LockedPath'] = ($lockedPath + '')
        return (Build-NewStageResult -Ok:$false -Reason 'CacheWorkingLocked' -Status 'Blocked' -Stage 'CacheInputs' -Data (Build-NewStageData -Stage 'CacheInputs' -Patch @{
            CacheModeEnabled = $true
            OriginalPaths = $origMap
            WorkingPaths = $workMap
            ExecutionStatus = 'BlockedWorkingLocked'
            Executed = $true
            StageNote = $msg
            LockedPath = ($lockedPath + '')
        }) -Errors @($msg))
    }

    try {
        if ($workMap['CsvPrimary']) { $Context.CsvPrimaryPath = $workMap['CsvPrimary'] }
        if ($workMap['CsvResample']) { $Context.CsvResamplePath = $workMap['CsvResample'] }
        if ($workMap['Worksheet']) { $Context.WorksheetPath = $workMap['Worksheet'] }
        if ($workMap['SealNeg']) { $Context.SealNegPath = $workMap['SealNeg'] }
        if ($workMap['SealPos']) { $Context.SealPosPath = $workMap['SealPos'] }
        if ($workMap['Template']) { $Context.TemplatePath = $workMap['Template'] }

        $finalOut = (($Context.OutputDir + '').Trim())
        if (-not $finalOut) { $finalOut = $env:TEMP }
        $proc['FinalOutputDir'] = $finalOut
        $proc['WorkingOutputDir'] = $cacheOutputRoot
        $Context.OutputDir = $cacheOutputRoot
        $proc['CacheRoot'] = $cacheRoot
        $proc['CacheModeEnabled'] = $true
        $proc['WorkingPaths'] = $workMap
        $proc['OriginalPaths'] = $origMap
        $proc['RunId'] = $runId
    } catch {
        $msg = ("CacheInputs kunde inte skriva tillbaka working paths till context: {0}" -f $_.Exception.Message)
        [void]$Result.Errors.Add($msg)
        return (Build-NewStageResult -Ok:$false -Reason 'CacheContextWriteBackFailed' -Status 'Failed' -Stage 'CacheInputs' -Data (Build-NewStageData -Stage 'CacheInputs' -Patch @{
            CacheModeEnabled = $true
            OriginalPaths = $origMap
            WorkingPaths = $workMap
            ExecutionStatus = 'FailedWriteBack'
            Executed = $true
            StageNote = $msg
        }) -Errors @($msg))
    }

    return (Build-NewStageResult -Ok:$true -Status 'Cached' -Stage 'CacheInputs' -Data (Build-NewStageData -Stage 'CacheInputs' -Patch @{
        CacheModeEnabled = $true
        OriginalPaths = $origMap
        WorkingPaths = $workMap
        ExecutionStatus = 'Applied'
        Executed = $true
        StageNote = ("RunId={0}" -f $runId)
    }))
}

function Stage-LoadData {
    param(
        [Parameter(Mandatory=$true)]$Context,
        [Parameter(Mandatory=$true)]$Result,
        [hashtable]$UiHooks
    )

    [void](Build-InvokeUiHook -UiHooks $UiHooks -Name 'Progress' -Arguments @('LoadData'))

    if (-not (Load-EPPlus)) {
        [void]$Result.Errors.Add('EPPlus kunde inte laddas.')
        return (Build-NewStageResult -Ok:$false -Reason 'LoadDataFailed' -Status 'Failed' -Stage 'LoadData' -Data (Build-NewStageData -Stage 'LoadData' -Patch @{ EpplusLoaded = $false; Executed = $true; ExecutionStatus = 'Failed' }) -Errors @('EPPlus kunde inte laddas.'))
    }
    return (Build-NewStageResult -Ok:$true -Status 'Loaded' -Stage 'LoadData' -Data (Build-NewStageData -Stage 'LoadData' -Patch @{ EpplusLoaded = $true; Executed = $true; ExecutionStatus = 'Executed' }))
}

function Stage-RunRules {
    param(
        [Parameter(Mandatory=$true)]$Context,
        [Parameter(Mandatory=$true)]$Result,
        [hashtable]$UiHooks
    )

    [void](Build-InvokeUiHook -UiHooks $UiHooks -Name 'Progress' -Arguments @('RunRules'))
    $note = 'RuleEngine exekveras i report-writer/canonical path (delegated).'
    return (Build-NewStageResult -Ok:$true -Status 'RulesDelegated' -Stage 'RunRules' -Data (Build-NewStageData -Stage 'RunRules' -Patch @{
        Executed = $false
        ExecutionStatus = 'Delegated'
        StageNote = $note
    }))
}

function Build-PublishOutputAtomic {
    param(
        [Parameter(Mandatory=$true)][string]$SourcePath,
        [Parameter(Mandatory=$true)][string]$DestinationDir
    )

    if (-not (Test-Path -LiteralPath $SourcePath)) {
        throw ("SourcePath saknas vid publish: {0}" -f $SourcePath)
    }

    $destDir = ($DestinationDir + '').Trim()
    if (-not $destDir) { $destDir = Split-Path -Path $SourcePath -Parent }
    if (-not (Test-Path -LiteralPath $destDir)) {
        New-Item -ItemType Directory -Path $destDir -Force | Out-Null
    }

    $leaf = Split-Path -Path $SourcePath -Leaf
    $tmpDest = Join-Path $destDir (".tmp_{0}_{1}" -f ([guid]::NewGuid().ToString('N').Substring(0, 8)), $leaf)
    $finalDest = Join-Path $destDir $leaf

    $publishResult = [pscustomobject]@{
        Path    = ''
        Method  = ''
        Warning = ''
    }

    try {
        Copy-Item -LiteralPath $SourcePath -Destination $tmpDest -Force -ErrorAction Stop
        Move-Item -LiteralPath $tmpDest -Destination $finalDest -Force -ErrorAction Stop
        $publishResult.Path = $finalDest
        $publishResult.Method = 'AtomicRenameInTarget'
        return $publishResult
    } catch {
        try { if (Test-Path -LiteralPath $tmpDest) { Remove-Item -LiteralPath $tmpDest -Force -ErrorAction SilentlyContinue } } catch {}
        $fallbackWarn = ("Atomic publish misslyckades, fallback till copy: {0}" -f $_.Exception.Message)
        Build-WriteDiagnosticWarn -Message $fallbackWarn -Context 'Build.Publish'
        try {
            Copy-Item -LiteralPath $SourcePath -Destination $finalDest -Force -ErrorAction Stop
            $publishResult.Path = $finalDest
            $publishResult.Method = 'FallbackCopy'
            $publishResult.Warning = $fallbackWarn
            return $publishResult
        } catch {
            throw ("Publish misslyckades (atomic + fallback copy): {0}" -f $_.Exception.Message)
        }
    }
}

function Build-ExecuteHeadlessReport {
    param(
        [Parameter(Mandatory=$true)]$Context,
        [hashtable]$UiHooks
    )

    $templatePath = ($Context.TemplatePath + '').Trim()
    $outputDir = ($Context.OutputDir + '').Trim()
    if (-not $outputDir) { $outputDir = $env:TEMP }
    if (-not (Test-Path -LiteralPath $outputDir)) { New-Item -ItemType Directory -Path $outputDir -Force | Out-Null }
    $publishDir = $outputDir
    $cacheModeEnabled = $false
    $proc = $null
    try {
        $proc = Build-EnsureContextProcessingState -Context $Context
        $cacheModeEnabled = [bool]$proc['CacheModeEnabled']
        if ($cacheModeEnabled -and $proc['FinalOutputDir']) {
            $publishDir = ($proc['FinalOutputDir'] + '').Trim()
            if (-not $publishDir) { $publishDir = $outputDir }
        }
    } catch {
        $cacheModeEnabled = $false
    }
    if ($proc) {
        try {
            if (-not $proc.Contains('PublishMethod')) { $proc['PublishMethod'] = '' }
            if (-not $proc.Contains('PublishWarning')) { $proc['PublishWarning'] = '' }
        } catch {}
    }

    $checkPaths = @($Context.SealNegPath, $Context.SealPosPath, $Context.WorksheetPath, $templatePath)
    if (-not (Build-TestFilesUnlockedHeadless -Paths $checkPaths)) {
        $retried = [bool](Build-InvokeUiHook -UiHooks $UiHooks -Name 'RetryFileLock' -Arguments @(@($checkPaths), 'Headless build: filer är låsta.'))
        if (-not $retried -or -not (Build-TestFilesUnlockedHeadless -Paths $checkPaths)) {
            $lockedPath = Build-GetFirstLockedPath -Paths $checkPaths
            if ($lockedPath) {
                throw ("En eller flera filer är låsta (headless): {0}" -f $lockedPath)
            }
            throw 'En eller flera filer är låsta (headless har ingen retry-dialog).'
        }
    }

    $nowTs = Get-Date -Format 'yyyyMMdd_HHmmss'
    $lsp = (($Context.Lsp + '').Trim())
    if (-not $lsp) { $lsp = 'MANUELL' }
    $user = ($Context.UserName + '')
    if (-not $user) { $user = $env:USERNAME }

    $outName = ("{0}_output_{1}_{2}.xlsx" -f $user, $lsp, $nowTs)
    $outPath = Join-Path $outputDir $outName
    $publishedPath = $outPath

    $pkg = $null
    try {
        $pkg = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($templatePath))
        $wsInfo = $pkg.Workbook.Worksheets['Run Information']
        if ($wsInfo) {
            try { $wsInfo.Cells['B3'].Style.Numberformat.Format = '@'; $wsInfo.Cells['B3'].Value = ($Context.Lsp + '') } catch {
                Build-WriteDiagnosticWarn -Message "Kunde inte skriva Run Information B3 i headless report" -Context 'Build.Headless.Report' -Exception $_.Exception
            }
            try {
                if ($Context.CsvSelection -and $Context.CsvSelection.PrimaryPath) {
                    $leafP = Split-Path $Context.CsvSelection.PrimaryPath -Leaf
                    $leafR = if ($Context.CsvSelection.ResamplePath) { Split-Path $Context.CsvSelection.ResamplePath -Leaf } else { '' }
                    $txt = if ($leafP -and $leafR) { "Primary: $leafP | Resampling: $leafR" } elseif ($leafP) { "Primary: $leafP" } else { '' }
                    if ($txt) { $wsInfo.Cells['B15'].Style.WrapText = $true; $wsInfo.Cells['B15'].Value = $txt }
                }
            } catch {
                Build-WriteDiagnosticWarn -Message "Kunde inte skriva Run Information B15 i headless report" -Context 'Build.Headless.Report' -Exception $_.Exception
            }
            try {
                if ($Context.WorksheetPath -and (Test-Path -LiteralPath $Context.WorksheetPath)) {
                    $wsPkg = $null
                    try {
                        $wsPkg = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($Context.WorksheetPath))
                        $hdr = Extract-WorksheetHeader -Pkg $wsPkg
                        if ($hdr -and $hdr.BatchNo) { $wsInfo.Cells['B19'].Style.Numberformat.Format = '@'; $wsInfo.Cells['B19'].Value = ($hdr.BatchNo + '') }
                    } finally {
                        try { if ($wsPkg) { $wsPkg.Dispose() } } catch {
                            Build-WriteDiagnosticWarn -Message "Kunde inte stänga temporärt Worksheet-paket i headless report" -Context 'Build.Headless.Report' -Exception $_.Exception
                        }
                    }
                }
            } catch {
                Build-WriteDiagnosticWarn -Message "Kunde inte extrahera/sätta BatchNo (Run Information B19) i headless report" -Context 'Build.Headless.Report' -Exception $_.Exception
            }
        }
        $wsQc = $pkg.Workbook.Worksheets['QC Summary']
        if ($wsQc) {
            try {
                $assayName = ''
                if ($Context.CsvSelection -and $Context.CsvSelection.PrimaryPath -and (Test-Path -LiteralPath $Context.CsvSelection.PrimaryPath)) {
                    $assayName = (Csv-GetAssay -Path $Context.CsvSelection.PrimaryPath -StartRow 10) + ''
                }
                if (-not $assayName) { $assayName = 'Headless build' }
                $wsQc.Cells['B3'].Style.Numberformat.Format = '@'
                $wsQc.Cells['B3'].Value = $assayName
            } catch {
                Build-WriteDiagnosticWarn -Message "Kunde inte skriva QC Summary B3 i headless report" -Context 'Build.Headless.Report' -Exception $_.Exception
            }
        }
        $pkg.SaveAs($outPath)
    } finally {
        try { if ($pkg) { $pkg.Dispose() } } catch {
            Build-WriteDiagnosticWarn -Message "Kunde inte stänga output-paket i headless report" -Context 'Build.Headless.Report' -Exception $_.Exception
        }
    }

    if ($cacheModeEnabled) {
        try {
            $publishRes = Build-PublishOutputAtomic -SourcePath $outPath -DestinationDir $publishDir
            $publishedPath = ($publishRes.Path + '')
            if ($proc) {
                try {
                    $proc['PublishMethod'] = ($publishRes.Method + '')
                    $proc['PublishWarning'] = ($publishRes.Warning + '')
                } catch {}
            }
        } catch {
            throw ("Kunde inte publicera cache-output atomiskt: {0}" -f $_.Exception.Message)
        }
    } else {
        if ($proc) {
            try {
                $proc['PublishMethod'] = 'DirectWrite'
                $proc['PublishWarning'] = ''
            } catch {}
        }
    }

    return $publishedPath
}

function Stage-WriteReport {
    param(
        [Parameter(Mandatory=$true)]$Context,
        [Parameter(Mandatory=$true)]$Result,
        [hashtable]$UiHooks
    )

    [void](Build-InvokeUiHook -UiHooks $UiHooks -Name 'Progress' -Arguments @('WriteReport'))
    $publishMethod = ''
    $publishWarning = ''

    try {
        if ([bool]$Context.Headless) {
            $outPath = Build-ExecuteHeadlessReport -Context $Context -UiHooks $UiHooks
            $Result.OutputPath = ($outPath + '')
            $Result.Success = $true
            try {
                $proc = Build-EnsureContextProcessingState -Context $Context
                $publishMethod = ($proc['PublishMethod'] + '').Trim()
                $publishWarning = ($proc['PublishWarning'] + '').Trim()
                if (-not $publishMethod) { $publishMethod = 'DirectWrite' }
            } catch {
                $publishMethod = 'DirectWrite'
                $publishWarning = ''
            }
        } else {
            $guiRes = Build-WriteReportCanonical -Context $Context -UiHooks $UiHooks
            if ($guiRes) {
                if ($guiRes.PSObject.Properties['Success']) { $Result.Success = [bool]$guiRes.Success }
                if ($guiRes.PSObject.Properties['OutputPath']) { $Result.OutputPath = ($guiRes.OutputPath + '') }
                if ($guiRes.PSObject.Properties['AuditPath']) { $Result.AuditPath = ($guiRes.AuditPath + '') }
                if ($guiRes.PSObject.Properties['Warnings']) {
                    foreach ($w in @($guiRes.Warnings)) { if ($w) { [void]$Result.Warnings.Add(($w + '')) } }
                }
                if ($guiRes.PSObject.Properties['Errors']) {
                    foreach ($e in @($guiRes.Errors)) { if ($e) { [void]$Result.Errors.Add(($e + '')) } }
                }
                $Result.Metrics['OutputOpenHandled'] = $true
                $publishMethod = 'DirectWriteGui'
            } else {
                [void]$Result.Errors.Add('Build-WriteReportCanonical returnerade inget resultatobjekt.')
            }
        }
    } catch {
        $exMsg = ($_.Exception.Message + '')
        [void]$Result.Errors.Add($exMsg)
        if ($exMsg -match '(?i)låst|locked') {
            $Result.ErrorCodeName = 'LockedFile'
        }
        Build-WriteDiagnosticWarn -Message 'Stage-WriteReport kastade exception' -Context 'Build.Stage.WriteReport' -Exception $_.Exception
    }

    if ($Result.Success) {
        if (-not $publishMethod) { $publishMethod = if ([bool]$Context.Headless) { 'DirectWrite' } else { 'DirectWriteGui' } }
        $Result.Metrics['PublishMethod'] = $publishMethod
        if ($publishWarning) {
            $Result.Metrics['PublishWarning'] = $publishWarning
            [void]$Result.Warnings.Add($publishWarning)
        }
        return (Build-NewStageResult -Ok:$true -Status 'ReportWritten' -Stage 'WriteReport' -Data (Build-NewStageData -Stage 'WriteReport' -Patch @{ ReportSuccess = $true; OutputPath = ($Result.OutputPath + ''); AuditPath = ($Result.AuditPath + ''); Executed = $true; ExecutionStatus = 'Executed'; PublishMethod = $publishMethod; PublishWarning = $publishWarning }))
    }
    return (Build-NewStageResult -Ok:$false -Reason 'WriteReportFailed' -Status 'Failed' -Stage 'WriteReport' -Data (Build-NewStageData -Stage 'WriteReport' -Patch @{ ReportSuccess = $false; OutputPath = ($Result.OutputPath + ''); AuditPath = ($Result.AuditPath + ''); Executed = $true; ExecutionStatus = 'Failed' }) -Errors @($Result.Errors))
}

function Build-GetOriginalPathFromContext {
    param(
        [Parameter(Mandatory=$true)]$Context,
        [Parameter(Mandatory=$true)][string]$Key,
        [string]$Fallback = ''
    )

    $fallbackVal = ($Fallback + '').Trim()
    try {
        $proc = Build-EnsureContextProcessingState -Context $Context
        if ($proc -and $proc['OriginalPaths']) {
            $orig = ($proc['OriginalPaths'][$Key] + '').Trim()
            if ($orig) { return $orig }
        }
    } catch {}
    return $fallbackVal
}

function Build-ApplyHeadlessSealSignatures {
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [Parameter(Mandatory=$true)][string]$SignText,
        [Parameter(Mandatory=$true)][bool]$Overwrite
    )

    if (-not (Test-Path -LiteralPath $Path)) {
        throw ("Seal Test-fil saknas: {0}" -f $Path)
    }

    $pkg = $null
    $written = 0
    try {
        $pkg = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($Path))
        foreach ($ws in $pkg.Workbook.Worksheets) {
            if (Test-IsSealTestSkipSheet -SheetName $ws.Name) { continue }

            $h3 = (Excel-GetCellText $ws 'H3' + '').Trim()
            if ($h3 -match '^[0-9]') {
                $existing = (Excel-GetCellText $ws 'B47' + '').Trim()
                if ((-not $Overwrite) -and (-not [string]::IsNullOrWhiteSpace($existing))) { continue }
                $ws.Cells['B47'].Style.Numberformat.Format = '@'
                $ws.Cells['B47'].Value = ($SignText + '')
                $written++
            } elseif ([string]::IsNullOrWhiteSpace($h3) -or $h3 -match '^(?i)(N\/?A|NA|Tomt( innehåll)?)$') {
                break
            }
        }

        $pkg.Save()
    } finally {
        try { if ($pkg) { $pkg.Dispose() } } catch {
            Build-WriteDiagnosticWarn -Message ("Kunde inte stänga Seal Test-paket efter signering: {0}" -f $Path) -Context 'Build.Stage.ApplySignatures' -Exception $_.Exception
        }
    }

    $verify = Verify-SealTestSignatures -Path $Path -ExpectedText ($SignText + '') -SignatureCell 'B47' -ActiveCheckCell 'H3' -ExpectedWritten $written
    if (-not $verify.OK) {
        $reason = if ($verify.Error) { $verify.Error } else { ($verify.Mismatches -join '; ') }
        throw ("Seal Test-signering verifiering misslyckades för {0}: {1}" -f (Split-Path $Path -Leaf), $reason)
    }

    return [pscustomobject]@{
        Written = [int]$written
    }
}

function Build-ApplyHeadlessWorksheetSignatures {
    param(
        [Parameter(Mandatory=$true)]$Context,
        [Parameter(Mandatory=$true)][bool]$HasResample
    )

    $modulesRoot = ($global:ModulesRoot + '').Trim()
    if (-not $modulesRoot) { $modulesRoot = Join-Path $script:BuildPipelineProjectRoot 'Modules' }

    $results = New-Object System.Collections.Generic.List[pscustomobject]
    $needsWorksheet = ([bool]$Context.DoWsSamm -or [bool]$Context.DoWsGransk)
    $worksheetPath = ''
    if ($needsWorksheet) {
        $worksheetPath = Build-GetOriginalPathFromContext -Context $Context -Key 'Worksheet' -Fallback ($Context.WorksheetPath + '')
        if (-not $worksheetPath -or -not (Test-Path -LiteralPath $worksheetPath)) {
            throw 'Worksheet-signering begärd men WorksheetPath saknas.'
        }
    }
    if ([bool]$Context.DoWsSamm) {
        $name = ($Context.SammName + '').Trim()
        $date = ($Context.SammDate + '').Trim()
        if (-not $name -or -not $date) { throw 'Sammanställning-signering kräver SammName och SammDate.' }
        $rS = Invoke-WorksheetSignature_OpenXml -Path $worksheetPath -FullName $name -SignDateYmd $date -Mode 'Sammanstallning' -HasResample:$HasResample -Overwrite ([bool]$Context.OverwriteSamm) -ModulesRoot $modulesRoot
        [void]$results.Add([pscustomobject]@{ Mode = 'Sammanstallning'; Result = $rS })
    }
    if ([bool]$Context.DoWsGransk) {
        $name = ($Context.GranskName + '').Trim()
        $date = ($Context.GranskDate + '').Trim()
        if (-not $name -or -not $date) { throw 'Granskning-signering kräver GranskName och GranskDate.' }
        $rG = Invoke-WorksheetSignature_OpenXml -Path $worksheetPath -FullName $name -SignDateYmd $date -Mode 'Granskning' -HasResample:$HasResample -Overwrite ([bool]$Context.OverwriteGransk) -ModulesRoot $modulesRoot
        [void]$results.Add([pscustomobject]@{ Mode = 'Granskning'; Result = $rG })
    }
    return @($results.ToArray())
}

function Stage-ApplySignatures {
    param(
        [Parameter(Mandatory=$true)]$Context,
        [Parameter(Mandatory=$true)]$Result,
        [hashtable]$UiHooks
    )

    [void](Build-InvokeUiHook -UiHooks $UiHooks -Name 'Progress' -Arguments @('ApplySignatures'))
    $requested = ([bool]$Context.DoSealTest -or [bool]$Context.DoWsSamm -or [bool]$Context.DoWsGransk)
    if (-not $requested) {
        return (Build-NewStageResult -Ok:$true -Status 'SignaturesNotRequested' -Stage 'ApplySignatures' -Data (Build-NewStageData -Stage 'ApplySignatures' -Patch @{
            SignaturesApplied = $false
            Executed = $false
            ExecutionStatus = 'NotRequested'
            StageNote = 'Ingen signering vald i context.'
        }))
    }

    if (-not [bool]$Context.Headless) {
        return (Build-NewStageResult -Ok:$true -Status 'SignaturesDelegated' -Stage 'ApplySignatures' -Data (Build-NewStageData -Stage 'ApplySignatures' -Patch @{
            SignaturesApplied = $false
            Executed = $false
            ExecutionStatus = 'Delegated'
            StageNote = 'Signering sker i GUI/canonical writer.'
        }))
    }

    if (-not [bool]$Context.HeadlessAllowSigning) {
        return (Build-NewStageResult -Ok:$true -Status 'SignaturesSkipped' -Stage 'ApplySignatures' -Data (Build-NewStageData -Stage 'ApplySignatures' -Patch @{
            SignaturesApplied = $false
            Executed = $false
            ExecutionStatus = 'SkippedHeadlessDisabled'
            StageNote = 'HeadlessAllowSigning=false'
        }))
    }

    try {
        $signTargets = @()
        $worksheetForSign = Build-GetOriginalPathFromContext -Context $Context -Key 'Worksheet' -Fallback ($Context.WorksheetPath + '')
        $sealNegForSign = Build-GetOriginalPathFromContext -Context $Context -Key 'SealNeg' -Fallback ($Context.SealNegPath + '')
        $sealPosForSign = Build-GetOriginalPathFromContext -Context $Context -Key 'SealPos' -Fallback ($Context.SealPosPath + '')
        if ([bool]$Context.DoWsSamm -or [bool]$Context.DoWsGransk) { if ($worksheetForSign) { $signTargets += $worksheetForSign } }
        if ([bool]$Context.DoSealTest) {
            if ($sealNegForSign) { $signTargets += $sealNegForSign }
            if ($sealPosForSign) { $signTargets += $sealPosForSign }
        }

        if (-not (Build-TestFilesUnlockedHeadless -Paths $signTargets)) {
            $lockedPath = Build-GetFirstLockedPath -Paths $signTargets
            $msg = if ($lockedPath) {
                "Headless signering blockerad: låst fil '$lockedPath'."
            } else {
                'Headless signering blockerad: minst en signeringsfil är låst.'
            }
            [void]$Result.Errors.Add($msg)
            $Result.ErrorCodeName = 'LockedFile'
            $Result.Metrics['LockedPath'] = ($lockedPath + '')
            return (Build-NewStageResult -Ok:$false -Reason 'SignatureFilesLocked' -Status 'Failed' -Stage 'ApplySignatures' -Data (Build-NewStageData -Stage 'ApplySignatures' -Patch @{
                SignaturesApplied = $false
                Executed = $false
                ExecutionStatus = 'BlockedLocked'
                StageNote = $msg
                LockedPath = ($lockedPath + '')
            }) -Errors @($msg))
        }

        $stageNotes = New-Object System.Collections.Generic.List[string]
        $applied = $false
        $hasResample = $false
        try {
            if ($Context.CsvSelection -and $Context.CsvSelection.PSObject.Properties['HasResample']) {
                $hasResample = [bool]$Context.CsvSelection.HasResample
            }
        } catch { $hasResample = $false }

        if ([bool]$Context.DoSealTest) {
            $sammName = ($Context.SammName + '').Trim()
            $sammDate = ($Context.SammDate + '').Trim()
            $sammSign = ($Context.SammSign + '').Trim()
            if (-not $sammName -or -not $sammDate -or -not $sammSign) {
                throw 'Seal Test-signering kräver SammName, SammDate och SammSign.'
            }
            $sealText = ("{0}, {1}, {2}" -f $sammName, $sammSign, $sammDate)

            if ($sealNegForSign) {
                $sealNegRes = Build-ApplyHeadlessSealSignatures -Path $sealNegForSign -SignText $sealText -Overwrite ([bool]$Context.OverwriteSamm)
                [void]$stageNotes.Add(("SealNEG written={0}" -f $sealNegRes.Written))
                if ($sealNegRes.Written -gt 0) { $applied = $true }
            }
            if ($sealPosForSign) {
                $sealPosRes = Build-ApplyHeadlessSealSignatures -Path $sealPosForSign -SignText $sealText -Overwrite ([bool]$Context.OverwriteSamm)
                [void]$stageNotes.Add(("SealPOS written={0}" -f $sealPosRes.Written))
                if ($sealPosRes.Written -gt 0) { $applied = $true }
            }
        }

        $wsModeResults = Build-ApplyHeadlessWorksheetSignatures -Context $Context -HasResample:$hasResample
        foreach ($m in @($wsModeResults)) {
            $mode = ($m.Mode + '')
            $wr = @($m.Result.Written)
            $sk = @($m.Result.Skipped)
            [void]$stageNotes.Add(("Worksheet {0}: written={1}, skipped={2}" -f $mode, $wr.Count, $sk.Count))
            if ($wr.Count -gt 0) { $applied = $true }
        }

        return (Build-NewStageResult -Ok:$true -Status 'SignaturesExecuted' -Stage 'ApplySignatures' -Data (Build-NewStageData -Stage 'ApplySignatures' -Patch @{
            SignaturesApplied = [bool]$applied
            Executed = $true
            ExecutionStatus = 'Executed'
            StageNote = (@($stageNotes) -join '; ')
        }))
    } catch {
        $msg = ("Headless signering misslyckades: {0}" -f $_.Exception.Message)
        [void]$Result.Errors.Add($msg)
        Build-WriteDiagnosticWarn -Message $msg -Context 'Build.Stage.ApplySignatures' -Exception $_.Exception
        return (Build-NewStageResult -Ok:$false -Reason 'SignaturesFailed' -Status 'Failed' -Stage 'ApplySignatures' -Data (Build-NewStageData -Stage 'ApplySignatures' -Patch @{
            SignaturesApplied = $false
            Executed = $true
            ExecutionStatus = 'Failed'
            StageNote = $msg
        }) -Errors @($msg))
    }
}

function Stage-Finalize {
    param(
        [Parameter(Mandatory=$true)]$Context,
        [Parameter(Mandatory=$true)]$Result,
        [hashtable]$UiHooks,
        [string]$OutcomeStatus = ''
    )

    if (-not $OutcomeStatus) {
        if ($Result.Success) { $OutcomeStatus = 'OK' }
        elseif ($Result.Errors.Count -gt 0) { $OutcomeStatus = 'Failed' }
        else { $OutcomeStatus = 'Blocked' }
    }

    $Result.Outcome = ($OutcomeStatus + '')
    if (($Result.ErrorCodeName + '') -eq 'LockedFile') {
        $Result.ErrorCode = 3
    } else {
        switch ($OutcomeStatus) {
            'OK'      { $Result.ErrorCode = 0 }
            'Blocked' { $Result.ErrorCode = 2 }
            default   { $Result.ErrorCode = 1 }
        }
    }

    try {
        $writtenAudit = Build-WriteAuditFile -Context $Context -Result $Result -Status $OutcomeStatus
        if ($writtenAudit) { $Result.AuditPath = ($writtenAudit + '') }
    } catch {
        $msg = ("Kunde inte skriva pipeline-audit i finalize: {0}" -f $_.Exception.Message)
        Build-WriteDiagnosticWarn -Message $msg -Context 'Build.Stage.Finalize' -Exception $_.Exception
        [void]$Result.Warnings.Add($msg)
    }

    $openHandled = $false
    try {
        if ($Result.Metrics -and $Result.Metrics.Contains('OutputOpenHandled')) {
            $openHandled = [bool]$Result.Metrics['OutputOpenHandled']
        }
    } catch { $openHandled = $false }

    if ($Result.Success -and $Context.OpenOutput -and (-not $openHandled) -and $Result.OutputPath -and (Test-Path -LiteralPath $Result.OutputPath)) {
        $opened = $false
        $openHook = Build-GetUiHookOrDefault -UiHooks $UiHooks -Name 'OpenFile' -Default { $null }
        if ($openHook -is [scriptblock]) {
            try {
                [void](Build-InvokeUiHook -UiHooks $UiHooks -Name 'OpenFile' -Arguments @($Result.OutputPath))
                $opened = $true
            } catch {
                $opened = $false
                Build-WriteDiagnosticWarn -Message 'UiHook OpenFile misslyckades i finalize' -Context 'Build.Stage.Finalize' -Exception $_.Exception
            }
        }
        if (-not $opened -and (-not [bool]$Context.Headless)) {
            try { Start-Process -FilePath $Result.OutputPath | Out-Null } catch {
                Build-WriteDiagnosticWarn -Message 'Start-Process misslyckades för output-fil i finalize' -Context 'Build.Stage.Finalize' -Exception $_.Exception
            }
        }
    }

    [void](Build-InvokeUiHook -UiHooks $UiHooks -Name 'Progress' -Arguments @('Finalize'))
    return $Result
}

function Invoke-BuildPipeline {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]$Context,
        [hashtable]$UiHooks
    )

    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    $res = Build-NewResult -Success:$false
    $script:BuildPipelineProjectRoot = Build-ResolveProjectRoot -Context $Context
    $stageTimes = [ordered]@{}
    $last = 0
    function _Mark([string]$name) {
        $ms = $sw.ElapsedMilliseconds
        $stageTimes[$name] = ($ms - $last)
        Set-Variable -Name last -Value $ms -Scope 1
    }

    $outcome = 'Failed'
    $continuePipeline = $true
    $stageState = [ordered]@{}
    try {
        try {
            $doCacheCleanup = $true
            $cleanupMaxAgeDays = 7
            $cleanupKeepLatest = 20
            try { $doCacheCleanup = [bool](Get-ConfigFlag -Name 'EnableCacheCleanup' -Default $true -ConfigOverride $global:Config) } catch {}
            try { $cleanupMaxAgeDays = [int](Get-ConfigValue -Name 'CacheCleanupMaxAgeDays' -Default 7 -ConfigOverride $global:Config) } catch { $cleanupMaxAgeDays = 7 }
            try { $cleanupKeepLatest = [int](Get-ConfigValue -Name 'CacheCleanupKeepLatest' -Default 20 -ConfigOverride $global:Config) } catch { $cleanupKeepLatest = 20 }

            if ($doCacheCleanup) {
                $cacheRoot = Build-GetCacheRoot -Context $Context
                $cleanupRes = Build-InvokeCacheCleanup -CacheRoot $cacheRoot -MaxAgeDays $cleanupMaxAgeDays -KeepLatest $cleanupKeepLatest
                $res.Metrics['CacheCleanup'] = $cleanupRes
            } else {
                $res.Metrics['CacheCleanup'] = [pscustomobject]@{ Ok = $true; Note = 'Disabled by config.'; DeletedCount = 0; FailedCount = 0; TotalSeen = 0 }
            }
        } catch {
            Build-WriteDiagnosticWarn -Message 'Cache cleanup preflight misslyckades (fortsätter fail-open)' -Context 'Build.CacheCleanup' -Exception $_.Exception
            $res.Metrics['CacheCleanup'] = [pscustomobject]@{ Ok = $false; Note = ("Preflight exception: {0}" -f $_.Exception.Message); DeletedCount = 0; FailedCount = 0; TotalSeen = 0 }
        }

        $s = Stage-ResolveInputs -Context $Context -Result $res -UiHooks $UiHooks
        _Mark 'ResolveInputs'
        if ($s -and $s.PSObject.Properties['Warnings']) {
            foreach ($w in @($s.Warnings)) { if ($w) { [void]$res.Warnings.Add(($w + '')) } }
        }
        if ($s -and $s.PSObject.Properties['Errors']) {
            foreach ($e in @($s.Errors)) { if ($e) { [void]$res.Errors.Add(($e + '')) } }
        }
        if ($s -and $s.PSObject.Properties['Data'] -and $s.Data) {
            $stageKey = if ($s.Stage) { ($s.Stage + '') } else { 'ResolveInputs' }
            $stageState[$stageKey] = $s.Data
        }
        if (-not $s.Ok) {
            $outcome = 'Blocked'
            $continuePipeline = $false
        }

        if ($continuePipeline) {
            $s = Stage-Validate -Context $Context -Result $res -UiHooks $UiHooks
            _Mark 'Validate'
            if ($s -and $s.PSObject.Properties['Warnings']) {
                foreach ($w in @($s.Warnings)) { if ($w) { [void]$res.Warnings.Add(($w + '')) } }
            }
            if ($s -and $s.PSObject.Properties['Errors']) {
                foreach ($e in @($s.Errors)) { if ($e) { [void]$res.Errors.Add(($e + '')) } }
            }
            if ($s -and $s.PSObject.Properties['Data'] -and $s.Data) {
                $stageKey = if ($s.Stage) { ($s.Stage + '') } else { 'Validate' }
                $stageState[$stageKey] = $s.Data
            }
            if (-not $s.Ok) {
                $outcome = 'Blocked'
                $continuePipeline = $false
            }
        }

        if ($continuePipeline) {
            $s = Stage-CacheInputs -Context $Context -Result $res -UiHooks $UiHooks
            _Mark 'CacheInputs'
            if ($s -and $s.PSObject.Properties['Warnings']) {
                foreach ($w in @($s.Warnings)) { if ($w) { [void]$res.Warnings.Add(($w + '')) } }
            }
            if ($s -and $s.PSObject.Properties['Errors']) {
                foreach ($e in @($s.Errors)) { if ($e) { [void]$res.Errors.Add(($e + '')) } }
            }
            if ($s -and $s.PSObject.Properties['Data'] -and $s.Data) {
                $stageKey = if ($s.Stage) { ($s.Stage + '') } else { 'CacheInputs' }
                $stageState[$stageKey] = $s.Data
            }
            if (-not $s.Ok) {
                $outcome = if (($s.Status + '') -eq 'Blocked') { 'Blocked' } else { 'Failed' }
                $continuePipeline = $false
            }
        }

        if ($continuePipeline) {
            $s = Stage-LoadData -Context $Context -Result $res -UiHooks $UiHooks
            _Mark 'LoadData'
            if ($s -and $s.PSObject.Properties['Warnings']) {
                foreach ($w in @($s.Warnings)) { if ($w) { [void]$res.Warnings.Add(($w + '')) } }
            }
            if ($s -and $s.PSObject.Properties['Errors']) {
                foreach ($e in @($s.Errors)) { if ($e) { [void]$res.Errors.Add(($e + '')) } }
            }
            if ($s -and $s.PSObject.Properties['Data'] -and $s.Data) {
                $stageKey = if ($s.Stage) { ($s.Stage + '') } else { 'LoadData' }
                $stageState[$stageKey] = $s.Data
            }
            if (-not $s.Ok) {
                $outcome = 'Failed'
                $continuePipeline = $false
            }
        }

        if ($continuePipeline) {
            $s = Stage-RunRules -Context $Context -Result $res -UiHooks $UiHooks
            _Mark 'RunRules'
            if ($s -and $s.PSObject.Properties['Warnings']) {
                foreach ($w in @($s.Warnings)) { if ($w) { [void]$res.Warnings.Add(($w + '')) } }
            }
            if ($s -and $s.PSObject.Properties['Errors']) {
                foreach ($e in @($s.Errors)) { if ($e) { [void]$res.Errors.Add(($e + '')) } }
            }
            if ($s -and $s.PSObject.Properties['Data'] -and $s.Data) {
                $stageKey = if ($s.Stage) { ($s.Stage + '') } else { 'RunRules' }
                $stageState[$stageKey] = $s.Data
            }
            if (-not $s.Ok) {
                $outcome = 'Failed'
                $continuePipeline = $false
            }
        }

        if ($continuePipeline) {
            $s = Stage-WriteReport -Context $Context -Result $res -UiHooks $UiHooks
            _Mark 'WriteReport'
            if ($s -and $s.PSObject.Properties['Warnings']) {
                foreach ($w in @($s.Warnings)) { if ($w) { [void]$res.Warnings.Add(($w + '')) } }
            }
            if ($s -and $s.PSObject.Properties['Errors']) {
                foreach ($e in @($s.Errors)) { if ($e) { [void]$res.Errors.Add(($e + '')) } }
            }
            if ($s -and $s.PSObject.Properties['Data'] -and $s.Data) {
                $stageKey = if ($s.Stage) { ($s.Stage + '') } else { 'WriteReport' }
                $stageState[$stageKey] = $s.Data
            }
            if (-not $s.Ok) {
                $outcome = 'Failed'
                $continuePipeline = $false
            }
        }

        if ($continuePipeline) {
            $s = Stage-ApplySignatures -Context $Context -Result $res -UiHooks $UiHooks
            _Mark 'ApplySignatures'
            if ($s -and $s.PSObject.Properties['Warnings']) {
                foreach ($w in @($s.Warnings)) { if ($w) { [void]$res.Warnings.Add(($w + '')) } }
            }
            if ($s -and $s.PSObject.Properties['Errors']) {
                foreach ($e in @($s.Errors)) { if ($e) { [void]$res.Errors.Add(($e + '')) } }
            }
            if ($s -and $s.PSObject.Properties['Data'] -and $s.Data) {
                $stageKey = if ($s.Stage) { ($s.Stage + '') } else { 'ApplySignatures' }
                $stageState[$stageKey] = $s.Data
            }
            if (-not $s.Ok) {
                $outcome = 'Failed'
                $continuePipeline = $false
            }
        }

        if ($continuePipeline -and $res.Success) {
            $outcome = 'OK'
        } elseif ($continuePipeline -and (-not $res.Success) -and $res.Errors.Count -gt 0) {
            $outcome = 'Failed'
        } elseif ($continuePipeline) {
            $outcome = 'Blocked'
        }
        return $res
    } finally {
        $sw.Stop()
        if ($stageState.Count -gt 0) {
            $res.Metrics['StageState'] = $stageState
        }
        $res.Metrics['Stages'] = $stageTimes
        $res.Metrics['StageTimings'] = $stageTimes
        $res.Metrics['TotalMs'] = $sw.ElapsedMilliseconds
        Stage-Finalize -Context $Context -Result $res -UiHooks $UiHooks -OutcomeStatus $outcome | Out-Null
    }
}

function Build-WriteReportCanonical {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$false)]$Context,
        [Parameter(Mandatory=$false)][hashtable]$UiHooks
    )

    $res = Build-NewResult -Success:$false
    $beforeReport = ''
    if (Test-Path variable:global:LastReportPath) {
        try { $beforeReport = ($global:LastReportPath + '') } catch { $beforeReport = '' }
    }
    $beforeReportTs = $null
    try {
        if ($beforeReport -and (Test-Path -LiteralPath $beforeReport)) {
            $beforeReportTs = (Get-Item -LiteralPath $beforeReport).LastWriteTimeUtc
        }
    } catch {
        Build-WriteDiagnosticWarn -Message 'Kunde inte läsa beforeReport timestamp i canonical writer' -Context 'Build.Canonical.Pre' -Exception $_.Exception
    }

    $auditDir = Join-Path $script:BuildPipelineProjectRoot 'audit'
    $beforeAudit = $null
    try {
        if (Test-Path -LiteralPath $auditDir) {
            $beforeAudit = @(
                Get-ChildItem -LiteralPath $auditDir -Filter '*_audit_*.csv' -File -ErrorAction SilentlyContinue |
                Sort-Object LastWriteTimeUtc -Descending |
                Select-Object -First 1 -ExpandProperty FullName
            )[0]
        }
    } catch {
        Build-WriteDiagnosticWarn -Message 'Kunde inte läsa beforeAudit i canonical writer' -Context 'Build.Canonical.Pre' -Exception $_.Exception
    }

    & {
    if (-not (Assert-StartupReady)) { return }

    # FAS4A: bygg ett explicit RunContext-objekt (används av headless pipeline och framtida tunn Main-orchestrering).
    try {
        $useLocalCache = Get-ConfigFlag -Name 'UseLocalCache' -Default $false -ConfigOverride $Config
        $headlessAllowSigning = Get-ConfigFlag -Name 'HeadlessAllowSigning' -Default $false -ConfigOverride $Config
        $script:LastRunContext = New-RunContext `
            -Lsp ($txtLSP.Text + '') `
            -CsvPaths @(Get-AllCheckedFilePaths $clbCsv) `
            -WorksheetPath (Get-CheckedFilePath $clbLsp) `
            -SealNegPath (Get-CheckedFilePath $clbNeg) `
            -SealPosPath (Get-CheckedFilePath $clbPos) `
            -TemplatePath (Join-Path $script:BuildPipelineProjectRoot 'output_template-v4.xlsx') `
            -OutputDir $env:TEMP `
            -AuditDir (Join-Path $script:BuildPipelineProjectRoot 'audit') `
            -DoSealTest ([bool]$chkSealTest.Checked) `
            -DoWsSamm ([bool]$chkWsSamm.Checked) `
            -DoWsGransk ([bool]$chkWsGransk.Checked) `
            -OverwriteSamm ([bool]$chkSignOverwrite.Checked) `
            -OverwriteGransk ([bool]$chkGranskOverwrite.Checked) `
            -SammName ($txtSammName.Text + '') `
            -SammDate ($txtSammDate.Text + '') `
            -SammSign ($txtSealTestSign.Text + '') `
            -GranskName ($txtGranskName.Text + '') `
            -GranskDate ($txtGranskDate.Text + '') `
            -Headless:$false `
            -UseLocalCache:$useLocalCache `
            -HeadlessAllowSigning:$headlessAllowSigning `
            -OpenOutput:$true
    } catch {
        Build-WriteDiagnosticWarn -Message 'Kunde inte skapa LastRunContext i canonical writer' -Context 'Build.Canonical.Context' -Exception $_.Exception
    }

    # Hjälpfunktion: ta bort TEMP-prefix (CSV_Primary__, SealNEG__, etc.) från filnamn för ren visning
    function Get-CleanLeaf([string]$Path) {
        if (-not $Path) { return '' }
        $leaf = Split-Path $Path -Leaf
        $leaf -replace '^(CSV_Primary|CSV_Resample|SealNEG|SealPOS|Worksheet)__', ''
    }

    if ($script:ScanInProgress) { Gui-Log "⚠️ Sökning pågår – vänta innan du skapar rapport." 'Warn'; return }
    if ($script:BuildInProgress) { Gui-Log "⚠️ Rapportgenerering kör redan – vänta." 'Warn'; return }
    $script:BuildInProgress = $true

 # --- Tidsmätning (metrics) ---
 $buildTimer = [System.Diagnostics.Stopwatch]::StartNew()
 $phaseTimings = [ordered]@{}
 $lastPhaseMs = 0
 function Mark-Phase([string]$Name) {
 $now = $buildTimer.ElapsedMilliseconds
 $phaseTimings[$Name] = ($now - $lastPhaseMs)
 Set-Variable -Name lastPhaseMs -Value $now -Scope 1
 }

    Gui-Log -Text '🔃 Skapar rapport…' -Severity Info -Category USER -Immediate
    Set-UiBusy -Busy $true -Message 'Skapar rapport…'
    Set-UiStep 5 'Initierar…'

    $pkgNeg = $null
    $pkgPos = $null
    $pkgOut = $null
    $stageDir = $null

    # Original paths (används för transparens + ev. signering)
    $selNegOrig = $null
    $selPosOrig = $null
    $selCsvOrig = $null
    $selCsvResOrig = $null
    $selLspOrig = $null

    # Regelmotor-cache (per körning)
    $script:RuleEngineShadow     = $null
    $script:RuleEngineShadowRes  = $null
    $script:RuleEngineCsvObjs    = $null
    $script:RuleEngineCsvObjsRes = $null
    $script:RuleBankCache        = $null

    try {
        if (-not (Load-EPPlus)) { Gui-Log "❌ EPPlus kunde inte laddas – avbryter." 'Error'; return }

        Set-UiStep 10 '🔃 Läser in Seal Test-filer…'
        Mark-Phase 'Init'

        $allCsvPaths = @(Get-AllCheckedFilePaths $clbCsv)
        $csvSelection = Csv-ResolveSelection -AllCsvPaths $allCsvPaths
        if (-not $csvSelection.Ok) {
            return
        }
        $selCsv = $csvSelection.PrimaryPath
        $selCsvRes = $csvSelection.ResamplePath
        $hasResampleForWorksheetSign = [bool]$csvSelection.HasResample

        $selNeg = Get-CheckedFilePath $clbNeg
        $selPos = Get-CheckedFilePath $clbPos

        if (-not $selNeg -or -not $selPos) { Gui-Log "❌ Du måste välja en Seal NEG och en Seal POS." 'Error'; return }

        $lspRaw    = ($txtLSP.Text + '').Trim()
        $lspDigits = ($lspRaw -replace '\D','')
        $hasLsp    = -not [string]::IsNullOrWhiteSpace($lspDigits)

        if ($hasLsp) {
            $lsp = $lspDigits
        } else {
            $lsp = 'MANUELL'
            Gui-Log "ℹ️ Ingen LSP angiven – kör manuellt läge (filval via Bläddra). Rapporten märks som '$lsp' och SharePoint/LSP-koppling hoppas över." 'Warn'
        }

        $lspForLinks = if ($hasLsp) { $lsp } else { '' }

        # ---- TEMP snapshot av valda filer (för att inte stanna om någon har filen öppen) ----
        $enableStaging = Get-ConfigFlag -Name 'EnableLocalStaging' -Default $true -ConfigOverride $Config
        if ($enableStaging) {
            try {

                # Standard: C:\IPTCompile_TEMP\... (kan styras via Config: TempSnapshotRoot)
                $root = Get-ConfigValue -Name 'TempSnapshotRoot' -Default 'C:\IPTCompile_TEMP' -ConfigOverride $Config
                if (-not $root) { $root = 'C:\IPTCompile_TEMP' }
                if (-not (Test-Path -LiteralPath $root)) { New-Item -ItemType Directory -Path $root -Force | Out-Null }
                $stageDir = Join-Path $root ("IPTCompile_" + $lsp + "_" + (Get-Date -Format 'yyyyMMdd_HHmmss') + "_" + ([guid]::NewGuid().ToString('N')))
                New-Item -ItemType Directory -Path $stageDir -Force | Out-Null
                # Spara original paths
                $selNegOrig = $selNeg
                $selPosOrig = $selPos
                if ($selCsv) { $selCsvOrig = $selCsv }
                if ($selCsvRes) { $selCsvResOrig = $selCsvRes }

                # Snapshot paths används för all läsning/rapportbygge
                $selNeg = Core-StageInputFileSnapshot -Path $selNeg -StageDir $stageDir -Prefix 'SealNEG'
                $selPos = Core-StageInputFileSnapshot -Path $selPos -StageDir $stageDir -Prefix 'SealPOS'
                if ($selCsv) { $selCsv = Core-StageInputFileSnapshot -Path $selCsv -StageDir $stageDir -Prefix 'CSV_Primary' }
                if ($selCsvRes) { $selCsvRes = Core-StageInputFileSnapshot -Path $selCsvRes -StageDir $stageDir -Prefix 'CSV_Resample' }

            } catch {
                Gui-Log ("⚠️ Kunde inte skapa arbetskopia: " + $_.Exception.Message) 'Warn'
            }
        }

        # Logg: visa originalfilnamn (utan TEMP-prefix)
        $negLeaf = Get-CleanLeaf $selNeg
        $posLeaf = Get-CleanLeaf $selPos
        Gui-Log "📄 Neg: $negLeaf" 'Info'
        Gui-Log "📄 Pos: $posLeaf" 'Info'
        if ($selCsv) {
            $csvLeaf = Get-CleanLeaf $selCsv
            Gui-Log "📄 CSV: $csvLeaf" 'Info'
        } else { Gui-Log "ℹ️ Ingen CSV vald." 'Info' }
        if ($selCsvRes) {
            $csvResLeaf = Get-CleanLeaf $selCsvRes
            Gui-Log "📄 CSV (Resample): $csvResLeaf" 'Info'
        }

        # =====================================================
        # === CSV-RADCACHE (läs varje fil max en gång)      ===
        # =====================================================
        Mark-Phase 'SealTestLoad'
        $script:CsvLinesPrimary  = $null
        $script:CsvLinesResample = $null
        if ($selCsv -and (Test-Path -LiteralPath $selCsv)) {
            try { $script:CsvLinesPrimary = Get-Content -LiteralPath $selCsv } catch { Gui-Log ("⚠️ Kunde inte läsa CSV: " + $_.Exception.Message) 'Warn' }
        }
        if ($selCsvRes -and (Test-Path -LiteralPath $selCsvRes)) {
            try { $script:CsvLinesResample = Get-Content -LiteralPath $selCsvRes } catch { Gui-Log ("⚠️ Kunde inte läsa Resample CSV: " + $_.Exception.Message) 'Warn' }
        }

        $negWritable = $true; $posWritable = $true
        if ($chkSealTest.Checked) {
            # GDP A5: Fil-lås med Retry-dialog för originalfiler (signering)
            $negLockPath = if ($selNegOrig) { $selNegOrig } else { $selNeg }
            $posLockPath = if ($selPosOrig) { $selPosOrig } else { $selPos }
            $signPaths = @($negLockPath, $posLockPath) | Where-Object { $_ -and (Test-Path -LiteralPath $_) }
            if ($signPaths.Count -gt 0) {
                if (-not (Ensure-FilesClosedOrCancel -Paths $signPaths -Hint 'Stäng Seal Test-filen i Excel och klicka Försök igen. Signering kan inte genomföras mot en låst fil.')) {
                    Gui-Log "🛑 Seal Test-signatur avbruten: fil(er) låsta." 'Error'
                    return
                }
            }
        }

        # UX: Om någon vald fil är öppen/låst – be användaren stänga den och Försök igen.
        $pathsToCheck = @($selNeg, $selPos)
        if (-not (Ensure-FilesClosedOrCancel -Paths $pathsToCheck)) {
            Gui-Log "🛑 Avbrutet: en eller flera filer var öppna/låsta." 'Warn'
            return
        }

        # ----------------------------
        # Öppna paket
        # ----------------------------
        try {
            $pkgNeg = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($selNeg))
            $pkgPos = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($selPos))
        } catch {
            Gui-Log "❌ Kunde inte öppna NEG/POS: $($_.Exception.Message)" 'Error'
            return
        }

        $templatePath = Join-Path $script:BuildPipelineProjectRoot "output_template-v4.xlsx"
        if (-not (Test-Path -LiteralPath $templatePath)) { Gui-Log "❌ Mallfilen 'output_template-v4.xlsx' saknas!" 'Error'; return }
        # UX: Mallfilen kan vara låst om någon har den öppen (t.ex. förhandsvisning/Excel).
        if (-not (Ensure-FilesClosedOrCancel -Paths @($templatePath))) {
            Gui-Log "🛑 Avbrutet: mallfilen är öppen/låst." 'Warn'
            return
        }
        try {
            $pkgOut = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($templatePath))
        } catch {
            Gui-Log "❌ Kunde inte läsa mall: $($_.Exception.Message)" 'Error'
            return
        }

        # ============================
        # === SIGNATUR I NEG/POS  ====
        # ============================

        $doSealTest = $chkSealTest.Checked
        $doWsSamm   = $chkWsSamm.Checked
        $doWsGransk = $chkWsGransk.Checked
        $doOverwrite      = $chkSignOverwrite.Checked
        $doOverwriteGransk = $chkGranskOverwrite.Checked
        if (($doSealTest -or $doWsSamm) -and (-not $doOverwrite)) {
            Gui-Log "❌ Overwrite måste kryssas i för att skapa rapport med signering (Sammanställning)." 'Error'
            return
        }
        if ($doWsGransk -and (-not $doOverwriteGransk)) {
            Gui-Log "❌ Overwrite måste kryssas i för att skapa rapport med signering (Granskning)." 'Error'
            return
        }

        # --- Sammanställnings-fält (delat av Seal Test + Worksheet Sammanställning) ---
        $sammName = ($txtSammName.Text + '').Trim()
        $sammDate = ($txtSammDate.Text + '').Trim()
        $sammSign = ($txtSealTestSign.Text + '').Trim()

        if ($doSealTest) {
            if (-not $sammName) { Gui-Log "❌ Sammanställning: Full Name saknas." 'Error'; return }
            if (-not $sammSign) { Gui-Log "❌ Sammanställning: SIGN saknas." 'Error'; return }
            if (-not $sammDate) { Gui-Log "❌ Sammanställning: Date saknas." 'Error'; return }
        }
        if ($doWsSamm) {
            if (-not $sammName) { Gui-Log "❌ Sammanställning: Full Name saknas." 'Error'; return }
            if (-not $sammDate) { Gui-Log "❌ Sammanställning: Date saknas." 'Error'; return }
        }
        if ($doWsGransk) {
            $granskName = ($txtGranskName.Text + '').Trim()
            $granskDate = ($txtGranskDate.Text + '').Trim()
            if (-not $granskName) { Gui-Log "❌ Granskning: Full Name saknas." 'Error'; return }
            if (-not $granskDate) { Gui-Log "❌ Granskning: Date saknas." 'Error'; return }
        }

        # Seal Test B47 = "Full name, SIGN, Date"
        $signToWrite = ''
        if ($doSealTest) {
            $signToWrite = "$sammName, $sammSign, $sammDate"
            if (-not (Confirm-SignatureInput -Text $signToWrite)) { Gui-Log "🛑 Seal Test-signatur ej bekräftad. Avbryter."; return }

            # Signera ORIGINAL om möjligt (snapshot används endast för läsning)
            $negPathForSign = if ($selNegOrig) { $selNegOrig } else { $selNeg }
            $posPathForSign = if ($selPosOrig) { $selPosOrig } else { $selPos }
            $pkgNegSign = $null
            $pkgPosSign = $null
            try {
                if ($negWritable) { $pkgNegSign = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($negPathForSign)) }
                if ($posWritable) { $pkgPosSign = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($posPathForSign)) }
            } catch {
                Gui-Log ("⚠️ Kunde inte öppna filen för signering: " + $_.Exception.Message) 'Warn'
            }

            $negWritten = 0; $posWritten = 0; $negSkipped = 0; $posSkipped = 0

            # Hjälpfunktion: skriver signatur i alla aktiva datablad
            function _SignSealTestSheets([object]$pkg, [string]$sigText, [string]$sigCell, [bool]$overwrite) {
                $written = 0; $skipped = 0
                if (-not $pkg) { return @{ Written = 0; Skipped = 0 } }
                foreach ($ws in $pkg.Workbook.Worksheets) {
                    if (Test-IsSealTestSkipSheet -SheetName $ws.Name) { continue }
                    $h3 = Excel-GetCellText $ws $Layout.SealActiveCheckCell
                    if ($h3 -match '^[0-9]') {
                        $existing = Excel-GetCellText $ws $sigCell
                        if ($existing -and -not $overwrite) { $skipped++; continue }
                        $ws.Cells[$sigCell].Style.Numberformat.Format = '@'
                        $ws.Cells[$sigCell].Value = $sigText
                        $written++
                    }
                    elseif ([string]::IsNullOrWhiteSpace($h3) -or $h3 -match '^(?i)(N\/\?A|NA|Tomt( innehåll)?)$') {
                        break
                    }
                }
                return @{ Written = $written; Skipped = $skipped }
            }

            $resNeg = _SignSealTestSheets $pkgNegSign $signToWrite $Layout.SignatureCell $doOverwrite
            $resPos = _SignSealTestSheets $pkgPosSign $signToWrite $Layout.SignatureCell $doOverwrite
            $negWritten = $resNeg.Written; $negSkipped = $resNeg.Skipped
            $posWritten = $resPos.Written; $posSkipped = $resPos.Skipped

            # GDP A1: Ingen silent fail — Save-fel stoppar hela flödet
            if ($negWritten -eq 0 -and $negSkipped -eq 0 -and $posWritten -eq 0 -and $posSkipped -eq 0) {
                Gui-Log "ℹ️ Inga databladsflikar efter flik 1 att sätta signatur i (ingen åtgärd)."
            } else {
                try {
                    if ($negWritten -gt 0 -and $pkgNegSign) { $pkgNegSign.Save() }
                    if ($posWritten -gt 0 -and $pkgPosSign) { $pkgPosSign.Save() }
                } catch {
                    Gui-Log "❌ SIGNERINGSFEL: Kunde inte spara Seal Test: $($_.Exception.Message)" 'Error'
                    try { Save-ForensicSnapshot -SourcePath $(if($negPathForSign){$negPathForSign}else{$posPathForSign}) -Reason "Save() misslyckades: $($_.Exception.Message)" -AuditDir (Join-Path $script:BuildPipelineProjectRoot 'audit') -Details @{ SignText=$signToWrite; NEG_Written=$negWritten; POS_Written=$posWritten } } catch {}
                    try { if ($pkgNegSign) { $pkgNegSign.Dispose() } } catch {}
                    try { if ($pkgPosSign) { $pkgPosSign.Dispose() } } catch {}
                    return
                }
                Gui-Log "🖊️ Signatur satt: NEG $negWritten blad (överhoppade $negSkipped), POS $posWritten blad (överhoppade $posSkipped)."
            }
            try { if ($pkgNegSign) { $pkgNegSign.Dispose() } } catch {}
            try { if ($pkgPosSign) { $pkgPosSign.Dispose() } } catch {}

            # GDP A2: Write → Save → Read-back verifiering
            $sealVerifyFailed = $false
            foreach ($vEntry in @(
                @{ Label='NEG'; Path=$negPathForSign; Written=$negWritten },
                @{ Label='POS'; Path=$posPathForSign; Written=$posWritten }
            )) {
                if ($vEntry.Written -gt 0 -and $vEntry.Path -and (Test-Path -LiteralPath $vEntry.Path)) {
                    $vr = Verify-SealTestSignatures -Path $vEntry.Path -ExpectedText $signToWrite -SignatureCell $Layout.SignatureCell -ActiveCheckCell $Layout.SealActiveCheckCell -ExpectedWritten $vEntry.Written
                    if ($vr.OK) {
                        Gui-Log "✅ Seal Test $($vEntry.Label) verifierad: $($vr.SheetsVerified)/$($vr.SheetsChecked) blad OK." 'Info'
                    } else {
                        $sealVerifyFailed = $true
                        $reason = if ($vr.Error) { $vr.Error } else { ($vr.Mismatches -join '; ') }
                        Gui-Log "❌ VERIFIERINGSFEL Seal Test $($vEntry.Label): $reason" 'Error'
                        # GDP A4: Forensisk snapshot
                        try { Save-ForensicSnapshot -SourcePath $vEntry.Path -Reason "Read-back mismatch: $reason" -AuditDir (Join-Path $script:BuildPipelineProjectRoot 'audit') -Details @{ SignText=$signToWrite; Expected=$vEntry.Written; Verified=$vr.SheetsVerified; Mismatches=($vr.Mismatches -join '|') } } catch {}
                    }
                }
            }
            if ($sealVerifyFailed) {
                Gui-Log "🛑 Seal Test-signatur ej verifierad. Rapport stoppas." 'Error'
                return
            }
        }

        # ==========================================
        # === SIGNATUR I WORKSHEET              ====
        # ==========================================

        if ($doWsSamm -or $doWsGransk) {
            $wsSignPath = $null
            try { $wsSignPath = Get-CheckedFilePath $clbLsp } catch {}
            if (-not $wsSignPath -or -not (Test-Path -LiteralPath $wsSignPath)) {
                Gui-Log "⚠️ Ingen Worksheet vald – hoppar över Worksheet-signatur." 'Warn'
            } else {
                # Bekräftelse
                $hasResample = [bool]$hasResampleForWorksheetSign
                $wsPlan = OpenXml-GetWorksheetSignDialogTargets `
                    -WorksheetPath $wsSignPath `
                    -DoWsSamm ([bool]$doWsSamm) `
                    -DoWsGransk ([bool]$doWsGransk) `
                    -HasResample $hasResample `
                    -ModulesRoot $modulesRoot
                $wsConfirmed = Confirm-WorksheetSignInput -FullName $(if ($doWsSamm) { $sammName } else { $granskName }) -SignDate $(if ($doWsSamm) { $sammDate } else { $granskDate }) -Targets @($wsPlan.Targets)
                if (-not $wsConfirmed) {
                    Gui-Log "🛑 Worksheet-signatur ej bekräftad." 'Info'
                } elseif (-not (Ensure-FilesClosedOrCancel -Paths @($wsSignPath) -Hint 'Stäng Worksheet-filen i Excel och klicka Försök igen. Signering kan inte genomföras mot en låst fil.')) {
                    # GDP A5: Fil-lås med Retry-dialog
                    Gui-Log "🛑 Worksheet-signatur avbruten: filen är låst." 'Error'
                    return
                } else {
                    try {
                        $hasResample = [bool]$hasResampleForWorksheetSign

                        # Konsoliderad loop: kör varje signerings-mode
                        $wsModes = @()
                        if ($doWsSamm)   { $wsModes += @{ Mode='Sammanstallning'; Label='Sammanställning'; Name=$sammName; Date=$sammDate; Overwrite=$doOverwrite } }
                        if ($doWsGransk) { $wsModes += @{ Mode='Granskning';      Label='Granskning';      Name=$granskName; Date=$granskDate; Overwrite=$doOverwriteGransk } }

                        $wsExec = OpenXml-InvokeWorksheetSigningModes `
                            -WorksheetPath $wsSignPath `
                            -Modes $wsModes `
                            -HasResample $hasResample `
                            -ModulesRoot $modulesRoot

                        foreach ($mRes in @($wsExec.ModeResults)) {
                            if ($mRes.Written.Count -gt 0) {
                                Gui-Log ("🖊️ WS $($mRes.Label): " + ($mRes.Written -join ', ')) 'Info'
                            }
                            if ($mRes.Skipped.Count -gt 0) {
                                Gui-Log ("WS $($mRes.Label) – överhoppade: " + ($mRes.Skipped -join ', ')) -Severity 'Info' -Category 'DEBUG'
                            }
                        }

                        # GDP A2: Write → Save → Read-back verifiering
                        $wsAllWrittenCells = @($wsExec.AllWrittenCells)
                        if ($wsAllWrittenCells.Count -gt 0) {
                            $wsVerify = Verify-WorksheetSignatures -Path $wsSignPath -WrittenCells $wsAllWrittenCells
                            if ($wsVerify.OK) {
                                Gui-Log "✅ Worksheet-signatur verifierad: $($wsVerify.CellsVerified)/$($wsVerify.CellsChecked) celler OK. $(Split-Path $wsSignPath -Leaf)" 'Info'
                            } else {
                                $reason = if ($wsVerify.Error) { $wsVerify.Error } else { ($wsVerify.Mismatches -join '; ') }
                                Gui-Log "❌ VERIFIERINGSFEL Worksheet: $reason" 'Error'
                                # GDP A4: Forensisk snapshot
                                try { Save-ForensicSnapshot -SourcePath $wsSignPath -Reason "WS read-back mismatch: $reason" -AuditDir (Join-Path $script:BuildPipelineProjectRoot 'audit') -Details @{ Checked=$wsVerify.CellsChecked; Verified=$wsVerify.CellsVerified; Mismatches=($wsVerify.Mismatches -join '|') } } catch {}
                                Gui-Log "🛑 Worksheet-signatur ej verifierad. Rapport stoppas." 'Error'
                                return
                            }
                        } else {
                            Gui-Log "✅ Worksheet-signatur sparad (inga nya celler skrivna — redan ifyllda): $(Split-Path $wsSignPath -Leaf)" 'Info'
                        }
                    } catch {
                        # GDP A1: Ingen silent fail — Exception stoppar flödet
                        Gui-Log ("❌ SIGNERINGSFEL Worksheet: " + $_.Exception.Message) 'Error'
                        try { Save-ForensicSnapshot -SourcePath $wsSignPath -Reason "Exception: $($_.Exception.Message)" -AuditDir (Join-Path $script:BuildPipelineProjectRoot 'audit') } catch {}
                        return
                    }
                }
            }
        }

        Mark-Phase 'Signering'

        #region Build: CSV-inläsning och RuleEngine
        # ============================
        # === CSV (Info/Control)  ====
        # ============================

        $csvRows = @()
        $runAssay = $null

        if ($selCsv) {
            try {
                $csvInfo = Get-Item -LiteralPath $selCsv -ErrorAction Stop
                $thresholdMb = 25
                try {
                    if ($Config -and ($Config -is [System.Collections.IDictionary]) -and $Config.Contains('CsvStreamingThresholdMB')) {
                        $thresholdMb = [int]$Config['CsvStreamingThresholdMB']
                    }
                } catch {}

                $useStreaming = ($csvInfo.Length -ge ($thresholdMb * 1MB))
                if ($useStreaming) {
                    Gui-Log ("⏳ CSV är stor ({0:N1} MB) – använder streaming-import…" -f ($csvInfo.Length / 1MB)) 'Info'
                    Set-UiStep 35 "Läser CSV (streaming)…"
                    $list = New-Object System.Collections.Generic.List[object]
                    Csv-ImportRowsStreaming -Path $selCsv -StartRow 10 -ProcessRow {
                        param($Fields,$RowIndex)
                        [void]$list.Add($Fields)
                        if (($RowIndex % 2000) -eq 0) { Invoke-UiPump }
                    }
                    $csvRows = @($list.ToArray())
                } else {
                    Set-UiStep 35 "Läser CSV…"
                    $csvRows = Csv-ImportRows -Path $selCsv -StartRow 10
                }

                # --- Robusthet: Sortera på kolumn C (Sample ID) innan vidare bearbetning.
                # Många efterföljande steg (gruppering/skrivning) förutsätter att raderna är konsekvent sorterade.
                try {
                    if ($csvRows -and $csvRows.Count -gt 1) {
                        if ($csvRows[0] -is [object[]]) {
                            # Csv-ImportRows* returnerar fält-arrayer: kolumn C = index 2
                            $csvRows = @($csvRows | Sort-Object { [string]($_[2]) })
                        } else {
                            # Om vi i framtiden får PSCustomObject-rader
                            $csvRows = @($csvRows | Sort-Object { [string]($_.'Sample ID') })
                        }
                        Gui-Log ("🔃 CSV sorterad på kolumn C (Sample ID). Rader: {0}" -f $csvRows.Count) 'Info' 'PROGRESS'
                    }
                } catch {
                    Gui-Log "⚠️ Kunde inte sortera CSV på kolumn C (Sample ID)." 'Warn'
                }
            } catch {
                Gui-Log "⚠️ CSV-import misslyckades: $($_.Exception.Message)" 'Warn'
                $csvRows = @()
            }
            try { $runAssay = Csv-GetAssay -Path $selCsv -StartRow 10 } catch {}
            if ($runAssay) { Gui-Log "🔎 Assay från CSV: $runAssay" }
        }

        # --- Import av Resample-CSV ---
        $csvRowsRes = @()
        $runAssayRes = $null
        if ($selCsvRes) {
            try {
                Set-UiStep 37 "Läser Resample-CSV…"
                $csvRowsRes = Csv-ImportRows -Path $selCsvRes -StartRow 10
                try {
                    if ($csvRowsRes -and $csvRowsRes.Count -gt 1) {
                        if ($csvRowsRes[0] -is [object[]]) {
                            $csvRowsRes = @($csvRowsRes | Sort-Object { [string]($_[2]) })
                        } else {
                            $csvRowsRes = @($csvRowsRes | Sort-Object { [string]($_.'Sample ID') })
                        }
                        Gui-Log ("🔃 Resample-CSV sorterad. Rader: {0}" -f $csvRowsRes.Count) 'Info' 'PROGRESS'
                    }
                } catch {}
            } catch {
                Gui-Log "⚠️ Resample-CSV-import misslyckades: $($_.Exception.Message)" 'Warn'
                $csvRowsRes = @()
            }
            try { $runAssayRes = Csv-GetAssay -Path $selCsvRes -StartRow 10 } catch {}
            if (-not $runAssayRes -and $runAssay) { $runAssayRes = $runAssay }  # Fallback till primary assay
        }

        # =====================================================
        # === SKANNING AV DATA SUMMARY-BLAD (fynd)
        # === Primär → 'Data Summary', Resample → 'Resample Data Summary'
        # =====================================================
        Mark-Phase 'CsvRead'
        $dataSummaryFindings     = @()
        $dataSummaryFindingsRes  = @()
        $script:WsPkg            = $null  # Återanvänds av Equipment/Header/QC-sektionerna

        $effectiveAssay = if ($runAssay) { $runAssay } elseif ($runAssayRes) { $runAssayRes } else { $null }
        if ($effectiveAssay) {
            try {
                $selLspDs = $null
                try { $selLspDs = Get-CheckedFilePath $clbLsp } catch { $selLspDs = $null }

                if ($selLspDs -and (Test-Path -LiteralPath $selLspDs)) {
                    $script:WsPkg = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($selLspDs))

                    # --- Primär CSV → 'Data Summary' ---
                    if ($selCsv) {
                        $dataSummaryFindings = @(Get-DataSummaryFindings -ExcelPackages @($script:WsPkg) -AssayName $effectiveAssay -SheetName $Layout.SheetDataSummary)
                    }

                    # --- Resample-CSV → 'Resample Data Summary' ---
                    if ($selCsvRes) {
                        $resSheetName = 'Resample Data Summary'
                        $dataSummaryFindingsRes = @(Get-DataSummaryFindings -ExcelPackages @($script:WsPkg) -AssayName $effectiveAssay -SheetName $resSheetName)
                        if ($dataSummaryFindingsRes.Count -gt 0) {
                            Gui-Log ("📋 Resample Data Summary: Findings={0}" -f $dataSummaryFindingsRes.Count) 'Info'
                        }
                    }
                }
            } catch {
                Gui-Log ("⚠️ Data Summary scan fel: " + $_.Exception.Message) 'Warn'
                $dataSummaryFindings     = @()
                $dataSummaryFindingsRes  = @()
                if ($script:WsPkg) { try { $script:WsPkg.Dispose() } catch {} }
                $script:WsPkg = $null
            }
        }
        # Kombinerat DataSummaryFindings (primär + resample) för CSV Sammanfattning
        $allDataSummaryFindings = @($dataSummaryFindings) + @($dataSummaryFindingsRes)
        $script:DataSummaryFindings = $allDataSummaryFindings

        # ============================
        # === RuleEngine (skuggresultat) ===
        # ============================
        Mark-Phase 'DataSummary'
        $script:RuleEngineShadowRes = $null   # Resample-resultat (separat)
        try {
            if ((Get-ConfigFlag -Name 'EnableRuleEngine' -Default $false -ConfigOverride $Config) -and
                ($selCsv -or $selCsvRes)) {

                # Ladda rulebank en gång
                $rb = Load-RuleBank -RuleBankDir $Config.RuleBankDir
                try { $rb = Compile-RuleBank -RuleBank $rb } catch {}
                if (Build-TestRuleBankForEngine -RuleBank $rb -Context 'Build.RuleEngineShadow') {
                    $script:RuleBankCache = $rb
                } else {
                    $script:RuleBankCache = $null
                    $script:RuleEngineShadow = $null
                    $script:RuleEngineShadowRes = $null
                }

                # ======================================
                # PRIMÄR CSV → RuleEngine
                # ======================================
                if ($selCsv -and (Test-Path -LiteralPath $selCsv)) {
                    $csvObjs = @()
                    if ($csvRows -and (Build-GetSafeCount $csvRows) -gt 0) {
                        $csvObjs = @($csvRows)
                        Gui-Log ("🧠 Regelmotor: CSV-källa: Csv-ImportRows ({0})" -f (Build-GetSafeCount $csvObjs)) 'Info' 'PROGRESS'
                    } else {
                        try {
                            $all = $script:CsvLinesPrimary
                            $allCount = Build-GetSafeCount $all
                            if ($all -and $allCount -gt 9) {
                                $del = Csv-GetDelimiter -Path $selCsv
                                $hdr = Csv-SplitFields $all[7]
                                $dl  = $all[9..($allCount-1)] | Where-Object { $_ -and $_.Trim() }
                                $csvObjs = @(ConvertFrom-Csv -InputObject ($dl -join "`n") -Delimiter $del -Header $hdr)
                            }
                        } catch { $csvObjs = @() }
                        Gui-Log ("🧠 Regelmotor: CSV-källa: Fallback-raw ({0})" -f (Build-GetSafeCount $csvObjs)) 'Info' 'PROGRESS'
                    }
                    $script:RuleEngineCsvObjs = $csvObjs

                    if (-not $csvObjs -or (Build-GetSafeCount $csvObjs) -eq 0) {
                        Gui-Log "⚠️ Regelmotor: CSV-objekt saknas (0 rader) – hoppar över." 'Warn'
                        $script:RuleEngineShadow = $null
                    } else {
                        if ($script:RuleBankCache) {
                            $re = Invoke-RuleEngine -CsvObjects $csvObjs -RuleBank $script:RuleBankCache -CsvPath $selCsv
                            $script:RuleEngineShadow = $re
                        } else {
                            Gui-Log "⚠️ Regelmotor: RuleBank ogiltig – shadow-körning hoppas över." 'Warn'
                            $script:RuleEngineShadow = $null
                        }
                    }
                }

                # ======================================
                # RESAMPLE-CSV → RuleEngine
                # ======================================
                if ($selCsvRes -and (Test-Path -LiteralPath $selCsvRes)) {
                    $csvObjsRes = @()
                    if ($csvRowsRes -and (Build-GetSafeCount $csvRowsRes) -gt 0) {
                        $csvObjsRes = @($csvRowsRes)
                        Gui-Log ("🧠 Regelmotor (Resample): Csv-ImportRows ({0})" -f (Build-GetSafeCount $csvObjsRes)) 'Info' 'PROGRESS'
                    } else {
                        try {
                            $allR = $script:CsvLinesResample
                            $allRCount = Build-GetSafeCount $allR
                            if ($allR -and $allRCount -gt 9) {
                                $delR = Csv-GetDelimiter -Path $selCsvRes
                                $hdrR = Csv-SplitFields $allR[7]
                                $dlR  = $allR[9..($allRCount-1)] | Where-Object { $_ -and $_.Trim() }
                                $csvObjsRes = @(ConvertFrom-Csv -InputObject ($dlR -join "`n") -Delimiter $delR -Header $hdrR)
                            }
                        } catch { $csvObjsRes = @() }
                    }
                    $script:RuleEngineCsvObjsRes = $csvObjsRes

                    if ($csvObjsRes -and (Build-GetSafeCount $csvObjsRes) -gt 0) {
                        if ($script:RuleBankCache) {
                            $reRes = Invoke-RuleEngine -CsvObjects $csvObjsRes -RuleBank $script:RuleBankCache -CsvPath $selCsvRes
                            $script:RuleEngineShadowRes = $reRes
                        } else {
                            $script:RuleEngineShadowRes = $null
                        }
                    }
                }

                # ======================================
                # KOMBINERAD SUMMERING (primär + resample)
                # ======================================
                $rePrimary = $script:RuleEngineShadow
                $reResamp  = $script:RuleEngineShadowRes

                # Sammanfogning: bygg nytt kombinerat resultat (undvik PS 5.1-bugg med readonly NoteProperty)
                if ($rePrimary -and $reResamp) {
                    try {
                        # Rader
                        $mergedRows = @($rePrimary.Rows) + @($reResamp.Rows)

                        # DeviationCounts — kopiera primär, addera resample
                        $mergedDev = @{}
                        if ($rePrimary.Summary.DeviationCounts) {
                            foreach ($dk in $rePrimary.Summary.DeviationCounts.Keys) { $mergedDev[$dk] = [int]$rePrimary.Summary.DeviationCounts[$dk] }
                        }
                        if ($reResamp.Summary.DeviationCounts) {
                            foreach ($dk in $reResamp.Summary.DeviationCounts.Keys) {
                                if ($mergedDev.ContainsKey($dk)) { $mergedDev[$dk] += [int]$reResamp.Summary.DeviationCounts[$dk] }
                                else { $mergedDev[$dk] = [int]$reResamp.Summary.DeviationCounts[$dk] }
                            }
                        }

                        # ObservedCounts
                        $mergedObs = @{}
                        if ($rePrimary.Summary.ObservedCounts) {
                            foreach ($ok2 in $rePrimary.Summary.ObservedCounts.Keys) { $mergedObs[$ok2] = [int]$rePrimary.Summary.ObservedCounts[$ok2] }
                        }
                        if ($reResamp.Summary.ObservedCounts) {
                            foreach ($ok2 in $reResamp.Summary.ObservedCounts.Keys) {
                                if ($mergedObs.ContainsKey($ok2)) { $mergedObs[$ok2] += [int]$reResamp.Summary.ObservedCounts[$ok2] }
                                else { $mergedObs[$ok2] = [int]$reResamp.Summary.ObservedCounts[$ok2] }
                            }
                        }

                        # Enkla räknare
                        $mergedInstErr  = ($rePrimary.Summary.InstrumentError + 0) + ($reResamp.Summary.InstrumentError + 0)
                        $mergedMinFunc  = ($rePrimary.Summary.MinorFunctionalError + 0) + ($reResamp.Summary.MinorFunctionalError + 0)
                        $mergedTotal    = ($rePrimary.Summary.Total + 0) + ($reResamp.Summary.Total + 0)
                        $mergedRetest   = ($rePrimary.Summary.RetestYes + 0) + ($reResamp.Summary.RetestYes + 0)

                        # TopDeviations
                        $mergedTop = @($rePrimary.TopDeviations) + @($reResamp.TopDeviations)

                        # QC (behåll primär)
                        $mergedQC = $rePrimary.QC

                        # Bygg nytt resultatobjekt
                        $mergedSummary = [pscustomobject]@{
                            Total                = $mergedTotal
                            ObservedCounts       = $mergedObs
                            DeviationCounts      = $mergedDev
                            RetestYes            = $mergedRetest
                            InstrumentError      = $mergedInstErr
                            MinorFunctionalError = $mergedMinFunc
                        }
                        $script:RuleEngineShadow = [pscustomobject]@{
                            Rows          = $mergedRows
                            Summary       = $mergedSummary
                            TopDeviations = $mergedTop
                            QC            = $mergedQC
                        }
                        Gui-Log ("✅ Merge CSV + Resampling CSV: {0} rader totalt" -f $mergedRows.Count) 'Info'
                    } catch {
                        Gui-Log "⚠️ Merge CSV + Resampling CSV resultat: $($_.Exception.Message)" 'Warn'
                    }
                } elseif (-not $rePrimary -and $reResamp) {
                    # Endast resample
                    $script:RuleEngineShadow = $reResamp
                }

                $re = $script:RuleEngineShadow
                if ($re -and $re.Summary) {
                    try {
                        $pos = 0; $neg = 0; $err = 0
                        if ($re.Summary.ObservedCounts) {
                            if ($re.Summary.ObservedCounts.ContainsKey('POS'))   { $pos = [int]$re.Summary.ObservedCounts['POS'] }
                            if ($re.Summary.ObservedCounts.ContainsKey('NEG'))   { $neg = [int]$re.Summary.ObservedCounts['NEG'] }
                            if ($re.Summary.ObservedCounts.ContainsKey('ERROR')) { $err = [int]$re.Summary.ObservedCounts['ERROR'] }
                        }

                        $ok = 0; $fp = 0; $fn = 0; $derr = 0; $ie = 0
                        if ($re.Summary.DeviationCounts) {
                            if ($re.Summary.DeviationCounts.ContainsKey('OK'))    { $ok   = [int]$re.Summary.DeviationCounts['OK'] }
                            if ($re.Summary.DeviationCounts.ContainsKey('FP'))    { $fp   = [int]$re.Summary.DeviationCounts['FP'] }
                            if ($re.Summary.DeviationCounts.ContainsKey('FN'))    { $fn   = [int]$re.Summary.DeviationCounts['FN'] }
                            if ($re.Summary.DeviationCounts.ContainsKey('ERROR')) { $derr = [int]$re.Summary.DeviationCounts['ERROR'] }
                        }
                        $ie = 0; if ($re.Summary.InstrumentError -ne $null) { $ie = [int]$re.Summary.InstrumentError }
                        $mf = 0; if ($re.Summary.MinorFunctionalError -ne $null) { $mf = [int]$re.Summary.MinorFunctionalError }

                        $resTag = if ($selCsvRes) { ' [+Resample]' } else { '' }
                        $sum = "🧠 Regelkontroll$resTag`: POS=$pos, NEG=$neg, Error=$err | OK=$ok, FP=$fp, FN=$fn, Minor Func=$mf | Instrument Error=$ie"
                        # Regelkontroll-detaljer döljs i GUI (kan stressa användare)
                        # Gui-Log -Text $sum -Severity Info -Category SUMMARY
                    } catch { }

                    if ((Get-ConfigFlag -Name 'EnableShadowCompare' -Default $false -ConfigOverride $Config) -and $re.TopDeviations) {
                        $n = 0
                        foreach ($d in $re.TopDeviations) {
                            $n++; if ($n -gt 20) { break }
                            $msg = "⚠️ RuleEngine dev: " + ($d.Deviation + '') + " | " + ($d.SampleId + '') + " | Exp=" + ($d.ExpectedCall + '') + " | Obs=" + ($d.ObservedCall + '')
                            if (($d.ErrorCode + '').Trim()) { $msg += " | Err=" + ($d.ErrorCode + '') }
                            Gui-Log -Text $msg -Severity Info -Category RuleEngineDev
                        }
                    }
                }
            }
        } catch {
            Gui-Log ("⚠️ RuleEngine (shadow) fel: " + $_.Exception.Message) 'Warn'
        }

        $controlTab = $null
        if ($runAssay) { $controlTab = Get-ControlTabName -AssayName $runAssay }
        if ($controlTab) { Gui-Log "🧪 Kontrollmaterial-flik: $controlTab" } else { Gui-Log "ℹ️ Ingen Kontrollmaterialsflik (fortsätter utan)." }

        # ============================
        # === Läs avvikelser       ===
        # ============================

        # P2: Extraherad hjälpfunktion (ersätter duplicerad NEG/POS-loop)
        function Get-SealViolations {
            param(
                [Parameter(Mandatory)][OfficeOpenXml.ExcelPackage]$Pkg,
                [double]$MinusThreshold = -3.0
            )
            $violations = New-Object System.Collections.Generic.List[object]
            $failCount  = 0

            foreach ($ws in $Pkg.Workbook.Worksheets) {
                if (Test-IsSealTestSkipSheet -SheetName $ws.Name) { continue }
                if (-not $ws.Dimension) { continue }
                $obsC = Find-ObservationCol $ws

                for ($r = 3; $r -le 45; $r++) {
                    $valK = $ws.Cells["K$r"].Value
                    $textL = $ws.Cells["L$r"].Text

                    if ($valK -ne $null -and $valK -is [double]) {
                        if ($textL -eq "FAIL" -or $valK -le $MinusThreshold) {
                            $obsTxt = $ws.Cells[$r, $obsC].Text
                            [void]$violations.Add([PSCustomObject]@{
                                Sheet      = $ws.Name
                                Cartridge  = $ws.Cells["H$r"].Text
                                InitialW   = $ws.Cells["I$r"].Value
                                FinalW     = $ws.Cells["J$r"].Value
                                WeightLoss = $valK
                                Status     = if ($textL -eq "FAIL") { "FAIL" } else { "Minusvärde" }
                                Obs        = $obsTxt
                            })
                            if ($textL -eq "FAIL") { $failCount++ }
                        }
                    }
                }
            }

            return [pscustomobject]@{
                Violations = @($violations.ToArray())
                FailCount  = $failCount
            }
        }

        $resNeg = Get-SealViolations -Pkg $pkgNeg
        $resPos = Get-SealViolations -Pkg $pkgPos
        $violationsNeg = $resNeg.Violations; $failNegCount = $resNeg.FailCount
        $violationsPos = $resPos.Violations; $failPosCount = $resPos.FailCount
        # STF-count för CSV Sammanfattning: räkna endast riktiga FAIL (Minusvärde visas fortfarande i STF Sum-bladet)
        $script:StfCount = $failNegCount + $failPosCount

        # ============================
        # === Seal Test Info (blad) ==
        # ============================
        Mark-Phase 'RuleEngine'
        $wsOut1 = $pkgOut.Workbook.Worksheets[$Layout.SheetSealTestInfo]
        if (-not $wsOut1) { Gui-Log "❌ Fliken 'Seal Test Info' saknas i mallen"; return }

        for ($row = 3; $row -le 15; $row++) {
            $wsOut1.Cells["D$row"].Value = $null
            try { $wsOut1.Cells["D$row"].Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::None } catch {}
        }

        $fields = @(
            @{ Label = "ROBAL";                         Cell = "F2"  }
            @{ Label = "Part Number";                   Cell = "B2"  }
            @{ Label = "Batch Number";                  Cell = "D2"  }
            @{ Label = "Cartridge Number (LSP)";        Cell = "B6"  }
            @{ Label = "PO Number";                     Cell = "B10" }
            @{ Label = "Assay Family";                  Cell = "D10" }
            @{ Label = "Weight Loss Spec";              Cell = "F10" }
            @{ Label = "Balance ID Number";             Cell = "B14" }
            @{ Label = "Balance Cal Due Date";          Cell = "D14" }
            @{ Label = "Vacuum Oven ID Number";         Cell = "B20" }
            @{ Label = "Vacuum Oven Cal Due Date";      Cell = "D20" }
            @{ Label = "Timer ID Number";               Cell = "B25" }
            @{ Label = "Timer Cal Due Date";            Cell = "D25" }
        )

        $forceText = @("ROBAL","Part Number","Batch Number","Cartridge Number (LSP)","PO Number","Assay Family","Balance ID Number","Vacuum Oven ID Number","Timer ID Number")
        $mismatchFields = $fields[0..6] | ForEach-Object { $_.Label }


            # --- Förväntad utrustningslista (valfritt, från equipment.xml) ---
        $equip = $null
        $equipPath = $null
        try {
            $equipPath = Get-ConfigValue -Name 'EquipmentXmlPath' -Default (Join-Path $script:BuildPipelineProjectRoot 'equipment.xml') -ConfigOverride $Config
            if ($equipPath -and -not (Test-Path -LiteralPath $equipPath)) {
                Gui-Log ("⚠️ Equipment.xml hittades inte: " + $equipPath) 'Warn'
            }
            if ($equipPath -and (Test-Path -LiteralPath $equipPath)) {
                $equip = Import-Clixml -LiteralPath $equipPath
            }
        } catch {
            $equip = $null
        }

        function _EquipTokens([string]$s) {
            if ([string]::IsNullOrWhiteSpace($s)) { return @() }
            $parts = $s -split '[,;]' | ForEach-Object { ($_ -replace '\s+', ' ').Trim() } | Where-Object { $_ }
            $tok = @()
            foreach ($p in $parts) {
                $v = (Normalize-HeaderText $p).Trim().ToUpper()
                $v = $v -replace '^(NR\.?|NO\.?)\s*', ''
                $v = $v -replace '[^A-Z0-9_-]', ''
                if ($v) { $tok += $v }
            }
            return @($tok | Sort-Object -Unique)
        }

        function _EquipPretty([string[]]$tokens, [string]$label) {
    # StrictMode-säker: $tokens kan vara $null eller ett enstaka värde beroende på källa
    if (@($tokens).Count -eq 0) { return '' }
    $t = @($tokens | Sort-Object -Unique)

    if ($label -ieq 'Timer ID Number') {
        # Visa som "Nr. 18, Nr. 19"
        return (($t | ForEach-Object { "Nr. $_" }) -join ', ')
    }

    return ($t -join ', ')
}

        function _FixMonthText([string]$s) {
            if ([string]::IsNullOrWhiteSpace($s)) { return '' }
            $t = (Normalize-HeaderText $s).Trim()
            # Byt ut kyrillisk A (А/а) mot latin A – vanligt i "Аpr-26"
            $t = $t -replace '[Аа]', 'A'
            $t = ($t -replace '\s+', ' ').Trim()
            return $t
        }

        function _EquipEvalList([string]$actual, [string]$expected) {
            # Returnerar: Match | Delvis | Saknas | Mismatch | Ingen referens
            if ([string]::IsNullOrWhiteSpace($expected)) { return 'NoRef' }
            $aT = _EquipTokens $actual
            $eT = _EquipTokens $expected
            # StrictMode-säker: Count på $null kastar i StrictMode
            if (@($aT).Count -eq 0) { return 'Saknas' }
            foreach ($a in $aT) { if (-not ($eT -contains $a)) { return 'Mismatch' } }
            foreach ($e in $eT) { if (-not ($aT -contains $e)) { return 'Delvis' } }
            return 'Match'
        }

        function _EquipEvalMonth([string]$actual, [string]$expected) {
            if ([string]::IsNullOrWhiteSpace($expected)) { return 'NoRef' }
            if ([string]::IsNullOrWhiteSpace($actual))   { return 'Saknas' }
            $a = (_FixMonthText $actual).ToUpper()
            $e = (_FixMonthText $expected).ToUpper()
            if ($a -eq $e) { return 'Match' }
            return 'Mismatch'
        }

function _IsActiveSealSheet($ws) {
    try {
        if (-not $ws) { return $false }
        if ($ws.Index -eq 1) { return $false }  # Skippa alltid första bladet (används ej)
        if (Test-IsSealTestSkipSheet -SheetName $ws.Name) { return $false }

        $h3 = Excel-GetCellText $ws $Layout.SealActiveCheckCell
        if (-not $h3) { return $false }

        $h3n = (Normalize-HeaderText $h3).Trim().ToUpper()
        if ($h3n -eq 'NA' -or $h3n -eq 'N/A') { return $false }

        return $true
    } catch {
        return $false
    }
}

function _GetPerSheetValueObjects($pkg, [string]$addr) {
    # Returnerar objektlista: Sheet, Addr, Value (en per "aktiv" flik)
    $out = New-Object System.Collections.Generic.List[object]
    foreach ($ws in $pkg.Workbook.Worksheets) {
        if (-not (_IsActiveSealSheet $ws)) { continue }
        try {
            $cell = $ws.Cells[$addr]
            $v = ''
            if ($cell -and $cell.Value -ne $null) {
                if ($cell.Value -is [datetime]) { $v = $cell.Value.ToString('MMM-yy') } else { $v = $cell.Text }
            }
            [void]$out.Add([pscustomobject]@{ Sheet = $ws.Name; Addr = $addr; Value = ('' + $v) })
        } catch {
            [void]$out.Add([pscustomobject]@{ Sheet = $ws.Name; Addr = $addr; Value = '' })
        }
    }
     return @($out.ToArray())
}


function _AggregateStatus([string[]]$statuses) {
    # Summerar: Mismatch > Saknas > Delvis > Match
    if (-not $statuses -or $statuses.Count -eq 0) { return 'NoRef' }
    if ($statuses -contains 'Mismatch') { return 'Mismatch' }
    if ($statuses -contains 'Saknas')   { return 'Saknas' }
    if ($statuses -contains 'Delvis')   { return 'Delvis' }
    if ($statuses -contains 'Match')    { return 'Match' }
    return 'NoRef'
}

        $equipMap = @{
            'Balance ID Number'        = @{ NegKey='SCALESNEG';       PosKey='SCALESPOS';       Mode='LIST'  }
            'Balance Cal Due Date'     = @{ NegKey='CAL_D_SCALES';    PosKey='CAL_D_SCALES';    Mode='MONTH' }
            'Vacuum Oven ID Number'    = @{ NegKey='OVENSNEG';        PosKey='OVENSPOS';        Mode='LIST'  }
            'Vacuum Oven Cal Due Date' = @{ NegKey='CAL_D_OVENS';     PosKey='CAL_D_OVENS';     Mode='MONTH' }
            'Timer ID Number'          = @{ NegKey='TIMERSNEG';       PosKey='TIMERSPOS';       Mode='LIST'  }
            'Timer Cal Due Date'       = @{ NegKey='CAL_D_TIMERSNEG'; PosKey='CAL_D_TIMERSPOS'; Mode='MONTH' }
        }

        $row = 3
        foreach ($f in $fields) {
$valNeg=''; $valPos=''
$srcNeg=''; $srcPos=''

# För utrustningsrader: samla per flik (inte avbrott på första!)
$perNeg = $null
$perPos = $null
$isEquip = ($equip -and $equipMap -and $equipMap.ContainsKey($f.Label))

if ($isEquip) {
    $perNegObj = _GetPerSheetValueObjects $pkgNeg $f.Cell
    $perPosObj = _GetPerSheetValueObjects $pkgPos $f.Cell
    $perNeg = @($perNegObj | ForEach-Object { $_.Value })
    $perPos = @($perPosObj | ForEach-Object { $_.Value })

    # Visa i B/C: union (för LIST) eller första icke-tom (för MONTH), bara för läsbarhet
    $map = $equipMap[$f.Label]
    if ($map.Mode -eq 'MONTH') {
        $valNeg = ($perNeg | Where-Object { $_ -and $_.Trim() } | Select-Object -First 1)
        $valPos = ($perPos | Where-Object { $_ -and $_.Trim() } | Select-Object -First 1)
    } else {
        $tokN = @()
        foreach ($x in $perNeg) { $tokN += (_EquipTokens $x) }
        $tokP = @()
        foreach ($x in $perPos) { $tokP += (_EquipTokens $x) }
$valNeg = _EquipPretty ($tokN | Sort-Object -Unique) $f.Label
$valPos = _EquipPretty ($tokP | Sort-Object -Unique) $f.Label
    }
}
else {
    # Befintligt beteende för "vanliga" fält: första AKTIVA flik med värde (skippa blad 1 + inaktiva)
    foreach ($wsN in $pkgNeg.Workbook.Worksheets) {
        if (-not (_IsActiveSealSheet $wsN)) { continue }
        $cell = $wsN.Cells[$f.Cell]
        if ($cell.Value -ne $null) {
            if ($cell.Value -is [datetime]) { $valNeg = $cell.Value.ToString('MMM-yy') } else { $valNeg = $cell.Text }
            $srcNeg = $wsN.Name
            break
        }
    }

    foreach ($wsP in $pkgPos.Workbook.Worksheets) {
        if (-not (_IsActiveSealSheet $wsP)) { continue }
        $cell = $wsP.Cells[$f.Cell]
        if ($cell.Value -ne $null) {
            if ($cell.Value -is [datetime]) { $valPos = $cell.Value.ToString('MMM-yy') } else { $valPos = $cell.Text }
            $srcPos = $wsP.Name
            break
        }
    }
}

            if ($forceText -contains $f.Label) {
                $wsOut1.Cells["B$row"].Style.Numberformat.Format = '@'
                $wsOut1.Cells["C$row"].Style.Numberformat.Format = '@'
            }

            $wsOut1.Cells["B$row"].Value = $valNeg
            $wsOut1.Cells["C$row"].Value = $valPos
            $wsOut1.Cells["B$row"].Style.Border.Right.Style = "Medium"
            $wsOut1.Cells["C$row"].Style.Border.Left.Style  = "Medium"

        if ($mismatchFields -contains $f.Label) {
                # D3:D9: visa tydlig Match/Mismatch med symboler
                if ($valNeg -and $valPos) {
                    if ($valNeg -ne $valPos) {
                        # Spårbarhet endast vid mismatch: flik + cell för var värdet hämtades
                        $tN = if ($srcNeg) { ("NEG:{0}@{1}" -f $srcNeg, $f.Cell) } else { ("NEG@{0}" -f $f.Cell) }
                        $tP = if ($srcPos) { ("POS:{0}@{1}" -f $srcPos, $f.Cell) } else { ("POS@{0}" -f $f.Cell) }
                        $wsOut1.Cells["D$row"].Value = ("⚠ Mismatch ({0} | {1})" -f $tN, $tP)
                        try { $wsOut1.Cells["D$row"].Style.Font.Size = 9 } catch {}
                        Excel-StyleCell $wsOut1.Cells["D$row"] $true "FF0000" "Medium" "FFFFFF"
                        Gui-Log "⚠️ Avvikelse: $($f.Label) (NEG='$valNeg' vs POS='$valPos')"
                    } else {
                        $wsOut1.Cells["D$row"].Value = "✓ Match"
                        Excel-StyleCell $wsOut1.Cells["D$row"] $true "C6EFCE" "Medium" "006100"
                    }
                } elseif ($valNeg -or $valPos) {
                    # Bara en av filerna har värde - markera som varning
                    $wsOut1.Cells["D$row"].Value = "⚠ Saknas"
                    Excel-StyleCell $wsOut1.Cells["D$row"] $true "FFE699" "Medium" "806000"
                }
            }

            # --- Utrustningskontroll (POS/NEG har egna tillåtna värden i equipment.xml) ---
            if ($equip -and $equipMap -and $equipMap.ContainsKey($f.Label)) {
                $map = $equipMap[$f.Label]
                $expNeg = $null; $expPos = $null
                try { if ($equip.Contains($map.NegKey)) { $expNeg = (""+$equip[$map.NegKey]).Trim() } } catch {}
                try { if ($equip.Contains($map.PosKey)) { $expPos = (""+$equip[$map.PosKey]).Trim() } } catch {}

# Utvärdera PER FLIK och summera
$stNegAll = @()
$stPosAll = @()
                $negMismatchSheets = @()
                $posMismatchSheets = @()
                $negDelvisSheets = @()
                $posDelvisSheets = @()

if ($map.Mode -eq 'MONTH') {
    for ($i = 0; $i -lt $perNegObj.Count; $i++) {
        $st = (_EquipEvalMonth $perNegObj[$i].Value $expNeg); $stNegAll += $st
        if ($st -eq 'Mismatch') { $negMismatchSheets += ("{0}@{1}" -f $perNegObj[$i].Sheet, $perNegObj[$i].Addr) }
    }
    for ($i = 0; $i -lt $perPosObj.Count; $i++) {
        $st = (_EquipEvalMonth $perPosObj[$i].Value $expPos); $stPosAll += $st
        if ($st -eq 'Mismatch') { $posMismatchSheets += ("{0}@{1}" -f $perPosObj[$i].Sheet, $perPosObj[$i].Addr) }
    }

} else {
    for ($i = 0; $i -lt $perNegObj.Count; $i++) {
        $st = (_EquipEvalList $perNegObj[$i].Value $expNeg); $stNegAll += $st
        if ($st -eq 'Mismatch') { $negMismatchSheets += ("{0}@{1}" -f $perNegObj[$i].Sheet, $perNegObj[$i].Addr) }
        if ($st -eq 'Delvis')   { $negDelvisSheets   += ("{0}@{1}" -f $perNegObj[$i].Sheet, $perNegObj[$i].Addr) }
    }
    for ($i = 0; $i -lt $perPosObj.Count; $i++) {
        $st = (_EquipEvalList $perPosObj[$i].Value $expPos); $stPosAll += $st
        if ($st -eq 'Mismatch') { $posMismatchSheets += ("{0}@{1}" -f $perPosObj[$i].Sheet, $perPosObj[$i].Addr) }
        if ($st -eq 'Delvis')   { $posDelvisSheets   += ("{0}@{1}" -f $perPosObj[$i].Sheet, $perPosObj[$i].Addr) }
    }
}

$sNeg = _AggregateStatus $stNegAll
$sPos = _AggregateStatus $stPosAll

                function _Txt($s) {
                    switch ($s) {
                        'Match'   { '✓ Match' }
                        'Delvis'  { '✓ Delvis' }
                        'Saknas'  { '⚠ Saknas' }
                        'Mismatch'{ '⚠ Mismatch' }
                        default   { '?' }
                    }
                }

                # Hjälpfunktion: plocka ut enbart bladnamn (ta bort @cellref)
                function _CleanSheets([string[]]$arr) {
                    ($arr | ForEach-Object { ($_ -replace '@.*$','').Trim() } | Select-Object -Unique) -join ', '
                }

                $hasMismatch = ($sNeg -eq 'Mismatch' -or $sPos -eq 'Mismatch')
                $hasDelvis   = ($sNeg -eq 'Delvis'   -or $sPos -eq 'Delvis')

                if ($hasMismatch -or $hasDelvis) {
                    # NEG → kolumn D
                    $dVal = 'NEG ' + (_Txt $sNeg)
                    if ($sNeg -eq 'Mismatch' -and $negMismatchSheets.Count -gt 0) {
                        $dVal += ': ' + (_CleanSheets $negMismatchSheets)
                    } elseif ($sNeg -eq 'Delvis' -and $negDelvisSheets.Count -gt 0) {
                        $dVal += ': ' + (_CleanSheets $negDelvisSheets)
                    }
                    $wsOut1.Cells["D$row"].Value = $dVal
                    try { $wsOut1.Cells["D$row"].Style.Font.Size = 9 } catch {}

                    # POS → kolumn E
                    $eVal = 'POS ' + (_Txt $sPos)
                    if ($sPos -eq 'Mismatch' -and $posMismatchSheets.Count -gt 0) {
                        $eVal += ': ' + (_CleanSheets $posMismatchSheets)
                    } elseif ($sPos -eq 'Delvis' -and $posDelvisSheets.Count -gt 0) {
                        $eVal += ': ' + (_CleanSheets $posDelvisSheets)
                    }
                    $wsOut1.Cells["E$row"].Value = $eVal
                    try { $wsOut1.Cells["E$row"].Style.Font.Size = 9 } catch {}
                } else {
                    $wsOut1.Cells["D$row"].Value = ('NEG ' + (_Txt $sNeg) + ' / POS ' + (_Txt $sPos))
                }

                # Formatera D+E utifrån respektive status
                $rank = @{ 'NoRef'=0; 'Match'=1; 'Delvis'=2; 'Saknas'=2; 'Mismatch'=3 }

                foreach ($pair in @(@{C='D';S=$sNeg}, @{C='E';S=$sPos})) {
                    $col = $pair.C; $st = $pair.S
                    $cellVal = ($wsOut1.Cells["$col$row"].Text + '').Trim()
                    if (-not $cellVal) { continue }
                    $r = $rank[$st]
                    if ($r -ge 3) {
                        Excel-StyleCell $wsOut1.Cells["$col$row"] $true "FF0000" "Medium" "FFFFFF"
                    } elseif ($r -ge 2) {
                        Excel-StyleCell $wsOut1.Cells["$col$row"] $true "FFE699" "Medium" "806000"
                    } elseif ($r -ge 1) {
                        Excel-StyleCell $wsOut1.Cells["$col$row"] $true "C6EFCE" "Medium" "006100"
                    }
                }
            }
            $row++
        }

        $wsOut1.Cells["D:D"].Style.WrapText = $false
        $wsOut1.Cells["E:E"].Style.WrapText = $false
        $wsOut1.Column(4).AutoFit()
        $wsOut1.Column(4).Width += 1.5
        $wsOut1.Column(4).BestFit = $true
        $wsOut1.Column(5).AutoFit()
        $wsOut1.Column(5).Width += 1.5
        $wsOut1.Column(5).BestFit = $true

        # R2: Freeze panes – fryser rad 1–2 (rubrik) så data scrollas under
        try { $wsOut1.View.FreezePanes(3, 1) } catch {}

        # ============================
        # === Testare (B43)        ===
        # ============================

        $testersNeg = @(); $testersPos = @()
        $unsignedNegSheets = New-Object System.Collections.Generic.List[string]
        $unsignedPosSheets = New-Object System.Collections.Generic.List[string]
        foreach ($s in $pkgNeg.Workbook.Worksheets) {
            if (-not (_IsActiveSealSheet $s)) { continue }
            $t = (($s.Cells["B43"].Text + '')).Trim()
            if ($t) {
                $testersNeg += ($t -split ",")
            } else {
                [void]$unsignedNegSheets.Add($s.Name)
            }
        }
        foreach ($s in $pkgPos.Workbook.Worksheets) {
            if (-not (_IsActiveSealSheet $s)) { continue }
            $t = (($s.Cells["B43"].Text + '')).Trim()
            if ($t) {
                $testersPos += ($t -split ",")
            } else {
                [void]$unsignedPosSheets.Add($s.Name)
            }
        }
        $testersNeg = $testersNeg | ForEach-Object { $_.Trim() } | Where-Object { $_ } | Sort-Object -Unique
        $testersPos = $testersPos | ForEach-Object { $_.Trim() } | Where-Object { $_ } | Sort-Object -Unique

        $wsOut1.Cells["B16"].Value = "Name of Tester"
        $wsOut1.Cells["B16:C16"].Merge = $true
        $wsOut1.Cells["B16"].Style.HorizontalAlignment = "Center"

        $maxTesters = [Math]::Max($testersNeg.Count, $testersPos.Count)
        $initialRows = 11
        if ($maxTesters -lt $initialRows) { $wsOut1.DeleteRow(17 + $maxTesters, $initialRows - $maxTesters) }
        if ($maxTesters -gt $initialRows) {
            $rowsToAdd = $maxTesters - $initialRows
            $lastRow = 16 + $initialRows
            for ($i = 1; $i -le $rowsToAdd; $i++) { $wsOut1.InsertRow($lastRow + 1, 1, $lastRow) }
        }

        for ($i = 0; $i -lt $maxTesters; $i++) {
            $rowIndex = 17 + $i
            $wsOut1.Cells["A$rowIndex"].Value = $null
            $wsOut1.Cells["B$rowIndex"].Value = if ($i -lt $testersNeg.Count) { $testersNeg[$i] } else { "N/A" }
            $wsOut1.Cells["C$rowIndex"].Value = if ($i -lt $testersPos.Count) { $testersPos[$i] } else { "N/A" }

            $topStyle    = if ($i -eq 0) { "Medium" } else { "Thin" }
            $bottomStyle = if ($i -eq $maxTesters - 1) { "Medium" } else { "Thin" }

            foreach ($col in @("B","C")) {
                $cell = $wsOut1.Cells["$col$rowIndex"]
                $cell.Style.Border.Top.Style    = $topStyle
                $cell.Style.Border.Bottom.Style = $bottomStyle
                $cell.Style.Border.Left.Style   = "Medium"
                $cell.Style.Border.Right.Style  = "Medium"
                $cell.Style.Fill.PatternType = "Solid"
                $cell.Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml("#CCFFFF"))
            }
        }

        function _BuildUnsignedSealText([string[]]$sheetNames) {
            $arr = @($sheetNames | Where-Object { $_ })
            if ($arr.Count -eq 0) { return '' }
            $arr = @($arr | Select-Object -Unique)
            if ($arr.Count -eq 1) { return ($arr[0] + ' osignerat') }
            return (($arr -join ', ') + ' osignerade')
        }

        $negUnsignedText = _BuildUnsignedSealText @($unsignedNegSheets.ToArray())
        $posUnsignedText = _BuildUnsignedSealText @($unsignedPosSheets.ToArray())
        $unsignedMsgs = @()
        if ($negUnsignedText) { $unsignedMsgs += ('NEG: ' + $negUnsignedText) }
        if ($posUnsignedText) { $unsignedMsgs += ('POS: ' + $posUnsignedText) }
        if ($unsignedMsgs.Count -gt 0) {
            $unsignedInfo = $unsignedMsgs -join ' | '
            $wsOut1.Cells['D16'].Value = 'Name of Tester (osignerat)'
            $wsOut1.Cells['D17'].Value = $unsignedInfo
            $wsOut1.Cells['D16'].Style.Font.Bold = $true
            $wsOut1.Cells['D16:D17'].Style.WrapText = $true
            Excel-StyleCell $wsOut1.Cells['D17'] $true "FFE699" "Medium" "806000"
            try {
                $wsOut1.Column(4).AutoFit()
                if ($wsOut1.Column(4).Width -lt 42) { $wsOut1.Column(4).Width = 42 }
                $wsOut1.Column(4).BestFit = $true
            } catch {}
            Gui-Log ("⚠️ Name of Tester saknas på aktiva datasheets: {0}" -f $unsignedInfo) 'Warn'
        }

        # ============================
        # === Signatur-jämförelse  ===
        # ============================

        $negSigSet = Get-SignatureSetForDataSheets -Pkg $pkgNeg
        $posSigSet = Get-SignatureSetForDataSheets -Pkg $pkgPos

        $negSet = New-Object 'System.Collections.Generic.HashSet[string]'
        $posSet = New-Object 'System.Collections.Generic.HashSet[string]'
        foreach ($n in $negSigSet.NormSet) { [void]$negSet.Add($n) }
        foreach ($p in $posSigSet.NormSet) { [void]$posSet.Add($p) }

        $hasNeg = ($negSet.Count -gt 0)
        $hasPos = ($posSet.Count -gt 0)

        $onlyNeg = @(); $onlyPos = @(); $sigMismatch = $false
        if ($hasNeg -and $hasPos) {
            foreach ($n in $negSet) { if (-not $posSet.Contains($n)) { $onlyNeg += $n } }
            foreach ($p in $posSet) { if (-not $negSet.Contains($p)) { $onlyPos += $p } }
            $sigMismatch = ($onlyNeg.Count -gt 0 -or $onlyPos.Count -gt 0)
        } else {
            $sigMismatch = $false
        }

        $mismatchSheets = @()
        if ($sigMismatch) {
            foreach ($k in $onlyNeg) {
                $raw = if ($negSigSet.RawByNorm.ContainsKey($k)) { $negSigSet.RawByNorm[$k] } else { $k }
                $where = if ($negSigSet.Occ.ContainsKey($k)) { ($negSigSet.Occ[$k] -join ', ') } else { '—' }
                $mismatchSheets += ("NEG: " + $raw + "  [Blad: " + $where + "]")
            }
            foreach ($k in $onlyPos) {
                $raw = if ($posSigSet.RawByNorm.ContainsKey($k)) { $posSigSet.RawByNorm[$k] } else { $k }
                $where = if ($posSigSet.Occ.ContainsKey($k)) { ($posSigSet.Occ[$k] -join ', ') } else { '—' }
                $mismatchSheets += ("POS: " + $raw + "  [Blad: " + $where + "]")
            }
            Gui-Log "⚠️ Avvikelse: Print Full Name, Sign, and Date (NEG vs POS)"
        }

        if (-not (Get-Command Set-MergedWrapAutoHeight -ErrorAction SilentlyContinue)) {
            function Set-MergedWrapAutoHeight {
                param([OfficeOpenXml.ExcelWorksheet]$Sheet,[int]$RowIndex,[int]$ColStart=2,[int]$ColEnd=3,[string]$Text)
                $rng = $Sheet.Cells[$RowIndex, $ColStart, $RowIndex, $ColEnd]
                $rng.Style.WrapText = $true
                $rng.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::None
                $Sheet.Row($RowIndex).CustomHeight = $false
                try {
                    $wChars = [Math]::Floor(($Sheet.Column($ColStart).Width + $Sheet.Column($ColEnd).Width) - 2); if ($wChars -lt 1) { $wChars = 1 }
                    $segments = $Text -split "(\r\n|\n|\r)"; $lineCount = 0
                    foreach ($seg in $segments) { if (-not $seg) { $lineCount++ } else { $lineCount += [Math]::Ceiling($seg.Length / $wChars) } }
                    if ($lineCount -lt 1) { $lineCount = 1 }
                    $targetHeight = [Math]::Max(15, [Math]::Ceiling(15 * $lineCount * 2.15))
                    if ($Sheet.Row($RowIndex).Height -lt $targetHeight) {
                        $Sheet.Row($RowIndex).Height = $targetHeight
                        $Sheet.Row($RowIndex).CustomHeight = $true
                    }
                } catch { $Sheet.Row($RowIndex).CustomHeight = $false }
            }
        }

        $signRow = 17 + $maxTesters + 3
        $displaySignNeg = $null; $displaySignPos = $null

        if ($signToWrite) {
            $displaySignNeg = $signToWrite
            $displaySignPos = $signToWrite
        } else {
            $displaySignNeg = if ($negSigSet.RawFirst) { $negSigSet.RawFirst } else { '—' }
            $displaySignPos = if ($posSigSet.RawFirst) { $posSigSet.RawFirst } else { '—' }
        }

        $wsOut1.Cells["B$signRow"].Style.Numberformat.Format = '@'
        $wsOut1.Cells["C$signRow"].Style.Numberformat.Format = '@'
        $wsOut1.Cells["B$signRow"].Value = $displaySignNeg
        $wsOut1.Cells["C$signRow"].Value = $displaySignPos

        foreach ($col in @('B','C')) {
            $cell = $wsOut1.Cells["${col}$signRow"]
            Excel-StyleCell $cell $false 'CCFFFF' 'Medium' $null
            $cell.Style.HorizontalAlignment = 'Center'
        }

        try { $wsOut1.Column(2).Width = 40; $wsOut1.Column(3).Width = 40 } catch {}

        if ($sigMismatch) {
            # === MISMATCH: röd markering och detaljtabell med tjock ram ===
            $mismatchCell = $wsOut1.Cells["D$signRow"]
            $mismatchCell.Value = '⚠ Mismatch'
            Excel-StyleCell $mismatchCell $true 'FF0000' 'Medium' 'FFFFFF'

            if ($mismatchSheets.Count -gt 0) {
                # Rubrikrad för mismatch-detaljer
                $headerRow = $signRow + 1
                $wsOut1.Cells["A$headerRow"].Value = 'Fil'
                $wsOut1.Cells["B$headerRow"].Value = 'Signatur'
                $wsOut1.Cells["C$headerRow"].Value = 'Blad'
                foreach ($col in @('A','B','C')) {
                    $hdrCell = $wsOut1.Cells["$col$headerRow"]
                    $hdrCell.Style.Font.Bold = $true
                    $hdrCell.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                    $hdrCell.Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml('#FFE699'))
                    $hdrCell.Style.HorizontalAlignment = [OfficeOpenXml.Style.ExcelHorizontalAlignment]::Center
                }

                $lastDataRow = $headerRow
                for ($j = 0; $j -lt $mismatchSheets.Count; $j++) {
                    $rowIdx = $headerRow + 1 + $j
                    $lastDataRow = $rowIdx
                    $text = $mismatchSheets[$j]

                    # Parsa "NEG: signatur  [Blad: namn]" eller "POS: signatur  [Blad: namn]"
                    $filType = ''; $sigVal = ''; $bladVal = ''
                    if ($text -match '^(NEG|POS):\s*(.+?)\s*\[Blad:\s*(.+?)\]$') {
                        $filType = $matches[1]
                        $sigVal  = $matches[2].Trim()
                        $bladVal = $matches[3].Trim()
                    } else {
                        $sigVal = $text
                    }

                    $wsOut1.Cells["A$rowIdx"].Value = $filType
                    $wsOut1.Cells["B$rowIdx"].Value = $sigVal
                    $wsOut1.Cells["C$rowIdx"].Value = $bladVal
                    # Radbrytning för "Blad" vid signaturmismatch (bättre läsbarhet)
                    try {
                        $cBlad = $wsOut1.Cells["C$rowIdx"]
                        $cBlad.Style.WrapText = $true
                        $cBlad.Style.VerticalAlignment = [OfficeOpenXml.Style.ExcelVerticalAlignment]::Top
                        $wsOut1.Row($rowIdx).CustomHeight = $true
                    } catch {}

                    # Färgkoda per fil + centrera
                    $bgColor = if ($filType -eq 'NEG') { '#B5E6A2' } else { '#FFB3B3' }
                    foreach ($col in @('A','B','C')) {
                        $dataCell = $wsOut1.Cells["$col$rowIdx"]
                        $dataCell.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                        $dataCell.Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml($bgColor))
                        $dataCell.Style.HorizontalAlignment = [OfficeOpenXml.Style.ExcelHorizontalAlignment]::Center
                    }
                }
                
                # === TJOCK YTTRE RAM runt hela mismatch-tabellen ===
                try {
                    $borderColor = [System.Drawing.Color]::FromArgb(0, 0, 0) # SVART
                    
                    # Toppkant på rubrikraden
                    for ($c = 1; $c -le 3; $c++) {
                        $wsOut1.Cells[$headerRow, $c].Style.Border.Top.Style = [OfficeOpenXml.Style.ExcelBorderStyle]::Thick
                        $wsOut1.Cells[$headerRow, $c].Style.Border.Top.Color.SetColor($borderColor)
                    }
                    
                    # Bottenkant på sista dataraden
                    for ($c = 1; $c -le 3; $c++) {
                        $wsOut1.Cells[$lastDataRow, $c].Style.Border.Bottom.Style = [OfficeOpenXml.Style.ExcelBorderStyle]::Thick
                        $wsOut1.Cells[$lastDataRow, $c].Style.Border.Bottom.Color.SetColor($borderColor)
                    }
                    
                    # Vänsterkant på kolumn A (alla rader)
                    for ($r = $headerRow; $r -le $lastDataRow; $r++) {
                        $wsOut1.Cells[$r, 1].Style.Border.Left.Style = [OfficeOpenXml.Style.ExcelBorderStyle]::Thick
                        $wsOut1.Cells[$r, 1].Style.Border.Left.Color.SetColor($borderColor)
                    }
                    
                    # Högerkant på kolumn C (alla rader)
                    for ($r = $headerRow; $r -le $lastDataRow; $r++) {
                        $wsOut1.Cells[$r, 3].Style.Border.Right.Style = [OfficeOpenXml.Style.ExcelBorderStyle]::Thick
                        $wsOut1.Cells[$r, 3].Style.Border.Right.Color.SetColor($borderColor)
                    }
                    
                    # Inre tunna ramar
                    for ($r = $headerRow; $r -le $lastDataRow; $r++) {
                        for ($c = 1; $c -le 3; $c++) {
                            if ($r -lt $lastDataRow) {
                                $wsOut1.Cells[$r, $c].Style.Border.Bottom.Style = [OfficeOpenXml.Style.ExcelBorderStyle]::Thin
                            }
                            if ($c -lt 3) {
                                $wsOut1.Cells[$r, $c].Style.Border.Right.Style = [OfficeOpenXml.Style.ExcelBorderStyle]::Thin
                            }
                        }
                    }
                } catch {}
            }
        } else {
            # === MATCH: grön markering när signaturer stämmer ===
            if ($hasNeg -and $hasPos) {
                $matchCell = $wsOut1.Cells["D$signRow"]
                $matchCell.Value = '✓ Match'
                Excel-StyleCell $matchCell $true 'C6EFCE' 'Medium' '006100'
            }
        }

        # ============================
        # === STF Sum              ===
        # ============================

        $wsOut2 = $pkgOut.Workbook.Worksheets[$Layout.SheetStfSummary]
        if (-not $wsOut2) { Gui-Log "❌ Fliken 'STF Summary' saknas i mallen!"; return }

        $totalRows = $violationsNeg.Count + $violationsPos.Count
        $currentRow = 2

        if ($totalRows -eq 0) {
            Gui-Log "✅ Seal Test hittades"
            $wsOut2.Cells["B1:H1"].Value = $null
            $wsOut2.Cells["A1"].Value = "Inga STF hittades!"
            Excel-StyleCell $wsOut2.Cells["A1"] $true "D9EAD3" "Medium" "006100"
            $wsOut2.Cells["A1"].Style.HorizontalAlignment = "Left"
            if ($wsOut2.Dimension -and $wsOut2.Dimension.End.Row -gt 1) { $wsOut2.DeleteRow(2, $wsOut2.Dimension.End.Row - 1) }
        }
        else {
            Gui-Log "❗ $failNegCount avvikelser i NEG, $failPosCount i POS"

            $oldDataRows = 0
            if ($wsOut2.Dimension) {
                $oldDataRows = $wsOut2.Dimension.End.Row - 1
                if ($oldDataRows -lt 0) { $oldDataRows = 0 }
            }

            if ($totalRows -lt $oldDataRows) {
                $wsOut2.DeleteRow(2 + $totalRows, $oldDataRows - $totalRows)
            }
            elseif ($totalRows -gt $oldDataRows) {
                $wsOut2.InsertRow(2 + $oldDataRows, $totalRows - $oldDataRows, 1 + $oldDataRows)
            }

            $currentRow = 2
            foreach ($v in $violationsNeg) {
                $wsOut2.Cells["A$currentRow"].Value = "NEG"
                $wsOut2.Cells["B$currentRow"].Value = $v.Sheet
                $wsOut2.Cells["C$currentRow"].Value = $v.Cartridge
                $wsOut2.Cells["D$currentRow"].Value = $v.InitialW
                $wsOut2.Cells["E$currentRow"].Value = $v.FinalW
                $wsOut2.Cells["F$currentRow"].Value = [Math]::Round($v.WeightLoss, 1)
                $wsOut2.Cells["G$currentRow"].Value = $v.Status
                $wsOut2.Cells["H$currentRow"].Value = if ([string]::IsNullOrWhiteSpace($v.Obs)) { 'NA' } else { $v.Obs }

                Excel-StyleCell $wsOut2.Cells["A$currentRow"] $true "B5E6A2" "Medium" $null
                $wsOut2.Cells["C$currentRow:E$currentRow"].Style.Fill.PatternType = "Solid"
                $wsOut2.Cells["C$currentRow:E$currentRow"].Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml("#CCFFFF"))
                $wsOut2.Cells["F$currentRow:G$currentRow"].Style.Fill.PatternType = "Solid"
                $wsOut2.Cells["F$currentRow:G$currentRow"].Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml("#FFFF99"))
                $wsOut2.Cells["H$currentRow"].Style.Fill.PatternType = "Solid"
                $wsOut2.Cells["H$currentRow"].Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml("#D9D9D9"))

                if ($v.Status -in @("FAIL","Minusvärde")) {
                    $wsOut2.Cells["F$currentRow"].Style.Font.Bold = $true
                    $wsOut2.Cells["F$currentRow"].Style.Font.Color.SetColor([System.Drawing.Color]::Red)
                    $wsOut2.Cells["G$currentRow"].Style.Font.Bold = $true
                    $wsOut2.Cells["G$currentRow"].Style.Font.Color.SetColor([System.Drawing.Color]::Red)
                    # R3: Röd bakgrund på FAIL-rader för visuell tydlighet
                    if ($v.Status -eq "FAIL") {
                        $wsOut2.Cells["G$currentRow"].Style.Fill.PatternType = "Solid"
                        $wsOut2.Cells["G$currentRow"].Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml("#FFC7CE"))
                    }
                }

                Excel-SetRowBorder -ws $wsOut2 -row $currentRow -firstRow 2 -lastRow ($totalRows + 1)
                $currentRow++
            }

            foreach ($v in $violationsPos) {
                $wsOut2.Cells["A$currentRow"].Value = "POS"
                $wsOut2.Cells["B$currentRow"].Value = $v.Sheet
                $wsOut2.Cells["C$currentRow"].Value = $v.Cartridge
                $wsOut2.Cells["D$currentRow"].Value = $v.InitialW
                $wsOut2.Cells["E$currentRow"].Value = $v.FinalW
                $wsOut2.Cells["F$currentRow"].Value = [Math]::Round($v.WeightLoss, 1)
                $wsOut2.Cells["G$currentRow"].Value = $v.Status
                $wsOut2.Cells["H$currentRow"].Value = if ($v.Obs) { $v.Obs } else { 'NA' }

                Excel-StyleCell $wsOut2.Cells["A$currentRow"] $true "FFB3B3" "Medium" $null
                $wsOut2.Cells["C$currentRow:E$currentRow"].Style.Fill.PatternType = "Solid"
                $wsOut2.Cells["C$currentRow:E$currentRow"].Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml("#CCFFFF"))
                $wsOut2.Cells["F$currentRow:G$currentRow"].Style.Fill.PatternType = "Solid"
                $wsOut2.Cells["F$currentRow:G$currentRow"].Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml("#FFFF99"))
                $wsOut2.Cells["H$currentRow"].Style.Fill.PatternType = "Solid"
                $wsOut2.Cells["H$currentRow"].Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml("#D9D9D9"))

                if ($v.Status -in @("FAIL","Minusvärde")) {
                    $wsOut2.Cells["F$currentRow"].Style.Font.Bold = $true
                    $wsOut2.Cells["F$currentRow"].Style.Font.Color.SetColor([System.Drawing.Color]::Red)
                    $wsOut2.Cells["G$currentRow"].Style.Font.Bold = $true
                    $wsOut2.Cells["G$currentRow"].Style.Font.Color.SetColor([System.Drawing.Color]::Red)
                    # R3: Röd bakgrund på FAIL-rader för visuell tydlighet
                    if ($v.Status -eq "FAIL") {
                        $wsOut2.Cells["G$currentRow"].Style.Fill.PatternType = "Solid"
                        $wsOut2.Cells["G$currentRow"].Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml("#FFC7CE"))
                    }
                }

                Excel-SetRowBorder -ws $wsOut2 -row $currentRow -firstRow 2 -lastRow ($totalRows + 1)
                $currentRow++
            }

            $wsOut2.Cells.Style.WrapText = $false
            $wsOut2.Cells["A1"].Style.HorizontalAlignment = "Left"
            try { $wsOut2.Cells[2,6,([Math]::Max($currentRow-1,2)),6].Style.Numberformat.Format = '0.0' } catch {}
            if ($wsOut2.Dimension) {
                try {
                    if (Get-Command Excel-AutoFitColumnsSafe -ErrorAction SilentlyContinue) {
                        Excel-AutoFitColumnsSafe -Ws $wsOut2 -Context 'OutputSheet'
                    } else {
                        $wsOut2.Cells[$wsOut2.Dimension.Address].AutoFitColumns() | Out-Null
                    }
                } catch {}
            }
        }


        #endregion Build: CSV-inläsning och RuleEngine

        #region Build: Output-flikar (Information, Utrustning, Kontrollmaterial, SP, QC)
# ============================
# === Information-blad     ===
# ============================

try {
    if (-not (Get-Command Add-Hyperlink -ErrorAction SilentlyContinue)) {
        function Add-Hyperlink {
            param(
                [OfficeOpenXml.ExcelRange]$Cell,
                [string]$Text,
                [string]$Url
            )
            try {
                $Cell.Value = $Text
                $Cell.Hyperlink = [Uri]$Url
                $Cell.Style.Font.UnderLine = $true
                $Cell.Style.Font.Color.SetColor([System.Drawing.Color]::FromArgb(0,102,204))
            } catch {}
        }
    }

    if (-not (Get-Command Find-RegexCell -ErrorAction SilentlyContinue)) {
        function Find-RegexCell {
            param(
                [OfficeOpenXml.ExcelWorksheet]$Ws,
                [regex]$Rx,
                [int]$MaxRows = 200,
                [int]$MaxCols = 40
            )
            if (-not $Ws -or -not $Ws.Dimension) { return $null }

            $rMax = [Math]::Min($Ws.Dimension.End.Row, $MaxRows)
            $cMax = [Math]::Min($Ws.Dimension.End.Column, $MaxCols)

            for ($r = 1; $r -le $rMax; $r++) {
                for ($c = 1; $c -le $cMax; $c++) {
                    $t = Normalize-HeaderText ($Ws.Cells[$r,$c].Text + '')
                    if ($t -and $Rx.IsMatch($t)) {
                        return @{ Row = $r; Col = $c; Text = $t }
                    }
                }
            }
            return $null
        }
    }

    if (-not (Get-Command Get-SealHeaderDocInfo -ErrorAction SilentlyContinue)) {
        function Get-SealHeaderDocInfo {
            param([OfficeOpenXml.ExcelPackage]$Pkg)

            $result = [pscustomobject]@{ Raw=''; DocNo=''; Rev='' }
            if (-not $Pkg) { return $result }

            $ws = $Pkg.Workbook.Worksheets | Where-Object { -not (Test-IsSealTestSkipSheet -SheetName $_.Name) } | Select-Object -First 1
            if (-not $ws) { return $result }

            try {
                $lt = ($ws.HeaderFooter.OddHeader.LeftAlignedText + '').Trim()
                if (-not $lt) { $lt = ($ws.HeaderFooter.EvenHeader.LeftAlignedText + '').Trim() }

                $result.Raw = $lt

                $rx = [regex]'(?i)(?:document\s*(?:no|nr|#|number)\s*[:#]?\s*([A-Z0-9\-_\.\/]+))?.*?(?:rev(?:ision)?\.?\s*[:#]?\s*([A-Z0-9\-_\.]+))?'
                $m = $rx.Match($lt)
                if ($m.Success) {
                    if ($m.Groups[1].Value) { $result.DocNo = $m.Groups[1].Value.Trim() }
                    if ($m.Groups[2].Value) { $result.Rev   = $m.Groups[2].Value.Trim() }
                }
            } catch {}

            return $result
        }
    }
    Mark-Phase 'Kontrollmaterial'
    $wsInfo = $pkgOut.Workbook.Worksheets[$Layout.SheetRunInfo]
    if (-not $wsInfo) { $wsInfo = $pkgOut.Workbook.Worksheets.Add($Layout.SheetRunInfo) }

    # Säkerställ att kolumn C (header-/match-info) alltid syns och har rimlig bredd
    try {
        $wsInfo.Column(3).Hidden = $false
        if ($wsInfo.Column(3).Width -lt 22) { $wsInfo.Column(3).Width = 34 }
        $wsInfo.Column(3).Style.WrapText = $true
    } catch {}

    try {
        $csvLines = $null
        $csvStats = $null

        # ✅ Viktigt: initiera alltid, även om ingen CSV är vald
        $csvInstrumentSerials = @()

        if ($selCsv -and (Test-Path -LiteralPath $selCsv)) {
            try { $csvLines = $script:CsvLinesPrimary } catch { Gui-Log ("⚠️ Kunde inte läsa CSV: " + $_.Exception.Message) 'Warn' }
            try { $csvStats = Csv-GetStats -Path $selCsv -Lines $csvLines } catch { Gui-Log ("⚠️ Csv-GetStats: " + $_.Exception.Message) 'Warn' }

            # Hämta exakt lista med Instrument S/N från CSV (för Equipment-blad när WS-skanning är av)
            try {
                if ($csvLines -and $csvLines.Count -gt 8) {
                    $hdr = Csv-SplitFields $csvLines[7]

                    $idx = -1
                    for ($ii=0; $ii -lt $hdr.Count; $ii++) {
                        $h = (($hdr[$ii] + '').Trim('\"').ToLower())
                        if ($h -eq 'instrument s/n' -or $h -match 'instrument') { $idx = $ii; break }
                    }

                    if ($idx -ge 0) {
                        $set = New-Object System.Collections.Generic.HashSet[string]
                        for ($rr=9; $rr -lt $csvLines.Count; $rr++) {
                            $ln = $csvLines[$rr]
                            if (-not $ln -or -not $ln.Trim()) { continue }
                            $f = Csv-SplitFields $ln
                            if ($f.Count -gt $idx) {
                                $v = ($f[$idx] + '').Trim().Trim('\"')
                                if ($v) { $null = $set.Add($v) }
                            }
                        }

                        # HashSet[T]-enumerering (PS 5.1-säker)
                        $csvInstrumentSerials = @($set | Sort-Object)
                    }
                }
            } catch {
                Gui-Log ("⚠️ Kunde inte extrahera Instrument S/N från CSV: " + $_.Exception.Message) 'Warn'
                $csvInstrumentSerials = @()
            }
        }

        if (-not $csvStats) {
            $csvStats = [pscustomobject]@{
                TestCount    = 0
                DupCount     = 0
                Duplicates   = @()
                LspValues    = @()
                LspOK        = $null
                InstrumentByType = [ordered]@{}
            }
        }

        # Statistik för Resample-CSV
        $csvStatsRes = $null
        if ($selCsvRes -and (Test-Path -LiteralPath $selCsvRes)) {
            try {
                $csvLinesRes = $script:CsvLinesResample
                $csvStatsRes = Csv-GetStats -Path $selCsvRes -Lines $csvLinesRes
            } catch { Gui-Log ("⚠️ Resample Csv-GetStats: " + $_.Exception.Message) 'Warn' }
        }

        $infSN = @()
        if ($script:GXINF_Map) {
            foreach ($k in $script:GXINF_Map.Keys) {
                if ($k -like 'Infinity-*') {
                    $infSN += ($script:GXINF_Map[$k].Split(',') | ForEach-Object { ($_ + '').Trim() } | Where-Object { $_ })
                }
            }
        }
        $infSN = $infSN | Select-Object -Unique

        $infSummary = '—'
        try {
            if ($selCsv -and (Test-Path -LiteralPath $selCsv) -and $infSN.Count -gt 0) {
                $infSummary = Get-InfinitySpFromCsvStrict -Path $selCsv -InfinitySerials $infSN -Lines $csvLines
            }
        } catch {
            Gui-Log ("Infinity SP fel: " + $_.Exception.Message) 'Warn'
        }

        # --- Dubbletter Sample ID ---
        $dupSampleCount = 0
        $dupSampleList  = @()
        if ($csvLines -and $csvLines.Count -gt 8) {
            try {
                $headerFields = Csv-SplitFields $csvLines[7]
                $sampleIdx = -1
                for ($i=0; $i -lt $headerFields.Count; $i++) {
                    $hf = ($headerFields[$i] + '').Trim().ToLower()
                    if ($hf -match 'sample') { $sampleIdx = $i; break }
                }
                if ($sampleIdx -ge 0) {
                    $samples = @()
                    for ($r=9; $r -lt $csvLines.Count; $r++) {
                        $line = $csvLines[$r]
                        if (-not $line -or -not $line.Trim()) { continue }
                        $fields = Csv-SplitFields $line
                        if ($fields.Count -gt $sampleIdx) {
                            $val = ($fields[$sampleIdx] + '').Trim()
                            if ($val) { $samples += $val }
                        }
                    }
                    if ($samples.Count -gt 0) {
                        $counts = @{}
                        foreach ($s in $samples) { if (-not $counts.ContainsKey($s)) { $counts[$s] = 0 }; $counts[$s]++ }
                        foreach ($entry in $counts.GetEnumerator()) {
                            if ($entry.Value -gt 1) { $dupSampleList += ("$($entry.Key) x$($entry.Value)") }
                        }
                        $dupSampleCount = $dupSampleList.Count
                    }
                }
            } catch {
                Gui-Log ("⚠️ Fel vid analys av Sample ID: " + $_.Exception.Message) 'Warn'
            }
        }

        $dupSampleText = if ($dupSampleCount -gt 0) {
            $show = ($dupSampleList | Select-Object -First 8) -join ', '
            "$dupSampleCount ($show)"
        } else { 'N/A' }

        $dupCartText = if ($csvStats.DupCount -gt 0) {
            $show = ($csvStats.Duplicates | Select-Object -First 8) -join ', '
            "$($csvStats.DupCount) ($show)"
        } else { 'N/A' }

        # --- LSP-summering ---
        $lspSummary = ''
        try {
            if ($csvLines -and $csvLines.Count -gt 8) {
                $counts = @{}
                for ($rr = 9; $rr -lt $csvLines.Count; $rr++) {
                    $ln = $csvLines[$rr]
                    if (-not $ln -or -not $ln.Trim()) { continue }
                    $fs = Csv-SplitFields $ln
                    if ($fs.Count -gt 4) {
                        $raw = ($fs[4] + '').Trim()
                        if ($raw) {
                            $mLsp = [regex]::Match($raw,'(\d{5})')
                            $code = if ($mLsp.Success) { $mLsp.Groups[1].Value } else { $raw }
                            if (-not $counts.ContainsKey($code)) { $counts[$code] = 0 }
                            $counts[$code]++
                        }
                    }
                }

                if ($counts.Count -gt 0) {
                    $sorted = @($counts.GetEnumerator() | Sort-Object Key)
                    $parts = @()
                    foreach ($kvp in $sorted) {
                        $parts += $(if ($kvp.Value -gt 1) { "$($kvp.Key) x$($kvp.Value)" } else { $kvp.Key })
                    }
                    if ($sorted.Count -eq 1) { $lspSummary = $sorted[0].Key }
                    else { $lspSummary = "$($sorted.Count) (" + ($parts -join ', ') + ")" }
                }
            }
        } catch {
            Gui-Log ("⚠️ Fel vid extraktion av LSP från CSV: " + $_.Exception.Message) 'Warn'
            $lspSummary = ''
        }

        $instText = if ($csvStats.InstrumentByType.Keys.Count -gt 0) {
            ($csvStats.InstrumentByType.GetEnumerator() | ForEach-Object { "$($_.Key)" } | Sort-Object) -join '; '
        } else { '' }

        function Find-InfoRow {
            param([OfficeOpenXml.ExcelWorksheet]$Ws, [string]$Label)
            if (-not $Ws -or -not $Ws.Dimension) { return $null }
            $maxRow = [Math]::Min($Ws.Dimension.End.Row, 300)
            for ($ri=1; $ri -le $maxRow; $ri++) {
                $txt = (($Ws.Cells[$ri,1].Text) + '').Trim()
                if (-not $txt) { continue }
                if ($txt.ToLowerInvariant() -eq $Label.ToLowerInvariant()) { return $ri }
            }
            return $null
        }

        # ✅ Standard: anta INTE nytt layoutläge om vi inte hittar ankaret
        $isNewLayout = $false
        try {
            $tmpRow = Find-InfoRow -Ws $wsInfo -Label 'CSV-Info'
            if ($tmpRow) { $isNewLayout = $true }
        } catch {}

        $rowCsvFile    = Find-InfoRow -Ws $wsInfo -Label 'CSV'
        $rowLsp        = Find-InfoRow -Ws $wsInfo -Label 'LSP'
        $rowAntal      = Find-InfoRow -Ws $wsInfo -Label 'Antal tester'
        $rowDupSample  = Find-InfoRow -Ws $wsInfo -Label 'Dubblett Sample ID'
        if (-not $rowDupSample) { $rowDupSample = Find-InfoRow -Ws $wsInfo -Label 'Dublett Sample ID' }

        $rowDupCart    = Find-InfoRow -Ws $wsInfo -Label 'Dubblett Cartridge S/N'
        if (-not $rowDupCart) { $rowDupCart = Find-InfoRow -Ws $wsInfo -Label 'Dublett Cartridge S/N' }

        $rowInst = Find-InfoRow -Ws $wsInfo -Label 'Använda INF/GX'

        $rowBag = Find-InfoRow -Ws $wsInfo -Label 'Bag Numbers Tested Using Infinity'
        if (-not $rowBag) { $rowBag = Find-InfoRow -Ws $wsInfo -Label 'Bag Numbers Tested Using Infinity:' }
        if (-not $rowBag) { $rowBag = 14 }

        $wsInfo.Cells["B$rowBag"].Style.Numberformat.Format = '@'
        $wsInfo.Cells["B$rowBag"].Value = $infSummary

        if ($isNewLayout) {
            if (-not $rowCsvFile)   { $rowCsvFile   = 8 }
            if (-not $rowLsp)       { $rowLsp       = 9 }
            if (-not $rowAntal)     { $rowAntal     = 10 }
            if (-not $rowDupSample) { $rowDupSample = 11 }
            if (-not $rowDupCart)   { $rowDupCart   = 12 }
            if (-not $rowInst)      { $rowInst      = 13 }
        }

        if ($selCsv -or $selCsvRes) {
            $wsInfo.Cells["B$rowCsvFile"].Style.Numberformat.Format = '@'
            $csvLabel = ''
            if ($selCsv -and $selCsvRes) {
                $csvLabel = "Primary: {0} | Resampling: {1}" -f (Get-CleanLeaf $selCsv), (Get-CleanLeaf $selCsvRes)
            } elseif ($selCsv) {
                $csvLabel = (Get-CleanLeaf $selCsv)
            } else {
                $csvLabel = "Resampling: {0}" -f (Get-CleanLeaf $selCsvRes)
            }
            $wsInfo.Cells["B$rowCsvFile"].Value = $csvLabel
        } else {
            $wsInfo.Cells["B$rowCsvFile"].Value = ''
        }

        $wsInfo.Cells["B$rowLsp"].Style.Numberformat.Format = '@'
        $wsInfo.Cells["B$rowLsp"].Value = $(if ($lspSummary) { $lspSummary } else { $lsp })

        # ✅ Skriv Antal tester EN gång (som text för att inte bli 1.00E+3 etc)
        $wsInfo.Cells["B$rowAntal"].Style.Numberformat.Format = '@'
        $totalTests = [int]$csvStats.TestCount
        $antalText = "$totalTests"
        if ($csvStatsRes -and $csvStatsRes.TestCount -gt 0) {
            $totalTests += [int]$csvStatsRes.TestCount
            $antalText = "$totalTests ($($csvStats.TestCount) + $($csvStatsRes.TestCount) Resample)"
        }
        $wsInfo.Cells["B$rowAntal"].Value = $antalText

        if ($rowDupSample) { $wsInfo.Cells["B$rowDupSample"].Value = $dupSampleText }
        if ($rowDupCart)   { $wsInfo.Cells["B$rowDupCart"].Value   = $dupCartText }

        if ($rowInst) { $wsInfo.Cells["B$rowInst"].Value = $instText }

        try { $wsInfo.Cells['B:B'].Style.WrapText = $false } catch {}
        try { $wsInfo.Column(2).AutoFit() } catch {}
        try {
            if ($wsInfo.Column(2).Width -lt 80) { $wsInfo.Column(2).Width = 80 }
            $wsInfo.Column(2).BestFit = $true
        } catch {}

    } catch {
        Gui-Log ("⚠️ CSV data-fel: " + $_.Exception.Message) 'Warn'
    }

    # --- Makro / dokumentinfo ---
    $assayForMacro = ''
    if ($runAssay) { $assayForMacro = $runAssay }
    elseif ($wsOut1) { $assayForMacro = Excel-GetCellText $wsOut1 $Layout.AssayNameCell }

    $miniVal = ''
    if (Get-Command Get-MinitabMacro -ErrorAction SilentlyContinue) {
        $miniVal = Get-MinitabMacro -AssayName $assayForMacro
    }
    if (-not $miniVal) { $miniVal = 'N/A' }

    $hdNeg = $null; $hdPos = $null
    try { $hdNeg = Get-SealHeaderDocInfo -Pkg $pkgNeg } catch {}
    try { $hdPos = Get-SealHeaderDocInfo -Pkg $pkgPos } catch {}
    if (-not $hdNeg) { $hdNeg = [pscustomobject]@{ Raw=''; DocNo=''; Rev='' } }
    if (-not $hdPos) { $hdPos = [pscustomobject]@{ Raw=''; DocNo=''; Rev='' } }

    $wsInfo.Cells['B2'].Value = $ScriptVersion
    $wsInfo.Cells['B3'].Value = $env:USERNAME
    $wsInfo.Cells['B4'].Value = (Get-Date).ToString('yyyy-MM-dd HH:mm')
    $wsInfo.Cells['B5'].Value = $miniVal

    # --- Batch + länkar ---
    $selLsp = $null
    try {
        if (Get-Variable -Name clbLsp -ErrorAction SilentlyContinue) {
            $selLsp = Get-CheckedFilePath $clbLsp
        }
    } catch {}

    # Snapshot även för Worksheet (om vald) – läsning sker från kopian
    if ($enableStaging -and $stageDir -and $selLsp -and (Test-Path -LiteralPath $selLsp)) {
        try {
            $selLspOrig = $selLsp
            $selLsp = Core-StageInputFileSnapshot -Path $selLsp -StageDir $stageDir -Prefix 'Worksheet'
        } catch {}
    }

    $batchInfo = Get-BatchLinkInfo -SealPosPath $selPos -SealNegPath $selNeg -Lsp $lspForLinks
    $batch     = $batchInfo.Batch

    $wsInfo.Cells['A34'].Value = 'SharePoint Batch'
    $wsInfo.Cells['A34'].Style.Font.Bold = $true
    Add-Hyperlink -Cell $wsInfo.Cells['B34'] -Text $batchInfo.LinkText -Url $batchInfo.Url

    $linkMap = [ordered]@{
        'IPT App'      = 'https://apps.powerapps.com/play/e/default-771c9c47-7f24-44dc-958e-34f8713a8394/a/fd340dbd-bbbf-470b-b043-d2af4cb62c83'
        'MES Login'    = 'http://mes.cepheid.pri/camstarportal/?domain=CEPHEID.COM'
        'CSV Uploader' = 'http://auw2wgxtpap01.cepaws.com/Welcome.aspx'
        'BMRAM'        = 'https://cepheid62468.coolbluecloud.com/'
        'Agile'        = 'https://agileprod.cepheid.com/Agile/default/login-cms.jsp'
    }

    $rowLink = 35
    foreach ($key in $linkMap.Keys) {
        $wsInfo.Cells["A$rowLink"].Value = $key
        Add-Hyperlink -Cell $wsInfo.Cells["B$rowLink"] -Text 'LÄNK' -Url $linkMap[$key]
        $rowLink++
    }

} catch {
    Gui-Log ("⚠️ Run Information fel: " + $_.Exception.Message) 'Warn'
}
                        
# ----------------------------------------------------------------
# WS (LSP-blad): hitta fil och skriv in i Information-bladet
# ----------------------------------------------------------------
try {
    if (-not $selLsp) {
        $probeDir = $null
        if ($selPos) { $probeDir = Split-Path -Parent $selPos }
        if (-not $probeDir -and $selNeg) { $probeDir = Split-Path -Parent $selNeg }

        if ($probeDir -and (Test-Path -LiteralPath $probeDir)) {
            $cand = Get-ChildItem -LiteralPath $probeDir -File -ErrorAction SilentlyContinue |
                    Where-Object {
                        ($_.Name -match '(?i)worksheet') -and
                        ($_.Name -match [regex]::Escape($lsp)) -and
                        ($_.Extension -match '^\.(xlsx|xlsm|xls)$')
                    } |
                    Sort-Object LastWriteTime -Descending |
                    Select-Object -First 1

            if ($cand) { $selLsp = $cand.FullName }
        }
    }

    if (-not (Get-Command Find-LabelValueRightward -ErrorAction SilentlyContinue)) {
        function Find-LabelValueRightward {
            param(
                [OfficeOpenXml.ExcelWorksheet]$Ws,
                [string]$Label,
                [int]$MaxRows = 200,
                [int]$MaxCols = 40
            )
            if (-not $Ws -or -not $Ws.Dimension) { return $null }

            $normLbl = Normalize-HeaderText $Label
            $pat = '^(?i)\s*' + [regex]::Escape($normLbl).Replace('\ ', '\s*') + '\s*[:\.]*\s*$'
            $rx  = [regex]::new($pat, [Text.RegularExpressions.RegexOptions]::IgnoreCase)

            $hit = Find-RegexCell -Ws $Ws -Rx $rx -MaxRows $MaxRows -MaxCols $MaxCols
            if (-not $hit) { return $null }

            $cMax = [Math]::Min($Ws.Dimension.End.Column, $MaxCols)
            for ($c = $hit.Col + 1; $c -le $cMax; $c++) {
                $t = Normalize-HeaderText ($Ws.Cells[$hit.Row,$c].Text + '')
                if ($t) { return $t }
            }
            return $null
        }
    }

    if ($selLsp -and (Test-Path -LiteralPath $selLsp)) {
        $wsLeaf = Get-CleanLeaf $selLsp
        Gui-Log ("🔎 Worksheet: " + $wsLeaf) 'Info'
    } else {
        Gui-Log "ℹ️ Ingen WS-fil vald/hittad (LSP Worksheet). Hoppar över WS-extraktion." 'Info'
    }
} catch {
    Gui-Log ("⚠️ WS-block fel: " + $_.Exception.Message) 'Warn'
}

try {
    # Se till att dessa alltid finns (de används senare)
    $headerWs  = $null
    $headerNeg = $null
    $headerPos = $null
    # OBS: $eqInfo används senare vid Equipment-blad → initiera här
    if (-not (Get-Variable -Name eqInfo -Scope 1 -ErrorAction SilentlyContinue)) {
        $eqInfo = $null
    }

    # --- Återanvänd WS-paketet från Data Summary-skanning om möjligt ---
    $tmpPkg = $null
    $tmpPkgReused = $false
    try {
        if ($selLsp -and (Test-Path -LiteralPath $selLsp)) {
            try {
                if ($script:WsPkg -and $script:WsPkg.File -and
                    $script:WsPkg.File.FullName -ieq (Resolve-Path -LiteralPath $selLsp -ErrorAction SilentlyContinue).Path) {
                    $tmpPkg = $script:WsPkg
                    $tmpPkgReused = $true
                } else {
                    # Sökväg ändrades (borde inte hända), öppna ny
                    if ($script:WsPkg) { try { $script:WsPkg.Dispose() } catch {} }
                    $script:WsPkg = $null
                    $tmpPkg = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($selLsp))
                }

                # ==============================
                # Utrustning / TestSummary
                # ==============================
                try {
                    # "EquipmentSheet" ska endast generera själva BLADET/mallen.
                    # Det ska *inte* automatiskt hämta pipetter/instrument från Test Summary/CSV här,
                    # annars blir det en blandning (automatiskt + manuellt) som förvirrar användaren.
                    if ($Config -and $Config.Contains('EnableEquipmentSheet') -and -not $Config.EnableEquipmentSheet) {
                        $eqInfo = $null
                        Gui-Log 'ℹ️ Utrustningslista avstängt. Hoppar över.' 'Info'
                    } else {
                        $eqInfo = $null
                        Gui-Log '✅ Utrustningslista hämtad.' 'Info' 'PROGRESS'
                    }
                } catch {
                    # Utrustning ska aldrig få stoppa rapporten
                    try { Gui-Log ("⚠️ Utrustningslista: kunde inte hämtas: " + $_.Exception.Message) 'Warn' } catch {}
                    $eqInfo = $null
                }

                # ==============================
                # Bladrubrik (extrahera + jämför)
                # ==============================
                try {
                    $headerWs = Extract-WorksheetHeader -Pkg $tmpPkg
                } catch {
                    $headerWs = $null
                }

                # Reservväg om extrahering gav null: skapa tomt objekt så .PartNo osv inte kraschar
                if (-not $headerWs) {
                    $headerWs = [pscustomobject]@{
                        WorksheetName   = ''
                        PartNo          = ''
                        BatchNo         = ''
                        CartridgeNo     = ''
                        DocumentNumber  = ''
                        Rev             = ''
                        Effective       = ''
                        Attachment      = ''
                    }
                }

                # StrictMode-säker: används senare även om jämförelsen misslyckas
                $wsHeaderCheck = $null

                try {
                    $wsHeaderRows  = Get-WorksheetHeaderPerSheet -Pkg $tmpPkg
                    $wsHeaderCheck = Compare-WorksheetHeaderSet   -Rows $wsHeaderRows
                    try {
                        if ($wsHeaderCheck.Issues -gt 0 -and $wsHeaderCheck.Summary) {
                            Gui-Log ("⚠️ Worksheet header-avvikelser: {0} – se Run Information!" -f $wsHeaderCheck.Summary) 'Warn'
                        } else {
                            Gui-Log "✅ Worksheet header korrekt" 'Info' 'PROGRESS'
                        }
                    } catch {}
                } catch {
                    try { Gui-Log ("⚠️ Worksheet header-jämförelse: " + $_.Exception.Message) 'Warn' } catch {}
                }

                # ==============================
                # Förstärk headerWs via etiketter (om extrahering missade)
                # ==============================
                try {
                    $wsLsp = $tmpPkg.Workbook.Worksheets | Where-Object { -not (Test-IsWorksheetHeaderSkipSheet -SheetName $_.Name) } | Select-Object -First 1
                    if (-not $wsLsp) {
                        $wsLsp = $tmpPkg.Workbook.Worksheets | Where-Object { -not (Test-IsSealTestSkipSheet -SheetName $_.Name) } | Select-Object -First 1
                    }
                    if ($wsLsp) {

                        if (-not $headerWs.PartNo) {
                            $val = $null
                            $labels = @('Part No.','Part No.:','Part No','Part Number','Part Number:','Part Number.','Part Number.:')
                            foreach ($lbl in $labels) { $val = Find-LabelValueRightward -Ws $wsLsp -Label $lbl; if ($val) { break } }
                            if ($val) { $headerWs.PartNo = $val }
                        }

                        if (-not $headerWs.BatchNo) {
                            $val = $null
                            $labels = @(
                                'Batch No(s)','Batch No(s).','Batch No(s):','Batch No(s).:',
                                'Batch No','Batch No.','Batch No:','Batch No.:',
                                'Batch Number','Batch Number.','Batch Number:','Batch Number.:'
                            )
                            foreach ($lbl in $labels) { $val = Find-LabelValueRightward -Ws $wsLsp -Label $lbl; if ($val) { break } }
                            if ($val) { $headerWs.BatchNo = $val }
                        }

                        if (-not $headerWs.CartridgeNo -or $headerWs.CartridgeNo -eq '.') {
                            $val = $null
                            $labels = @(
                                'Cartridge No. (LSP)','Cartridge No. (LSP):','Cartridge No. (LSP) :',
                                'Cartridge No (LSP)','Cartridge No (LSP):','Cartridge No (LSP) :',
                                'Cartridge Number (LSP)','Cartridge Number (LSP):','Cartridge Number (LSP) :',
                                'Cartridge No.','Cartridge No.:','Cartridge No. :','Cartridge No :',
                                'Cartridge Number','Cartridge Number:','Cartridge Number :',
                                'Cartridge No','Cartridge No:','Cartridge No :'
                            )
                            foreach ($lbl in $labels) { $val = Find-LabelValueRightward -Ws $wsLsp -Label $lbl; if ($val) { break } }

                            if (-not $val) {
                                $rxCart = [regex]::new('(?i)Cartridge.*\(LSP\)')
                                $maxCols = [Math]::Min($wsLsp.Dimension.End.Column, 100)
                                $hitCart = Find-RegexCell -Ws $wsLsp -Rx $rxCart -MaxRows 200 -MaxCols $maxCols
                                if ($hitCart) {
                                    for ($c = $hitCart.Col + 1; $c -le $wsLsp.Dimension.End.Column; $c++) {
                                        $cellVal = ($wsLsp.Cells[$hitCart.Row, $c].Text + '').Trim()
                                        if ($cellVal) { $val = $cellVal; break }
                                    }
                                }
                            }

                            if ($val) { $headerWs.CartridgeNo = $val }
                        }

                        if (-not $headerWs.Effective) {
                            $val = Find-LabelValueRightward -Ws $wsLsp -Label 'Effective'
                            if (-not $val) { $val = Find-LabelValueRightward -Ws $wsLsp -Label 'Effective Date' }
                            if ($val) { $headerWs.Effective = $val }
                        }
                    }
                } catch {}

                # Filnamnsreserv för CartridgeNo om fältet fortfarande är tomt
                try {
                    if ($selLsp -and (-not $headerWs.CartridgeNo -or $headerWs.CartridgeNo -eq '.' -or $headerWs.CartridgeNo -eq '')) {
                        $fn = Split-Path $selLsp -Leaf
                        $m = [regex]::Matches($fn, '(?<!\d)(\d{5,7})(?!\d)')
                        if ($m.Count -gt 0) { $headerWs.CartridgeNo = $m[0].Groups[1].Value }
                    }
                } catch {}

                # ==============================
                # QC-påminnelse – HIV/HBV/HCV-assays (läser Test Summary B3 medan $tmpPkg är öppen)
                # ==============================
                $script:QcReminderB3 = $null
                try {
                    $qcTriggerAssays = @(
                        'Xpert_HIV-1 Viral Load',
                        'Xpert HIV-1 Viral Load XC',
                        'Xpert_HCV Viral Load',
                        'Xpert HCV VL Fingerstick',
                        'Xpert HBV Viral Load',
                        'Xpert_HIV-1 Qual',
                        'HIV-1_Qual RUO',
                        'HIV-1 Qual XC DBS RUO',
                        'HIV-1 Qual XC DBS IUO',
                        'Xpert HIV-1 Qual XC PQC',
                        'Xpert HIV-1 Qual XC PQC RUO'


                    )
                    $qcValidPartNos = @(
                        'GXHIV-VL-CE-10','GXHIV-VL-IN-10','GXHIV-VL-CN-10',
                        'GXHIV-VL-XC-CE-10','GXHCV-VL-CE-10','GXHCV-VL-IN-10',
                        'GXHCV-FS-CE-10','GXHBV-VL-CE-10',
                        'GXHIV-QA-CE-10','RHIVQ-10'
                        '700-6098/HIV-1 QUAL XC, RUO','700-6137/HIV-1 QUAL XC, IUO',
                        '700-6793/ HIV-1 QUAL XC, CE-IVD','700-6911/ HIV-1 QUAL XC, RUO'
                    )

                    $qcAssayMatch = $false
                    if ($runAssay) {
                        foreach ($_qa in $qcTriggerAssays) {
                            if ($runAssay -ilike "$_qa*") { $qcAssayMatch = $true; break }
                        }
                    }

                    if ($qcAssayMatch) {
                        $tsWs = $tmpPkg.Workbook.Worksheets | Where-Object { $_.Name -ieq 'Test Summary' } | Select-Object -First 1
                        if ($tsWs) {
                            $b3Val = Excel-GetCellText $tsWs 'B3'
                            if ($b3Val -and ($qcValidPartNos -contains $b3Val)) {
                                $script:QcReminderB3 = $b3Val
                                Gui-Log ("🔬 QC Reminder: Assay={0}, Test Summary B3={1} → aktiverad" -f $runAssay, $b3Val) 'Info'
                            } else {
                                Gui-Log ("ℹ️ QC Reminder: Assay matchar men B3='{0}' ej i listan → hoppar över." -f $b3Val) 'Info'
                            }
                        } else {
                            Gui-Log "ℹ️ QC Reminder: Assay matchar men 'Test Summary'-blad saknas i Worksheet." 'Info'
                        }
                    }
                } catch {
                    Gui-Log ("⚠️ QC Reminder (läsning): " + $_.Exception.Message) 'Warn'
                }

            } catch {
                # Om WS öppnas men något inne fallerar: låt det inte döda hela rapporten
                Gui-Log ("⚠️ WS-parse fel: " + $_.Exception.Message) 'Warn'
            }
        }
    } finally {
        # Frigör WS-paketet (nollställ $script:WsPkg oavsett om det återanvändes)
        if ($tmpPkg) { try { $tmpPkg.Dispose() } catch {} }
        $script:WsPkg = $null
        $tmpPkg = $null
    }

    # SealTest-rubriker
    try { $headerNeg = Extract-SealTestHeader -Pkg $pkgNeg } catch {}
    try { $headerPos = Extract-SealTestHeader -Pkg $pkgPos } catch {}

    # Reserv för Effective i Seal POS/NEG om fält saknas
    try {
        if ($pkgPos -and $headerPos -and -not $headerPos.Effective) {
            $wsPos = $pkgPos.Workbook.Worksheets | Where-Object { -not (Test-IsSealTestSkipSheet -SheetName $_.Name) } | Select-Object -First 1
            if ($wsPos) {
                $val = Find-LabelValueRightward -Ws $wsPos -Label 'Effective'
                if (-not $val) { $val = Find-LabelValueRightward -Ws $wsPos -Label 'Effective Date' }
                if ($val) { $headerPos.Effective = $val }
            }
        }
    } catch {}

    try {
        if ($pkgNeg -and $headerNeg -and -not $headerNeg.Effective) {
            $wsNeg = $pkgNeg.Workbook.Worksheets | Where-Object { -not (Test-IsSealTestSkipSheet -SheetName $_.Name) } | Select-Object -First 1
            if ($wsNeg) {
                $val = Find-LabelValueRightward -Ws $wsNeg -Label 'Effective'
                if (-not $val) { $val = Find-LabelValueRightward -Ws $wsNeg -Label 'Effective Date' }
                if ($val) { $headerNeg.Effective = $val }
            }
        }
    } catch {}

    # --------------------------
    # Rubriksammanfattning → Information
    # --------------------------
    try {
        $wsBatch   = if ($headerWs -and $headerWs.BatchNo) { $headerWs.BatchNo } else { $null }
        $sealBatch = $batch
        if (-not $sealBatch) {
            try { if ($selPos) { $sealBatch = Get-BatchNumberFromSealFile $selPos } } catch {}
            if (-not $sealBatch) { try { if ($selNeg) { $sealBatch = Get-BatchNumberFromSealFile $selNeg } } catch {} }
        }

        $rowWsFile = Find-InfoRow -Ws $wsInfo -Label 'Worksheet'
        if (-not $rowWsFile) { $rowWsFile = 17 }
        $rowPart  = $rowWsFile + 1
        $rowBatch = $rowWsFile + 2
        $rowCart  = $rowWsFile + 3
        $rowDoc   = $rowWsFile + 4
        $rowRev   = $rowWsFile + 5
        $rowEff   = $rowWsFile + 6

        $rowPosFile = Find-InfoRow -Ws $wsInfo -Label 'Seal Test POS'
        if (-not $rowPosFile) { $rowPosFile = $rowWsFile + 7 }
        $rowPosDoc = $rowPosFile + 1
        $rowPosRev = $rowPosFile + 2
        $rowPosEff = $rowPosFile + 3

        $rowNegFile = Find-InfoRow -Ws $wsInfo -Label 'Seal Test NEG'
        if (-not $rowNegFile) { $rowNegFile = $rowPosFile + 4 }
        $rowNegDoc = $rowNegFile + 1
        $rowNegRev = $rowNegFile + 2
        $rowNegEff = $rowNegFile + 3

        if ($selLsp) {
            $wsInfo.Cells["B$rowWsFile"].Style.Numberformat.Format = '@'
            $wsInfo.Cells["B$rowWsFile"].Value = (Get-CleanLeaf $selLsp)
        } else {
            $wsInfo.Cells["B$rowWsFile"].Value = ''
        }

        $consPart  = Get-ConsensusValue -Type 'Part'      -Ws $headerWs.PartNo      -Pos $headerPos.PartNumber   -Neg $headerNeg.PartNumber
        $consBatch = Get-ConsensusValue -Type 'Batch'     -Ws $headerWs.BatchNo     -Pos $headerPos.BatchNumber  -Neg $headerNeg.BatchNumber
        $consCart  = Get-ConsensusValue -Type 'Cartridge' -Ws $headerWs.CartridgeNo -Pos $headerPos.CartridgeNo  -Neg $headerNeg.CartridgeNo

        if (-not $consCart.Value -and $selLsp) {
            $fnCart = Split-Path $selLsp -Leaf
            $mCart  = [regex]::Match($fnCart,'(?<!\d)(\d{5,7})(?!\d)')
            if ($mCart.Success) {
                $consCart = @{ Value=$mCart.Groups[1].Value; Source='FILENAME'; Note='Filename fallback' }
            }
        }

        $wsInfo.Cells["B$rowPart"].Value  = if ($consPart.Value)  { $consPart.Value }  else { '' }
        $wsInfo.Cells["B$rowBatch"].Value = if ($consBatch.Value) { $consBatch.Value } else { '' }
        $wsInfo.Cells["B$rowCart"].Value  = if ($consCart.Value)  { $consCart.Value }  else { '' }

        # wsHeaderCheck → skriv Match/Mismatch i C-kolumn för Part/Batch/Cartridge
        try {
            $StyleMismatchCell = {
                param($Cell, $Text)
                $Cell.Style.Numberformat.Format = '@'
                $Cell.Value = '⚠ ' + $Text
                $Cell.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                $Cell.Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml('#FFCCCC'))
                $Cell.Style.Font.Bold = $true
                $Cell.Style.Font.Color.SetColor([System.Drawing.Color]::DarkRed)
            }

            $StyleMatchCell = {
                param($Cell)
                $Cell.Style.Numberformat.Format = '@'
                $Cell.Value = '✓ Alla flikar matchar'
                $Cell.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                $Cell.Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml('#C6EFCE'))
                $Cell.Style.Font.Bold = $true
                $Cell.Style.Font.Color.SetColor([System.Drawing.ColorTranslator]::FromHtml('#006100'))
            }

            $devPart = $null; $devBatch = $null; $devCart = $null

            if ($wsHeaderCheck -and $wsHeaderCheck.Details) {
                $linesDev = ($wsHeaderCheck.Details -split "`r?`n")
                foreach ($ln in $linesDev) {
                    if ($ln -match '^-\s*PartNo[^:]*:\s*(.+)$')      { $devPart  = $matches[1].Trim() }
                    elseif ($ln -match '^-\s*BatchNo[^:]*:\s*(.+)$') { $devBatch = $matches[1].Trim() }
                    elseif ($ln -match '^-\s*CartridgeNo[^:]*:\s*(.+)$') { $devCart = $matches[1].Trim() }
                }
            }

            if ($wsHeaderCheck) {
                if ($devPart)  { & $StyleMismatchCell $wsInfo.Cells["C$rowPart"]  ('Avvikande: ' + $devPart) }
                else           { & $StyleMatchCell $wsInfo.Cells["C$rowPart"] }
                
                if ($devBatch) { & $StyleMismatchCell $wsInfo.Cells["C$rowBatch"] ('Avvikande: ' + $devBatch) }
                else           { & $StyleMatchCell $wsInfo.Cells["C$rowBatch"] }
                
                if ($devCart)  { & $StyleMismatchCell $wsInfo.Cells["C$rowCart"]  ('Avvikande: ' + $devCart) }
                else           { & $StyleMatchCell $wsInfo.Cells["C$rowCart"] }
            }
        } catch {}

        if ($headerWs) {
            $doc = $headerWs.DocumentNumber
            if ($doc) { $doc = ($doc -replace '(?i)\s+(?:Rev(?:ision)?|Effective|p\.)\b.*$', '').Trim() }
            if ($headerWs.Attachment -and ($doc -notmatch '(?i)\bAttachment\s+\w+\b')) {
                $doc = "$doc Attachment $($headerWs.Attachment)"
            }
            $wsInfo.Cells["B$rowDoc"].Value = $doc
            $wsInfo.Cells["B$rowRev"].Value = $headerWs.Rev
            $wsInfo.Cells["B$rowEff"].Value = $headerWs.Effective
            
            if ($wsHeaderCheck -and $doc) { & $StyleMatchCell $wsInfo.Cells["C$rowDoc"] }
            if ($wsHeaderCheck -and $headerWs.Rev) { & $StyleMatchCell $wsInfo.Cells["C$rowRev"] }
            if ($wsHeaderCheck -and $headerWs.Effective) { & $StyleMatchCell $wsInfo.Cells["C$rowEff"] }
        } else {
            $wsInfo.Cells["B$rowDoc"].Value = ''
            $wsInfo.Cells["B$rowRev"].Value = ''
            $wsInfo.Cells["B$rowEff"].Value = ''
        }

        if ($selPos) {
            $wsInfo.Cells["B$rowPosFile"].Style.Numberformat.Format = '@'
            $wsInfo.Cells["B$rowPosFile"].Value = (Get-CleanLeaf $selPos)
        } else { $wsInfo.Cells["B$rowPosFile"].Value = '' }

        if ($headerPos) {
            $docPos = $headerPos.DocumentNumber
            if ($docPos) { $docPos = ($docPos -replace '(?i)\s+(?:Rev(?:ision)?|Effective|p\.)\b.*$','').Trim() }
            $wsInfo.Cells["B$rowPosDoc"].Value = $docPos
            $wsInfo.Cells["B$rowPosRev"].Value = $headerPos.Rev
            $wsInfo.Cells["B$rowPosEff"].Value = $headerPos.Effective

            $posHeaderCheck = $null
            try { $posHeaderCheck = $headerPos.HeaderCheck } catch {}
            $devPosDoc = $null; $devPosRev = $null; $devPosEff = $null

            if ($posHeaderCheck -and $posHeaderCheck.Details) {
                $linesDev = ($posHeaderCheck.Details -split "`r?`n")
                foreach ($ln in $linesDev) {
                    if ($ln -match '^-\s*DocumentNumber[^|]*\|\s*avvikande flikar:\s*(.+)$') { $devPosDoc = $matches[1].Trim() }
                    elseif ($ln -match '^-\s*Rev[^|]*\|\s*avvikande flikar:\s*(.+)$') { $devPosRev = $matches[1].Trim() }
                    elseif ($ln -match '^-\s*Effective[^|]*\|\s*avvikande flikar:\s*(.+)$') { $devPosEff = $matches[1].Trim() }
                }
            }

            if ($posHeaderCheck) {
                if ($docPos) {
                    if ($devPosDoc) { & $StyleMismatchCell $wsInfo.Cells["C$rowPosDoc"] ('Avvikande flikar: ' + $devPosDoc) }
                    else { & $StyleMatchCell $wsInfo.Cells["C$rowPosDoc"] }
                }
                if ($headerPos.Rev) {
                    if ($devPosRev) { & $StyleMismatchCell $wsInfo.Cells["C$rowPosRev"] ('Avvikande flikar: ' + $devPosRev) }
                    else { & $StyleMatchCell $wsInfo.Cells["C$rowPosRev"] }
                }
                if ($headerPos.Effective) {
                    if ($devPosEff) { & $StyleMismatchCell $wsInfo.Cells["C$rowPosEff"] ('Avvikande flikar: ' + $devPosEff) }
                    else { & $StyleMatchCell $wsInfo.Cells["C$rowPosEff"] }
                }
            } else {
            }
        } else {
            $wsInfo.Cells["B$rowPosDoc"].Value = ''
            $wsInfo.Cells["B$rowPosRev"].Value = ''
            $wsInfo.Cells["B$rowPosEff"].Value = ''
        }

        if ($selNeg) {
            $wsInfo.Cells["B$rowNegFile"].Style.Numberformat.Format = '@'
            $wsInfo.Cells["B$rowNegFile"].Value = (Get-CleanLeaf $selNeg)
        } else { $wsInfo.Cells["B$rowNegFile"].Value = '' }

        if ($headerNeg) {
            $docNeg = $headerNeg.DocumentNumber
            if ($docNeg) { $docNeg = ($docNeg -replace '(?i)\s+(?:Rev(?:ision)?|Effective|p\.)\b.*$','').Trim() }
            $wsInfo.Cells["B$rowNegDoc"].Value = $docNeg
            $wsInfo.Cells["B$rowNegRev"].Value = $headerNeg.Rev
            $wsInfo.Cells["B$rowNegEff"].Value = $headerNeg.Effective
            
            $negHeaderCheck = $null
            try { $negHeaderCheck = $headerNeg.HeaderCheck } catch {}
            $devNegDoc = $null; $devNegRev = $null; $devNegEff = $null

            if ($negHeaderCheck -and $negHeaderCheck.Details) {
                $linesDev = ($negHeaderCheck.Details -split "`r?`n")
                foreach ($ln in $linesDev) {
                    if ($ln -match '^-\s*DocumentNumber[^|]*\|\s*avvikande flikar:\s*(.+)$') { $devNegDoc = $matches[1].Trim() }
                    elseif ($ln -match '^-\s*Rev[^|]*\|\s*avvikande flikar:\s*(.+)$') { $devNegRev = $matches[1].Trim() }
                    elseif ($ln -match '^-\s*Effective[^|]*\|\s*avvikande flikar:\s*(.+)$') { $devNegEff = $matches[1].Trim() }
                }
            }

            if ($negHeaderCheck) {
                if ($docNeg) {
                    if ($devNegDoc) { & $StyleMismatchCell $wsInfo.Cells["C$rowNegDoc"] ('Avvikande flikar: ' + $devNegDoc) }
                    else { & $StyleMatchCell $wsInfo.Cells["C$rowNegDoc"] }
                }
                if ($headerNeg.Rev) {
                    if ($devNegRev) { & $StyleMismatchCell $wsInfo.Cells["C$rowNegRev"] ('Avvikande flikar: ' + $devNegRev) }
                    else { & $StyleMatchCell $wsInfo.Cells["C$rowNegRev"] }
                }
                if ($headerNeg.Effective) {
                    if ($devNegEff) { & $StyleMismatchCell $wsInfo.Cells["C$rowNegEff"] ('Avvikande flikar: ' + $devNegEff) }
                    else { & $StyleMatchCell $wsInfo.Cells["C$rowNegEff"] }
                }
            } else {
            }
        } else {
            $wsInfo.Cells["B$rowNegDoc"].Value = ''
            $wsInfo.Cells["B$rowNegRev"].Value = ''
            $wsInfo.Cells["B$rowNegEff"].Value = ''
        }

    } catch {
        Gui-Log ("⚠️ Header summary fel: " + $_.Exception.Message) 'Warn'
    }

} catch {
    Gui-Log "⚠️ Run Information fel: $($_.Exception.Message)" 'Warn'
}

# ============================
# === Utrustningsblad      ===
# ============================
Mark-Phase 'SealTestInfo'
# OBS: Endast mall kopieras - ingen automatisk ifyllning av pipetter/instrument.
# Användaren fyller i manuellt i output-filen.
if ($Config -and $Config.Contains('EnableEquipmentSheet') -and -not $Config.EnableEquipmentSheet) {
    Gui-Log 'ℹ️ Utrustningslista avstängt. Hoppar över.' 'Info'
} else {
    try {
        if (Test-Path -LiteralPath $UtrustningListPath) {
            $srcPkg = $null
            try {
                $srcPkg = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($UtrustningListPath))

                $srcWs = $srcPkg.Workbook.Worksheets['Sheet1']
                if (-not $srcWs) { $srcWs = $srcPkg.Workbook.Worksheets[1] }

                if ($srcWs) {
                    # Ta bort befintlig flik om den finns
                    $wsEq = $pkgOut.Workbook.Worksheets[$Layout.SheetUtrustning]
                    if ($wsEq) { $pkgOut.Workbook.Worksheets.Delete($wsEq) }

                    # Kopiera mallen som en ny flik
                    $wsEq = $pkgOut.Workbook.Worksheets.Add($Layout.SheetUtrustning, $srcWs)

                    # Ta bort formler och behåll bara värden
                    if ($wsEq.Dimension) {
                        foreach ($cell in $wsEq.Cells[$wsEq.Dimension.Address]) {
                            if ($cell.Formula -or $cell.FormulaR1C1) {
                                $val = $cell.Value
                                $cell.Formula     = $null
                                $cell.FormulaR1C1 = $null
                                $cell.Value       = $val
                            }
                        }
                        # Kopiera kolumnbredder
                        $colCount = $srcWs.Dimension.End.Column
                        for ($c = 1; $c -le $colCount; $c++) {
                            try { $wsEq.Column($c).Width = $srcWs.Column($c).Width } catch {}
                        }
                    }
                    Gui-Log "✅ Utrustningslista kopierad." 'Info' 'PROGRESS'
                }
            } finally {
                if ($srcPkg) { try { $srcPkg.Dispose() } catch {} }
            }
        } else {
            Gui-Log ("ℹ️ Utrustningslista saknas: $UtrustningListPath") 'Info'
        }
    } catch {
        Gui-Log "⚠️ Kunde inte skapa Utrustningslista-flik: $($_.Exception.Message)" 'Warn'
    }
}

# ============================
# === Kontrollmaterial     ===
# ============================
Mark-Phase 'Equipment'

try {
    if ($controlTab -and (Test-Path -LiteralPath $RawDataPath)) {
        $srcPkg = $null
        try {
            $srcPkg = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($RawDataPath))
            try { $srcPkg.Workbook.Calculate() } catch {}

            $candidates = if ($controlTab -match '\|') {
                $controlTab -split '\|' | ForEach-Object { $_.Trim() } | Where-Object { $_ }
            } else { @($controlTab) }

            $srcWs = $null
            foreach ($cand in $candidates) {
                $srcWs = $srcPkg.Workbook.Worksheets | Where-Object { $_.Name -eq $cand } | Select-Object -First 1
                if ($srcWs) { break }
                $srcWs = $srcPkg.Workbook.Worksheets | Where-Object { $_.Name -like "*$cand*" } | Select-Object -First 1
                if ($srcWs) { break }
            }

            if ($srcWs) {
                $safeName = if ($srcWs.Name.Length -gt 31) { $srcWs.Name.Substring(0,31) } else { $srcWs.Name }
                $destName = $safeName; $n = 1
                while ($pkgOut.Workbook.Worksheets[$destName]) {
                    $base = if ($safeName.Length -gt 27) { $safeName.Substring(0,27) } else { $safeName }
                    $destName = "$base($n)"; $n++
                }

                $wsCM = $pkgOut.Workbook.Worksheets.Add($destName, $srcWs)
                if ($wsCM.Dimension) {
                    foreach ($cell in $wsCM.Cells[$wsCM.Dimension.Address]) {
                        if ($cell.Formula -or $cell.FormulaR1C1) {
                            $v = $cell.Value
                            $cell.Formula = $null
                            $cell.FormulaR1C1 = $null
                            $cell.Value = $v
                        }
                    }
                    try {
                        if (Get-Command Excel-AutoFitColumnsSafe -ErrorAction SilentlyContinue) {
                            Excel-AutoFitColumnsSafe -Ws $wsCM -Context 'ControlMaterial'
                        } else {
                            $wsCM.Cells[$wsCM.Dimension.Address].AutoFitColumns() | Out-Null
                        }
                    } catch {}
                }

                if ($srcWs.Name -ne $destName) {
                    Gui-Log "✅ Kontrollmaterial: '$($srcWs.Name)' → '$destName'" 'Info'
                if ($srcWs.Name -ne $destName) {
                    Gui-Log "✅ Kontrollmaterial: '$($srcWs.Name)' → '$destName'" 'Info'
                } else {
                    Gui-Log "✅ Kontrollmaterial: '$destName'" 'Info' 'PROGRESS'
                }
                } else {
                    Gui-Log "✅ Kontrollmaterial: '$destName'" 'Info' 'PROGRESS'
                }
            } else {
                Gui-Log "ℹ️ Hittade inget blad i kontrollfilen som matchar '$controlTab'." 'Info'
            }
        } finally {
            if ($srcPkg) { try { $srcPkg.Dispose() } catch {} }
        }
    } else {
        Gui-Log "ℹ️ Ingen Control-flik skapad (saknar mappning eller kontrollfil)." 'Info'
    }
} catch {
    Gui-Log "⚠️ Control Material-fel: $($_.Exception.Message)" 'Warn'
}

# ============================
# === SharePoint Info      ===
# ============================
try {
    $skipSpInfo = -not $global:SpEnabled

    if ($skipSpInfo) {
        Gui-Log "ℹ️ SharePoint Info avstängt i konfigurationen – hoppar över." 'Info'
        try {
            $old = $pkgOut.Workbook.Worksheets["SharePoint Info"]
            if ($old) { $pkgOut.Workbook.Worksheets.Delete($old) }
        } catch {}
    } else {

        $spOk = $false
        $spStatus = Get-SPClientStatus
        if ($spStatus.Connected) { $spOk = $true }

        if (-not $spOk) {
            # Om manuell anslutning är valt: detta är normalt tills användaren klickar "🔌 Anslut SP".
            if ($global:SpEnabled -and (-not $global:SpAutoConnect)) {
                Gui-Log "ℹ️ SharePoint ej anslutet (manuellt läge). Klicka '🔌 Anslut SP' för att hämta SharePoint-data." 'Info'
            }
            else {
                $errMsg = if ($global:SpError) { $global:SpError } else { 'Okänt fel' }
                Gui-Log ("⚠️ SharePoint ej tillgängligt: $errMsg") 'Warn'
            }
        }

        $batchInfo = Get-BatchLinkInfo -SealPosPath $selPos -SealNegPath $selNeg -Lsp $lspForLinks
        $batch = $batchInfo.Batch

        # Startcell för SharePoint Info-blocket i bladet 'Information' (konfigurerbart)
        $spStartCell = $null
        try { $spStartCell = Get-ConfigValue -Name 'SharePointInfoStartCell' -Default $Layout.SpInfoStartCell } catch { $spStartCell = $Layout.SpInfoStartCell }
        $spRc = Convert-A1ToRowCol -A1 $spStartCell -DefaultRow 1 -DefaultCol 5
        $spStartRow = $spRc.Row
        $spStartCol = $spRc.Col


        if (-not $batch) {
            Gui-Log "ℹ️ Inget Batch # i POS/NEG – skriver SharePoint Info i 'Run Information'." 'Info'

            # Skriv tomt block (1:1 layout) in i Information (till höger)
            [void](Write-SPBlockIntoInformation -Pkg $pkgOut -Rows @() -Batch '—' -TargetSheetName $Layout.SheetRunInfo -StartRow $spStartRow -StartCol $spStartCol)

            # Säkerställ att separat flik inte finns kvar (banta rapporten)
            try {
                $old = $pkgOut.Workbook.Worksheets["SharePoint Info"]
                if ($old) { $pkgOut.Workbook.Worksheets.Delete($old) }
            } catch {}
        } else {
            Gui-Log "🔎 Batch hittad: $batch" 'Info'

            $fields = @(
                'Work_x0020_Center','Title','Batch_x0023_','SAP_x0020_Batch_x0023__x0020_2',
                'LSP','Material','BBD_x002f_SLED','Actual_x0020_startdate_x002f__x0',
                'PAL_x0020__x002d__x0020_Sample_x','Sample_x0020_Reagent_x0020_P_x00',
                'Order_x0020_quantity','Total_x0020_good','ITP_x0020_Test_x0020_results',
                'IPT_x0020__x002d__x0020_Testing_0','MES_x0020__x002d__x0020_Order_x0'
            )
            $renameMap = @{
                'Work Center'            = 'Work Center'
                'Title'                  = 'Order#'
                'Batch#'                 = 'SAP Batch#'
                'SAP Batch# 2'           = 'SAP Batch# 2'
                'LSP'                    = 'LSP'
                'Material'               = 'Material'
                'BBD/SLED'               = 'BBD/SLED'
                'Actual startdate/_x0'   = 'ROBAL - Actual start date/time'
                'PAL - Sample_x'         = 'Sample Reagent use'
                'Sample Reagent P'       = 'Sample Reagent P/N'
                'Order quantity'         = 'Order quantity'
                'Total good'             = 'ROBAL - Till Packning'
                'IPT Test results'       = 'IPT Test results'
                'IPT - Testing_0'        = 'IPT - Testing Finalized'
                'MES - Order_x0'         = 'MES Order'
            }

            $desiredOrder = @(
                'Work Center','Order#','SAP Batch#','SAP Batch# 2','LSP','Material','BBD/SLED',
                'ROBAL - Actual start date/time','Sample Reagent use','Sample Reagent P/N',
                'Order quantity','ROBAL - Till Packning','IPT Test results',
                'IPT - Testing Finalized','MES Order'
            )

            $dateFields      = @('BBD/SLED','ROBAL - Actual start date/time','IPT - Testing Finalized')
            $shortDateFields = @('BBD/SLED')

            $rows = @()
            if ($spOk) {
                try {
                    # Hela PnP-frågan + fält-extraktion körs i SPClient-runspacen
                    # (PnP ListItem-objekt kan inte serialiseras korrekt över runspace-gränser)
                    $spResult = Invoke-SPClient -Script {
                        param($listName, $fieldNames, $batchToFind)
                        try {
                            $items = Get-PnPListItem -List $listName -Fields $fieldNames -PageSize 2000 -ErrorAction Stop
                            $match = $items | Where-Object {
                                $v1 = $_['Batch_x0023_']; $v2 = $_['SAP_x0020_Batch_x0023__x0020_2']
                                $s1 = if ($null -ne $v1) { ([string]$v1).Trim() } else { '' }
                                $s2 = if ($null -ne $v2) { ([string]$v2).Trim() } else { '' }
                                $s1 -eq $batchToFind -or $s2 -eq $batchToFind
                            } | Select-Object -First 1

                            if (-not $match) {
                                return @{ Ok = $true; Found = $false; Data = @{} }
                            }

                            # Extrahera alla fält som enkel hashtable (kan serialiseras)
                            $extracted = @{}
                            foreach ($fn in $fieldNames) {
                                $val = $match[$fn]
                                if ($null -ne $val -and $val -ne '') {
                                    # Konvertera LookupValue etc. till strings
                                    if ($val -is [Microsoft.SharePoint.Client.FieldLookupValue]) {
                                        $val = $val.LookupValue
                                    }
                                    $extracted[$fn] = $val
                                }
                            }
                            return @{ Ok = $true; Found = $true; Data = $extracted }
                        } catch {
                            return @{ Ok = $false; Err = $_.Exception.ToString() }
                        }
                    } -Arguments @("Cepheid | Production orders", $fields, $batch)

                    if (-not $spResult -or -not $spResult.Ok) {
                        $spErrMsg = if ($spResult -and $spResult.Err) { $spResult.Err } else { 'Okänt fel' }
                        Gui-Log "⚠️ SP: Get-PnPListItem misslyckades: $spErrMsg" 'Warn'
                    }
                    elseif ($spResult.Found) {
                        foreach ($f in $fields) {
                            $val = $spResult.Data[$f]
                            if ($null -eq $val -or $val -eq '') { continue }

                            $label = $f -replace '_x0020_', ' ' `
                                         -replace '_x002d_', '-' `
                                         -replace '_x0023_', '#' `
                                         -replace '_x002f_', '/' `
                                         -replace '_x2013_', '–' `
                                         -replace '_x00',''
                            $label = $label.Trim()
                            if ($renameMap.ContainsKey($label)) { $label = $renameMap[$label] }

                            if ($val -eq $true) { $val = 'JA' }
                            elseif ($val -eq $false) { $val = 'NEJ' }

                            $dt = $null
                            if ($val -is [datetime]) { $dt = [datetime]$val }
                            else { try { $dt = [datetime]::Parse($val) } catch { $dt = $null } }

                            if ($dt -ne $null -and ($dateFields -contains $label)) {
                                $fmt = if ($shortDateFields -contains $label) { 'yyyy-MM-dd' } else { 'yyyy-MM-dd HH:mm' }
                                $val = $dt.ToString($fmt)
                            }

                            $rows += [pscustomobject]@{ Rubrik = $label; 'Värde' = $val }
                        }

                        if ($rows.Count -gt 0) {
                            $ordered = @()
                            foreach ($label in $desiredOrder) {
                                $hit = $rows | Where-Object { $_.Rubrik -eq $label } | Select-Object -First 1
                                if ($hit) { $ordered += $hit }
                            }
                            if ($ordered.Count -gt 0) { $rows = $ordered }

                            # Cache ROBAL-datum för auto-population av signeringsfält
                            $robalRow = $rows | Where-Object { $_.Rubrik -eq 'ROBAL - Actual start date/time' } | Select-Object -First 1
                            if ($robalRow -and $robalRow.'Värde') {
                                $robalVal = ($robalRow.'Värde' + '').Trim()
                                if ($robalVal -match '^\d{4}-\d{2}-\d{2}') {
                                    $script:RobalDateShort = $robalVal.Substring(0,10) -replace '-',' '
                                }
                            }
                        }

                        Gui-Log "📄 SharePoint-post hittad – skriver blad." 'Info'
                    } else {
                        Gui-Log "ℹ️ Ingen post i SharePoint för Batch=$batch." 'Info'
                    }
                } catch {
                    Gui-Log "⚠️ SP: Invoke-SPClient misslyckades: $($_.Exception.Message)" 'Warn'
                }
            }

            [void](Write-SPBlockIntoInformation -Pkg $pkgOut -Rows $rows -Batch $batch -TargetSheetName $Layout.SheetRunInfo -StartRow $spStartRow -StartCol $spStartCol)

            try {
                $old = $pkgOut.Workbook.Worksheets["SharePoint Info"]
                if ($old) { $pkgOut.Workbook.Worksheets.Delete($old) }
            } catch {}

            try {
                if ($slBatchLink -and $batch) {
                    $slBatchLink.Text = "SharePoint: $batch"
                    $slBatchLink.Tag  = $batchInfo.Url
                    $slBatchLink.Enabled = $true
                }
            } catch {}

            try {
                $wsSP = $pkgOut.Workbook.Worksheets[$Layout.SheetRunInfo]
                if ($wsSP) {
                    $labelCol = $spStartCol
                $valueCol = $spStartCol + 1
                for ($r = ($spStartRow + 1); $r -le ($spStartRow + 120); $r++) {
                        if ((Normalize-HeaderText (($wsSP.Cells[$r,$labelCol].Text + '')).Trim()) -ieq 'Sample Reagent use') {
                            $wsSP.Cells[$r,$valueCol].Style.WrapText = $true
                            $wsSP.Cells[$r,$valueCol].Style.VerticalAlignment = [OfficeOpenXml.Style.ExcelVerticalAlignment]::Top
                            $wsSP.Row($r).CustomHeight = $true
                            break
                        }
                    }
                }
            } catch {
                Gui-Log "⚠️ WrapText på 'Sample Reagent use' misslyckades: $($_.Exception.Message)" 'Warn'
            }

            # ============================================================
            # === Sample Reagent Checklist-markering (additiv)         ===
            # ============================================================
            try {
                $_srhPNs = @()
                try { $_srhPNs = @(Get-ConfigValue -Name 'SampleReagentChecklistPNs' -Default @()) } catch {}

                if ($_srhPNs.Count -gt 0) {
                    $_srhWs = $pkgOut.Workbook.Worksheets[$Layout.SheetRunInfo]
                    if ($_srhWs -and $_srhWs.Dimension) {
                        $_srhLabelCol = $spStartCol
                        $_srhValueCol = $spStartCol + 1
                        $_srhPNRow  = -1; $_srhUseRow = -1
                        $_srhPNVal  = ''; $_srhUseVal = ''

                        for ($_sr = ($spStartRow + 1); $_sr -le ($spStartRow + 120); $_sr++) {
                            $_srhLabel = (Normalize-HeaderText ($_srhWs.Cells[$_sr, $_srhLabelCol].Text + '')).Trim()
                            if ($_srhLabel -ieq 'Sample Reagent P/N') {
                                $_srhPNRow = $_sr
                                $_srhPNVal = ($_srhWs.Cells[$_sr, $_srhValueCol].Text + '').Trim()
                            }
                            if ($_srhLabel -ieq 'Sample Reagent use') {
                                $_srhUseRow = $_sr
                                $_srhUseVal = ($_srhWs.Cells[$_sr, $_srhValueCol].Text + '').Trim()
                            }
                        }

                        $_srhMatch = $false
                        if ($_srhPNVal) {
                            foreach ($_pn in $_srhPNs) {
                                if ($_srhPNVal -eq ($_pn + '').Trim()) { $_srhMatch = $true; break }
                            }
                        }

                        if ($_srhMatch) {
                            $_srhHighlightBg = [System.Drawing.Color]::FromArgb(255, 255, 200)
                            $_srhWarningBg   = [System.Drawing.Color]::FromArgb(255, 235, 156)
                            $_srhWarningFg   = [System.Drawing.Color]::FromArgb(156, 101, 0)
                            $_srhOkBg        = [System.Drawing.Color]::FromArgb(198, 239, 206)
                            $_srhOkFg        = [System.Drawing.Color]::FromArgb(0, 97, 0)

                            if ($_srhPNRow -gt 0) {
                                $_srhWs.Cells[$_srhPNRow, $_srhValueCol].Style.Fill.PatternType = 'Solid'
                                $_srhWs.Cells[$_srhPNRow, $_srhValueCol].Style.Fill.BackgroundColor.SetColor($_srhHighlightBg)
                                $_srhWs.Cells[$_srhPNRow, $_srhValueCol].Style.Font.Bold = $true
                            }

                            if ($_srhUseRow -gt 0) {
                                if ($_srhUseVal) {
                                    $_srhWs.Cells[$_srhUseRow, $_srhValueCol].Style.Fill.PatternType = 'Solid'
                                    $_srhWs.Cells[$_srhUseRow, $_srhValueCol].Style.Fill.BackgroundColor.SetColor($_srhOkBg)
                                    $_srhWs.Cells[$_srhUseRow, $_srhValueCol].Style.Font.Color.SetColor($_srhOkFg)
                                    $_srhWs.Cells[$_srhUseRow, $_srhValueCol].Style.Font.Bold = $true
                                } else {
                                    $_srhWs.Cells[$_srhUseRow, $_srhValueCol].Value = '⚠ SAKNAS'
                                    $_srhWs.Cells[$_srhUseRow, $_srhValueCol].Style.Fill.PatternType = 'Solid'
                                    $_srhWs.Cells[$_srhUseRow, $_srhValueCol].Style.Fill.BackgroundColor.SetColor($_srhWarningBg)
                                    $_srhWs.Cells[$_srhUseRow, $_srhValueCol].Style.Font.Color.SetColor($_srhWarningFg)
                                    $_srhWs.Cells[$_srhUseRow, $_srhValueCol].Style.Font.Bold = $true
                                    Gui-Log '⚠️ Sample Reagent Saknas' 'Warn'
                                }
                            }
                        }
                    }
                }
            } catch {
                Gui-Log "⚠️ Sample Reagent highlight: $($_.Exception.Message)" 'Warn'
            }

        }
    }
} catch {
    Gui-Log "⚠️ SP-blad: $($_.Exception.Message)" 'Warn'
}

# ============================
# === QC-påminnelse (HIV/HBV/HCV) → Information E16:F18 ===
# ============================
try {
    if ($script:QcReminderB3) {
        $wsInfo = $pkgOut.Workbook.Worksheets[$Layout.SheetRunInfo]
        if ($wsInfo) {
            $qcRow = 16
            $eCol  = 5   # E
            $fCol  = 6   # F

            # Färger (samma som SharePoint Info-rubriken)
            $HeaderBg  = [System.Drawing.Color]::FromArgb(68, 84, 106)
            $HeaderFg  = [System.Drawing.Color]::White
            $SectionBg = [System.Drawing.Color]::FromArgb(217, 225, 242)
            $SectionFg = [System.Drawing.Color]::FromArgb(0, 32, 96)
            $BorderClr = [System.Drawing.Color]::FromArgb(68, 84, 106)

            # --- Rad 16: rubrik (sammanfogad E16:F16) ---
            $wsInfo.Cells[$qcRow, $eCol, $qcRow, $fCol].Merge = $true
            $hdrCell = $wsInfo.Cells[$qcRow, $eCol]
            $hdrCell.Value = ('QC Reminder – ' + $script:QcReminderB3)
            $hdrCell.Style.Font.Bold = $true
            $hdrCell.Style.Font.Size = 14
            $hdrCell.Style.Font.Name = 'Calibri'
            $hdrCell.Style.Font.Color.SetColor($HeaderFg)
            $hdrCell.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
            $hdrCell.Style.Fill.BackgroundColor.SetColor($HeaderBg)
            $hdrCell.Style.HorizontalAlignment = [OfficeOpenXml.Style.ExcelHorizontalAlignment]::Left
            $hdrCell.Style.VerticalAlignment   = [OfficeOpenXml.Style.ExcelVerticalAlignment]::Center
            $wsInfo.Row($qcRow).Height = 22

            # --- Rad 17: "Additional QC-Data?" / "JA" ---
            $wsInfo.Cells[($qcRow+1), $eCol].Value = 'Additional QC-Data?'
            $wsInfo.Cells[($qcRow+1), $eCol].Style.Font.Bold = $true
            $wsInfo.Cells[($qcRow+1), $eCol].Style.Font.Name = 'Calibri'
            $wsInfo.Cells[($qcRow+1), $eCol].Style.Font.Size = 10
            $wsInfo.Cells[($qcRow+1), $eCol].Style.Font.Color.SetColor($SectionFg)
            $wsInfo.Cells[($qcRow+1), $eCol].Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
            $wsInfo.Cells[($qcRow+1), $eCol].Style.Fill.BackgroundColor.SetColor($SectionBg)

            $wsInfo.Cells[($qcRow+1), $fCol].Value = 'JA'
            $wsInfo.Cells[($qcRow+1), $fCol].Style.Font.Bold = $true
            $wsInfo.Cells[($qcRow+1), $fCol].Style.Font.Name = 'Calibri'
            $wsInfo.Cells[($qcRow+1), $fCol].Style.Font.Size = 10
            $wsInfo.Cells[($qcRow+1), $fCol].Style.Font.Color.SetColor([System.Drawing.Color]::FromArgb(0, 128, 0))
            $wsInfo.Cells[($qcRow+1), $fCol].Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
            $wsInfo.Cells[($qcRow+1), $fCol].Style.Fill.BackgroundColor.SetColor([System.Drawing.Color]::White)
            $wsInfo.Cells[($qcRow+1), $fCol].Style.HorizontalAlignment = [OfficeOpenXml.Style.ExcelHorizontalAlignment]::Left

            # --- Rad 18: "Lathund QC data" med länk (sammanfogad E18:F18) ---
            $wsInfo.Cells[($qcRow+2), $eCol, ($qcRow+2), $fCol].Merge = $true
            $linkCell = $wsInfo.Cells[($qcRow+2), $eCol]

            $lathundPath = ''
            if ($Config) {
                # Primär nyckel (finns i Config.ps1 i LIVE-zippen)
                if ($Config.Contains('QcDataCheatSheetLink')) {
                    $lathundPath = $Config.QcDataCheatSheetLink
                }
                # Reservnyckel om du någon gång vill använda ett annat namn
                elseif ($Config.Contains('QcReminderLathundPath')) {
                    $lathundPath = $Config.QcReminderLathundPath
                }
            }

            $linkCell.Value = 'Lathund QC data'
            $linkCell.Style.Font.Name = 'Calibri'
            $linkCell.Style.Font.Size = 10
            $linkCell.Style.Font.UnderLine = $true
            $linkCell.Style.Font.Color.SetColor([System.Drawing.Color]::FromArgb(5, 99, 193))
            $linkCell.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
            $linkCell.Style.Fill.BackgroundColor.SetColor($SectionBg)
            # Centrera sammanfogad E18:F18 (både horisontellt och vertikalt)
            $linkCell.Style.HorizontalAlignment = [OfficeOpenXml.Style.ExcelHorizontalAlignment]::Center
            $linkCell.Style.VerticalAlignment   = [OfficeOpenXml.Style.ExcelVerticalAlignment]::Center

            if ($lathundPath) {
                try {
                    # Bygg stabil URI:
                    $uriText = $lathundPath
                    if ($uriText -match '^(?i)https?://') {
                        $linkCell.Hyperlink = New-Object System.Uri($uriText)
                   }
                    elseif ($uriText -match '^[A-Za-z]:\\') {
                        # ex: N:\Folder\File.docx -> file:///N:/Folder/File.docx
                        $fileUri = 'file:///' + ($uriText -replace '\\','/')
                        $fileUri = [System.Uri]::EscapeUriString($fileUri)
                        $linkCell.Hyperlink = New-Object System.Uri($fileUri)
                    }
                    elseif ($uriText -match '^\\\\') {
                        # UNC-sökväg: System.Uri hanterar \\server\share nativt och bevarar Unicode
                        $linkCell.Hyperlink = New-Object System.Uri($uriText)
                    }
                    else {
                        # Sista försök (om du ger en redan korrekt URI)
                        $linkCell.Hyperlink = New-Object System.Uri($uriText)
                    }
                 } catch {
                     Gui-Log ("⚠️ QC Reminder: Kunde inte skapa hyperlänk till '{0}': {1}" -f $lathundPath, $_.Exception.Message) 'Warn'
                 }
             }

            # Ramar runt hela QC-påminnelseblocket (E16:F18)
            $rng = $wsInfo.Cells[$qcRow, $eCol, ($qcRow+2), $fCol]
            $rng.Style.Border.Top.Style    = [OfficeOpenXml.Style.ExcelBorderStyle]::Thin
            $rng.Style.Border.Bottom.Style = [OfficeOpenXml.Style.ExcelBorderStyle]::Thin
            $rng.Style.Border.Left.Style   = [OfficeOpenXml.Style.ExcelBorderStyle]::Thin
            $rng.Style.Border.Right.Style  = [OfficeOpenXml.Style.ExcelBorderStyle]::Thin
            $rng.Style.Border.Top.Color.SetColor($BorderClr)
            $rng.Style.Border.Bottom.Color.SetColor($BorderClr)
            $rng.Style.Border.Left.Color.SetColor($BorderClr)
            $rng.Style.Border.Right.Color.SetColor($BorderClr)

            Gui-Log ("✅ QC Reminder skrivet i Run Information E{0}:F{1} (B3={2})" -f $qcRow, ($qcRow+2), $script:QcReminderB3) 'Info'
        }
    }
} catch {
    Gui-Log ("⚠️ QC Reminder (skrivning): " + $_.Exception.Message) 'Warn'
}

# ============================
# === Rubrik-vattenstämpel ===
# ============================
try {
    foreach ($ws in $pkgOut.Workbook.Worksheets) {
        try {
            $ws.HeaderFooter.OddHeader.CenteredText   = '&"Arial,Bold"&14 UNCONTROLLED'
            $ws.HeaderFooter.EvenHeader.CenteredText  = '&"Arial,Bold"&14 UNCONTROLLED'
            $ws.HeaderFooter.FirstHeader.CenteredText = '&"Arial,Bold"&14 UNCONTROLLED'
        } catch {
            Gui-Log ("⚠️ Kunde inte sätta header på blad: " + $ws.Name) 'Warn'
        }
    }
} catch {
    Gui-Log "⚠️ Fel vid vattenstämpling av rapporten." 'Warn'
}

        # ============================
        # === Flikfärger (före sparning)
        # ============================
        try {
            $wsT = $pkgOut.Workbook.Worksheets[$Layout.SheetRunInfo];     if ($wsT) { $wsT.TabColor = [System.Drawing.Color]::FromArgb(255, 52, 152, 219) }
            $wsT = $pkgOut.Workbook.Worksheets[$Layout.SheetUtrustning];     if ($wsT) { $wsT.TabColor = [System.Drawing.Color]::FromArgb(255, 33, 115, 70) }
        } catch {
        Gui-Log "⚠️ Kunde inte sätta tab-färg: $($_.Exception.Message)" 'Warn'
    }

        #endregion Build: Output-flikar

        #region Build: Spara rapport och revision
        # ============================
        # === Spara & revision     ===
        # ============================

        $nowTs    = Get-Date -Format "yyyyMMdd_HHmmss"
        $baseName = "$($env:USERNAME)_output_${lsp}_$nowTs.xlsx"
        $saveDir  = $env:TEMP
        $SavePath = Join-Path $saveDir $baseName
        Gui-Log ("💾 Sparar rapport: {0}" -f $baseName) 'Info' 'USER'
        try {
            $pkgOut.Workbook.View.ActiveTab = 0
            $wsInitial = $pkgOut.Workbook.Worksheets[$Layout.SheetRunInfo]
            if ($wsInitial) { $wsInitial.View.TabSelected = $true }

            # ============================
            # === RuleEngine felsökningsblad ==
            # ============================
            try {
                if ((Get-ConfigFlag -Name 'EnableRuleEngine' -Default $false -ConfigOverride $Config) -and
                    (Get-ConfigFlag -Name 'EnableRuleEngineDebugSheet' -Default $false -ConfigOverride $Config) -and
                    (($selCsv -and (Test-Path -LiteralPath $selCsv)) -or ($selCsvRes -and (Test-Path -LiteralPath $selCsvRes)))) {

                    $shadowRowsCount = 0
                    if ($script:RuleEngineShadow -and (Build-ObjectHasProperty -Object $script:RuleEngineShadow -PropertyName 'Rows')) {
                        $shadowRowsCount = Build-GetSafeCount $script:RuleEngineShadow.Rows
                    }
                    if (-not $script:RuleEngineShadow -or $shadowRowsCount -eq 0) {

                        Gui-Log "🧠 Regelmotor: saknas vid Save → bygger nu..." 'Warn'

                        $rb2 = $script:RuleBankCache
                        if (-not $rb2) {
                            $rb2 = Load-RuleBank -RuleBankDir $Config.RuleBankDir
                            try { $rb2 = Compile-RuleBank -RuleBank $rb2 } catch {}
                        }
                        if (-not $rb2 -or -not (Build-TestRuleBankForEngine -RuleBank $rb2 -Context 'Build.RuleEngineSave')) {
                            $rb2 = $null
                            Gui-Log "⚠️ Regelmotor: RuleBank ogiltig vid Save – CSV-Sammanfattning hoppas över." 'Warn'
                        }

                        # Primär
                        $csvObjs2 = @()
                        if ($selCsv -and (Test-Path -LiteralPath $selCsv)) {
                            $csvObjs2 = $script:RuleEngineCsvObjs
                            if (-not $csvObjs2 -or (Build-GetSafeCount $csvObjs2) -eq 0) {
                                if ($csvRows -and (Build-GetSafeCount $csvRows) -gt 0) {
                                    $csvObjs2 = @($csvRows)
                                } else {
                                    try {
                                        $all = $script:CsvLinesPrimary
                                        $allCount = Build-GetSafeCount $all
                                        if ($all -and $allCount -gt 9) {
                                            $hdr = Csv-SplitFields $all[7]
                                            $dl  = $all[9..($allCount-1)] | Where-Object { $_ -and $_.Trim() }
                                            $del = Csv-GetDelimiter -Path $selCsv
                                            $csvObjs2 = @(ConvertFrom-Csv -InputObject ($dl -join "`n") -Delimiter $del -Header $hdr)
                                        }
                                    } catch { $csvObjs2 = @() }
                                }
                            }
                            if ($rb2 -and $csvObjs2 -and (Build-GetSafeCount $csvObjs2) -gt 0) {
                                $script:RuleEngineShadow = Invoke-RuleEngine -CsvObjects $csvObjs2 -RuleBank $rb2 -CsvPath $selCsv
                            }
                        }

                        # Resample-del
                        if ($selCsvRes -and (Test-Path -LiteralPath $selCsvRes)) {
                            $csvObjsR2 = $script:RuleEngineCsvObjsRes
                            if (-not $csvObjsR2 -or (Build-GetSafeCount $csvObjsR2) -eq 0) {
                                if ($csvRowsRes -and (Build-GetSafeCount $csvRowsRes) -gt 0) {
                                    $csvObjsR2 = @($csvRowsRes)
                                } else {
                                    try {
                                        $allR = $script:CsvLinesResample
                                        $allRCount = Build-GetSafeCount $allR
                                        if ($allR -and $allRCount -gt 9) {
                                            $hdrR = Csv-SplitFields $allR[7]
                                            $dlR  = $allR[9..($allRCount-1)] | Where-Object { $_ -and $_.Trim() }
                                            $delR = Csv-GetDelimiter -Path $selCsvRes
                                            $csvObjsR2 = @(ConvertFrom-Csv -InputObject ($dlR -join "`n") -Delimiter $delR -Header $hdrR)
                                        }
                                    } catch { $csvObjsR2 = @() }
                                }
                            }
                            if ($rb2 -and $csvObjsR2 -and (Build-GetSafeCount $csvObjsR2) -gt 0) {
                                $reR2 = Invoke-RuleEngine -CsvObjects $csvObjsR2 -RuleBank $rb2 -CsvPath $selCsvRes
                                if ($script:RuleEngineShadow -and $reR2) {
                                    # Sammanfogning (nytt objekt för PS 5.1-kompatibilitet)
                                    $script:RuleEngineShadow = [pscustomobject]@{
                                        Rows          = @($script:RuleEngineShadow.Rows) + @($reR2.Rows)
                                        Summary       = $script:RuleEngineShadow.Summary
                                        TopDeviations = @($script:RuleEngineShadow.TopDeviations) + @($reR2.TopDeviations)
                                        QC            = $script:RuleEngineShadow.QC
                                    }
                                } elseif ($reR2) {
                                    $script:RuleEngineShadow = $reR2
                                }
                            }
                        }

                        $shadowRowsCountAfterSaveBuild = 0
                        if ($script:RuleEngineShadow -and (Build-ObjectHasProperty -Object $script:RuleEngineShadow -PropertyName 'Rows')) {
                            $shadowRowsCountAfterSaveBuild = Build-GetSafeCount $script:RuleEngineShadow.Rows
                        }
                        if (-not $script:RuleEngineShadow -or $shadowRowsCountAfterSaveBuild -eq 0) {
                            Gui-Log "⚠️ Regelmotor: kunde inte bygga vid Save (0 rader)." 'Warn'
                        }
                    }

                    $shadowRowsCountForWrite = 0
                    if ($script:RuleEngineShadow -and (Build-ObjectHasProperty -Object $script:RuleEngineShadow -PropertyName 'Rows')) {
                        $shadowRowsCountForWrite = Build-GetSafeCount $script:RuleEngineShadow.Rows
                    }
                    if ($script:RuleEngineShadow -and $shadowRowsCountForWrite -gt 0) {
                        Gui-Log "🧠 Skriver CSV-Sammanfattning..." 'Info' 'PROGRESS'
                        $includeAll = Get-ConfigFlag -Name 'RuleEngineDebugIncludeAllRows' -Default $false -ConfigOverride $Config
                        $dsf = @()
                        if ($script:DataSummaryFindings) { $dsf = @($script:DataSummaryFindings) }
                        $stf = 0
                        if ($script:StfCount) { $stf = [int]$script:StfCount }
                        [void](Write-RuleEngineDebugSheet -Pkg $pkgOut -RuleEngineResult $script:RuleEngineShadow -IncludeAllRows $includeAll -DataSummaryFindings $dsf -StfCount $stf)

                        # --- Skriv använda INF/GX i QC Summary (kolumn I+) ---
                        try {
                            $wsQcs = $pkgOut.Workbook.Worksheets[$Layout.SheetQcSummary]
                            if ($wsQcs) {
                                # Samla unika systemnamn från primär + resample CSV
                                $usedSystems = [ordered]@{}
                                if ($csvStats -and $csvStats.InstrumentByType) {
                                    foreach ($k in $csvStats.InstrumentByType.Keys) {
                                        if ($k -and $k -ne 'Unknown') { $usedSystems[$k] = $true }
                                    }
                                }
                                if ($csvStatsRes -and $csvStatsRes.InstrumentByType) {
                                    foreach ($k in $csvStatsRes.InstrumentByType.Keys) {
                                        if ($k -and $k -ne 'Unknown') { $usedSystems[$k] = $true }
                                    }
                                }
                                $names = @($usedSystems.Keys | Sort-Object)
                                if ($names.Count -gt 0) {
                                    $startCol = 9  # Kolumn I
                                    $hdrRow   = 3  # Rad bredvid Övergripande data

                                    # Rubrik
                                    $wsQcs.Cells[$hdrRow, $startCol].Value = 'Använda INF/GX'
                                    $wsQcs.Cells[$hdrRow, $startCol].Style.Font.Bold = $true
                                    $wsQcs.Cells[$hdrRow, $startCol].Style.Font.Size = 10
                                    $hdrRng = $wsQcs.Cells[$hdrRow, $startCol, $hdrRow, ($startCol + $names.Count - 1)]
                                    $hdrRng.Merge = $true
                                    $hdrRng.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                                    $hdrRng.Style.Fill.BackgroundColor.SetColor([System.Drawing.Color]::FromArgb(217, 225, 242))
                                    $hdrRng.Style.Font.Color.SetColor([System.Drawing.Color]::FromArgb(0, 32, 96))
                                    $hdrRng.Style.HorizontalAlignment = [OfficeOpenXml.Style.ExcelHorizontalAlignment]::Center

                                    # Systemnamn + kalibreringsdatum
                                    $calMap = $script:CalDueMap
                                    for ($ci = 0; $ci -lt $names.Count; $ci++) {
                                        $col = $startCol + $ci
                                        $sysName = $names[$ci]

                                        # Rad 1: Systemnamn
                                        $cName = $wsQcs.Cells[($hdrRow + 1), $col]
                                        $cName.Value = $sysName
                                        $cName.Style.Font.Bold = $true
                                        $cName.Style.Font.Size = 9
                                        $cName.Style.HorizontalAlignment = [OfficeOpenXml.Style.ExcelHorizontalAlignment]::Center
                                        $cName.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                                        $cName.Style.Fill.BackgroundColor.SetColor([System.Drawing.Color]::FromArgb(242, 242, 242))

                                        # Rad 2: Cal Due Date
                                        $cCal = $wsQcs.Cells[($hdrRow + 2), $col]
                                        $calVal = ''
                                        if ($calMap -and $calMap.ContainsKey($sysName)) { $calVal = $calMap[$sysName] }
                                        $cCal.Value = $calVal
                                        $cCal.Style.Font.Size = 9
                                        $cCal.Style.HorizontalAlignment = [OfficeOpenXml.Style.ExcelHorizontalAlignment]::Center
                                        $cCal.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                                        $cCal.Style.Fill.BackgroundColor.SetColor([System.Drawing.Color]::FromArgb(198, 239, 206))

                                        # AutoFit kolumnbredd
                                        try { $wsQcs.Column($col).AutoFit() } catch {}
                                        try { $wsQcs.Column($col).Width = [Math]::Max($wsQcs.Column($col).Width, 14) } catch {}
                                    }
                                }
                            }
                        } catch {
                            Gui-Log ("⚠️ QC Summary INF/GX fel: " + $_.Exception.Message) 'Warn'
                        }

                        # Visa vilken CSV som klassades som primär/resample direkt i CSV Sammanfattning (rad 2)
                        try {
                            $wsDbg = $pkgOut.Workbook.Worksheets['CSV Sammanfattning']
                            if ($wsDbg) {
                                $pPath = if ($selCsvOrig) { $selCsvOrig } elseif ($selCsv) { $selCsv } else { '' }
                                $rPath = if ($selCsvResOrig) { $selCsvResOrig } elseif ($selCsvRes) { $selCsvRes } else { '' }
                                $pLeaf = Get-CleanLeaf $pPath
                                $rLeaf = Get-CleanLeaf $rPath
                                $lbl = if ($pLeaf -and $rLeaf) {
                                    "CSV: {0} | RES CSV: {1}" -f $pLeaf, $rLeaf
                                } elseif ($pLeaf) {
                                    "CSV: {0}" -f $pLeaf
                                } elseif ($rLeaf) {
                                    "Resample CSV: {0}" -f $rLeaf
                                } else { '' }
                                if ($lbl) {
                                    $rng = $wsDbg.Cells[2, 1, 2, 8]
                                    $rng.Merge = $true
                                    $rng.Style.Numberformat.Format = '@'
                                    $rng.Style.Font.Italic = $true
                                    $wsDbg.Cells[2, 1].Value = $lbl
                                }
                            }
                        } catch {}
                    } else {
                        Gui-Log "⚠️ Kunde inte skriva CSV-Sammanfattning." 'Warn'
                    }
                }
            } catch {
                Gui-Log ("⚠️ Kunde inte skriva CSV-Sammanfattning: " + $_.Exception.Message) 'Warn'
            }

            Set-UiStep 90 'Sparar rapport…'
            Mark-Phase 'RunInfo'
            # UX: Om rapportfilen redan finns och är öppen (Excel), be användaren stänga innan SaveAs
            try {
                if ($SavePath -and (Test-Path -LiteralPath $SavePath)) {
                    if (-not (Ensure-FilesClosedOrCancel -Paths @($SavePath) -Hint 'Stäng rapporten i Excel (eller stäng Preview i Explorer) och klicka Försök igen.')) {
                        Gui-Log "🛑 Avbrutet: output-filen är låst/öppen." 'Warn'
                        return
                    }
                }
            } catch {}
            try {
                $pkgOut.SaveAs($SavePath)
            } catch {
                $saveErr = $_.Exception.Message
                if ($saveErr -match 'being used by another process|access.*denied|permission') {
                    Gui-Log ("❌ Kunde inte spara: filen är låst av ett annat program. Stäng Excel/Preview och försök igen.") 'Error'
                } else {
                    Gui-Log ("❌ Kunde inte spara rapporten: $saveErr") 'Error'
                }
                return
            }
            Mark-Phase 'Save'
            $buildTimer.Stop()
            $totalMs = $buildTimer.ElapsedMilliseconds
            $doneMsg = 'Klar ✅  ({0:N1}s)' -f ($totalMs / 1000)
            Set-UiStep 100 $doneMsg
            Gui-Log -Text (" Rapport sparad: {0} ({1:N1}s)" -f $SavePath, ($totalMs / 1000)) -Severity Info -Category RESULT
            # Signeringssammanfattning
            $signParts = @()
            if ($doSealTest) { $signParts += "Seal Test: NEG+POS" }
            if ($doWsSamm)   { $signParts += "WS Sammanst." }
            if ($doWsGransk) { $signParts += "WS Granskning" }
            if ($signParts.Count -gt 0) {
                Gui-Log ("🔏 Verifierad signering: " + ($signParts -join ', ')) 'Info'
            }
            $global:LastReportPath = $SavePath
            try { $form.Text = "IPTCompile – $ScriptVersion — $(Split-Path $SavePath -Leaf)" } catch {}
            try {
                $auditDir = Join-Path $script:BuildPipelineProjectRoot 'audit'
                if (-not (Test-Path -LiteralPath $auditDir)) { New-Item -ItemType Directory -Path $auditDir -Force | Out-Null }

            # Fasdetaljerad tidsmätning (ms)
            $phaseJson = ''
            try { $phaseJson = ($phaseTimings | ConvertTo-Json -Compress) } 
            catch { $phaseJson = '' }


                $auditObj = [pscustomobject]@{
                    DatumTid        = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
                    Användare       = $env:USERNAME
                    LSP             = $lsp
                    ValdCSV         = if ($selCsv -or $selCsvRes) { (@($(if($selCsv){Get-CleanLeaf $selCsv}), $(if($selCsvRes){'(Res) '+(Get-CleanLeaf $selCsvRes)})) | Where-Object {$_}) -join ' + ' } else { '' }
                    ValdSealNEG     = Get-CleanLeaf $selNeg
                    ValdSealPOS     = Get-CleanLeaf $selPos
                    Assay           = $runAssay
                    AntalTester     = $(try { if ($csvStats) { 
                    [int]$csvStats.TestCount } else { 0 } } catch { 0 })
                    SignaturSkriven = if ($doSealTest) { 'Ja (verifierad)' } else { 'Nej' }
                    WsSammSkriven   = if ($doWsSamm) { 'Ja (verifierad)' } else { 'Nej' }
                    WsGranskSkriven = if ($doWsGransk) { 'Ja (verifierad)' } else { 'Nej' }
                    SigMismatch     = if ($sigMismatch) { 'Ja' } else { 'Nej' }
                    MismatchSheets  = if ($mismatchSheets -and $mismatchSheets.Count -gt 0) { ($mismatchSheets -join ';') } else { '' }
                    ViolationsNEG   = $violationsNeg.Count
                    ViolationsPOS   = $violationsPos.Count
                    Violations      = ($violationsNeg.Count + $violationsPos.Count)
                    TotalTid_ms     = $totalMs
                    TotalTid_s      = [math]::Round($totalMs / 1000, 1)
                    FasTider_json   = $phaseJson
                    Sparläge        = 'Temporärt'
                    OutputFile      = $SavePath
                    Kommentar       = 'UNCONTROLLED rapport, ingen källfil ändrades automatiskt.'
                    ScriptVersion   = $ScriptVersion
                }

                $auditFile = Join-Path $auditDir ("$($env:USERNAME)_audit_${nowTs}.csv")
                $auditObj | Export-Csv -Path $auditFile -NoTypeInformation -Encoding UTF8

                try {
                    $statusText = 'OK'
                    if (($violationsNeg.Count + $violationsPos.Count) -gt 0 -or $sigMismatch -or ($mismatchSheets -and $mismatchSheets.Count -gt 0)) {
                        $statusText = 'Warnings'
                    }
                    $auditTests = $null
                    try {
                        if ($csvStats) { $auditTests = [int]$csvStats.TestCount }
                        if ($csvStatsRes -and $csvStatsRes.TestCount -gt 0) { $auditTests = ($auditTests + 0) + [int]$csvStatsRes.TestCount }
                    } catch {}
                    Add-AuditEntry -Lsp $lsp -Assay $runAssay -BatchNumber $batch -TestCount $auditTests -Status $statusText -ReportPath $SavePath -TotalMs $totalMs -PhaseJson $phaseJson
                } catch {
                    Gui-Log "⚠️ Kunde inte skriva audit-CSV: $($_.Exception.Message)" 'Warn'
                }
            } catch {
                Gui-Log "⚠️ Kunde inte skriva revisionsfil: $($_.Exception.Message)" 'Warn'
            }

            # Kort visuell blink på Build-knappen
            $origBack = $btnBuild.BackColor
            try {
                $btnBuild.BackColor = [System.Drawing.Color]::FromArgb(46, 125, 50)
                $btnBuild.Refresh()
                Start-Sleep -Milliseconds 600
                $btnBuild.BackColor = $origBack
                $btnBuild.Refresh()
            } catch { try { $btnBuild.BackColor = $origBack } catch {} }

            try { Start-Process -FilePath $SavePath } catch {

            # Kort ljud-notis vid klar rapport
            try { [System.Media.SystemSounds]::Exclamation.Play() } catch {}
                Gui-Log "ℹ️ Rapporten sparades men kunde inte öppnas automatiskt: $($_.Exception.Message)" 'Info' 'USER'
            }
        }
        catch {
            Gui-Log "❌ Kunde inte spara rapporten: $($_.Exception.Message)" 'Error'
        }

    } finally {
        try { if ($pkgNeg) { $pkgNeg.Dispose() } } catch {}
        try { if ($pkgPos) { $pkgPos.Dispose() } } catch {}
        try { if ($pkgOut) { $pkgOut.Dispose() } } catch {}
        try { if ($script:WsPkg) { $script:WsPkg.Dispose(); $script:WsPkg = $null } } catch {}
        try {
            if ($stageDir -and (Test-Path -LiteralPath $stageDir)) {
                # Säkerhet: radera bara om den ligger under TEMP-root
                $root = Get-ConfigValue -Name 'TempSnapshotRoot' -Default 'C:\IPTCompile_TEMP' -ConfigOverride $Config
                if (-not $root) { $root = 'C:\IPTCompile_TEMP' }
                $stageFull = (Resolve-Path -LiteralPath $stageDir -ErrorAction SilentlyContinue).Path
                $rootFull  = (Resolve-Path -LiteralPath $root -ErrorAction SilentlyContinue).Path
                if ($stageFull -and $rootFull -and $stageFull.StartsWith($rootFull, [System.StringComparison]::OrdinalIgnoreCase)) {
                    Remove-Item -LiteralPath $stageDir -Recurse -Force -ErrorAction SilentlyContinue
                }
            }
        } catch {}
        Set-UiBusy -Busy $false
        $script:BuildInProgress = $false
    }
    #endregion Build: Spara rapport och revision
    }

    $afterReport = ''
    if (Test-Path variable:global:LastReportPath) {
        try { $afterReport = ($global:LastReportPath + '') } catch { $afterReport = '' }
    }
    if ($afterReport -and (Test-Path -LiteralPath $afterReport)) {
        $afterTs = $null
        try { $afterTs = (Get-Item -LiteralPath $afterReport).LastWriteTimeUtc } catch {}
        if (($afterReport -ne $beforeReport) -or ($afterTs -and $beforeReportTs -and $afterTs -gt $beforeReportTs) -or (-not $beforeReportTs)) {
            $res.Success = $true
            $res.OutputPath = $afterReport
        }
    }

    try {
        if (Test-Path -LiteralPath $auditDir) {
            $afterAudit = @(
                Get-ChildItem -LiteralPath $auditDir -Filter '*_audit_*.csv' -File -ErrorAction SilentlyContinue |
                Sort-Object LastWriteTimeUtc -Descending |
                Select-Object -First 1 -ExpandProperty FullName
            )[0]
            if ($afterAudit -and ($afterAudit -ne $beforeAudit)) {
                $res.AuditPath = $afterAudit
            }
        }
    } catch {}

    if (-not $res.Success) {
        [void]$res.Errors.Add('Canonical report writer rapporterade inte ny output-fil.')
    }

    return $res
}
