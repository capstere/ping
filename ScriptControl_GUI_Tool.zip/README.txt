\
ScriptControl (GUI)
===================

What this is
- A styled WinForms GUI replacement for the old console menu in scriptcontrol.ps1
- Same functionality:
  1) Enable/Disable AutoMappscript (writes status.txt)
  2) View/Change Instrumentlist (edits equipment.xml; autosaves)

Files
- ScriptControl_GUI.ps1  (main GUI)
- Run_ScriptControl.bat  (simple launcher)
- Run_ScriptControl_hidden.vbs (optional launcher that hides the console)

How to run
- Double click Run_ScriptControl.bat
  or
- Double click Run_ScriptControl_hidden.vbs (no console window)

Integration idea (IPTCompile Tools)
- Point a "Verktyg" button/menu item to run:
  powershell.exe -NoProfile -ExecutionPolicy Bypass -File "<path>\ScriptControl_GUI.ps1"
