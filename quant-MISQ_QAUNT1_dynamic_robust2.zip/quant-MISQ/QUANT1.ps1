﻿# ================================
# KONSTANTER – ALLA ASSAYS
# ================================

$Assays = @{

  # ------------------------------
  # ASSAY:
  # Xpert_HIV-1 Viral Load
  # HIV-1 Viral Load RUO #D51110
  # ------------------------------
  "Xpert_HIV-1 Viral Load" = @{
    Modes = @{
      Low  = @{
        # HIV-1 (Low)
        CtMin     = 35.51
        CtMax     = 37.30
        AvgLogMin = 2.07    # Calculated Average Log Titer (Min)
        AvgLogMax = 2.53    # Calculated Average Log Titer (Max)
        SDMax     = 0.200   # Calculated Average Log Titer SD (Max)
        LogMin    = 1.70    # Global Log Titer (Min)
        LogMax    = 2.90    # Global Log Titer (Max)
        EPFMin    = $null   # (ej angivet i din tabell)
      }
      High = @{
        # HIV-1 (High)
        CtMin     = 26.27
        CtMax     = 27.59
        AvgLogMin = 4.85    # Calculated Average Log Titer (Min)
        AvgLogMax = 5.15    # Calculated Average Log Titer (Max)
        SDMax     = 0.100   # Calculated Average Log Titer SD (Max)
        LogMin    = $null   # Global Log Titer saknas i tabellen för High
        LogMax    = $null
        EPFMin    = $null   # (ej angivet i din tabell)
      }
    }
    IQS = @{
      H = @{ CtMin = 22.50; CtMax = 24.30 }  # IQS-H Ct
      L = @{ CtMin = 32.70; CtMax = 34.80 }  # IQS-L Ct
    }
  }

  # ------------------------------
  # ASSAY:
  # Xpert HBV Viral Load D51114
  # ------------------------------
  "Xpert HBV Viral Load" = @{
    Modes = @{
      Low  = @{
        CtMin     = 33.0; CtMax     = 35.2
        AvgLogMin = 1.26; AvgLogMax = 1.70
        SDMax     = 0.20
        LogMin    = 0.88; LogMax    = 2.08
        EPFMin    = $null
      }
      High = @{
        CtMin     = 19.2; CtMax     = 20.8
        AvgLogMin = 5.54; AvgLogMax = 5.86
        SDMax     = 0.15
        LogMin    = $null; LogMax = $null
        EPFMin    = $null
      }
    }
    IQS = @{
      H = @{ CtMin = 19.2; CtMax = 21.2 }
      L = @{ CtMin = 29.9; CtMax = 32.3 }
    }
  }

  # ------------------------------
  # ASSAY:
  # Xpert HCV Viral Load + HCV Viral Load RUO #D51112
  # ------------------------------
  "Xpert_HCV Viral Load" = @{
    Modes = @{
      Low  = @{
        CtMin     = 33.0; CtMax     = 34.4
        AvgLogMin = 1.50; AvgLogMax = 1.90
        SDMax     = 0.17
        LogMin    = 1.10; LogMax    = 2.30
        EPFMin    = $null
      }
      High = @{
        CtMin     = 23.6; CtMax     = 24.8
        AvgLogMin = 4.25; AvgLogMax = 4.55
        SDMax     = 0.12
        LogMin    = $null; LogMax   = $null
        EPFMin    = $null
      }
    }
    IQS = @{
      H = @{ CtMin = 21.3; CtMax = 23.1 }
      L = @{ CtMin = 31.5; CtMax = 33.8 }
    }
  }

  # ------------------------------
  # ASSAY:
  # Xpert HCV VL Fingerstick + HCV VL WB RUO #D51113
  # ------------------------------
  "Xpert HCV VL Fingerstick" = @{
    Modes = @{
      Low  = @{
        CtMin     = 34.6; CtMax     = 37.1
        AvgLogMin = 2.29; AvgLogMax = 2.67
        SDMax     = 0.200
        LogMin    = 1.88; LogMax    = 3.08
        EPFMin    = $null
      }
      High = @{
        CtMin     = 23.1; CtMax     = 25.2
        AvgLogMin = 5.50; AvgLogMax = 5.90
        SDMax     = 0.136
        LogMin    = $null; LogMax   = $null
        EPFMin    = $null
      }
    }
    IQS = @{
      H = @{ CtMin = 21.9; CtMax = 24.4 }
      L = @{ CtMin = 32.2; CtMax = 34.7 }
    }
  }

  # ------------------------------
  # ASSAY:
  # HIV-1 Viral Load XC IUO
  # HIV-1 Viral Load XC RUO
  # Xpert HIV-1 Viral Load XC # D51111 # D79377
  # ------------------------------
  "HIV-1 Viral Load XC" = @{
    Modes = @{
      Low  = @{
        CtMin     = 33.7; CtMax     = 35.9
        AvgLogMin = 2.08; AvgLogMax = 2.52
        SDMax     = 0.20
        LogMin    = 1.70; LogMax    = 2.90
        EPFMin    = 300
      }
      High = @{
        CtMin     = 22.6; CtMax     = 23.8
        AvgLogMin = 5.54; AvgLogMax = 5.86
        SDMax     = 0.10
        LogMin    = $null; LogMax   = $null
        EPFMin    = 583
      }
    }
    IQS = @{
      H = @{ CtMin = 21.4; CtMax = 24.4 }
      L = @{ CtMin = 29.3; CtMax = 32.0 }
    }
  }

}

function Get-ExpectedLog {
    param(
        [Parameter(Mandatory)][double]$Ct,
        [Parameter(Mandatory)][hashtable]$ModeSpec  # t.ex. $Assays['Xpert HCV VL Fingerstick'].Modes.Low
    )
    $ctSpan  = $ModeSpec.CtMax  - $ModeSpec.CtMin
    $logSpan = $ModeSpec.AvgLogMax - $ModeSpec.AvgLogMin
    if ($ctSpan -le 0 -or $logSpan -le 0) { throw "Ogiltiga intervall (CtSpan=$ctSpan, LogSpan=$logSpan)." }
    $frac = ($Ct - $ModeSpec.CtMin) / $ctSpan
    return $ModeSpec.AvgLogMax - $frac * $logSpan   # CtMin ↔ AvgLogMax, CtMax ↔ AvgLogMin
}

function Resolve-ModeFromSampleTypeCode {
    param(
        [Parameter(Mandatory)][int]$SampleTypeCode
    )
    switch ($SampleTypeCode) {
        1 { 'Low'  }
        2 { 'High' }
        default { 'Auto' }
    }
}

function Test-QuantGeneric {
    <#
    .SYNOPSIS
      PASS/MISQUANT beräkning mot din konstanter-tabell.

    .DESCRIPTION
      - Mode: Auto -> väljer Low/High från Ct
      - QC=PASS  -> ExpectedLog(Ct) ± SDMax
      - QC<>PASS -> LogMin..LogMax om de finns; annars fallback till dynamiskt fönster
      - IQS kontroller flaggas (kan göras strikt via -StrictQC)
      - EPF min (om spec anger det)

    .OUTPUTS
      Objekt med Status, Reason, ExpectedLog, Lower/Upper, Delta, Flags
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$AssayName,
        [Parameter(Mandatory)][double]$Ct,
        [Parameter(Mandatory)][double]$ReportedLog,
        [ValidateSet('PASS','FAIL','WARN','NA')] [string]$QCStatus = 'PASS',
        [ValidateSet('Auto','Low','High')] [string]$Mode = 'Auto',
        [Nullable[double]]$IQS_H_Ct = $null,
        [Nullable[double]]$IQS_L_Ct = $null,
        [Nullable[double]]$EPF = $null,
        [switch]$StrictQC
    )

    if (-not $Assays.ContainsKey($AssayName)) { throw "Okänt assay: $AssayName" }
    $spec = $Assays[$AssayName]
    $low  = $spec.Modes.Low
    $high = $spec.Modes.High

    # Mode-val
    if ($Mode -eq 'Auto') {
        if ($Ct -ge $low.CtMin -and $Ct -le $low.CtMax)      { $Mode = 'Low' }
        elseif ($Ct -ge $high.CtMin -and $Ct -le $high.CtMax) { $Mode = 'High' }
        else {
            return [pscustomobject]@{
                Assay=$AssayName; Mode='Unknown'; Status='MISQUANT'
                Reason="Ct $Ct utanför både Low [$($low.CtMin)-$($low.CtMax)] och High [$($high.CtMin)-$($high.CtMax)]."
                Ct=$Ct; ReportedLog=$ReportedLog
                ExpectedLog=$null; Lower=$null; Upper=$null; DeltaLog=$null
                Flags=@('Ct out-of-range')
            }
        }
    }
    $m = if ($Mode -eq 'Low') { $low } else { $high }

    # Ct-range i valt mode
    if ($Ct -lt $m.CtMin -or $Ct -gt $m.CtMax) {
        return [pscustomobject]@{
            Assay=$AssayName; Mode=$Mode; Status='MISQUANT'
            Reason="Ct $Ct utanför $Mode-intervall [$($m.CtMin),$($m.CtMax)]."
            Ct=$Ct; ReportedLog=$ReportedLog
            ExpectedLog=$null; Lower=$null; Upper=$null; DeltaLog=$null
            Flags=@('Ct out-of-range (mode)')
        }
    }

    # IQS QC (flagga)
    $flags = New-Object System.Collections.Generic.List[string]
    if ($IQS_H_Ct.HasValue) {
        $h = $spec.IQS.H
        if ($IQS_H_Ct.Value -lt $h.CtMin -or $IQS_H_Ct.Value -gt $h.CtMax) { $flags.Add("IQS-H $($IQS_H_Ct.Value) utanför [$($h.CtMin),$($h.CtMax)].") }
    }
    if ($IQS_L_Ct.HasValue) {
        $l = $spec.IQS.L
        if ($IQS_L_Ct.Value -lt $l.CtMin -or $IQS_L_Ct.Value -gt $l.CtMax) { $flags.Add("IQS-L $($IQS_L_Ct.Value) utanför [$($l.CtMin),$($l.CtMax)].") }
    }
    if ($EPF.HasValue -and $m.EPFMin) {
        if ($EPF.Value -lt $m.EPFMin) { $flags.Add("$Mode EPF $($EPF.Value) < min $($m.EPFMin).") }
    }

    # ExpectedLog & dynamiskt fönster ± SDMax
    $expected = Get-ExpectedLog -Ct $Ct -ModeSpec $m
    $lower    = $expected - $m.SDMax
    $upper    = $expected + $m.SDMax
    $delta    = [math]::Abs($ReportedLog - $expected)

    # Beslutsregler
    $status='PASS'; $reason='OK'
    if ($QCStatus -ne 'PASS') {
        if ($m.LogMin -ne $null -and $m.LogMax -ne $null) {
            if ($ReportedLog -lt $m.LogMin -or $ReportedLog -gt $m.LogMax) {
                $status='MISQUANT'
                $reason="QC=$QCStatus och ReportedLog $ReportedLog utanför globalt logfönster [$($m.LogMin),$($m.LogMax)]."
            } else {
                $status='PASS'
                $reason="QC=$QCStatus; ReportedLog inom globalt logfönster [$($m.LogMin),$($m.LogMax)]."
            }
        } else {
            # fallback-policy där globala gränser saknas
            if ($ReportedLog -lt $lower -or $ReportedLog -gt $upper) {
                $status='MISQUANT'
                $reason="QC=$QCStatus; dynamik: ReportedLog utanför [$([math]::Round($lower,3)),$([math]::Round($upper,3))]."
            } else {
                $status='PASS'
                $reason="QC=$QCStatus; dynamik: ReportedLog inom [$([math]::Round($lower,3)),$([math]::Round($upper,3))]."
            }
        }
    } else {
        if ($ReportedLog -lt $lower -or $ReportedLog -gt $upper) {
            $status='MISQUANT'
            $reason="ReportedLog $ReportedLog utanför dynamiskt fönster [$([math]::Round($lower,3)),$([math]::Round($upper,3))] (Expected=$([math]::Round($expected,3)); tol=±$([math]::Round($m.SDMax,3)))."
        } else {
            $status='PASS'
            $reason="ReportedLog inom dynamiskt fönster (Expected=$([math]::Round($expected,3)); tol=±$([math]::Round($m.SDMax,3)))."
        }
    }

    if ($StrictQC -and $flags.Count -gt 0) {
        $status='MISQUANT'
        if ($reason -eq 'OK') { $reason = 'QC flaggade och StrictQC aktivt.' }
    }

    [pscustomobject]@{
        Assay       = $AssayName
        Mode        = $Mode
        Status      = $status
        Reason      = $reason
        Ct          = $Ct
        ReportedLog = [math]::Round($ReportedLog,6)
        ExpectedLog = [math]::Round($expected,6)
        Lower       = [math]::Round($lower,6)
        Upper       = [math]::Round($upper,6)
        DeltaLog    = [math]::Round($delta,6)
        Flags       = $flags.ToArray()
    }
}

# ================================
# EXEMPEL (ta bort/behåll som självtest)
# Framtida måste hämtas korrekt från CSV
# ================================

# Exempel HCV Fingerstick (exempelvärden)
Test-QuantGeneric -AssayName "Xpert HCV VL Fingerstick" -Ct 39.4 -ReportedLog 2.00 -QCStatus PASS -Mode Auto

# Exempel HBV Low (exempelvärden)
Test-QuantGeneric -AssayName "Xpert HBV Viral Load" -Ct 33.6 -ReportedLog 2.08 -QCStatus PASS -Mode Auto

# Exempel HIV-1 XC Low m EPF & IQS – StrictQC aktiv (exempelvärden)
Test-QuantGeneric -AssayName "HIV-1 Viral Load XC" -Ct 34.4 -ReportedLog 2.18 -QCStatus PASS -Mode Auto `
  -IQS_H_Ct 22.5 -IQS_L_Ct 31.7 -EPF 310 -StrictQC

# Exempel:
Test-QuantGeneric -AssayName "HIV-1 Viral Load XC" -Ct 24.1 -ReportedLog 5.48 -QCStatus PASS -Mode High

# Exempel:
Test-QuantGeneric -AssayName "HIV-1 Viral Load XC" -Ct 24.0 -ReportedLog 5.38 -QCStatus PASS -Mode High