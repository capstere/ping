--- /mnt/data/Config.ps1.bak	2026-02-21 18:16:58.461367026 +0000
+++ /mnt/data/Config.ps1	2026-02-21 18:19:52.871705499 +0000
@@ -152,6 +152,13 @@
     SealPosPath    = ''
     WorksheetPath  = ''
 
+# --- Post-download organizer (Camstar -> Downloads -> N:) ---
+# Om tomt används standard för användarens "Downloads".
+DownloadsDir = ''
+
+# Rotmappar där LSP-mapparna ligger (per status). Används av "Flytta nedladdade filer"-knapparna.
+Stage3RootPath = (Resolve-IptPath (Join-Path $script:DefaultIptRoot '3. IPT - KLART FÖR SAMMANSTÄLLNING'))
+Stage4RootPath = (Resolve-IptPath (Join-Path $script:DefaultIptRoot '4. IPT - KLART FÖR GRANSKNING'))
     EnableSharePoint = $true
     # Styr om PnP-modulen laddas och Connect-PnPOnline körs vid uppstart.
     # Sätt $false för att hoppa över inloggning (SP Info skrivs ej, men rapporten genereras snabbare).







		 
		 
		 
	
	
	
	
		 --- /mnt/data/Main.ps1.bak	2026-02-21 18:16:58.454851044 +0000
+++ /mnt/data/Main.ps1	2026-02-21 18:20:11.572273674 +0000
@@ -304,6 +304,46 @@
 
 $tlSearch.Controls.Add($lblLSP,0,0)
 $tlSearch.Controls.Add($txtLSP,1,0)
+
+# ---------- Flytta nedladdade filer (Camstar -> Downloads -> N:) ----------
+$grpDl = New-Object System.Windows.Forms.GroupBox
+$grpDl.Text = 'Flytta nedladdade filer (från MES/Camstar)'
+$grpDl.Dock = 'Top'
+$grpDl.Padding = New-Object System.Windows.Forms.Padding(10,10,10,12)
+$grpDl.Height = 86
+
+$tlDl = New-Object System.Windows.Forms.TableLayoutPanel
+$tlDl.Dock = 'Fill'
+$tlDl.ColumnCount = 3
+$tlDl.RowCount = 2
+[void]$tlDl.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 100)))
+[void]$tlDl.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute, 210)))
+[void]$tlDl.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute, 210)))
+[void]$tlDl.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 22)))
+[void]$tlDl.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 40)))
+
+$lblDl = New-Object System.Windows.Forms.Label
+$lblDl.Text = 'Flyttar 1–5 filer från Downloads till LSP-mapp (matchar LSP##### i filnamn).'
+$lblDl.Dock = 'Fill'
+$lblDl.AutoSize = $false
+$lblDl.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
+
+$btnMove3 = New-Object System.Windows.Forms.Button
+$btnMove3.Text = '➡️ Till stage 3'
+$btnMove3.Dock = 'Fill'
+Set-AccentButton $btnMove3
+
+$btnMove4 = New-Object System.Windows.Forms.Button
+$btnMove4.Text = '➡️ Till stage 4'
+$btnMove4.Dock = 'Fill'
+Set-AccentButton $btnMove4
+
+$tlDl.Controls.Add($lblDl, 0, 0)
+$tlDl.SetColumnSpan($lblDl, 3)
+$tlDl.Controls.Add($btnMove3, 1, 1)
+$tlDl.Controls.Add($btnMove4, 2, 1)
+
+$grpDl.Controls.Add($tlDl)
 $tlSearch.Controls.Add($btnScan,2,0)
 
 $pLog = New-Object System.Windows.Forms.Panel
@@ -607,6 +647,7 @@
 $content.Controls.Add($grpSign)
 $content.Controls.Add($grpPick)
 $content.Controls.Add($pLog)
+$content.Controls.Add($grpDl)
 $content.Controls.Add($tlSearch)
 $content.Controls.Add($panelHeader)
 $content.ResumeLayout()
@@ -913,6 +954,264 @@
         } catch {}
     }
 
+function Get-DefaultDownloadsPath {
+    try {
+        # Försök använda känd mapp (Shell)
+        $d = [Environment]::GetFolderPath('UserProfile')
+        if ($d) {
+            $cand = Join-Path $d 'Downloads'
+            if (Test-Path -LiteralPath $cand) { return $cand }
+        }
+    } catch {}
+    try {
+        $cand = Join-Path $env:USERPROFILE 'Downloads'
+        if (Test-Path -LiteralPath $cand) { return $cand }
+    } catch {}
+    return $null
+}
+
+function Get-DownloadsPathEffective {
+    $cfg = Get-ConfigValue -Name 'DownloadsDir' -Default '' -ConfigOverride $Config
+    $cfg = ($cfg + '').Trim()
+    if ($cfg) {
+        try { if (Test-Path -LiteralPath $cfg) { return $cfg } } catch {}
+    }
+    return (Get-DefaultDownloadsPath)
+}
+
+function Get-LspDigitsFromString {
+    param([Parameter(Mandatory=$true)][string]$Text)
+
+    $s = ($Text + '')
+    if (-not $s) { return $null }
+
+    # Primär: LSP + exakt 5 siffror
+    if ($s -match '(?i)(?<!\d)LSP\D*(\d{5})(?!\d)') { return $matches[1] }
+
+    # Sekundär: bara en fristående 5-siffrig token (t.ex. "#38401" eller " 38401 ")
+    if ($s -match '(?i)(?<!\d)#?\s*(\d{5})(?!\d)') { return $matches[1] }
+
+    return $null
+}
+
+function Get-UniqueDestinationPath {
+    param(
+        [Parameter(Mandatory=$true)][string]$DestinationDir,
+        [Parameter(Mandatory=$true)][string]$FileName
+    )
+
+    $base = [System.IO.Path]::GetFileNameWithoutExtension($FileName)
+    $ext  = [System.IO.Path]::GetExtension($FileName)
+    $cand = Join-Path $DestinationDir ($base + $ext)
+    if (-not (Test-Path -LiteralPath $cand)) { return $cand }
+
+    for ($i=1; $i -le 50; $i++) {
+        $cand = Join-Path $DestinationDir ("{0} ({1}){2}" -f $base, $i, $ext)
+        if (-not (Test-Path -LiteralPath $cand)) { return $cand }
+    }
+
+    $stamp = (Get-Date).ToString('yyyyMMdd_HHmmss')
+    return (Join-Path $DestinationDir ("{0} ({1}){2}" -f $base, $stamp, $ext))
+}
+
+function Show-ListSelectionDialog {
+    param(
+        [Parameter(Mandatory=$true)][string]$Title,
+        [Parameter(Mandatory=$true)][string]$Prompt,
+        [Parameter(Mandatory=$true)][string[]]$Items
+    )
+
+    $dlg = New-Object System.Windows.Forms.Form
+    $dlg.Text = $Title
+    $dlg.StartPosition = 'CenterParent'
+    $dlg.Size = New-Object System.Drawing.Size(520,420)
+    $dlg.MinimumSize = New-Object System.Drawing.Size(520,420)
+    $dlg.MaximizeBox = $false
+    $dlg.MinimizeBox = $false
+    $dlg.FormBorderStyle = 'FixedDialog'
+    $dlg.Font = New-Object System.Drawing.Font('Segoe UI',10)
+
+    $lbl = New-Object System.Windows.Forms.Label
+    $lbl.Text = $Prompt
+    $lbl.Dock = 'Top'
+    $lbl.Height = 44
+    $lbl.Padding = New-Object System.Windows.Forms.Padding(10,10,10,0)
+
+    $list = New-Object System.Windows.Forms.ListBox
+    $list.Dock = 'Fill'
+    $list.IntegralHeight = $false
+    $list.SelectionMode = 'One'
+    [void]$list.Items.AddRange($Items)
+
+    $panelBtns = New-Object System.Windows.Forms.Panel
+    $panelBtns.Dock = 'Bottom'
+    $panelBtns.Height = 52
+    $panelBtns.Padding = New-Object System.Windows.Forms.Padding(10,8,10,8)
+
+    $btnOk = New-Object System.Windows.Forms.Button
+    $btnOk.Text = 'OK'
+    $btnOk.Width = 90
+    $btnOk.Anchor = 'Right'
+    $btnOk.DialogResult = [System.Windows.Forms.DialogResult]::OK
+
+    $btnCancel = New-Object System.Windows.Forms.Button
+    $btnCancel.Text = 'Avbryt'
+    $btnCancel.Width = 90
+    $btnCancel.Anchor = 'Right'
+    $btnCancel.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
+
+    $btnCancel.Location = New-Object System.Drawing.Point(($panelBtns.Width - 100), 10)
+
+    $panelBtns.Controls.Add($btnCancel)
+    $panelBtns.Controls.Add($btnOk)
+
+    $btnOk.Location = New-Object System.Drawing.Point(($dlg.ClientSize.Width - 210), 10)
+    $btnCancel.Location = New-Object System.Drawing.Point(($dlg.ClientSize.Width - 110), 10)
+
+    $dlg.AcceptButton = $btnOk
+    $dlg.CancelButton = $btnCancel
+
+    $dlg.Controls.Add($list)
+    $dlg.Controls.Add($panelBtns)
+    $dlg.Controls.Add($lbl)
+
+    $list.add_DoubleClick({ if ($list.SelectedItem) { $dlg.DialogResult = [System.Windows.Forms.DialogResult]::OK; $dlg.Close() } })
+
+    $res = $dlg.ShowDialog($form)
+    if ($res -ne [System.Windows.Forms.DialogResult]::OK) { return $null }
+    if (-not $list.SelectedItem) { return $null }
+    return [string]$list.SelectedItem
+}
+
+function Move-DownloadedLspFiles {
+    [CmdletBinding()]
+    param(
+        [Parameter(Mandatory=$true)][ValidateSet('3','4')][string]$TargetStage
+    )
+
+    if (-not (Assert-StartupReady)) { return }
+    if ($script:BuildInProgress -or $script:ScanInProgress) {
+        Gui-Log "⚠️ Vänta tills pågående operation är klar." 'Warn'
+        return
+    }
+
+    $downloads = Get-DownloadsPathEffective
+    if (-not $downloads -or -not (Test-Path -LiteralPath $downloads)) {
+        Gui-Log "❌ Kunde inte hitta Downloads-mappen. (Konfig: DownloadsDir)" 'Error'
+        return
+    }
+
+    $stageRoot = if ($TargetStage -eq '3') {
+        Get-ConfigValue -Name 'Stage3RootPath' -Default (Resolve-IptPath (Join-Path $script:DefaultIptRoot '3. IPT - KLART FÖR SAMMANSTÄLLNING')) -ConfigOverride $Config
+    } else {
+        Get-ConfigValue -Name 'Stage4RootPath' -Default (Resolve-IptPath (Join-Path $script:DefaultIptRoot '4. IPT - KLART FÖR GRANSKNING')) -ConfigOverride $Config
+    }
+
+    if (-not $stageRoot -or -not (Test-Path -LiteralPath $stageRoot)) {
+        Gui-Log "❌ Stage-rotmappen saknas: $stageRoot" 'Error'
+        return
+    }
+
+    $all = @()
+    try { $all = Get-ChildItem -LiteralPath $downloads -File -ErrorAction SilentlyContinue } catch {}
+    if (-not $all -or $all.Count -eq 0) {
+        Gui-Log "ℹ️ Inga filer i Downloads." 'Info'
+        return
+    }
+
+    # Grupp efter LSP i filnamn
+    $groups = @{}
+    foreach ($f in $all) {
+        $lsp = $null
+        try { $lsp = Get-LspDigitsFromString -Text $f.Name } catch { $lsp = $null }
+        if (-not $lsp) { continue }
+        if (-not $groups.ContainsKey($lsp)) { $groups[$lsp] = New-Object System.Collections.Generic.List[object] }
+        $groups[$lsp].Add($f)
+    }
+
+    if ($groups.Keys.Count -eq 0) {
+        Gui-Log "ℹ️ Hittade inga filer i Downloads med LSP##### i filnamn." 'Info'
+        return
+    }
+
+    # Om användaren redan skrivit LSP i rutan, använd den om den finns bland träffarna
+    $typed = ($txtLSP.Text + '').Trim()
+    $typedDigits = if ($typed) { ($typed -replace '\D','') } else { '' }
+
+    $selectedLsp = $null
+    if ($typedDigits -and $groups.ContainsKey($typedDigits)) {
+        $selectedLsp = $typedDigits
+    } elseif ($groups.Keys.Count -eq 1) {
+        $selectedLsp = @($groups.Keys)[0]
+    } else {
+        $opts = @($groups.Keys | Sort-Object)
+        $picked = Show-ListSelectionDialog -Title 'Välj LSP' -Prompt 'Flera LSP hittades i Downloads. Välj vilket som ska flyttas:' -Items $opts
+        if (-not $picked) { Gui-Log 'ℹ️ Avbrutet.' 'Info'; return }
+        $selectedLsp = $picked
+    }
+
+    $files = @($groups[$selectedLsp])
+    if (-not $files -or $files.Count -eq 0) {
+        Gui-Log "ℹ️ Inga filer att flytta för LSP$selectedLsp." 'Info'
+        return
+    }
+
+    $destFolder = Find-LspFolder -Lsp $selectedLsp -Roots @($stageRoot)
+    if (-not $destFolder) {
+        Gui-Log "❌ Hittade ingen LSP-mapp för $selectedLsp under: $stageRoot" 'Error'
+        return
+    }
+
+    Gui-Log ("📥 Downloads: {0}" -f $downloads) 'Info' 'USER'
+    Gui-Log ("📂 Destination: {0}" -f $destFolder.FullName) 'Info' 'USER'
+
+    $moved = New-Object System.Collections.Generic.List[string]
+    $failed = New-Object System.Collections.Generic.List[string]
+
+    foreach ($f in $files | Sort-Object LastWriteTime -Descending) {
+        try {
+            $target = Get-UniqueDestinationPath -DestinationDir $destFolder.FullName -FileName $f.Name
+            Move-Item -LiteralPath $f.FullName -Destination $target -Force
+            $moved.Add((Split-Path -Leaf $target))
+        } catch {
+            $failed.Add(("{0} -> {1}" -f $f.Name, $_.Exception.Message))
+        }
+    }
+
+    # Skriv loggfil i destinationen
+    try {
+        $logName = "MoveLog_LSP{0}_{1}.txt" -f $selectedLsp, (Get-Date).ToString('yyyyMMdd_HHmmss')
+        $logPath = Join-Path $destFolder.FullName $logName
+        $lines = New-Object System.Collections.Generic.List[string]
+        $lines.Add(("Timestamp: {0}" -f (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')))
+        $lines.Add(("User: {0}" -f $env:USERNAME))
+        $lines.Add(("From: {0}" -f $downloads))
+        $lines.Add(("To: {0}" -f $destFolder.FullName))
+        $lines.Add('')
+        $lines.Add('Moved:')
+        foreach ($n in $moved) { $lines.Add("  - $n") }
+        if ($failed.Count -gt 0) {
+            $lines.Add('')
+            $lines.Add('Failed:')
+            foreach ($e in $failed) { $lines.Add("  - $e") }
+        }
+        [System.IO.File]::WriteAllLines($logPath, $lines.ToArray(), [System.Text.Encoding]::UTF8)
+    } catch {}
+
+    if ($moved.Count -gt 0) {
+        Gui-Log ("✅ Flyttade {0} fil(er) för LSP{1} till stage {2}." -f $moved.Count, $selectedLsp, $TargetStage) 'Info' 'USER'
+    } else {
+        Gui-Log ("⚠️ Inga filer flyttades för LSP{0}." -f $selectedLsp) 'Warn' 'USER'
+    }
+
+    if ($failed.Count -gt 0) {
+        Gui-Log ("⚠️ {0} fil(er) kunde inte flyttas. Se MoveLog i destinationen." -f $failed.Count) 'Warn' 'USER'
+    }
+}
+
 #region Händelsehanterare
 $miScan.add_Click({ $btnScan.PerformClick() })
@@ -1162,6 +1458,10 @@
 
 # Om
 $miOm.add_Click({ [System.Windows.Forms.MessageBox]::Show("OBS! Detta är endast ett hjälpmedel och ersätter inte någon IPT-process.`n $ScriptVersion`nav Jesper","Om") | Out-Null })
+
+# Flytta nedladdade filer (LSP##### i filnamn)
+$btnMove3.Add_Click({ Move-DownloadedLspFiles -TargetStage '3' })
+$btnMove4.Add_Click({ Move-DownloadedLspFiles -TargetStage '4' })
 
 $btnScan.Add_Click({
     if (-not (Assert-StartupReady)) { return }
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 






*** ALL DIFFS (Config.ps1 + Main.ps1) ***

--- Config.ps1	2026-02-21
+++ Config.ps1	2026-02-21
@@ -152,6 +152,14 @@
     SealPosPath    = ''
     WorksheetPath  = ''
 
+    # --- Post-download organizer (Camstar -> Downloads -> N:) ---
+    # Om tomt används standard för användarens 'Downloads'.
+    DownloadsDir = ''
+
+    # Rotmappar där LSP-mapparna ligger (per status). Används av "Flytta nedladdade filer"-knapparna.
+    Stage3RootPath = (Resolve-IptPath (Join-Path $script:DefaultIptRoot '3. IPT - KLART FÖR SAMMANSTÄLLNING'))
+    Stage4RootPath = (Resolve-IptPath (Join-Path $script:DefaultIptRoot '4. IPT - KLART FÖR GRANSKNING'))
+
     EnableSharePoint = $true


--- Main.ps1	2026-02-21
+++ Main.ps1	2026-02-21
@@ -1612,6 +1612,56 @@
 # ============================
 # ===== RAPPORTLOGIK =========
 # ============================
+
+function Show-CloseFileToContinueDialog {
+    param(
+        [Parameter(Mandatory=$true)][string]$Path,
+        [string]$ExtraHint = ''
+    )
+
+    $leaf = $Path
+    try { $leaf = Split-Path $Path -Leaf } catch {}
+
+    $msg = "Stäng fil:`n`n$leaf`n`nFör att fortsätta."
+    if ($ExtraHint) { $msg += "`n`nTips: $ExtraHint" }
+
+    try {
+        return [System.Windows.Forms.MessageBox]::Show(
+            $msg,
+            'Filen är öppen',
+            [System.Windows.Forms.MessageBoxButtons]::RetryCancel,
+            [System.Windows.Forms.MessageBoxIcon]::Warning
+        )
+    } catch {
+        return [System.Windows.Forms.DialogResult]::Cancel
+    }
+}
+
+function Ensure-FilesClosedOrCancel {
+    param(
+        [Parameter(Mandatory=$true)][string[]]$Paths,
+        [string]$Hint = 'Om filen inte är öppen i Excel: stäng förhandsvisning i Explorer, eller OneDrive/Preview som kan låsa filen.'
+    )
+
+    $clean = @($Paths | Where-Object { $_ -and (Test-Path -LiteralPath $_) } | Select-Object -Unique)
+    if (-not $clean -or $clean.Count -eq 0) { return $true }
+
+    while ($true) {
+        $locked = $null
+        foreach ($p in $clean) {
+            try {
+                if (Test-FileLocked $p) { $locked = $p; break }
+            } catch {}
+        }
+
+        if (-not $locked) { return $true }
+
+        $res = Show-CloseFileToContinueDialog -Path $locked -ExtraHint $Hint
+        if ($res -ne [System.Windows.Forms.DialogResult]::Retry) { return $false }
+        Start-Sleep -Milliseconds 200
+    }
+}
+
@@ -1725,6 +1775,13 @@
             $posWritable = -not (Test-FileLocked $selPos); if (-not $posWritable) { Gui-Log "🔒 POS är låst (öppen i Excel?)." 'Warn' }
         }
 
+        # UX: Om någon vald fil är öppen/låst – be användaren stänga den och Försök igen.
+        $pathsToCheck = @($selNeg, $selPos)
+        if (-not (Ensure-FilesClosedOrCancel -Paths $pathsToCheck)) {
+            Gui-Log "🛑 Avbrutet: en eller flera filer var öppna/låsta." 'Warn'
+            return
+        }
+
         # ----------------------------
         # Öppna paket
         # ----------------------------
@@ -1738,6 +1795,11 @@
 
         $templatePath = Join-Path $PSScriptRoot "output_template-v4.xlsx"
         if (-not (Test-Path -LiteralPath $templatePath)) { Gui-Log "❌ Mallfilen 'output_template-v4.xlsx' saknas!" 'Error'; return }
+        # UX: Mallfilen kan vara låst om någon har den öppen (t.ex. förhandsvisning/Excel).
+        if (-not (Ensure-FilesClosedOrCancel -Paths @($templatePath))) {
+            Gui-Log "🛑 Avbrutet: mallfilen är öppen/låst." 'Warn'
+            return
+        }
         try {
             $pkgOut = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($templatePath))
         } catch {
@@ -4461,6 +4523,15 @@
             }
 
             Set-UiStep 90 'Sparar rapport…'
+            # UX: Om rapportfilen redan finns och är öppen (Excel), be användaren stänga innan SaveAs
+            try {
+                if ($SavePath -and (Test-Path -LiteralPath $SavePath)) {
+                    if (-not (Ensure-FilesClosedOrCancel -Paths @($SavePath) -Hint 'Stäng rapporten i Excel (eller stäng Preview i Explorer) och klicka Försök igen.')) {
+                        Gui-Log "🛑 Avbrutet: output-filen är låst/öppen." 'Warn'
+                        return
+                    }
+                }
+            } catch {}
             $pkgOut.SaveAs($SavePath)
             Set-UiStep 100 'Klar ✅'
             Gui-Log -Text ("✅ Rapport sparad: {0}" -f $SavePath) -Severity Info -Category RESULT