﻿Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

# ----------------------------- Settings -----------------------------
$AppName            = 'IPTCompile'
$CacheRoot          = 'C:\IPTCompile'
$AuditFolderName    = '_LauncherAudit'
$VersionFileName    = 'Version.txt'
$SourcePathFileName = 'SourcePath.txt'

$RoboCopyMT   = 8
$RoboRetries  = 2
$RoboWaitSec  = 1

$ExcludeDirs = @($AuditFolderName, 'Loggar', 'audit')

# ----------------------------- Helpers -----------------------------
function Get-ScriptDir {
    if ($PSScriptRoot) { return $PSScriptRoot }
    if ($PSCommandPath) { return (Split-Path -LiteralPath $PSCommandPath -Parent) }
    return (Get-Location).Path
}

function Read-FirstNonEmptyLine([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path)) { return $null }
    foreach ($line in [System.IO.File]::ReadAllLines($Path)) {
        $t = ($line + '').Trim()
        if ($t) {
            if ($t.StartsWith('"') -and $t.EndsWith('"') -and $t.Length -ge 2) {
                $t = $t.Substring(1, $t.Length - 2)
            }
            return $t.Trim()
        }
    }
    return $null
}

function Ensure-DirWritable([string]$Path) {
    try {
        if (-not (Test-Path -LiteralPath $Path)) {
            New-Item -Path $Path -ItemType Directory -Force | Out-Null
        }
        $probe = Join-Path $Path ("._probe_{0}.tmp" -f [Guid]::NewGuid().ToString('N'))
        [System.IO.File]::WriteAllText($probe, 'ok')
        Remove-Item -LiteralPath $probe -Force -ErrorAction SilentlyContinue
        return $true
    } catch {
        return $false
    }
}

function Normalize-Version([string]$v) {
    $t = ($v + '').Trim()
    if (-not $t) { return '0' }
    return $t
}

function Resolve-NetworkPath([string]$Path) {
    $p = ($Path + '').Trim()
    if (-not $p) { return $Path }

    if ($p -match '^[A-Za-z]:\\') {
        try {
            $drive = $p.Substring(0,2)
            $ld = Get-WmiObject -Class Win32_LogicalDisk -Filter ("DeviceID='{0}'" -f $drive) -ErrorAction Stop
            if ($ld -and $ld.ProviderName) {
                return ($ld.ProviderName + $p.Substring(2))
            }
        } catch {
            # best-effort
        }
    }
    return $p
}

function Write-Audit {
    param(
        [string]$AuditDir,
        [string]$Message,
        [ValidateSet('INFO','WARN','ERROR')] [string]$Level = 'INFO'
    )
    $ts = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
    $line = '[{0}] [{1}] {2}' -f $ts, $Level, $Message

    Write-Host $line
    if (-not $AuditDir) { return }

    try {
        if (-not (Test-Path -LiteralPath $AuditDir)) {
            New-Item -Path $AuditDir -ItemType Directory -Force | Out-Null
        }
        $logPath = Join-Path $AuditDir 'Launcher.log'
        Add-Content -LiteralPath $logPath -Value $line -Encoding UTF8
    } catch {
    }
}

function Get-LogTail([string]$Path, [int]$Lines = 30) {
    try {
        if ($Path -and (Test-Path -LiteralPath $Path)) {
            return (Get-Content -LiteralPath $Path -Tail $Lines -ErrorAction Stop) -join [Environment]::NewLine
        }
    } catch { }
    return $null
}

function Invoke-Robocopy {
    param(
        [string]$Source,
        [string]$Dest,
        [string[]]$ExcludeDirectories,
        [string]$LogFile,
        [int]$MultiThread = $RoboCopyMT,
        [int]$Retries = $RoboRetries,
        [int]$WaitSec = $RoboWaitSec,
        [switch]$Restartable
    )

    $args = New-Object System.Collections.Generic.List[string]
    $args.Add("`"$Source`"")
    $args.Add("`"$Dest`"")
    $args.Add('/MIR')
    $args.Add("/R:$Retries")
    $args.Add("/W:$WaitSec")
    $args.Add('/FFT')
    $args.Add('/XJ')
    $args.Add('/NP')
    $args.Add('/NFL')
    $args.Add('/NDL')
    
    if ($Restartable) { $args.Add('/Z') }

    if ($MultiThread -gt 1) { $args.Add("/MT:$MultiThread") }

    foreach ($xd in ($ExcludeDirectories | Where-Object { $_ })) {
        $args.Add('/XD')
        $args.Add("`"$(Join-Path $Source $xd)`"")
    }

    if ($LogFile) {
        $args.Add("/LOG:`"$LogFile`"")
    }

    $p = Start-Process -FilePath 'robocopy.exe' -ArgumentList $args.ToArray() -Wait -PassThru -WindowStyle Hidden
    return $p.ExitCode
}

function Invoke-RobocopyWithRetry {
    param(
        [string]$Source,
        [string]$Dest,
        [string[]]$ExcludeDirectories,
        [string]$LogFile,
        [string]$AuditDir
    )

    $rc = Invoke-Robocopy -Source $Source -Dest $Dest -ExcludeDirectories $ExcludeDirectories -LogFile $LogFile `
        -MultiThread $RoboCopyMT -Retries $RoboRetries -WaitSec $RoboWaitSec

    if ($rc -lt 8) { return $rc }

    $tail = Get-LogTail -Path $LogFile -Lines 20
    if ($tail) {
        Write-Audit -AuditDir $AuditDir -Level WARN -Message ("Robocopy misslyckades (kod=$rc). Sista loggrader:`n$tail")
    } else {
        Write-Audit -AuditDir $AuditDir -Level WARN -Message ("Robocopy misslyckades (kod=$rc). Försöker igen med säkrare inställningar…")
    }

    Start-Sleep -Seconds 2

    $rc = Invoke-Robocopy -Source $Source -Dest $Dest -ExcludeDirectories $ExcludeDirectories -LogFile $LogFile `
        -MultiThread 1 -Retries 5 -WaitSec 2 -Restartable

    return $rc
}

function Get-PowerShellExe {
    $sysnative = Join-Path $env:WINDIR 'sysnative\WindowsPowerShell\v1.0\powershell.exe'
    if ([Environment]::Is64BitOperatingSystem -and -not [Environment]::Is64BitProcess -and (Test-Path -LiteralPath $sysnative)) {
        return $sysnative
    }
    return (Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe')
}

function Invoke-IptMain {
    param(
        [string]$MainPath
    )

    if ([string]::IsNullOrWhiteSpace($MainPath)) {
        throw "Invoke-IptMain: MainPath saknas."
    }

    if ($script:SourceRoot) { $env:IPT_NETWORK_ROOT = $script:SourceRoot }

    $exe = Get-PowerShellExe

    $full = [System.IO.Path]::GetFullPath($MainPath)
    $wd   = [System.IO.Path]::GetDirectoryName($full)

    Push-Location -LiteralPath $wd
    try {
        & $exe -NoProfile -ExecutionPolicy Bypass -File $full
        $rc = $LASTEXITCODE
    } finally {
        Pop-Location
    }
    exit $rc
}

# ----------------------------- Main -----------------------------
$scriptDir = Get-ScriptDir
$srcFile   = Join-Path $scriptDir $SourcePathFileName
$script:SourceRoot = Read-FirstNonEmptyLine -Path $srcFile

if (-not $script:SourceRoot) {
    Write-Host '[ERROR] SourcePath.txt saknas eller är tom bredvid Launcher.ps1'
    exit 1
}

$script:SourceRoot = Resolve-NetworkPath $script:SourceRoot
$script:SourceRoot = $script:SourceRoot.TrimEnd('\')
$mainNet = Join-Path $script:SourceRoot 'Main.ps1'
if (-not (Test-Path -LiteralPath $mainNet)) {
    Write-Host ('[ERROR] Källsökväg saknar Main.ps1: {0}' -f $script:SourceRoot)
    exit 1
}

$auditDir = Join-Path $script:SourceRoot $AuditFolderName
Write-Audit -AuditDir $auditDir -Level INFO -Message ('Launcher start. SourceRoot={0}' -f $script:SourceRoot)

if (-not (Ensure-DirWritable -Path $CacheRoot)) {
    Write-Audit -AuditDir $auditDir -Level ERROR -Message ('Kunde inte skapa skrivbar cachemapp: {0}. Kör från nätverket.' -f $CacheRoot)
    Invoke-IptMain -MainPath $mainNet
}

$dest  = $CacheRoot

$rbLog = Join-Path $auditDir 'robocopy_last.log'

try {
    $srcFull  = [System.IO.Path]::GetFullPath($script:SourceRoot)
    $destFull = [System.IO.Path]::GetFullPath($dest)
    if ($destFull.StartsWith($srcFull, [System.StringComparison]::OrdinalIgnoreCase) -or
        $srcFull.StartsWith($destFull, [System.StringComparison]::OrdinalIgnoreCase)) {
        throw ('Säkerhetskontroll: käll- och cachesökväg överlappar. Source={0} Cache={1}' -f $srcFull, $destFull)
    }
} catch {
    Write-Audit -AuditDir $auditDir -Level ERROR -Message $_.Exception.Message
    Invoke-IptMain -MainPath $mainNet
}

$netVerPath = Join-Path $script:SourceRoot $VersionFileName
$locVerPath = Join-Path $dest $VersionFileName

$vNet = Normalize-Version (Read-FirstNonEmptyLine -Path $netVerPath)
$vLoc = Normalize-Version (Read-FirstNonEmptyLine -Path $locVerPath)

$needCopy = $false
if (-not (Test-Path -LiteralPath (Join-Path $dest 'Main.ps1'))) { $needCopy = $true }
elseif (Test-Path -LiteralPath $netVerPath) {
    if ($vNet -ne $vLoc) { $needCopy = $true }
}

$mutexName = ('Global\{0}_CacheUpdate' -f $AppName)
try {
    $mutex = New-Object System.Threading.Mutex($false, $mutexName)
} catch {
    $mutexName = ('Local\{0}_CacheUpdate' -f $AppName)
    $mutex = New-Object System.Threading.Mutex($false, $mutexName)
}

$haveMutex = $false

try {
    $haveMutex = $mutex.WaitOne(25000)
    if (-not $haveMutex) {
        Write-Audit -AuditDir $auditDir -Level WARN -Message 'Cache-uppdatering låst av annan instans. Kör befintlig cache om möjligt.'
        $localMain = Join-Path $dest 'Main.ps1'
        if (Test-Path -LiteralPath $localMain) {
            Invoke-IptMain -MainPath $localMain
        } else {
            Invoke-IptMain -MainPath $mainNet
        }
    }
    if ($needCopy) {
        Write-Audit -AuditDir $auditDir -Level INFO -Message ('Uppdaterar cache (in-place). Dest={0} vNet={1} vLoc={2}' -f $dest, $vNet, $vLoc)

        # Säkerställ att målmappen finns
        if (-not (Test-Path -LiteralPath $dest)) {
            New-Item -Path $dest -ItemType Directory -Force | Out-Null
        }

        # Direkt robocopy: nätverk → cache (ingen staging/swap)
        $rc = Invoke-RobocopyWithRetry -Source $script:SourceRoot -Dest $dest -ExcludeDirectories $ExcludeDirs -LogFile $rbLog -AuditDir $auditDir
        Write-Audit -AuditDir $auditDir -Level INFO -Message ('Robocopy exitkod={0} (0-7 OK, 8+ fel). Logg={1}' -f $rc, $rbLog)

        if ($rc -ge 8) {
            $localMain = Join-Path $dest 'Main.ps1'
            if (Test-Path -LiteralPath $localMain) {
                Write-Audit -AuditDir $auditDir -Level WARN -Message ('Robocopy misslyckades (kod={0}). Kör befintlig cache: {1}' -f $rc, $dest)
            } else {
                Write-Audit -AuditDir $auditDir -Level ERROR -Message ('Robocopy misslyckades (kod={0}). Ingen lokal cache – kör från nätverket.' -f $rc)
                Invoke-IptMain -MainPath $mainNet
            }
        } else {
            # Uppdatera versionsfilen i cachen
            if (Test-Path -LiteralPath $netVerPath) {
                try { Set-Content -LiteralPath (Join-Path $dest $VersionFileName) -Value $vNet -Encoding ASCII } catch { }
            }
        }

        # Slutkontroll: Main.ps1 måste finnas
        $mainLocal = Join-Path $dest 'Main.ps1'
        if (-not (Test-Path -LiteralPath $mainLocal)) {
            Write-Audit -AuditDir $auditDir -Level ERROR -Message 'Main.ps1 saknas i cache efter uppdatering. Kör från nätverket.'
            Invoke-IptMain -MainPath $mainNet
        }
    } else {
        Write-Audit -AuditDir $auditDir -Level INFO -Message ('Cache uppdaterad. vLoc={0}' -f $vLoc)
    }

} finally {
    if ($haveMutex) { try { $mutex.ReleaseMutex() } catch { } }
    $mutex.Dispose()
}

$mainLocalFinal = Join-Path $dest 'Main.ps1'

if (Test-Path -LiteralPath $mainLocalFinal) {
    Write-Audit -AuditDir $auditDir -Level INFO -Message ('Kör lokalt: {0}' -f $mainLocalFinal)
    Invoke-IptMain -MainPath $mainLocalFinal
} else {
    Write-Audit -AuditDir $auditDir -Level WARN -Message ('Lokal cache saknar Main.ps1; kör från nätverket: {0}' -f $mainNet)
    Invoke-IptMain -MainPath $mainNet
}