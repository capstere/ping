﻿[CmdletBinding()]
param(
    [string]$Lsp,
    [string]$HeadFolder,
    [string]$NewDatePrefix
)

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles() | Out-Null

function Get-WinAccentColor {
    try {
        $p = Get-ItemProperty 'HKCU:\Software\Microsoft\Windows\DWM' -ErrorAction Stop
        $argb = if ($p.AccentColor) { $p.AccentColor } elseif ($p.ColorizationColor) { $p.ColorizationColor } else { $null }
        if ($argb) { return [System.Drawing.Color]::FromArgb([int]$argb) }
    } catch {}
    return [System.Drawing.Color]::FromArgb(38, 120, 178)
}

function New-Color {
    param([int]$A, [int]$R, [int]$G, [int]$B)
    [System.Drawing.Color]::FromArgb($A, $R, $G, $B)
}

function Darken {
    param([System.Drawing.Color]$c, [double]$f = 0.85)
    New-Color 255 ([int]($c.R * $f)) ([int]($c.G * $f)) ([int]($c.B * $f))
}

function Lighten {
    param([System.Drawing.Color]$c, [double]$f = 0.12)
    New-Color 255 `
        ([int]([Math]::Min(255, $c.R + (255 - $c.R) * $f))) `
        ([int]([Math]::Min(255, $c.G + (255 - $c.G) * $f))) `
        ([int]([Math]::Min(255, $c.B + (255 - $c.B) * $f)))
}

$Accent         = Get-WinAccentColor
$AccentBorder   = Darken  $Accent 0.75
$AccentHover    = Lighten $Accent 0.12
$AccentDisabled = New-Color 255 210 210 210

$Theme = @{
    FormBack    = New-Color 255 245 248 250
    HeaderBack  = $Accent
    HeaderText  = [System.Drawing.Color]::White
    HeaderSub   = Lighten $Accent 0.40
    AccentLine  = $AccentBorder
    GroupBack   = New-Color 255 252 252 252
    ButtonBack  = $Accent
    ButtonFore  = [System.Drawing.Color]::White
    ButtonHover = $AccentHover
    ButtonBorder= $AccentBorder
    LogBack     = [System.Drawing.Color]::White
}

# =====================[ KONFIG ]=====================

$RootFolders = @(
    '\\SE.CEPHEID.PRI\Cepheid Sweden\QC\QC-1\IPT\Skiftspecifika dokument\PQC analyst\JESPER\Scripts\Tests',
    '\\SE.CEPHEID.PRI\Cepheid Sweden\QC\QC-1\IPT\3. IPT - KLART FÖR SAMMANSTÄLLNING',
    '\\SE.CEPHEID.PRI\Cepheid Sweden\QC\QC-1\IPT\4. IPT - KLART FÖR GRANSKNING'
) |
Where-Object { $_ -and (Test-Path -LiteralPath $_) } |
Select-Object -Unique

if (-not $RootFolders -or $RootFolders.Count -eq 0) {
    [System.Windows.Forms.MessageBox]::Show(
        "Inga giltiga rotmappar hittades i konfigurationen.",
        "LSP-datum-prefix-rename"
    ) | Out-Null
    return
}

# =====================[ GUI-logg ]=====================

$script:LogTextBox        = $null
$script:CurrentItems      = @()
$script:CurrentHeadFolder = $null
$script:LspHits           = @()

function Add-GuiLog {
    param([string]$Text)

    if ($script:LogTextBox -ne $null -and -not $script:LogTextBox.IsDisposed) {
        if ($script:LogTextBox.TextLength -gt 0) {
            $script:LogTextBox.AppendText("`r`n$Text")
        } else {
            $script:LogTextBox.AppendText($Text)
        }
        $script:LogTextBox.SelectionStart = $script:LogTextBox.TextLength
        $script:LogTextBox.ScrollToCaret()
    }
}

# =====================[ Hjälpfunktioner ]=====================

function Parse-DatePrefixName {
    param(
        [Parameter(Mandatory=$true)][string]$Name
    )

    # Förväntat format: "yyyy MM dd Resten av namnet.ext"
    $pattern = '^(?<year>\d{4})\s(?<month>\d{2})\s(?<day>\d{2})\s(?<rest>.+)$'
    $m = [System.Text.RegularExpressions.Regex]::Match($Name, $pattern)
    if (-not $m.Success) { return $null }

    $year  = [int]$m.Groups['year'].Value
    $month = [int]$m.Groups['month'].Value
    $day   = [int]$m.Groups['day'].Value

    try {
        $dt = Get-Date -Year $year -Month $month -Day $day -Hour 0 -Minute 0 -Second 0
    }
    catch {
        return $null
    }

    [pscustomobject]@{
        Date  = $dt
        Rest  = $m.Groups['rest'].Value
        Year  = $year
        Month = $month
        Day   = $day
    }
}

function Get-RelativePath {
    param(
        [Parameter(Mandatory=$true)][string]$Base,
        [Parameter(Mandatory=$true)][string]$Full
    )

    $baseNorm = (Resolve-Path -LiteralPath $Base).ProviderPath.TrimEnd('\')
    $fullNorm = (Resolve-Path -LiteralPath $Full).ProviderPath.TrimEnd('\')

    if ($fullNorm.StartsWith($baseNorm, [System.StringComparison]::OrdinalIgnoreCase)) {
        $rel = $fullNorm.Substring($baseNorm.Length)
        if ($rel.StartsWith('\')) { $rel = $rel.Substring(1) }
        return $rel
    }

    return $Full
}

function Truncate-Text {
    param(
        [Parameter(Mandatory=$true)][string]$Text,
        [Parameter(Mandatory=$true)][int]$MaxLength
    )

    if ($Text.Length -le $MaxLength) { return $Text }

    $half = [int]([math]::Floor(($MaxLength - 5) / 2))
    if ($half -lt 1) { return $Text.Substring(0, $MaxLength) }

    $start = $Text.Substring(0, $half + 2)
    $end   = $Text.Substring($Text.Length - $half, $half)

    return ("{0} ... {1}" -f $start, $end)
}

function Scan-DatePrefixItems {
    param(
        [Parameter(Mandatory=$true)][string]$BaseFolder,
        [Parameter(Mandatory=$true)][string]$TargetDatePrefix
    )

    $results = @()

    if ([string]::IsNullOrWhiteSpace($BaseFolder)) { return $results }
    if (-not (Test-Path -LiteralPath $BaseFolder -PathType Container)) { return $results }

    $baseResolved = (Resolve-Path -LiteralPath $BaseFolder).ProviderPath

    $scanCount = 0

    # --- Mappar ---
    $dirs = @()
    try {
        $dirs = [System.IO.Directory]::EnumerateDirectories(
            $baseResolved,
            '*',
            [System.IO.SearchOption]::AllDirectories
        )
    }
    catch { $dirs = @() }

    foreach ($dir in $dirs) {
        $scanCount++
        if (($scanCount % 200) -eq 0) { [System.Windows.Forms.Application]::DoEvents() }

        $name   = [System.IO.Path]::GetFileName($dir)
        $parsed = Parse-DatePrefixName -Name $name
        if ($parsed -eq $null) { continue }

        $newName = "{0} {1}" -f $TargetDatePrefix, $parsed.Rest

        $results += [pscustomobject]@{
            IsDir    = $true
            FullName = $dir
            OldName  = $name
            NewName  = $newName
            RelPath  = Get-RelativePath -Base $baseResolved -Full $dir
        }
    }

    # --- Filer ---
    $files = @()
    try {
        $files = [System.IO.Directory]::EnumerateFiles(
            $baseResolved,
            '*',
            [System.IO.SearchOption]::AllDirectories
        )
    }
    catch { $files = @() }

    foreach ($file in $files) {
        $scanCount++
        if (($scanCount % 200) -eq 0) { [System.Windows.Forms.Application]::DoEvents() }

        $name   = [System.IO.Path]::GetFileName($file)
        $parsed = Parse-DatePrefixName -Name $name
        if ($parsed -eq $null) { continue }

        $newName = "{0} {1}" -f $TargetDatePrefix, $parsed.Rest

        $results += [pscustomobject]@{
            IsDir    = $false
            FullName = $file
            OldName  = $name
            NewName  = $newName
            RelPath  = Get-RelativePath -Base $baseResolved -Full $file
        }
    }

    $results
}

function Test-FileLocked {
    param(
        [Parameter(Mandatory=$true)][string]$Path
    )

    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return $false }

    try {
        $stream = [System.IO.File]::Open($Path,
            [System.IO.FileMode]::Open,
            [System.IO.FileAccess]::ReadWrite,
            [System.IO.FileShare]::None
        )
        if ($stream) {
            $stream.Close()
            return $false
        }
    }
    catch {
        return $true
    }

    return $false
}

function Apply-Rename {
    param(
        [string]$BaseFolder,
        [object[]]$Items,
        [string]$TargetDatePrefix
    )

    $DirOK = 0
    $DirErr = 0
    $FileOK = 0
    $FileErr = 0
    $LockedFiles = @()

    # --- 1) Mappar, djupaste först ---
    $dirItems = @($Items | Where-Object { $_.IsDir -eq $true })
    if ($dirItems.Count -gt 0) {
        $dirItems = $dirItems | Sort-Object {
            if ([string]::IsNullOrWhiteSpace($_.RelPath)) {
                0
            }
            else {
                ($_.RelPath -split '\\').Length
            }
        } -Descending

        $i = 0
        foreach ($item in $dirItems) {
            $i++
            if (($i % 100) -eq 0) { [System.Windows.Forms.Application]::DoEvents() }

            $full = $item.FullName
            if (-not (Test-Path -LiteralPath $full -PathType Container)) {
                $DirErr++
                continue
            }

            $parent     = [System.IO.Path]::GetDirectoryName($full)
            $targetLeaf = $item.NewName
            $target     = Join-Path -Path $parent -ChildPath $targetLeaf

            if ($full.TrimEnd('\') -ieq $target.TrimEnd('\')) { continue }

            if (Test-Path -LiteralPath $target) {
                $altLeaf   = ($item.NewName + " (1)")
                $altTarget = Join-Path -Path $parent -ChildPath $altLeaf

                if (Test-Path -LiteralPath $altTarget) {
                    Add-GuiLog ("Varning: kunde inte byta mapp (mål finns redan två gånger): {0}" -f $full)
                    $DirErr++
                    continue
                }
                else {
                    $targetLeaf = $altLeaf
                    $target     = $altTarget
                }
            }

            try {
                Rename-Item -LiteralPath $full -NewName $targetLeaf -ErrorAction Stop
                $DirOK++
            }
            catch {
                Add-GuiLog ("Varning: kunde inte byta mapp: {0}. Fel: {1}" -f $full, $_.Exception.Message)
                $DirErr++
            }
        }
    }

    # --- 2) Skanna om filer efter mapp-bytet ---
    $fileItems = Scan-DatePrefixItems -BaseFolder $BaseFolder -TargetDatePrefix $TargetDatePrefix |
        Where-Object { $_.IsDir -eq $false }

    # --- 3) Filer ---
    $j = 0
    foreach ($item in $fileItems) {
        $j++
        if (($j % 200) -eq 0) { [System.Windows.Forms.Application]::DoEvents() }

        $full = $item.FullName
        if (-not (Test-Path -LiteralPath $full -PathType Leaf)) {
            $FileErr++
            continue
        }

        if (Test-FileLocked -Path $full) {
            Add-GuiLog ("🔒 Låst fil (hoppar över): {0}" -f $full)
            $FileErr++
            $LockedFiles += $full
            continue
        }

        $parent     = [System.IO.Path]::GetDirectoryName($full)
        $targetLeaf = $item.NewName
        $target     = Join-Path -Path $parent -ChildPath $targetLeaf

        if ($full -ieq $target) { continue }

        if (Test-Path -LiteralPath $target) {
            $nameOnly = [System.IO.Path]::GetFileNameWithoutExtension($item.NewName)
            $ext      = [System.IO.Path]::GetExtension($item.NewName)

            if ($ext) {
                $altLeaf = ("{0} (1){1}" -f $nameOnly, $ext)
            }
            else {
                $altLeaf = ($nameOnly + " (1)")
            }

            $altTarget = Join-Path -Path $parent -ChildPath $altLeaf
            if (Test-Path -LiteralPath $altTarget) {
                Add-GuiLog ("Varning: kunde inte byta fil (mål finns redan två gånger): {0}" -f $full)
                $FileErr++
                continue
            }
            else {
                $targetLeaf = $altLeaf
                $target     = $altTarget
            }
        }

        try {
            Rename-Item -LiteralPath $full -NewName $targetLeaf -ErrorAction Stop
            $FileOK++
        }
        catch {
            Add-GuiLog ("Varning: kunde inte byta fil: {0}. Fel: {1}" -f $full, $_.Exception.Message)
            $FileErr++
        }
    }

    [pscustomobject]@{
        DirOK       = $DirOK
        DirErr      = $DirErr
        FileOK      = $FileOK
        FileErr     = $FileErr
        LockedFiles = $LockedFiles
    }
}

function Find-LspHeadFolders {
    param(
        [Parameter(Mandatory=$true)][string]$LspNumber
    )

    # FIX: använd giltigt regex (ingen "*" i början)
    $pattern = [regex]::Escape($LspNumber.Trim())
    $hits    = @()

    foreach ($root in $RootFolders) {
        if (-not (Test-Path -LiteralPath $root -PathType Container)) { continue }

        try {
            $children = Get-ChildItem -LiteralPath $root -Directory -ErrorAction SilentlyContinue
        }
        catch { $children = @() }

        foreach ($child in $children) {
            if ($child.Name -match $pattern) {
                $full = $child.FullName
                if ($full -match '^[A-Za-z]:\\?$' -or $full -match '^[A-Za-z]:?$') {
                    continue
                }

                $hits += [pscustomobject]@{
                    Name     = $child.Name
                    FullPath = $full
                }
            }
        }
    }

    $hits
}

# =====================[ GUI-layout ]=====================

$form = New-Object System.Windows.Forms.Form
$form.Text = "Click-Less · LSP-datum-prefix-rename"
$form.StartPosition = "CenterScreen"
$form.Size = New-Object System.Drawing.Size(1200, 900)
$form.MinimumSize = New-Object System.Drawing.Size(1000, 600)
$form.BackColor = $Theme.FormBack
$form.Font = New-Object System.Drawing.Font("Segoe UI", 9)

# TOP filter-panel
$panelTop = New-Object System.Windows.Forms.Panel
$panelTop.Dock = [System.Windows.Forms.DockStyle]::Top
$panelTop.Height = 90
$panelTop.Padding = New-Object System.Windows.Forms.Padding(10,4,10,4)
$panelTop.BackColor = $Theme.FormBack
$form.Controls.Add($panelTop)

# MITT-panel (preview)
$panelMid = New-Object System.Windows.Forms.Panel
$panelMid.Dock = [System.Windows.Forms.DockStyle]::Fill
$panelMid.Padding = New-Object System.Windows.Forms.Padding(10,4,10,4)
$panelMid.BackColor = $Theme.FormBack
$form.Controls.Add($panelMid)

# BOTTOM-panel (logg + knappar)
$panelBottom = New-Object System.Windows.Forms.Panel
$panelBottom.Dock = [System.Windows.Forms.DockStyle]::Bottom
$panelBottom.Height = 120
$panelBottom.Padding = New-Object System.Windows.Forms.Padding(10,4,10,10)
$panelBottom.BackColor = $Theme.FormBack
$form.Controls.Add($panelBottom)

# Accentlinje
$panelAccent = New-Object System.Windows.Forms.Panel
$panelAccent.Dock = [System.Windows.Forms.DockStyle]::Top
$panelAccent.Height = 2
$panelAccent.BackColor = $Theme.AccentLine
$form.Controls.Add($panelAccent)

# Header (ska ligga allra överst)
$panelHeader = New-Object System.Windows.Forms.Panel
$panelHeader.Dock = [System.Windows.Forms.DockStyle]::Top
$panelHeader.Height = 70
$panelHeader.Padding = New-Object System.Windows.Forms.Padding(15, 12, 15, 8)
$panelHeader.BackColor = $Theme.HeaderBack
$form.Controls.Add($panelHeader)

$lblTitle = New-Object System.Windows.Forms.Label
$lblTitle.Text = "LSP-datum-prefix-rename"
$lblTitle.AutoSize = $true
$lblTitle.ForeColor = $Theme.HeaderText
$lblTitle.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 14, [System.Drawing.FontStyle]::Bold)
$lblTitle.Location = New-Object System.Drawing.Point(10, 8)
$panelHeader.Controls.Add($lblTitle)

$lblSubtitle = New-Object System.Windows.Forms.Label
$lblSubtitle.Text = "Byter datum-prefix (yyyy MM dd) i alla mappar och filer under vald LSP-huvudmapp."
$lblSubtitle.AutoSize = $true
$lblSubtitle.ForeColor = $Theme.HeaderSub
$lblSubtitle.Font = New-Object System.Drawing.Font("Segoe UI", 9)
$lblSubtitle.Location = New-Object System.Drawing.Point(12, 38)
$panelHeader.Controls.Add($lblSubtitle)

# ----- Innehåll TOP: två groupboxes -----

$grpLsp = New-Object System.Windows.Forms.GroupBox
$grpLsp.Text = " LSP "
$grpLsp.BackColor = $Theme.GroupBack
$grpLsp.Location = New-Object System.Drawing.Point(10, 5)
$grpLsp.Size = New-Object System.Drawing.Size(650, 80)
$panelTop.Controls.Add($grpLsp)

$lblLsp = New-Object System.Windows.Forms.Label
$lblLsp.Text = "LSP-nummer:"
$lblLsp.AutoSize = $true
$lblLsp.Location = New-Object System.Drawing.Point(10, 25)
$grpLsp.Controls.Add($lblLsp)

$txtLsp = New-Object System.Windows.Forms.TextBox
$txtLsp.Location = New-Object System.Drawing.Point(100, 22)
$txtLsp.Width = 120
$grpLsp.Controls.Add($txtLsp)

$btnFindLsp = New-Object System.Windows.Forms.Button
$btnFindLsp.Text = "Hitta LSP-mappar"
$btnFindLsp.Location = New-Object System.Drawing.Point(240, 20)
$btnFindLsp.Width = 150
$grpLsp.Controls.Add($btnFindLsp)

$lblLspHits = New-Object System.Windows.Forms.Label
$lblLspHits.Text = "LSP-mappar:"
$lblLspHits.AutoSize = $true
$lblLspHits.Location = New-Object System.Drawing.Point(10, 53)
$grpLsp.Controls.Add($lblLspHits)

$listLspHits = New-Object System.Windows.Forms.ListBox
$listLspHits.Location = New-Object System.Drawing.Point(100, 49)
$listLspHits.Width = 500
$listLspHits.Height = 22
$listLspHits.Anchor = "Top,Left,Right"
$grpLsp.Controls.Add($listLspHits)

$grpDate = New-Object System.Windows.Forms.GroupBox
$grpDate.Text = " Datum-prefix "
$grpDate.BackColor = $Theme.GroupBack
$grpDate.Location = New-Object System.Drawing.Point(680, 5)
$grpDate.Size = New-Object System.Drawing.Size(480, 80)
$panelTop.Controls.Add($grpDate)

$lblDate = New-Object System.Windows.Forms.Label
$lblDate.Text = "Nytt datum-prefix (yyyy MM dd):"
$lblDate.AutoSize = $true
$lblDate.Location = New-Object System.Drawing.Point(10, 25)
$grpDate.Controls.Add($lblDate)

$txtDate = New-Object System.Windows.Forms.TextBox
$txtDate.Location = New-Object System.Drawing.Point(210, 22)
$txtDate.Width = 110
if ($NewDatePrefix) { $txtDate.Text = $NewDatePrefix } else { $txtDate.Text = (Get-Date -Format 'yyyy MM dd') }
$grpDate.Controls.Add($txtDate)

$btnScan = New-Object System.Windows.Forms.Button
$btnScan.Text = "Skanna datum-prefix"
$btnScan.Location = New-Object System.Drawing.Point(335, 20)
$btnScan.Width = 130
$grpDate.Controls.Add($btnScan)

$form.Add_Resize({
    $width = $form.ClientSize.Width - 20
    $grpLsp.Width  = [int]($width * 0.6)
    $grpDate.Width = [int]($width * 0.4)
    $grpDate.Left  = 10 + $grpLsp.Width + 10
})

# ----- Innehåll MID: ListView -----

$lvPreview = New-Object System.Windows.Forms.ListView
$lvPreview.View             = [System.Windows.Forms.View]::Details
$lvPreview.FullRowSelect    = $true
$lvPreview.GridLines        = $true
$lvPreview.HideSelection    = $false
$lvPreview.ShowItemToolTips = $true
$lvPreview.Font             = New-Object System.Drawing.Font("Consolas", 9)
$lvPreview.Dock             = [System.Windows.Forms.DockStyle]::Fill
$lvPreview.Scrollable       = $true
$lvPreview.MultiSelect      = $false

$colOld = $lvPreview.Columns.Add("Nuvarande namn", 550)
$colNew = $lvPreview.Columns.Add("Nytt namn", 550)
$panelMid.Controls.Add($lvPreview)

$lvPreview.Add_SizeChanged({
    $totalWidth = $lvPreview.ClientSize.Width
    if ($totalWidth -gt 0) {
        $colWidth = [int]([math]::Floor($totalWidth / 2))
        $colOld.Width = $colWidth
        $colNew.Width = $colWidth
    }
})

# ----- Innehåll BOTTOM: logg + knappar -----

$lblSummary = New-Object System.Windows.Forms.Label
$lblSummary.Text = "Ingen skanning utförd ännu."
$lblSummary.AutoSize = $true
$lblSummary.Location = New-Object System.Drawing.Point(10, 5)
$panelBottom.Controls.Add($lblSummary)

$lblLog = New-Object System.Windows.Forms.Label
$lblLog.Text = "Logg:"
$lblLog.AutoSize = $true
$lblLog.Location = New-Object System.Drawing.Point(10, 30)
$panelBottom.Controls.Add($lblLog)

$txtLog = New-Object System.Windows.Forms.TextBox
$txtLog.Location = New-Object System.Drawing.Point(60, 28)
$txtLog.Width = 780
$txtLog.Height = 60
$txtLog.Multiline = $true
$txtLog.ScrollBars = "Vertical"
$txtLog.ReadOnly = $true
$txtLog.BackColor = $Theme.LogBack
$txtLog.Anchor = "Top,Left,Right"
$panelBottom.Controls.Add($txtLog)
$script:LogTextBox = $txtLog

# Panel för knappar till höger
$panelButtons = New-Object System.Windows.Forms.Panel
$panelButtons.Dock = [System.Windows.Forms.DockStyle]::Right
$panelButtons.Width = 180
$panelButtons.BackColor = $Theme.FormBack
$panelBottom.Controls.Add($panelButtons)

$btnRename = New-Object System.Windows.Forms.Button
$btnRename.Text = "Byt datum-prefix"
$btnRename.Width = 160
$btnRename.Location = New-Object System.Drawing.Point(10, 20)
$panelButtons.Controls.Add($btnRename)

$btnClose = New-Object System.Windows.Forms.Button
$btnClose.Text = "Avsluta"
$btnClose.Width = 160
$btnClose.Location = New-Object System.Drawing.Point(10, 60)
$btnClose.Add_Click({ $form.Close() })
$panelButtons.Controls.Add($btnClose)

foreach ($btn in @($btnFindLsp, $btnScan, $btnRename, $btnClose)) {
    $btn.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $btn.FlatAppearance.BorderSize = 1
    $btn.FlatAppearance.BorderColor = $Theme.ButtonBorder
    $btn.BackColor = $Theme.ButtonBack
    $btn.ForeColor = $Theme.ButtonFore
    $btn.Add_MouseEnter({ param($s,$e) $s.BackColor = $Theme.ButtonHover })
    $btn.Add_MouseLeave({ param($s,$e) $s.BackColor = $Theme.ButtonBack })
}

# =====================[ Enter-genvägar ]=====================

$txtLsp.Add_KeyDown({
    param($sender, $e)
    if ($e.KeyCode -eq [System.Windows.Forms.Keys]::Enter) {
        $e.SuppressKeyPress = $true
        $btnFindLsp.PerformClick()
    }
})

$txtDate.Add_KeyDown({
    param($sender, $e)
    if ($e.KeyCode -eq [System.Windows.Forms.Keys]::Enter) {
        $e.SuppressKeyPress = $true
        $btnScan.PerformClick()
    }
})

# =====================[ Händelser ]=====================

$btnFindLsp.Add_Click({
    $txtLog.Clear()
    $lvPreview.Items.Clear()
    $lblSummary.Text = "Ingen skanning utförd ännu."
    $script:CurrentItems = @()
    $script:CurrentHeadFolder = $null
    $listLspHits.Items.Clear()
    $script:LspHits = @()

    $lspVal = $txtLsp.Text.Trim()
    if ([string]::IsNullOrWhiteSpace($lspVal)) {
        [System.Windows.Forms.MessageBox]::Show("Ange LSP-nummer först.","LSP") | Out-Null
        return
    }

    Add-GuiLog ("Söker LSP-mappar för #{0}..." -f $lspVal)
    $hits = Find-LspHeadFolders -LspNumber $lspVal

    if (-not $hits -or $hits.Count -eq 0) {
        Add-GuiLog ("Inga LSP-huvudmappar (#{0}) hittades i rotmapparna." -f $lspVal)
        [System.Windows.Forms.MessageBox]::Show(
            ("Inga LSP-mappar hittades för #{0}." -f $lspVal),
            "LSP"
        ) | Out-Null
        return
    }

    $script:LspHits = $hits
    foreach ($h in $hits) { [void]$listLspHits.Items.Add($h.Name) }
    if ($listLspHits.Items.Count -gt 0) { $listLspHits.SelectedIndex = 0 }

    Add-GuiLog ("Hittade {0} LSP-huvudmappor." -f $hits.Count)
})

$btnScan.Add_Click({
    $txtLog.Clear()
    $lvPreview.Items.Clear()
    $script:CurrentItems = @()

    if (-not $script:LspHits -or $script:LspHits.Count -eq 0) {
        if (-not [string]::IsNullOrWhiteSpace($txtLsp.Text)) {
            $btnFindLsp.PerformClick()
            if ($listLspHits.Items.Count -eq 0) { return }
        }
    }

    if ($listLspHits.SelectedIndex -lt 0) {
        [System.Windows.Forms.MessageBox]::Show("Välj en LSP-mapp i listan.","LSP") | Out-Null
        return
    }

    $head = $script:LspHits[$listLspHits.SelectedIndex].FullPath
    $script:CurrentHeadFolder = $head

    $prefix = $txtDate.Text.Trim()
    if ($prefix -notmatch '^\d{4}\s\d{2}\s\d{2}$') {
        [System.Windows.Forms.MessageBox]::Show(
            "Ogiltigt datum-prefix. Använd formatet 'yyyy MM dd'.",
            "Datum-prefix"
        ) | Out-Null
        return
    }

    Add-GuiLog ("Skannar '{0}' för datum-prefix..." -f (Split-Path -Path $head -Leaf))
    [System.Windows.Forms.Application]::DoEvents()

    $items = Scan-DatePrefixItems -BaseFolder $head -TargetDatePrefix $prefix
    $script:CurrentItems = $items

    if (-not $items -or $items.Count -eq 0) {
        $lblSummary.Text = "Inga filer/mappar med giltigt datum-prefix hittades."
        Add-GuiLog "Inga filer/mappar med giltigt datum-prefix hittades. Ingen åtgärd."
        return
    }

    $dirCount   = (@($items | Where-Object { $_.IsDir -eq $true })).Count
    $fileCount  = (@($items | Where-Object { $_.IsDir -eq $false })).Count

    $lblSummary.Text = ("Hittade {0} mappar och {1} filer med datum-prefix." -f $dirCount, $fileCount)
    Add-GuiLog ("Hittade {0} mappar och {1} filer med datum-prefix." -f $dirCount, $fileCount)

    $lvPreview.BeginUpdate()
    try {
        foreach ($it in $items) {
            $oldShort = Truncate-Text -Text $it.OldName -MaxLength 60
            $newShort = Truncate-Text -Text $it.NewName -MaxLength 60

            $li = New-Object System.Windows.Forms.ListViewItem
            $li.Text = $oldShort
            [void]$li.SubItems.Add($newShort)

            $li.ToolTipText = ("{0}`r`n→`r`n{1}" -f $it.OldName, $it.NewName)
            [void]$lvPreview.Items.Add($li)
        }
    }
    finally {
        $lvPreview.EndUpdate()
    }

    $lvPreview.AutoResizeColumns([System.Windows.Forms.ColumnHeaderAutoResizeStyle]::ColumnContent)

    if ($lvPreview.Items.Count -gt 0) {
        $lvPreview.TopItem = $lvPreview.Items[0]
    }

    Add-GuiLog "Granska listan ovan. Klicka 'Byt datum-prefix' för att genomföra ändringen."
})

$btnRename.Add_Click({
    if (-not $script:CurrentHeadFolder -or -not $script:CurrentItems -or $script:CurrentItems.Count -eq 0) {
        [System.Windows.Forms.MessageBox]::Show(
            "Ingen skanning att genomföra. Skanna först.",
            "Byt datum-prefix"
        ) | Out-Null
        return
    }

    $prefix = $txtDate.Text.Trim()
    if ($prefix -notmatch '^\d{4}\s\d{2}\s\d{2}$') {
        [System.Windows.Forms.MessageBox]::Show(
            "Ogiltigt datum-prefix. Använd formatet 'yyyy MM dd'.",
            "Datum-prefix"
        ) | Out-Null
        return
    }

    $confirm = [System.Windows.Forms.MessageBox]::Show(
        ("Vill du byta datum-prefix till '{0}' i alla listade filer och mappar?" -f $prefix),
        "Bekräfta",
        [System.Windows.Forms.MessageBoxButtons]::YesNo,
        [System.Windows.Forms.MessageBoxIcon]::Question
    )

    if ($confirm -ne [System.Windows.Forms.DialogResult]::Yes) {
        Add-GuiLog "Avbröt datum-byte på användarens begäran."
        return
    }

    Add-GuiLog "Genomför datum-byte..."
    [System.Windows.Forms.Application]::DoEvents()

    $result = Apply-Rename -BaseFolder $script:CurrentHeadFolder -Items $script:CurrentItems -TargetDatePrefix $prefix

    Add-GuiLog ""
    Add-GuiLog ("Mappar bytta: {0}, fel: {1}" -f $result.DirOK, $result.DirErr)
    Add-GuiLog ("Filer bytta:  {0}, fel: {1}" -f $result.FileOK, $result.FileErr)

    if ($result.LockedFiles -and $result.LockedFiles.Count -gt 0) {
        $lockedCount = $result.LockedFiles.Count
        Add-GuiLog ("Obs: {0} fil(er) var låsta (troligen öppna i Excel) och hoppades över." -f $lockedCount)

        $toShow = $result.LockedFiles | Select-Object -First 5
        foreach ($lf in $toShow) {
            Add-GuiLog ("  Låst: {0}" -f $lf)
        }

        if ($lockedCount -gt 5) {
            $extraLocked = $lockedCount - 5
            Add-GuiLog ("  ...och ytterligare {0} låsta filer." -f $extraLocked)
        }

        Add-GuiLog "Stäng Excel-filerna och kör skriptet igen om de också ska bytas."
    }

    Add-GuiLog ""
    Add-GuiLog "Klar. Om något blev fel, kör skriptet igen och välj rätt datum / LSP-mapp."
})

# Om HeadFolder angivits vid start – använd den direkt
if ($HeadFolder -and (Test-Path -LiteralPath $HeadFolder -PathType Container)) {
    $resolved = (Resolve-Path -LiteralPath $HeadFolder).ProviderPath
    $script:LspHits = @([pscustomobject]@{
        Name     = (Split-Path -Path $resolved -Leaf)
        FullPath = $resolved
    })
    $listLspHits.Items.Clear()
    [void]$listLspHits.Items.Add($script:LspHits[0].Name)
    $listLspHits.SelectedIndex = 0
}

[void]$form.ShowDialog()