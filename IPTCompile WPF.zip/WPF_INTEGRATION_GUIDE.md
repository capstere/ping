# =============================================================================
# IPTCompile — WPF GUI Integration Guide
# =============================================================================
#
# Hur man byter från WinForms till WPF i Main.ps1
# ================================================
#
# STEG 1: Kopiera WpfGui.ps1 till Modules-mappen
# -----------------------------------------------
#   Kopiera filen WpfGui.ps1 till samma mapp som övriga moduler:
#     Modules/WpfGui.ps1
#
#
# STEG 2: Modifiera Main.ps1 (3 ändringar)
# -----------------------------------------
#
# ÄNDRING 1 (rad ~9-12): Ta bort WinForms assembly loading
#   Main.ps1 laddar redan assemblies tidigt. WpfGui.ps1 hanterar sina egna.
#   Inga ändringar behövs här — WpfGui.ps1 laddar WPF-assemblies och 
#   behåller WinForms för kompatibilitet (MessageBox, OpenFileDialog).
#
#
# ÄNDRING 2 (rad ~111-687): Ersätt hela #region GUI med en rad
#   KOMMENTERA BORT eller RADERA allt mellan:
#     #region GUI
#     ...  (ca 575 rader GUI-bygge)
#     #endregion GUI-bygge
#
#   ERSÄTT MED:
#     . (Join-Path $modulesRoot 'WpfGui.ps1')
#
#   Detta laddar hela WPF-GUI:t och skapar identiska variabelnamn.
#
#
# ÄNDRING 3 (rad ~5354): Byt Application.Run mot WPF ShowDialog
#   ERSÄTT:
#     [System.Windows.Forms.Application]::Run($form)
#
#   MED:
#     $script:WpfWindow.ShowDialog() | Out-Null
#
#
# VARIABLER SOM EXPONERAS AV WpfGui.ps1
# ======================================
# Alla dessa skapas med identiska namn så att befintlig kod fungerar:
#
# GUI-kontroller:
#   $form             — Form-adapter (proxy med .Close(), .Text, .Height)
#   $txtLSP           — WPF TextBox (LSP-nummer)
#   $btnScan          — WPF Button (sök filer)
#   $btnBuild         — WPF Button (skapa rapport)
#   $outputBox        — WPF TextBox (logg-output, readonly)
#   $txtSigner        — WPF TextBox (signatur)
#   $chkWriteSign     — WPF CheckBox (signera)
#   $chkOverwriteSign — WPF CheckBox (aktivera)
#   $grpSign          — WPF Border (signaturruta, .Visible adapter)
#   $grpDl            — WPF Border (flytta filer)
#   $btnMove3         — WPF Button (TEST, dold)
#   $btnMove4         — WPF Button (KLART FÖR GRANSKNING)
#   $btnCsvBrowse     — WPF Button
#   $btnNegBrowse     — WPF Button
#   $btnPosBrowse     — WPF Button
#   $btnLspBrowse     — WPF Button
#
# CheckedListBox-adapters (identiskt API):
#   $clbCsv           — Items.Add/Clear/Count, GetItemChecked, SetItemChecked
#   $clbNeg           — dito
#   $clbPos           — dito
#   $clbLsp           — dito
#
# Menyalternativ:
#   $menuStrip, $miArkiv, $miVerktyg, $miSettings, $miHelp, $miAbout
#   $miNew, $miOpenRecent, $miExit, $miScan, $miBuild
#   $miScript1..5, $miToggleSign, $miTheme
#   $miLightTheme, $miDarkTheme, $miShowInstr, $miFAQ, $miHelpDlg
#   $miGenvagar, $miOm
#
# Statusrad:
#   $slCount          — TextBlock (filantal)
#   $slWork           — TextBlock (meddelande)
#   $pbWork           — ProgressBar
#   $slBatchLink      — TextBlock med .Enabled, .Tag, .IsLink
#   $btnSpConnect     — WPF Button
#
# Funktioner som omdefinieras:
#   Set-Theme, Set-UiBusy, Set-UiStep, Update-StatusBar
#   Invoke-UiPump, Enable-DoubleBuffer, Add-ShortcutItem
#   Set-LogOutputControl
#
#
# VERIFIERING
# ===========
# 1. Kopiera WpfGui.ps1 → Modules/
# 2. Gör ändringarna ovan i Main.ps1
# 3. Kör: powershell -STA -ExecutionPolicy Bypass -File Main.ps1.ps1
# 4. Verifiera att GUI:t startar med det nya mörka temat
# 5. Testa: LSP-sökning, filval, rapportgenerering
#
#
# ROLLBACK
# ========
# Om något inte fungerar, ångra bara de 3 ändringarna i Main.ps1.
# WpfGui.ps1 påverkar inga andra filer och kan tas bort utan konsekvenser.
#
# =============================================================================
