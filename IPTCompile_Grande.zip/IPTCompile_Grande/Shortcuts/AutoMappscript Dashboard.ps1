﻿<#
Dashboard för MAPPPSCRIPTISH Errorlog, Folderlog och Log från AutoMappscript.
laddar in CSV-loggfiler
#>

#region
Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName PresentationCore
Add-Type -AssemblyName WindowsBase
Add-Type -AssemblyName System.Windows.Forms
#endregion

#region ── konfigiigi
$Script:LogBasePath = '\\SE.CEPHEID.PRI\Cepheid Sweden\QC\QC-1\IPT\Skiftspecifika dokument\Skift 1\Mahdi\powerpoint\AutoMappscript\Log'
$Script:Version     = 'AutoMappscript Dashboard v1.0'

# Färger
$Script:Colors = @{
    BgDark        = '#0F1923'
    BgCard        = '#172231'
    BgCardHover   = '#1E2D3F'
    BgInput       = '#1A2A3A'
    Accent        = '#00B4D8'
    AccentDim     = '#0090AD'
    AccentGlow    = '#00D4FF'
    Error         = '#FF6B6B'
    ErrorDim      = '#CC4444'
    Warning       = '#FFB347'
    Success       = '#4ADE80'
    TextPrimary   = '#E8EDF2'
    TextSecondary = '#8899AA'
    TextMuted     = '#5A6A7A'
    Border        = '#2A3A4A'
    TabActive     = '#00B4D8'
    TabInactive   = '#2A3A4A'
    RowAlt        = '#1A2838'
    RowHover      = '#1F3040'
}
#endregion

#region XAML
[xml]$XAML = @"
<Window
    xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
    xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
    Title="$($Script:Version)"
    Width="1320" Height="820"
    MinWidth="900" MinHeight="600"
    WindowStartupLocation="CenterScreen"
    Background="$($Script:Colors.BgDark)"
    FontFamily="Segoe UI"
    Foreground="$($Script:Colors.TextPrimary)">

    <Window.Resources>
        <!-- ScrollBar Styling -->
        <Style TargetType="ScrollBar">
            <Setter Property="Width" Value="8"/>
            <Setter Property="Background" Value="Transparent"/>
        </Style>
        <Style TargetType="ScrollViewer">
            <Setter Property="VerticalScrollBarVisibility" Value="Auto"/>
        </Style>

        <!-- Button Base -->
        <Style x:Key="BtnBase" TargetType="Button">
            <Setter Property="Background" Value="$($Script:Colors.BgCard)"/>
            <Setter Property="Foreground" Value="$($Script:Colors.TextPrimary)"/>
            <Setter Property="BorderBrush" Value="$($Script:Colors.Border)"/>
            <Setter Property="BorderThickness" Value="1"/>
            <Setter Property="Padding" Value="16,8"/>
            <Setter Property="Cursor" Value="Hand"/>
            <Setter Property="FontSize" Value="13"/>
            <Setter Property="Template">
            <Setter.Value>
            <ControlTemplate TargetType="Button">
            <Border x:Name="bd" Background="{TemplateBinding Background}"
             BorderBrush="{TemplateBinding BorderBrush}"
             BorderThickness="{TemplateBinding BorderThickness}"
             CornerRadius="6" Padding="{TemplateBinding Padding}">
             <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
             </Border>
             <ControlTemplate.Triggers>
             <Trigger Property="IsMouseOver" Value="True">
             <Setter TargetName="bd" Property="Background" Value="$($Script:Colors.BgCardHover)"/>
             <Setter TargetName="bd" Property="BorderBrush" Value="$($Script:Colors.Accent)"/>
                            </Trigger>
                        </ControlTemplate.Triggers>
                    </ControlTemplate>
                </Setter.Value>
            </Setter>
        </Style>

        <!-- Accent Button -->
        <Style x:Key="BtnAccent" TargetType="Button" BasedOn="{StaticResource BtnBase}">
            <Setter Property="Background" Value="$($Script:Colors.Accent)"/>
            <Setter Property="Foreground" Value="#FFFFFF"/>
            <Setter Property="BorderBrush" Value="$($Script:Colors.Accent)"/>
            <Setter Property="FontWeight" Value="SemiBold"/>
        </Style>

        <!-- TextBox -->
        <Style x:Key="SearchBox" TargetType="TextBox">
            <Setter Property="Background" Value="$($Script:Colors.BgInput)"/>
            <Setter Property="Foreground" Value="$($Script:Colors.TextPrimary)"/>
            <Setter Property="BorderBrush" Value="$($Script:Colors.Border)"/>
            <Setter Property="BorderThickness" Value="1"/>
            <Setter Property="Padding" Value="10,8"/>
            <Setter Property="FontSize" Value="13"/>
            <Setter Property="CaretBrush" Value="$($Script:Colors.Accent)"/>
        </Style>

        <!-- ComboBox -->
        <Style TargetType="ComboBox">
            <Setter Property="Background" Value="$($Script:Colors.BgInput)"/>
            <Setter Property="Foreground" Value="$($Script:Colors.TextPrimary)"/>
            <Setter Property="BorderBrush" Value="$($Script:Colors.Border)"/>
            <Setter Property="Padding" Value="8,6"/>
            <Setter Property="FontSize" Value="13"/>
        </Style>
        <Style TargetType="ComboBoxItem">
            <Setter Property="Background" Value="$($Script:Colors.BgCard)"/>
            <Setter Property="Foreground" Value="$($Script:Colors.TextPrimary)"/>
            <Setter Property="Padding" Value="8,6"/>
            <Style.Triggers>
                <Trigger Property="IsHighlighted" Value="True">
                    <Setter Property="Background" Value="$($Script:Colors.Accent)"/>
                    <Setter Property="Foreground" Value="#FFFFFF"/>
                </Trigger>
            </Style.Triggers>
        </Style>

        <!-- DataGrid Styling -->
        <Style TargetType="DataGrid">
            <Setter Property="Background" Value="Transparent"/>
            <Setter Property="Foreground" Value="$($Script:Colors.TextPrimary)"/>
            <Setter Property="BorderBrush" Value="$($Script:Colors.Border)"/>
            <Setter Property="BorderThickness" Value="1"/>
            <Setter Property="RowBackground" Value="$($Script:Colors.BgCard)"/>
            <Setter Property="AlternatingRowBackground" Value="$($Script:Colors.RowAlt)"/>
            <Setter Property="GridLinesVisibility" Value="Horizontal"/>
            <Setter Property="HorizontalGridLinesBrush" Value="$($Script:Colors.Border)"/>
            <Setter Property="VerticalGridLinesBrush" Value="Transparent"/>
            <Setter Property="HeadersVisibility" Value="Column"/>
            <Setter Property="SelectionMode" Value="Single"/>
            <Setter Property="IsReadOnly" Value="True"/>
            <Setter Property="AutoGenerateColumns" Value="False"/>
            <Setter Property="CanUserReorderColumns" Value="True"/>
            <Setter Property="CanUserSortColumns" Value="True"/>
            <Setter Property="FontSize" Value="12.5"/>
        </Style>
        <Style TargetType="DataGridColumnHeader">
            <Setter Property="Background" Value="$($Script:Colors.BgDark)"/>
            <Setter Property="Foreground" Value="$($Script:Colors.Accent)"/>
            <Setter Property="FontWeight" Value="SemiBold"/>
            <Setter Property="FontSize" Value="12"/>
            <Setter Property="Padding" Value="12,10"/>
            <Setter Property="BorderBrush" Value="$($Script:Colors.Border)"/>
            <Setter Property="BorderThickness" Value="0,0,1,2"/>
        </Style>
        <Style TargetType="DataGridRow">
            <Setter Property="Cursor" Value="Hand"/>
            <Style.Triggers>
                <Trigger Property="IsSelected" Value="True">
                    <Setter Property="Background" Value="$($Script:Colors.AccentDim)"/>
                </Trigger>
                <Trigger Property="IsMouseOver" Value="True">
                    <Setter Property="Background" Value="$($Script:Colors.RowHover)"/>
                </Trigger>
            </Style.Triggers>
        </Style>
        <Style TargetType="DataGridCell">
            <Setter Property="Padding" Value="12,8"/>
            <Setter Property="BorderThickness" Value="0"/>
            <Setter Property="Template">
                <Setter.Value>
                    <ControlTemplate TargetType="DataGridCell">
                        <Border Padding="{TemplateBinding Padding}" Background="{TemplateBinding Background}">
                            <ContentPresenter VerticalAlignment="Center"/>
                        </Border>
                    </ControlTemplate>
                </Setter.Value>
            </Setter>
            <Style.Triggers>
                <Trigger Property="IsSelected" Value="True">
                    <Setter Property="Foreground" Value="White"/>
                </Trigger>
            </Style.Triggers>
        </Style>
    </Window.Resources>

    <Grid Margin="0">
        <Grid.RowDefinitions>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="*"/>
            <RowDefinition Height="Auto"/>
        </Grid.RowDefinitions>

        <!-- ═══ Header ═══ -->
        <Border Grid.Row="0" Background="$($Script:Colors.BgCard)" BorderBrush="$($Script:Colors.Border)" BorderThickness="0,0,0,1">
            <Grid Margin="24,16">
                <Grid.ColumnDefinitions>
                    <ColumnDefinition Width="*"/>
                    <ColumnDefinition Width="Auto"/>
                </Grid.ColumnDefinitions>

                <StackPanel Grid.Column="0" Orientation="Horizontal" VerticalAlignment="Center">
                    <!-- Logo icon -->
                    <Border Width="38" Height="38" CornerRadius="8" Background="$($Script:Colors.Accent)" Margin="0,0,14,0">
                        <TextBlock Text="A" FontSize="20" FontWeight="Bold" Foreground="White"
                                   HorizontalAlignment="Center" VerticalAlignment="Center"/>
                    </Border>
                    <StackPanel VerticalAlignment="Center">
                        <TextBlock Text="AutoMappscript Dashboard" FontSize="18" FontWeight="SemiBold"
                                   Foreground="$($Script:Colors.TextPrimary)"/>
                        <TextBlock x:Name="txtSubtitle" Text="Log Viewer" FontSize="11"
                                   Foreground="$($Script:Colors.TextSecondary)" Margin="0,2,0,0"/>
                    </StackPanel>
                </StackPanel>

                <StackPanel Grid.Column="1" Orientation="Horizontal" VerticalAlignment="Center">
                    <Button x:Name="btnRefresh" Content="⟳  Uppdatera" Style="{StaticResource BtnAccent}" Margin="0,0,10,0"/>
                    <Button x:Name="btnChangePath" Content="📁  Byt sökväg" Style="{StaticResource BtnBase}"/>
                </StackPanel>
            </Grid>
        </Border>

        <!-- ═══ KPI Cards ═══ -->
        <Border Grid.Row="1" Margin="24,16,24,0">
            <UniformGrid Columns="4" x:Name="pnlKPI">
                <!-- Card 1: Total Folders -->
                <Border CornerRadius="10" Background="$($Script:Colors.BgCard)" BorderBrush="$($Script:Colors.Border)"
                        BorderThickness="1" Margin="0,0,10,0" Padding="20,16">
                    <StackPanel>
                        <TextBlock Text="SKAPADE MAPPAR" FontSize="10" FontWeight="SemiBold" Foreground="$($Script:Colors.TextMuted)"/>
                        <TextBlock x:Name="kpiFolders" Text="—" FontSize="32" FontWeight="Bold"
                                   Foreground="$($Script:Colors.Success)" Margin="0,4,0,2"/>
                        <TextBlock x:Name="kpiFoldersDetail" Text="" FontSize="11"
                                   Foreground="$($Script:Colors.TextSecondary)"/>
                    </StackPanel>
                </Border>
                <!-- Card 2: Errors -->
                <Border CornerRadius="10" Background="$($Script:Colors.BgCard)" BorderBrush="$($Script:Colors.Border)"
                        BorderThickness="1" Margin="5,0,5,0" Padding="20,16">
                    <StackPanel>
                        <TextBlock Text="FEL REGISTRERADE" FontSize="10" FontWeight="SemiBold" Foreground="$($Script:Colors.TextMuted)"/>
                        <TextBlock x:Name="kpiErrors" Text="—" FontSize="32" FontWeight="Bold"
                                   Foreground="$($Script:Colors.Error)" Margin="0,4,0,2"/>
                        <TextBlock x:Name="kpiErrorsDetail" Text="" FontSize="11"
                                   Foreground="$($Script:Colors.TextSecondary)"/>
                    </StackPanel>
                </Border>
                <!-- Card 3: Log entries -->
                <Border CornerRadius="10" Background="$($Script:Colors.BgCard)" BorderBrush="$($Script:Colors.Border)"
                        BorderThickness="1" Margin="5,0,5,0" Padding="20,16">
                    <StackPanel>
                        <TextBlock Text="LOGGMEDDELANDEN" FontSize="10" FontWeight="SemiBold" Foreground="$($Script:Colors.TextMuted)"/>
                        <TextBlock x:Name="kpiLogs" Text="—" FontSize="32" FontWeight="Bold"
                                   Foreground="$($Script:Colors.Accent)" Margin="0,4,0,2"/>
                        <TextBlock x:Name="kpiLogsDetail" Text="" FontSize="11"
                                   Foreground="$($Script:Colors.TextSecondary)"/>
                    </StackPanel>
                </Border>
                <!-- Card 4: Unika produkter -->
                <Border CornerRadius="10" Background="$($Script:Colors.BgCard)" BorderBrush="$($Script:Colors.Border)"
                        BorderThickness="1" Margin="10,0,0,0" Padding="20,16">
                    <StackPanel>
                        <TextBlock Text="UNIKA PRODUKTER" FontSize="10" FontWeight="SemiBold" Foreground="$($Script:Colors.TextMuted)"/>
                        <TextBlock x:Name="kpiProducts" Text="—" FontSize="32" FontWeight="Bold"
                                   Foreground="$($Script:Colors.Warning)" Margin="0,4,0,2"/>
                        <TextBlock x:Name="kpiProductsDetail" Text="" FontSize="11"
                                   Foreground="$($Script:Colors.TextSecondary)"/>
                    </StackPanel>
                </Border>
            </UniformGrid>
        </Border>

        <!-- ═══ Tab Buttons ═══ -->
        <Border Grid.Row="2" Margin="24,16,24,0">
            <StackPanel Orientation="Horizontal">
                <Button x:Name="tabFolders" Content="📁  Mappar (Folderlog)" Style="{StaticResource BtnBase}" Margin="0,0,8,0"
                        FontSize="13" FontWeight="SemiBold"/>
                <Button x:Name="tabErrors" Content="⚠  Fel (Errorlog)" Style="{StaticResource BtnBase}" Margin="0,0,8,0"
                        FontSize="13"/>
                <Button x:Name="tabLog" Content="📋  Logg (Log)" Style="{StaticResource BtnBase}" Margin="0,0,8,0"
                        FontSize="13"/>
            </StackPanel>
        </Border>

        <!-- ═══ Filter/Search Bar ═══ -->
        <Border Grid.Row="3" Margin="24,12,24,0">
            <Grid>
                <Grid.ColumnDefinitions>
                    <ColumnDefinition Width="*"/>
                    <ColumnDefinition Width="Auto"/>
                    <ColumnDefinition Width="Auto"/>
                    <ColumnDefinition Width="Auto"/>
                </Grid.ColumnDefinitions>

                <TextBox x:Name="txtSearch" Grid.Column="0" Style="{StaticResource SearchBox}"
                         Margin="0,0,10,0"/>

                <ComboBox x:Name="cmbMaterial" Grid.Column="1" Width="200" Margin="0,0,10,0"/>
                <ComboBox x:Name="cmbDateRange" Grid.Column="2" Width="160" Margin="0,0,10,0"/>

                <Button x:Name="btnExport" Content="📤 Exportera" Grid.Column="3" Style="{StaticResource BtnBase}"/>
            </Grid>
        </Border>

        <!-- ═══ Data Grid ═══ -->
        <Border Grid.Row="4" Margin="24,12,24,0" CornerRadius="10" Background="$($Script:Colors.BgCard)"
                BorderBrush="$($Script:Colors.Border)" BorderThickness="1" ClipToBounds="True">
            <Grid>
                <!-- Folderlog Grid -->
                <DataGrid x:Name="dgFolders" Visibility="Visible">
                    <DataGrid.Columns>
                        <DataGridTextColumn Header="Datum" Binding="{Binding 'Date Created'}" Width="140"/>
                        <DataGridTextColumn Header="ROBAL" Binding="{Binding ROBAL}" Width="65"/>
                        <DataGridTextColumn Header="LSP" Binding="{Binding LSP}" Width="70"/>
                        <DataGridTextColumn Header="Material" Binding="{Binding Material}" Width="*"/>
                        <DataGridTextColumn Header="Batch" Binding="{Binding 'Batch(s)'}" Width="120"/>
                        <DataGridTextColumn Header="Order" Binding="{Binding Order}" Width="90"/>
                        <DataGridTextColumn Header="Antal" Binding="{Binding 'Order Amount'}" Width="75"/>
                        <DataGridTextColumn Header="Produktion" Binding="{Binding 'Production time'}" Width="110"/>
                        <DataGridTextColumn Header="Rev" Binding="{Binding Revision}" Width="50"/>
                    </DataGrid.Columns>
                </DataGrid>

                <!-- Errorlog Grid -->
                <DataGrid x:Name="dgErrors" Visibility="Collapsed">
                    <DataGrid.Columns>
                        <DataGridTextColumn Header="Datum" Binding="{Binding Date}" Width="140"/>
                        <DataGridTextColumn Header="Rad" Binding="{Binding Line}" Width="60"/>
                        <DataGridTextColumn Header="Felmeddelande" Binding="{Binding 'Error Message'}" Width="*"/>
                        <DataGridTextColumn Header="Exception" Binding="{Binding 'Error Exception'}" Width="*"/>
                    </DataGrid.Columns>
                </DataGrid>

                <!-- General Log Grid -->
                <DataGrid x:Name="dgLog" Visibility="Collapsed">
                    <DataGrid.Columns>
                        <DataGridTextColumn Header="Datum" Binding="{Binding Date}" Width="160"/>
                        <DataGridTextColumn Header="Meddelande" Binding="{Binding 'General Message'}" Width="*"/>
                    </DataGrid.Columns>
                </DataGrid>

                <!-- Loading / empty overlay -->
                <Border x:Name="pnlOverlay" Visibility="Collapsed" Background="#CC0F1923">
                    <StackPanel VerticalAlignment="Center" HorizontalAlignment="Center">
                        <TextBlock x:Name="txtOverlay" Text="Laddar data..." FontSize="16"
                                   Foreground="$($Script:Colors.TextSecondary)" HorizontalAlignment="Center"/>
                    </StackPanel>
                </Border>
            </Grid>
        </Border>

        <!-- ═══ Statusfält ═══ -->
        <Border Grid.Row="5" Background="$($Script:Colors.BgCard)" BorderBrush="$($Script:Colors.Border)" BorderThickness="0,1,0,0"
                Padding="24,8">
            <Grid>
                <Grid.ColumnDefinitions>
                    <ColumnDefinition Width="*"/>
                    <ColumnDefinition Width="Auto"/>
                    <ColumnDefinition Width="Auto"/>
                </Grid.ColumnDefinitions>
                <TextBlock x:Name="txtStatus" Grid.Column="0" FontSize="11"
                           Foreground="$($Script:Colors.TextSecondary)" VerticalAlignment="Center"
                           Text="Redo"/>
                <TextBlock x:Name="txtRowCount" Grid.Column="1" FontSize="11"
                           Foreground="$($Script:Colors.TextMuted)" VerticalAlignment="Center" Margin="0,0,20,0"/>
                <TextBlock x:Name="txtPath" Grid.Column="2" FontSize="11"
                           Foreground="$($Script:Colors.TextMuted)" VerticalAlignment="Center"
                           Text="" TextTrimming="CharacterEllipsis" MaxWidth="500"/>
            </Grid>
        </Border>
    </Grid>
</Window>
"@
#endregion

#region
$reader = [System.Xml.XmlNodeReader]::new($XAML)
$window = [System.Windows.Markup.XamlReader]::Load($reader)

# Bind UI-element
$ui = @{}
@(
    'txtSubtitle','btnRefresh','btnChangePath',
    'kpiFolders','kpiFoldersDetail','kpiErrors','kpiErrorsDetail',
    'kpiLogs','kpiLogsDetail','kpiProducts','kpiProductsDetail',
    'tabFolders','tabErrors','tabLog',
    'txtSearch','cmbMaterial','cmbDateRange','btnExport',
    'dgFolders','dgErrors','dgLog',
    'pnlOverlay','txtOverlay',
    'txtStatus','txtRowCount','txtPath'
) | ForEach-Object { $ui[$_] = $window.FindName($_) }
#endregion

#region
$Script:ActiveTab    = 'Folders'
$Script:DataFolders  = $null
$Script:DataErrors   = $null
$Script:DataLog      = $null
$Script:CurrentPath  = $Script:LogBasePath
#endregion

#region ── Hjälpfunktioner

function Set-ActiveTab {
    param([string]$Tab)
    $Script:ActiveTab = $Tab

    # Visa/dölj grids
    $ui['dgFolders'].Visibility  = if ($Tab -eq 'Folders')  { 'Visible' } else { 'Collapsed' }
    $ui['dgErrors'].Visibility   = if ($Tab -eq 'Errors')   { 'Visible' } else { 'Collapsed' }
    $ui['dgLog'].Visibility      = if ($Tab -eq 'Log')      { 'Visible' } else { 'Collapsed' }

    # Tab-knappars utseende
    $accentBrush  = [System.Windows.Media.BrushConverter]::new().ConvertFromString($Script:Colors.Accent)
    $dimBrush     = [System.Windows.Media.BrushConverter]::new().ConvertFromString($Script:Colors.BgCard)
    $boldWeight   = [System.Windows.FontWeights]::SemiBold
    $normalWeight = [System.Windows.FontWeights]::Normal

    $ui['tabFolders'].Background = if ($Tab -eq 'Folders') { $accentBrush } else { $dimBrush }
    $ui['tabErrors'].Background  = if ($Tab -eq 'Errors')  { $accentBrush } else { $dimBrush }
    $ui['tabLog'].Background     = if ($Tab -eq 'Log')     { $accentBrush } else { $dimBrush }

    $ui['tabFolders'].FontWeight = if ($Tab -eq 'Folders') { $boldWeight } else { $normalWeight }
    $ui['tabErrors'].FontWeight  = if ($Tab -eq 'Errors')  { $boldWeight } else { $normalWeight }
    $ui['tabLog'].FontWeight     = if ($Tab -eq 'Log')     { $boldWeight } else { $normalWeight }

    # Uppdatera materialfilter synlighet
    $ui['cmbMaterial'].Visibility = if ($Tab -eq 'Folders') { 'Visible' } else { 'Collapsed' }

    # Uppdatera söktext placeholder
    Update-SearchPlaceholder

    # Applicera aktuellt filter
    Apply-Filter
}

function Update-SearchPlaceholder {
    if ([string]::IsNullOrEmpty($ui['txtSearch'].Text) -or $ui['txtSearch'].Text -like '🔍*') {
        $label = switch ($Script:ActiveTab) {
            'Folders' { '🔍  Sök i mappar (LSP, material, batch, order...)' }
            'Errors'  { '🔍  Sök i felmeddelanden...' }
            'Log'     { '🔍  Sök i loggmeddelanden...' }
        }
        $ui['txtSearch'].Text = $label
        $ui['txtSearch'].Foreground = [System.Windows.Media.BrushConverter]::new().ConvertFromString($Script:Colors.TextMuted)
    }
}

function Load-Data {
    $ui['txtStatus'].Text = 'Laddar data...'
    $ui['pnlOverlay'].Visibility = 'Visible'
    $ui['txtOverlay'].Text = 'Laddar loggfiler...'
    $ui['txtPath'].Text = $Script:CurrentPath

    $errors = @()

    # ── Folderlog ──
    $folderPath = Join-Path $Script:CurrentPath 'Folderlog.csv'
    if (Test-Path $folderPath) {
        try {
            $raw = Get-Content -Path $folderPath -Encoding Default | Where-Object { $_.Trim() -ne '' }
            $Script:DataFolders = $raw | ConvertFrom-Csv
        } catch {
            $errors += "Folderlog: $_"
            $Script:DataFolders = @()
        }
    } else {
        $errors += "Folderlog.csv hittades inte"
        $Script:DataFolders = @()
    }

    # ── Errorlog ──
    $errorPath = Join-Path $Script:CurrentPath 'Errorlog.csv'
    if (Test-Path $errorPath) {
        try {
            $raw = Get-Content -Path $errorPath -Encoding Default | Where-Object { $_.Trim() -ne '' }
            $Script:DataErrors = $raw | ConvertFrom-Csv
        } catch {
            $errors += "Errorlog: $_"
            $Script:DataErrors = @()
        }
    } else {
        $errors += "Errorlog.csv hittades inte"
        $Script:DataErrors = @()
    }

    # ── Log ──
    $logPath = Join-Path $Script:CurrentPath 'Log.csv'
    if (Test-Path $logPath) {
        try {
            $raw = Get-Content -Path $logPath -Encoding Default | Where-Object { $_.Trim() -ne '' }
            $Script:DataLog = $raw | ConvertFrom-Csv
        } catch {
            $errors += "Log: $_"
            $Script:DataLog = @()
        }
    } else {
        $errors += "Log.csv hittades inte"
        $Script:DataLog = @()
    }

    # ── Uppdatera KPI ──
    Update-KPIs

    # ── Populera material-filter ──
    $ui['cmbMaterial'].Items.Clear()
    $ui['cmbMaterial'].Items.Add('Alla produkter') | Out-Null
    if ($Script:DataFolders.Count -gt 0) {
        $materials = $Script:DataFolders | Select-Object -ExpandProperty Material -Unique | Sort-Object
        foreach ($m in $materials) {
            $ui['cmbMaterial'].Items.Add($m) | Out-Null
        }
    }
    $ui['cmbMaterial'].SelectedIndex = 0

    # ── Populera datumfilter ──
    $ui['cmbDateRange'].Items.Clear()
    @('Alla datum', 'Senaste 7 dagarna', 'Senaste 30 dagarna', 'Senaste 90 dagarna', 'I år') | ForEach-Object {
        $ui['cmbDateRange'].Items.Add($_) | Out-Null
    }
    $ui['cmbDateRange'].SelectedIndex = 0

    # ── Visa data ──
    $ui['pnlOverlay'].Visibility = 'Collapsed'

    if ($errors.Count -gt 0) {
        $ui['txtStatus'].Text = "Laddad med varningar: $($errors -join '; ')"
        $ui['txtStatus'].Foreground = [System.Windows.Media.BrushConverter]::new().ConvertFromString($Script:Colors.Warning)
    } else {
        $fc = if ($Script:DataFolders) { $Script:DataFolders.Count } else { 0 }
        $ec = if ($Script:DataErrors)  { $Script:DataErrors.Count }  else { 0 }
        $lc = if ($Script:DataLog)     { $Script:DataLog.Count }     else { 0 }
        $ui['txtStatus'].Text = "Data laddad: $fc mappar, $ec fel, $lc loggposter"
        $ui['txtStatus'].Foreground = [System.Windows.Media.BrushConverter]::new().ConvertFromString($Script:Colors.Success)
    }

    Set-ActiveTab -Tab 'Folders'
}

function Update-KPIs {
    # Mappar
    $folderCount = if ($Script:DataFolders) { $Script:DataFolders.Count } else { 0 }
    $ui['kpiFolders'].Text = $folderCount.ToString('N0')
    if ($folderCount -gt 0) {
        $latestFolder = ($Script:DataFolders | Sort-Object 'Date Created' -Descending | Select-Object -First 1).'Date Created'
        $ui['kpiFoldersDetail'].Text = "Senaste: $latestFolder"
    }

    # Fel
    $errorCount = if ($Script:DataErrors) { $Script:DataErrors.Count } else { 0 }
    $ui['kpiErrors'].Text = $errorCount.ToString()
    if ($errorCount -gt 0) {
        $latestError = ($Script:DataErrors | Sort-Object Date -Descending | Select-Object -First 1).Date
        $ui['kpiErrorsDetail'].Text = "Senaste: $latestError"
    }

    # Logg
    $logCount = if ($Script:DataLog) { $Script:DataLog.Count } else { 0 }
    $ui['kpiLogs'].Text = $logCount.ToString('N0')
    if ($logCount -gt 0) {
        $uniqueMessages = ($Script:DataLog | Select-Object -ExpandProperty 'General Message' -Unique).Count
        $ui['kpiLogsDetail'].Text = "$uniqueMessages unika meddelanden"
    }

    # Unika produkter
    if ($Script:DataFolders -and $Script:DataFolders.Count -gt 0) {
        $products = ($Script:DataFolders | Select-Object -ExpandProperty Material -Unique)
        $ui['kpiProducts'].Text = $products.Count.ToString()
        # Mest förekommande
        $topProduct = $Script:DataFolders | Group-Object Material | Sort-Object Count -Descending | Select-Object -First 1
        if ($topProduct) {
            $ui['kpiProductsDetail'].Text = "Top: $($topProduct.Name) ($($topProduct.Count))"
        }
    } else {
        $ui['kpiProducts'].Text = '0'
    }
}

function Apply-Filter {
    $searchText   = $ui['txtSearch'].Text
    $materialSel  = $ui['cmbMaterial'].SelectedItem
    $dateRangeSel = $ui['cmbDateRange'].SelectedItem

    # Ignorera placeholder
    if ($searchText -like '🔍*') { $searchText = '' }

    # Beräkna datum-gräns
    $dateLimit = $null
    switch ($dateRangeSel) {
        'Senaste 7 dagarna'  { $dateLimit = (Get-Date).AddDays(-7) }
        'Senaste 30 dagarna' { $dateLimit = (Get-Date).AddDays(-30) }
        'Senaste 90 dagarna' { $dateLimit = (Get-Date).AddDays(-90) }
        'I år'               { $dateLimit = Get-Date -Month 1 -Day 1 -Hour 0 -Minute 0 -Second 0 }
    }

    switch ($Script:ActiveTab) {
        'Folders' {
            $data = $Script:DataFolders
            if (-not $data) { $data = @() }

            # Materialfilter
            if ($materialSel -and $materialSel -ne 'Alla produkter') {
                $data = $data | Where-Object { $_.Material -eq $materialSel }
            }

            # Datumfilter
            if ($dateLimit) {
                $data = $data | Where-Object {
                    try { [datetime]::ParseExact($_.'Date Created'.Substring(0,10), 'yyyy-MM-dd', $null) -ge $dateLimit } catch { $true }
                }
            }

            # Sökfilter
            if ($searchText) {
                $data = $data | Where-Object {
                    $_.'Date Created' -like "*$searchText*" -or
                    $_.ROBAL          -like "*$searchText*" -or
                    $_.LSP            -like "*$searchText*" -or
                    $_.Material       -like "*$searchText*" -or
                    $_.'Batch(s)'     -like "*$searchText*" -or
                    $_.Order          -like "*$searchText*" -or
                    $_.Revision       -like "*$searchText*"
                }
            }

            $ui['dgFolders'].ItemsSource = [System.Collections.ArrayList]@($data)
            $ui['txtRowCount'].Text = "$($data.Count) rader"
        }
        'Errors' {
            $data = $Script:DataErrors
            if (-not $data) { $data = @() }

            if ($dateLimit) {
                $data = $data | Where-Object {
                    try { [datetime]::ParseExact($_.Date.Substring(0,10), 'yyyy-MM-dd', $null) -ge $dateLimit } catch { $true }
                }
            }

            if ($searchText) {
                $data = $data | Where-Object {
                    $_.'Error Message'   -like "*$searchText*" -or
                    $_.'Error Exception' -like "*$searchText*" -or
                    $_.Date             -like "*$searchText*" -or
                    $_.Line             -like "*$searchText*"
                }
            }

            $ui['dgErrors'].ItemsSource = [System.Collections.ArrayList]@($data)
            $ui['txtRowCount'].Text = "$($data.Count) rader"
        }
        'Log' {
            $data = $Script:DataLog
            if (-not $data) { $data = @() }

            if ($dateLimit) {
                $data = $data | Where-Object {
                    try { [datetime]::ParseExact($_.Date.Substring(0,10), 'yyyy-MM-dd', $null) -ge $dateLimit } catch { $true }
                }
            }

            if ($searchText) {
                $data = $data | Where-Object {
                    $_.'General Message' -like "*$searchText*" -or
                    $_.Date             -like "*$searchText*"
                }
            }

            $ui['dgLog'].ItemsSource = [System.Collections.ArrayList]@($data)
            $ui['txtRowCount'].Text = "$($data.Count) rader"
        }
    }
}

function Export-CurrentView {
    $saveDialog = [System.Windows.Forms.SaveFileDialog]::new()
    $saveDialog.Filter = 'CSV-fil (*.csv)|*.csv|Alla filer (*.*)|*.*'
    $saveDialog.Title  = 'Exportera filtrerad data'

    $tabName = switch ($Script:ActiveTab) {
        'Folders' { 'Folderlog' }
        'Errors'  { 'Errorlog' }
        'Log'     { 'Log' }
    }
    $saveDialog.FileName = "${tabName}_export_$(Get-Date -Format 'yyyyMMdd_HHmmss').csv"

    if ($saveDialog.ShowDialog() -eq 'OK') {
        $grid = switch ($Script:ActiveTab) {
            'Folders' { $ui['dgFolders'] }
            'Errors'  { $ui['dgErrors'] }
            'Log'     { $ui['dgLog'] }
        }

        if ($grid.ItemsSource) {
            $grid.ItemsSource | Export-Csv -Path $saveDialog.FileName -NoTypeInformation -Encoding UTF8
            $ui['txtStatus'].Text = "Exporterad till: $($saveDialog.FileName)"
            $ui['txtStatus'].Foreground = [System.Windows.Media.BrushConverter]::new().ConvertFromString($Script:Colors.Success)
        }
    }
}

#endregion

#region ── Event Handlers

# Tab-knappar
$ui['tabFolders'].Add_Click({ Set-ActiveTab -Tab 'Folders' })
$ui['tabErrors'].Add_Click({ Set-ActiveTab -Tab 'Errors' })
$ui['tabLog'].Add_Click({ Set-ActiveTab -Tab 'Log' })

# Sökfält — placeholder-hantering
$ui['txtSearch'].Add_GotFocus({
    if ($ui['txtSearch'].Text -like '🔍*') {
        $ui['txtSearch'].Text = ''
        $ui['txtSearch'].Foreground = [System.Windows.Media.BrushConverter]::new().ConvertFromString($Script:Colors.TextPrimary)
    }
})
$ui['txtSearch'].Add_LostFocus({
    if ([string]::IsNullOrWhiteSpace($ui['txtSearch'].Text)) {
        Update-SearchPlaceholder
    }
})
$ui['txtSearch'].Add_TextChanged({
    if (-not ($ui['txtSearch'].Text -like '🔍*')) {
        Apply-Filter
    }
})

# Filter-combos
$ui['cmbMaterial'].Add_SelectionChanged({ Apply-Filter })
$ui['cmbDateRange'].Add_SelectionChanged({ Apply-Filter })

# Uppdatera
$ui['btnRefresh'].Add_Click({
    Load-Data
})

# Byt sökväg
$ui['btnChangePath'].Add_Click({
    $folderDialog = [System.Windows.Forms.FolderBrowserDialog]::new()
    $folderDialog.Description  = 'Välj mapp med loggfiler (Errorlog.csv, Folderlog.csv, Log.csv)'
    $folderDialog.SelectedPath = $Script:CurrentPath

    if ($folderDialog.ShowDialog() -eq 'OK') {
        $Script:CurrentPath = $folderDialog.SelectedPath
        Load-Data
    }
})

# Exportera
$ui['btnExport'].Add_Click({ Export-CurrentView })

# Dubbelklick i datagrid — visa detalj i popup
$ui['dgErrors'].Add_MouseDoubleClick({
    $item = $ui['dgErrors'].SelectedItem
    if ($item) {
        $msg = "FEL: $($item.'Error Message')`n`nEXCEPTION:`n$($item.'Error Exception')`n`nRAD: $($item.Line)`nDATUM: $($item.Date)"
        [System.Windows.MessageBox]::Show($msg, 'Feldetalj', 'OK', 'Warning') | Out-Null
    }
})

$ui['dgLog'].Add_MouseDoubleClick({
    $item = $ui['dgLog'].SelectedItem
    if ($item) {
        $msg = "MEDDELANDE:`n$($item.'General Message')`n`nDATUM: $($item.Date)"
        [System.Windows.MessageBox]::Show($msg, 'Loggdetalj', 'OK', 'Information') | Out-Null
    }
})

$ui['dgFolders'].Add_MouseDoubleClick({
    $item = $ui['dgFolders'].SelectedItem
    if ($item) {
        $msg = @"
MATERIAL: $($item.Material)
LSP: $($item.LSP)
ROBAL: $($item.ROBAL)
BATCH: $($item.'Batch(s)')
ORDER: $($item.Order)
SAMPLE REAGENT: $($item.'Sample Reagent')
ANTAL: $($item.'Order Amount')
PRODUKTION: $($item.'Production time')
REVISION: $($item.Revision)
SKAPAD: $($item.'Date Created')
"@
        [System.Windows.MessageBox]::Show($msg, 'Mappdetalj', 'OK', 'Information') | Out-Null
    }
})

# Keyboard shortcuts
$window.Add_KeyDown({
    if ($_.Key -eq 'F5') { Load-Data }
    if ($_.Key -eq 'F' -and [System.Windows.Input.Keyboard]::Modifiers -eq 'Control') {
        $ui['txtSearch'].Focus()
        if ($ui['txtSearch'].Text -like '🔍*') {
            $ui['txtSearch'].Text = ''
            $ui['txtSearch'].Foreground = [System.Windows.Media.BrushConverter]::new().ConvertFromString($Script:Colors.TextPrimary)
        }
    }
    if ($_.Key -eq 'D1' -and [System.Windows.Input.Keyboard]::Modifiers -eq 'Control') { Set-ActiveTab -Tab 'Folders' }
    if ($_.Key -eq 'D2' -and [System.Windows.Input.Keyboard]::Modifiers -eq 'Control') { Set-ActiveTab -Tab 'Errors' }
    if ($_.Key -eq 'D3' -and [System.Windows.Input.Keyboard]::Modifiers -eq 'Control') { Set-ActiveTab -Tab 'Log' }
})

#endregion

#region ── Starta
$window.Add_Loaded({ Load-Data })
$window.ShowDialog() | Out-Null
#endregion