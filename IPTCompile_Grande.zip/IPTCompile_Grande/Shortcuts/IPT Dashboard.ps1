﻿<#
.SYNOPSIS
 IPTCompile Metrics Dashboard – Visualiserar tidsbesparingar och kvalitetsdata
 från audit-CSV-filer genererade av IPTCompile.
.DESCRIPTION
 Läser alla Audit_*.csv-filer från audit-katalogen och visar:
 - Total tidsåtgång per rapport (medel, median, min, max)
 - Fas-fördelning (vilka steg tar längst tid)
 - Rapporter per användare, assay och dag
 - Avvikelsestatus (Warnings vs OK)
 - Uppskattad tidsbesparing jämfört med manuell process
.PARAMETER AuditDir
 Sökväg till audit-katalogen. Standard: .\audit
.PARAMETER ManualMinutes
 Uppskattad tid (minuter) för manuell rapportgenerering. Standard: 20
.PARAMETER ExportCsv
 Om angiven, exportera sammanställning till angiven CSV-fil
.EXAMPLE
 .\IPT_Dashboard.ps1
 .\IPT_Dashboard.ps1 -AuditDir "\\server\share\audit" -ManualMinutes 25
 .\IPT_Dashboard.ps1 -ExportCsv "metrics_export.csv"
#>
param(
 [string]$AuditDir = 'N:\QC\QC-1\IPT\Skiftspecifika dokument\PQC analyst\JESPER\zz_IPTCompile\audit',
 [int]$ManualMinutes = 20,
 [string]$ExportCsv = 'N:\QC\QC-1\IPT\Skiftspecifika dokument\PQC analyst\JESPER\Scripts\zz_IPTCompile_Shortcut\IPTCompile metrics\metrics.csv'
)
# ============================================================================
# HJÄLPFUNKTIONER
# ============================================================================
function Write-Header([string]$Text) {
 $line = '=' * 70
 Write-Host ""
 Write-Host $line -ForegroundColor Cyan
 Write-Host " $Text" -ForegroundColor White
 Write-Host $line -ForegroundColor Cyan
}
function Write-SubHeader([string]$Text) {
 Write-Host ""
 Write-Host " --- $Text ---" -ForegroundColor Yellow
}
function Write-Metric([string]$Label, $Value, [string]$Unit = '', [ConsoleColor]$Color = 'White') {
 $valText = if ($Value -is [double] -or $Value -is [decimal]) { "{0:N1}" -f $Value } else { "$Value" }
 if ($Unit) { $valText += " $Unit" }
 Write-Host (" {0,-35} {1}" -f $Label, $valText) -ForegroundColor $Color
}
function Write-Bar([string]$Label, [double]$Value, [double]$Max, [int]$BarWidth = 30, [ConsoleColor]$Color = 'Green') {
 $filled = if ($Max -gt 0) { [math]::Round(($Value / $Max) * $BarWidth) } else { 0 }
 $filled = [math]::Max(0, [math]::Min($BarWidth, $filled))
 $bar = ('█' * $filled) + ('░' * ($BarWidth - $filled))
 Write-Host (" {0,-20} {1} {2,8:N1}" -f $Label, $bar, $Value) -ForegroundColor $Color
}
# ============================================================================
# LADDA DATA
# ============================================================================
if (-not (Test-Path -LiteralPath $AuditDir)) {
 Write-Host " Audit-katalog hittades inte: $AuditDir" -ForegroundColor Red
 Write-Host " Kör IPTCompile minst en gång för att generera audit-data." -ForegroundColor Gray
 exit 1
}
$csvFiles = Get-ChildItem -LiteralPath $AuditDir -Filter "Audit_*.csv" -File -ErrorAction SilentlyContinue
if (-not $csvFiles -or $csvFiles.Count -eq 0) {
 # Prova även med äldre namnformat
 $csvFiles = Get-ChildItem -LiteralPath $AuditDir -Filter "*_audit_*.csv" -File -ErrorAction SilentlyContinue
}
if (-not $csvFiles -or $csvFiles.Count -eq 0) {
 Write-Host " Inga audit-CSV-filer hittades i: $AuditDir" -ForegroundColor Red
 exit 1
}
$allRows = @()
foreach ($file in $csvFiles) {
 try {
 $rows = Import-Csv -LiteralPath $file.FullName -Encoding UTF8
 foreach ($r in $rows) {
 # Normalisera fältnamn (stöd både gammalt och nytt format)
 $obj = [pscustomobject]@{
 Timestamp = if ($r.Timestamp) { $r.Timestamp } elseif ($r.DatumTid) { $r.DatumTid } else { '' }
 Username = if ($r.Username) { $r.Username } elseif ($r.Användare) { $r.Användare } else { '' }
 LSP = if ($r.LSP) { $r.LSP } else { '' }
 Assay = if ($r.Assay) { $r.Assay } else { '' }
 Batch = if ($r.Batch) { $r.Batch } elseif ($r.BatchNumber) { $r.BatchNumber } else { '' }
 TestCount = 0
 Status = if ($r.Status) { $r.Status } else { 'OK' }
 TotalMs = 0
 TotalSec = 0
 PhaseJson = if ($r.PhaseJson) { $r.PhaseJson } elseif ($r.FasTider_json) { $r.FasTider_json } else { '' }
 Violations = 0
 Source = $file.Name
 }
 try { $obj.TestCount = [int]($r.TestCount) } catch {}
 try { if (-not $obj.TestCount -and $r.AntalTester) { $obj.TestCount = [int]($r.AntalTester) } } catch {}
 try { $obj.TotalMs = [int]($r.TotalMs) } catch {}
 try { if (-not $obj.TotalMs -and $r.TotalTid_ms) { $obj.TotalMs = [int]($r.TotalTid_ms) } } catch {}
 try { $obj.TotalSec = [double]($r.TotalSec) } catch {}
 try { if (-not $obj.TotalSec -and $r.TotalTid_s) { $obj.TotalSec = [double]($r.TotalTid_s) } } catch {}
 try { $obj.Violations = [int]($r.Violations) } catch {}
 if (-not $obj.TotalSec -and $obj.TotalMs -gt 0) { $obj.TotalSec = [math]::Round($obj.TotalMs / 1000, 1) }
 $allRows += $obj
 }
 } catch {
 Write-Host " Kunde inte läsa: $($file.Name) – $($_.Exception.Message)" -ForegroundColor Yellow
 }
}
if ($allRows.Count -eq 0) {
 Write-Host " Inga datarader laddades." -ForegroundColor Red
 exit 1
}
# ============================================================================
# GRUNDSTATISTIK
# ============================================================================
Write-Header "IPTCompile Metrics Dashboard"
Write-Host " Datakälla: $AuditDir" -ForegroundColor Gray
Write-Host " Antal filer: $($csvFiles.Count) | Antal rapporter: $($allRows.Count)" -ForegroundColor Gray
# --- Övergripande ---
Write-SubHeader "Övergripande"
$dates = @()
foreach ($r in $allRows) {
 try { $d = [datetime]::Parse($r.Timestamp); $dates += $d } catch {}
}
if ($dates.Count -gt 0) {
 $first = ($dates | Sort-Object | Select-Object -First 1).ToString('yyyy-MM-dd')
 $last = ($dates | Sort-Object | Select-Object -Last 1).ToString('yyyy-MM-dd')
 Write-Metric "Period" "$first → $last"
}
Write-Metric "Totalt antal rapporter" $allRows.Count
$totalTests = ($allRows | ForEach-Object { $_.TestCount } | Measure-Object -Sum).Sum
Write-Metric "Totalt antal tester analyserade" $totalTests
$users = @($allRows | ForEach-Object { $_.Username } | Where-Object { $_ } | Select-Object -Unique)
Write-Metric "Unika användare" $users.Count
# --- Tidsmätning ---
$timedRows = @($allRows | Where-Object { $_.TotalMs -gt 0 })
if ($timedRows.Count -gt 0) {
 Write-SubHeader "Tidsåtgång per rapport (sekunder)"
 $secs = $timedRows | ForEach-Object { $_.TotalSec }
 $stats = $secs | Measure-Object -Average -Minimum -Maximum
 $sorted = $secs | Sort-Object
 $median = $sorted[[math]::Floor($sorted.Count / 2)]
 Write-Metric "Medel" $stats.Average "s" Green
 Write-Metric "Median" $median "s" Green
 Write-Metric "Min" $stats.Minimum "s" Cyan
 Write-Metric "Max" $stats.Maximum "s" Yellow
 Write-Metric "Mätpunkter" $timedRows.Count
 # --- Tidsbesparing ---
 Write-SubHeader "Uppskattad tidsbesparing"
 $manualSec = $ManualMinutes * 60
 $avgSec = $stats.Average
 $savedPerReport = $manualSec - $avgSec
 $totalSaved = $savedPerReport * $allRows.Count
 $totalSavedHrs = $totalSaved / 3600
 Write-Metric "Manuell tid (uppskattad)" $ManualMinutes "min" Gray
 Write-Metric "IPTCompile medeltid" ([math]::Round($avgSec, 1)) "s" Green
 Write-Metric "Besparing per rapport" ([math]::Round($savedPerReport / 60, 1)) "min" Green
 Write-Metric "Total besparing ($($allRows.Count) rapporter)" ([math]::Round($totalSavedHrs, 1)) "timmar" Green
 $speedup = if ($avgSec -gt 0) { [math]::Round($manualSec / $avgSec, 0) } else { 0 }
 Write-Metric "Hastighetsökning" "${speedup}x" '' Cyan
 # --- Fas-fördelning ---
 $phaseTotals = @{}
 $phaseCount = 0
 foreach ($r in $timedRows) {
 if (-not $r.PhaseJson) { continue }
 try {
 $phases = $r.PhaseJson | ConvertFrom-Json
 $phaseCount++
 foreach ($prop in $phases.PSObject.Properties) {
 if (-not $phaseTotals.ContainsKey($prop.Name)) { $phaseTotals[$prop.Name] = 0 }
 $phaseTotals[$prop.Name] += [double]$prop.Value
 }
 } catch {}
 }
 if ($phaseTotals.Count -gt 0 -and $phaseCount -gt 0) {
 Write-SubHeader "Medeltid per fas (ms) — $phaseCount mätpunkter"
 $maxPhase = ($phaseTotals.Values | Measure-Object -Maximum).Maximum / $phaseCount
 foreach ($key in ($phaseTotals.Keys | Sort-Object @{Expression={ $phaseTotals[$_] }} -Descending)) {
 $avg = $phaseTotals[$key] / $phaseCount
 Write-Bar $key $avg $maxPhase 30 Green
 }
 }
}
# --- Per användare ---
if ($users.Count -gt 0) {
 Write-SubHeader "Rapporter per användare"
 $byUser = $allRows | Group-Object Username | Sort-Object Count -Descending
 $maxUser = ($byUser | Select-Object -First 1).Count
 foreach ($g in $byUser) {
 $name = if ($g.Name) { $g.Name } else { '(okänd)' }
 Write-Bar $name $g.Count $maxUser 30 Cyan
 }
}
# --- Per assay ---
$assays = @($allRows | ForEach-Object { $_.Assay } | Where-Object { $_ } | Select-Object -Unique)
if ($assays.Count -gt 0) {
 Write-SubHeader "Rapporter per assay"
 $byAssay = $allRows | Where-Object { $_.Assay } | Group-Object Assay | Sort-Object Count -Descending
 $maxAssay = ($byAssay | Select-Object -First 1).Count
 foreach ($g in $byAssay) {
 Write-Bar $g.Name $g.Count $maxAssay 30 Yellow
 }
}
# --- Avvikelsestatus ---
Write-SubHeader "Avvikelsestatus"
$okCount = @($allRows | Where-Object { $_.Status -eq 'OK' }).Count
$warnCount = @($allRows | Where-Object { $_.Status -ne 'OK' -and $_.Status }).Count
Write-Metric "✓ OK (inga avvikelser)" $okCount '' Green
Write-Metric "⚠ Warnings" $warnCount '' Yellow
if ($allRows.Count -gt 0) {
 $okPct = [math]::Round(($okCount / $allRows.Count) * 100, 1)
 Write-Metric "Andel felfria rapporter" $okPct "%" Green
}
# --- Per dag (senaste 14 dagarna) ---
$byDay = @{}
foreach ($r in $allRows) {
 try {
 $d = [datetime]::Parse($r.Timestamp).ToString('yyyy-MM-dd')
 if (-not $byDay.ContainsKey($d)) { $byDay[$d] = 0 }
 $byDay[$d]++
 } catch {}
}
if ($byDay.Count -gt 0) {
 Write-SubHeader "Rapporter per dag (senaste)"
 $sortedDays = $byDay.Keys | Sort-Object -Descending | Select-Object -First 14
 $maxDay = ($sortedDays | ForEach-Object { $byDay[$_] } | Measure-Object -Maximum).Maximum
 foreach ($d in ($sortedDays | Sort-Object)) {
 Write-Bar $d $byDay[$d] $maxDay 30 Cyan
 }
}
# ============================================================================
# EXPORT
# ============================================================================
if ($ExportCsv) {
 try {
 $exportRows = foreach ($r in $allRows) {
 [pscustomobject]@{
 Timestamp = $r.Timestamp
 Username = $r.Username
 LSP = $r.LSP
 Assay = $r.Assay
 TestCount = $r.TestCount
 Status = $r.Status
 TotalSec = $r.TotalSec
 Violations = $r.Violations
 }
 }
 $exportRows | Export-Csv -Path $ExportCsv -NoTypeInformation -Encoding UTF8
 Write-Host ""
 Write-Host " Exporterat till: $ExportCsv" -ForegroundColor Green
 } catch {
 Write-Host " Kunde inte exportera: $($_.Exception.Message)" -ForegroundColor Red
 }
}
# ============================================================================
# SAMMANFATTNING
# ============================================================================
Write-Header "Sammanfattning"
if ($timedRows.Count -gt 0) {
 $avgSec = ($timedRows | ForEach-Object { $_.TotalSec } | Measure-Object -Average).Average
 Write-Host ""
 Write-Host " IPTCompile genererar en rapport på i snitt $([math]::Round($avgSec,1)) sekunder." -ForegroundColor White
 Write-Host " Jämfört med uppskattad manuell tid ($ManualMinutes min) ger detta en" -ForegroundColor White
 Write-Host " tidsbesparing på ~$([math]::Round(($ManualMinutes * 60 - $avgSec) / 60, 1)) min per rapport." -ForegroundColor Green
 Write-Host ""
 Write-Host " Totalt har $($allRows.Count) rapporter genererats, vilket motsvarar" -ForegroundColor White
 Write-Host " ~$([math]::Round(($allRows.Count * ($ManualMinutes * 60 - $avgSec)) / 3600, 1)) sparade arbetstimmar." -ForegroundColor Green
} else {
 Write-Host ""
 Write-Host " Inga tidsmätningar tillgängliga ännu." -ForegroundColor Yellow
 Write-Host " Kör IPTCompile med den senaste versionen för att börja samla tidsdata." -ForegroundColor Gray
}
Write-Host ""