#requires -Version 3.0

<#
Migration Notes (WinForms -> WPF)
- Mapping kontroller:
  - Form -> WPF Window (`MainWindow`) + `form`-shim (Close/Height/Cursor/Refresh)
  - CheckedListBox -> WPF `ListBox` med `CheckBox`-items via `clb*`-shim (`GetItemChecked`, `SetItemChecked`, `CheckedItems`, `add_ItemCheck`)
  - StatusStrip/ToolStripStatusLabel -> WPF statusrad (`TextBlock`/`Button`) via `sl*`/`status`-shims
  - ToolStripProgressBar -> WPF `ProgressBar` via `pbWork`-shim (`Visible`, `Style`, `Value`)
  - WinForms Button/CheckBox -> WPF `Button`/`CheckBox` via shims (`Text`, `Enabled`, `Visible`, `Checked`, `PerformClick`)
- Event mapping:
  - `Add_Click`/`add_Click` -> WPF `Click`
  - `add_TextChanged` -> WPF `TextChanged`
  - `CheckedListBox.ItemCheck` -> syntetiskt event från wrappern när item-`CheckBox` togglas
  - Form KeyDown -> WPF `PreviewKeyDown`
- Theme/accent:
  - Basfärger/stilar finns i `GUI/WPF/Themes/Light.xaml` och `GUI/WPF/Themes/Dark.xaml`
  - Accent uppdateras dynamiskt från `UiStyling.ps1` (`$Accent` / `Get-WinAccentColor`) i `Set-WpfThemeResources`
- Felsökning XAML-load:
  - `Import-WpfXamlWindow` fångar fel, loggar via `Gui-Log` (om tillgängligt) och visar `MessageBox` med stacktrace
  - Vanliga fel: stavfel i `x:Name`, saknad resource key, ogiltig XAML-syntax
#>

$script:WpfGuiRoot = $PSScriptRoot
$script:WpfThemeDictionary = $null
if (-not $script:UI) { $script:UI = @{} }

function Import-WpfAssemblies {
    $assemblies = @('PresentationFramework','PresentationCore','WindowsBase','System.Xaml')
    foreach ($asm in $assemblies) {
        try { Add-Type -AssemblyName $asm -ErrorAction Stop } catch {}
    }
}

function Show-WpfBootstrapError {
    param(
        [Parameter(Mandatory)][string]$Title,
        [Parameter(Mandatory)][string]$Message,
        [System.Exception]$Exception
    )

    $detail = $Message
    if ($Exception) {
        try { $detail = $detail + "`r`n`r`n" + $Exception.ToString() } catch {}
    }

    try { Gui-Log ("❌ {0}: {1}" -f $Title, $detail) 'Error' } catch {}

    try {
        [System.Windows.MessageBox]::Show($detail, $Title, [System.Windows.MessageBoxButton]::OK, [System.Windows.MessageBoxImage]::Error) | Out-Null
    } catch {
        try { [System.Windows.Forms.MessageBox]::Show($detail, $Title) | Out-Null } catch {}
    }
}

function Import-WpfXamlWindow {
    param([Parameter(Mandatory)][string]$Path)

    Import-WpfAssemblies

    if (-not (Test-Path -LiteralPath $Path)) {
        $ex = New-Object System.IO.FileNotFoundException("XAML hittades inte: $Path")
        Show-WpfBootstrapError -Title 'WPF/XAML fel' -Message 'Kunde inte ladda MainWindow.xaml.' -Exception $ex
        throw $ex
    }

    try {
        $raw = Get-Content -LiteralPath $Path -Raw -Encoding UTF8
        $xml = New-Object System.Xml.XmlDocument
        $xml.PreserveWhitespace = $true
        $xml.LoadXml($raw)

        # Ta bort x:Class om det finns (PowerShell XamlReader hanterar inte code-behind-klass)
        $nsMgr = New-Object System.Xml.XmlNamespaceManager($xml.NameTable)
        $nsMgr.AddNamespace('x','http://schemas.microsoft.com/winfx/2006/xaml')
        $root = $xml.DocumentElement
        if ($root -and $root.Attributes['x:Class']) {
            $null = $root.Attributes.RemoveNamedItem('x:Class')
        }

        $sr = New-Object System.IO.StringReader($xml.OuterXml)
        $xr = [System.Xml.XmlReader]::Create($sr)
        try {
            return [Windows.Markup.XamlReader]::Load($xr)
        } finally {
            try { $xr.Close() } catch {}
            try { $sr.Dispose() } catch {}
        }
    }
    catch {
        Show-WpfBootstrapError -Title 'WPF/XAML fel' -Message ("Kunde inte ladda XAML: {0}" -f $Path) -Exception $_.Exception
        throw
    }
}

function Get-WpfNamedControlMap {
    param(
        [Parameter(Mandatory)][System.Windows.FrameworkElement]$Root,
        [Parameter(Mandatory)][string]$XamlPath
    )

    $map = @{}
    try {
        [xml]$xml = Get-Content -LiteralPath $XamlPath -Raw -Encoding UTF8
        $nsmgr = New-Object System.Xml.XmlNamespaceManager($xml.NameTable)
        $nsmgr.AddNamespace('x','http://schemas.microsoft.com/winfx/2006/xaml')
        $nodes = @($xml.SelectNodes('//*[@x:Name or @Name]', $nsmgr))
        foreach ($n in $nodes) {
            $name = $null
            try { $name = $n.Attributes['Name'].Value } catch {}
            if (-not $name) { try { $name = $n.Attributes['x:Name'].Value } catch {} }
            if (-not $name) { try { $name = $n.GetAttribute('Name') } catch {} }
            if (-not $name) { continue }
            try {
                $ctrl = $Root.FindName($name)
                if ($ctrl) { $map[$name] = $ctrl }
            } catch {}
        }
    } catch {}
    return $map
}

function Get-WpfThemePath {
    param([ValidateSet('light','dark')][string]$Theme)
    $file = if ($Theme -eq 'dark') { 'Dark.xaml' } else { 'Light.xaml' }
    return (Join-Path $script:WpfGuiRoot (Join-Path 'Themes' $file))
}

function Convert-FromDrawingColorToWpf {
    param([Parameter(Mandatory)][System.Drawing.Color]$Color)
    return [System.Windows.Media.Color]::FromArgb([byte]$Color.A, [byte]$Color.R, [byte]$Color.G, [byte]$Color.B)
}

function New-WpfSolidBrush {
    param([Parameter(Mandatory)][System.Windows.Media.Color]$Color)
    $b = New-Object System.Windows.Media.SolidColorBrush $Color
    try { $b.Freeze() } catch {}
    return $b
}

function Get-WpfAccentInfo {
    $accentDrawing = $null
    try {
        if ($script:Accent -and ($script:Accent -is [System.Drawing.Color])) { $accentDrawing = $script:Accent }
    } catch {}
    if (-not $accentDrawing) {
        try {
            if ($global:Accent -and ($global:Accent -is [System.Drawing.Color])) { $accentDrawing = $global:Accent }
        } catch {}
    }
    if (-not $accentDrawing) {
        try {
            if (Get-Command Get-WinAccentColor -ErrorAction SilentlyContinue) {
                $accentDrawing = Get-WinAccentColor
            }
        } catch {}
    }
    if (-not $accentDrawing) {
        $accentDrawing = [System.Drawing.Color]::FromArgb(38,120,178)
    }

    $accent = Convert-FromDrawingColorToWpf -Color $accentDrawing
    $hoverR = [byte][Math]::Min(255, [int]$accent.R + 18)
    $hoverG = [byte][Math]::Min(255, [int]$accent.G + 18)
    $hoverB = [byte][Math]::Min(255, [int]$accent.B + 18)
    $hover = [System.Windows.Media.Color]::FromArgb([byte]255, $hoverR, $hoverG, $hoverB)

    $isDark = (($accent.R * 0.299) + ($accent.G * 0.587) + ($accent.B * 0.114)) -lt 150
    $fg = if ($isDark) {
        [System.Windows.Media.Color]::FromArgb(255,255,255,255)
    } else {
        [System.Windows.Media.Color]::FromArgb(255,15,23,32)
    }

    [pscustomobject]@{
        AccentColor = $accent
        AccentHover = $hover
        AccentFg    = $fg
    }
}

function Set-WpfThemeResources {
    param([ValidateSet('light','dark')][string]$Theme = 'light')

    if (-not $script:UI -or -not $script:UI.Window) { return }

    try {
        $themePath = Get-WpfThemePath -Theme $Theme
        $dict = Import-WpfXamlWindow -Path $themePath
        if ($dict -isnot [System.Windows.ResourceDictionary]) {
            throw "Theme-filen laddades inte som ResourceDictionary: $themePath"
        }

        $md = $script:UI.Window.Resources.MergedDictionaries
        if (-not $md) { return }

        if ($script:WpfThemeDictionary) {
            try { $null = $md.Remove($script:WpfThemeDictionary) } catch {}
        }

        $accent = Get-WpfAccentInfo
        $dict['AccentBrush'] = (New-WpfSolidBrush -Color $accent.AccentColor)
        $dict['AccentHoverBrush'] = (New-WpfSolidBrush -Color $accent.AccentHover)
        $dict['AccentForegroundBrush'] = (New-WpfSolidBrush -Color $accent.AccentFg)

        $md.Add($dict)
        $script:WpfThemeDictionary = $dict
        $script:UI.Theme = $Theme
    }
    catch {
        Show-WpfBootstrapError -Title 'Tema-fel' -Message ("Kunde inte växla tema till '{0}'." -f $Theme) -Exception $_.Exception
    }
}

function Invoke-WpfUi {
    param([Parameter(Mandatory)][scriptblock]$ScriptBlock)

    $dispatcher = $null
    try { $dispatcher = $script:UI.Window.Dispatcher } catch {}
    if (-not $dispatcher) { & $ScriptBlock; return }

    if ($dispatcher.CheckAccess()) {
        & $ScriptBlock
    } else {
        $dispatcher.Invoke([action]$ScriptBlock)
    }
}

function Invoke-WpfUiAsync {
    param([Parameter(Mandatory)][scriptblock]$ScriptBlock)

    $dispatcher = $null
    try { $dispatcher = $script:UI.Window.Dispatcher } catch {}
    if (-not $dispatcher) { & $ScriptBlock; return $null }

    if ($dispatcher.CheckAccess()) {
        & $ScriptBlock
        return $null
    }
    return $dispatcher.BeginInvoke([action]$ScriptBlock)
}

function Invoke-WpfUiPump {
    try {
        if (-not $script:UI.Window) { return }
        $dispatcher = $script:UI.Window.Dispatcher
        if (-not $dispatcher) { return }

        if ($dispatcher.CheckAccess()) {
            $frame = New-Object System.Windows.Threading.DispatcherFrame
            $cb = [System.Windows.Threading.DispatcherOperationCallback]{
                param($f)
                try { $f.Continue = $false } catch {}
                return $null
            }
            $null = $dispatcher.BeginInvoke([System.Windows.Threading.DispatcherPriority]::Background, $cb, $frame)
            [System.Windows.Threading.Dispatcher]::PushFrame($frame)
        } else {
            $dispatcher.Invoke([action]{})
        }
    } catch {}
}

function New-WpfTimerShim {
    param([int]$Interval = 200)

    Import-WpfAssemblies
    $timer = New-Object System.Windows.Threading.DispatcherTimer
    $timer.Interval = [TimeSpan]::FromMilliseconds([Math]::Max(10,$Interval))

    $shim = [pscustomobject]@{
        __Timer = $timer
    }

    Add-Member -InputObject $shim -MemberType ScriptMethod -Name add_Tick -Value {
        param([scriptblock]$Handler)
        $t = $this.__Timer
        $t.add_Tick($Handler)
    } -Force
    Add-Member -InputObject $shim -MemberType ScriptMethod -Name Start -Value { $this.__Timer.Start() } -Force
    Add-Member -InputObject $shim -MemberType ScriptMethod -Name Stop -Value { $this.__Timer.Stop() } -Force
    Add-Member -InputObject $shim -MemberType ScriptMethod -Name Dispose -Value {
        try { $this.__Timer.Stop() } catch {}
    } -Force
    Add-Member -InputObject $shim -MemberType NoteProperty -Name Interval -Value $Interval -Force

    return $shim
}

function Ui-LogAppend {
    param(
        [Parameter(Mandatory)][object]$Control,
        [Parameter(Mandatory)][string]$Text
    )

    if ($Control -is [System.Windows.Controls.TextBox]) {
        $append = {
            param($tb,$line)
            $tb.AppendText($line + "`r`n")
            $tb.CaretIndex = $tb.Text.Length
            $tb.ScrollToEnd()
        }

        try {
            if ($Control.Dispatcher -and -not $Control.Dispatcher.CheckAccess()) {
                $null = $Control.Dispatcher.BeginInvoke([action[object,string]]$append, @($Control,$Text))
            } else {
                & $append $Control $Text
            }
            return $true
        } catch { return $false }
    }
    return $false
}

function Start-WpfGui {
    if (-not $script:UI -or -not $script:UI.Window) {
        throw 'WPF GUI är inte initierat. Kör Initialize-WpfGui först.'
    }

    try {
        $null = $script:UI.Window.ShowDialog()
    } catch {
        Show-WpfBootstrapError -Title 'WPF körfel' -Message 'Huvudfönstret kunde inte startas.' -Exception $_.Exception
        throw
    }
}
