# Regression Report

## Körstatus i denna miljö

- Datum: 2026-03-04
- Miljö: macOS (Darwin), ingen `powershell.exe` / Windows PowerShell 5.1 tillgänglig.
- Konsekvens: full E2E-körning av WinForms/EPPlus/OpenXML pipeline kunde inte exekveras här.

## Reproducerbart kommando (Windows PowerShell 5.1)

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\tools\run_regression.ps1 -TestRoot .\TEST-LSP -OutDir .\tmp\regression_out -BaselineDir .\TEST-LSP
```

## Testcase-status (denna körning)

| Case | Status | Notering |
|---|---|---|
| 31004 | BLOCKED | PS5.1-runtime saknas i aktuell miljö |
| 32101 | BLOCKED | PS5.1-runtime saknas i aktuell miljö |
| 33301 | BLOCKED | PS5.1-runtime saknas i aktuell miljö |
| 34509 | BLOCKED | PS5.1-runtime saknas i aktuell miljö |
| 95107 | BLOCKED | PS5.1-runtime saknas i aktuell miljö |

## Input-upptäckt (statisk kontroll)

| Case | Worksheet-filer | Seal Neg | Seal Pos | CSV (exkl. audit) |
|---|---:|---:|---:|---:|
| 31004 | 1 | 1 | 1 | 1 |
| 32101 | 1 | 1 | 1 | 1 |
| 33301 | 1 | 1 | 1 | 2 |
| 34509 | 1 | 1 | 1 | 1 |
| 95107 | 1 | 1 | 1 | 2 |

## Notering

- `tools/run_regression.ps1` är implementerad för PS 5.1 headless core-dry-run (CSV selection + RuleEngine + OpenXML plan).
- `-GenerateOutputs` är markerad men inte implementerad i denna fas, eftersom `Main.ps1` ännu saknar en ren headless Build-entrypoint.
