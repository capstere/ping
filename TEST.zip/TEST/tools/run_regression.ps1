[CmdletBinding()]
param(
    [string]$TestRoot = (Join-Path $PSScriptRoot '..\TEST-LSP'),
    [string]$OutDir = (Join-Path $PSScriptRoot '..\tmp\regression_out'),
    [string]$BaselineDir = '',
    [switch]$GenerateOutputs
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

if ($PSVersionTable.PSVersion.Major -ne 5) {
    throw "run_regression.ps1 kräver Windows PowerShell 5.1. Aktuell version: $($PSVersionTable.PSVersion)"
}

$repoRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$modulesRoot = Join-Path $repoRoot 'Modules'
$ruleBankDir = Join-Path $repoRoot 'RuleBank'

if (-not (Test-Path -LiteralPath $OutDir)) {
    New-Item -ItemType Directory -Path $OutDir -Force | Out-Null
}

$global:ModulesRoot = $modulesRoot
$global:LibRoot = Join-Path $repoRoot 'Lib'

. (Join-Path $modulesRoot 'Config.ps1') -ScriptRoot $repoRoot
. (Join-Path $modulesRoot 'Logging.ps1')
. (Join-Path $modulesRoot 'DataHelpers.ps1')
. (Join-Path $modulesRoot 'OpenXmlHelpers.ps1')
. (Join-Path $modulesRoot 'RuleEngine.ps1')
. (Join-Path (Join-Path $modulesRoot 'Core') 'Pipeline.ps1')

$caseIds = @('31004','32101','33301','34509','95107')
$rows = New-Object System.Collections.Generic.List[pscustomobject]
$anyFail = $false

$ruleBank = $null
try {
    $ruleBank = Load-RuleBank -RuleBankDir $ruleBankDir
} catch {
    throw "Kunde inte läsa RuleBank från '$ruleBankDir': $($_.Exception.Message)"
}

foreach ($caseId in $caseIds) {
    $caseDir = Join-Path $TestRoot $caseId
    $status = 'PASS'
    $notes = New-Object System.Collections.Generic.List[string]

    if (-not (Test-Path -LiteralPath $caseDir)) {
        $status = 'FAIL'
        [void]$notes.Add("Case-katalog saknas: $caseDir")
        $anyFail = $true
        [void]$rows.Add([pscustomobject]@{
            CaseId = $caseId
            Status = $status
            PrimaryCsv = ''
            ResampleCsv = ''
            Worksheet = ''
            RuleRowsPrimary = 0
            RuleRowsResample = 0
            CurrentOutputs = 0
            CurrentAudits = 0
            BaselineOutputs = 0
            BaselineAudits = 0
            PlanSamm = ''
            PlanGransk = ''
            Notes = ($notes -join ' | ')
        })
        continue
    }

    $allCsv = @(
        Get-ChildItem -LiteralPath $caseDir -Filter '*.csv' -File -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -notmatch '(?i)(^|_)audit_' } |
        Sort-Object Name |
        Select-Object -ExpandProperty FullName
    )

    $worksheetPath = @(
        Get-ChildItem -LiteralPath $caseDir -Filter '*Worksheet*.xlsx' -File -ErrorAction SilentlyContinue |
        Sort-Object Name |
        Select-Object -First 1 -ExpandProperty FullName
    )[0]

    $currentOutputs = @(
        Get-ChildItem -LiteralPath $caseDir -Filter '*output_*.xlsx' -File -ErrorAction SilentlyContinue |
        Sort-Object Name
    )
    $currentAudits = @(
        Get-ChildItem -LiteralPath $caseDir -Filter '*audit_*.csv' -File -ErrorAction SilentlyContinue |
        Sort-Object Name
    )
    $baselineOutputs = @()
    $baselineAudits = @()
    if ($BaselineDir) {
        $baseCaseDir = Join-Path $BaselineDir $caseId
        if (Test-Path -LiteralPath $baseCaseDir) {
            $baselineOutputs = @(
                Get-ChildItem -LiteralPath $baseCaseDir -Filter '*output_*.xlsx' -File -ErrorAction SilentlyContinue |
                Sort-Object Name
            )
            $baselineAudits = @(
                Get-ChildItem -LiteralPath $baseCaseDir -Filter '*audit_*.csv' -File -ErrorAction SilentlyContinue |
                Sort-Object Name
            )
            if ($baselineOutputs.Count -ne $currentOutputs.Count) {
                [void]$notes.Add(("Baseline compare: output-count {0} -> {1}" -f $baselineOutputs.Count, $currentOutputs.Count))
            }
            if ($baselineAudits.Count -ne $currentAudits.Count) {
                [void]$notes.Add(("Baseline compare: audit-count {0} -> {1}" -f $baselineAudits.Count, $currentAudits.Count))
            }
        } else {
            [void]$notes.Add("Baseline-katalog saknas för case: $baseCaseDir")
        }
    }

    $csvSel = $null
    try {
        $csvSel = Resolve-CsvSelection -AllCsvPaths $allCsv
    } catch {
        $status = 'FAIL'
        [void]$notes.Add("Resolve-CsvSelection exception: $($_.Exception.Message)")
        $anyFail = $true
    }

    if ($csvSel -and $csvSel.Warnings) {
        foreach ($w in @($csvSel.Warnings)) { [void]$notes.Add($w) }
    }

    if ($csvSel -and (-not $csvSel.Ok)) {
        $status = 'FAIL'
        foreach ($e in @($csvSel.Errors)) { [void]$notes.Add($e) }
        $anyFail = $true
    }

    $ruleRowsPrimary = 0
    $ruleRowsResample = 0

    if ($csvSel -and $csvSel.Ok -and $csvSel.PrimaryPath -and (Test-Path -LiteralPath $csvSel.PrimaryPath)) {
        try {
            $csvRows = Import-CsvRows -Path $csvSel.PrimaryPath -StartRow 10
            $re = Invoke-RuleEngine -CsvObjects $csvRows -RuleBank $ruleBank -CsvPath $csvSel.PrimaryPath
            $ruleRowsPrimary = @($re.Rows).Count
        } catch {
            $status = 'FAIL'
            [void]$notes.Add("RuleEngine primary exception: $($_.Exception.Message)")
            $anyFail = $true
        }
    }

    if ($csvSel -and $csvSel.Ok -and $csvSel.ResamplePath -and (Test-Path -LiteralPath $csvSel.ResamplePath)) {
        try {
            $csvRowsRes = Import-CsvRows -Path $csvSel.ResamplePath -StartRow 10
            $reRes = Invoke-RuleEngine -CsvObjects $csvRowsRes -RuleBank $ruleBank -CsvPath $csvSel.ResamplePath
            $ruleRowsResample = @($reRes.Rows).Count
        } catch {
            $status = 'FAIL'
            [void]$notes.Add("RuleEngine resample exception: $($_.Exception.Message)")
            $anyFail = $true
        }
    }

    $planSamm = ''
    $planGransk = ''

    if ($worksheetPath -and (Test-Path -LiteralPath $worksheetPath)) {
        try {
            $pS = Get-WorksheetSignaturePlan_OpenXml -Path $worksheetPath -Mode 'Sammanstallning' -HasResample:$([bool]($csvSel -and $csvSel.HasResample)) -ModulesRoot $modulesRoot
            $planSamm = ("Planned={0}; Skipped={1}" -f @($pS.Planned).Count, @($pS.Skipped).Count)
        } catch {
            $status = 'FAIL'
            [void]$notes.Add("Signplan Sammanställning exception: $($_.Exception.Message)")
            $anyFail = $true
        }

        try {
            $pG = Get-WorksheetSignaturePlan_OpenXml -Path $worksheetPath -Mode 'Granskning' -HasResample:$([bool]($csvSel -and $csvSel.HasResample)) -ModulesRoot $modulesRoot
            $planGransk = ("Planned={0}; Skipped={1}" -f @($pG.Planned).Count, @($pG.Skipped).Count)
        } catch {
            $status = 'FAIL'
            [void]$notes.Add("Signplan Granskning exception: $($_.Exception.Message)")
            $anyFail = $true
        }
    } else {
        [void]$notes.Add('Worksheet saknas i testkatalog.')
    }

    if ($GenerateOutputs) {
        [void]$notes.Add('GenerateOutputs är ännu inte implementerad: Main.ps1 saknar headless Build-entrypoint i denna fas.')
    }

    $primaryLeaf = if ($csvSel -and $csvSel.PrimaryPath) { Split-Path $csvSel.PrimaryPath -Leaf } else { '' }
    $resLeaf = if ($csvSel -and $csvSel.ResamplePath) { Split-Path $csvSel.ResamplePath -Leaf } else { '' }
    $wsLeaf = if ($worksheetPath) { Split-Path $worksheetPath -Leaf } else { '' }

    [void]$rows.Add([pscustomobject]@{
        CaseId = $caseId
        Status = $status
        PrimaryCsv = $primaryLeaf
        ResampleCsv = $resLeaf
        Worksheet = $wsLeaf
        RuleRowsPrimary = $ruleRowsPrimary
        RuleRowsResample = $ruleRowsResample
        CurrentOutputs = @($currentOutputs).Count
        CurrentAudits = @($currentAudits).Count
        BaselineOutputs = @($baselineOutputs).Count
        BaselineAudits = @($baselineAudits).Count
        PlanSamm = $planSamm
        PlanGransk = $planGransk
        Notes = ($notes -join ' | ')
    })
}

$reportPath = Join-Path $OutDir 'RegressionReport.md'
$jsonPath = Join-Path $OutDir 'RegressionReport.json'

$lines = New-Object System.Collections.Generic.List[string]
[void]$lines.Add('# Regression Report')
[void]$lines.Add('')
[void]$lines.Add(('Date: {0}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')))
[void]$lines.Add(('Host: {0}' -f $env:COMPUTERNAME))
[void]$lines.Add(('PowerShell: {0}' -f $PSVersionTable.PSVersion))
[void]$lines.Add(('TestRoot: {0}' -f (Resolve-Path -LiteralPath $TestRoot).Path))
[void]$lines.Add(('OutDir: {0}' -f (Resolve-Path -LiteralPath $OutDir).Path))
if ($BaselineDir) { [void]$lines.Add(('BaselineDir: {0}' -f $BaselineDir)) }
[void]$lines.Add('')
[void]$lines.Add('| Case | Status | Primary CSV | Resample CSV | Worksheet | RuleRows Primary | RuleRows Resample | Outputs (curr/base) | Audits (curr/base) | Plan Samm | Plan Gransk | Notes |')
[void]$lines.Add('|---|---|---|---|---|---:|---:|---|---|---|---|---|')
foreach ($r in $rows) {
    [void]$lines.Add(("| {0} | {1} | {2} | {3} | {4} | {5} | {6} | {7}/{8} | {9}/{10} | {11} | {12} | {13} |" -f $r.CaseId, $r.Status, $r.PrimaryCsv, $r.ResampleCsv, $r.Worksheet, $r.RuleRowsPrimary, $r.RuleRowsResample, $r.CurrentOutputs, $r.BaselineOutputs, $r.CurrentAudits, $r.BaselineAudits, $r.PlanSamm, $r.PlanGransk, $r.Notes))
}

Set-Content -LiteralPath $reportPath -Value $lines -Encoding UTF8
$rows | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $jsonPath -Encoding UTF8

Write-Host "Regression report written: $reportPath"
Write-Host "Regression json written:   $jsonPath"

if ($anyFail) { exit 1 }
exit 0
