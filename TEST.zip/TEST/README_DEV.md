# README_DEV

## Nuvarande modulansvar (före/under refaktor)

| Modul | Huvudansvar |
|---|---|
| `Main.ps1` | WinForms-init, UI-händelser, orkestrering av hela rapportflödet |
| `Modules/Config.ps1` | Miljö/paths, scriptversion, central confighämtning |
| `Modules/Logging.ps1` | `Gui-Log`, strukturerad logg, audit-entry helper |
| `Modules/DataHelpers.ps1` | CSV parsing/import, EPPlus-laddning, worksheet-headeranalys, filsnapshot |
| `Modules/OpenXmlHelpers.ps1` | OpenXML-läs/skriv, merge-aware signering, planering/verifiering |
| `Modules/RuleEngine.ps1` | RuleBank-laddning och avvikelseklassning |
| `Modules/SignatureHelpers.ps1` | Signaturdialog/format/verifiering (Seal + Worksheet wrapper) |
| `Modules/SharePointClient.ps1` | PnP/SharePoint anslutning och async runspace-klient |
| `Modules/UiStyling.ps1` | Tema/visuell styling |
| `Modules/Splash.ps1` | Splashscreen |
| `Modules/Core/Pipeline.ps1` | (Ny FAS 2) core orchestration utan UI-kontroller |

## 10 största dupliceringar (evidensbaserat)

1. CSV-classifiering (Primary/Resample) låg inline i `Main.ps1` och användes på flera ställen.
   Status: flyttad till `Resolve-CsvSelection` i [Modules/Core/Pipeline.ps1](/Users/jesperfredriksson/Desktop/zz_IPTCompile/Modules/Core/Pipeline.ps1:45), call-site i [Main.ps1](/Users/jesperfredriksson/Desktop/zz_IPTCompile/Main.ps1:2431).
2. Worksheet-signeringsdialogens target-plan byggdes med duplicerad Samm/Gransk-loop.
   Status: flyttad till `Get-WorksheetSignDialogTargets_OpenXml` i [Modules/Core/Pipeline.ps1](/Users/jesperfredriksson/Desktop/zz_IPTCompile/Modules/Core/Pipeline.ps1:111), call-site i [Main.ps1](/Users/jesperfredriksson/Desktop/zz_IPTCompile/Main.ps1:2703).
3. Worksheet-signeringsinvoke kördes mode-för-mode inline i Main.
   Status: flyttad till `Invoke-WorksheetSigningModes_OpenXml` i [Modules/Core/Pipeline.ps1](/Users/jesperfredriksson/Desktop/zz_IPTCompile/Modules/Core/Pipeline.ps1:161), call-site i [Main.ps1](/Users/jesperfredriksson/Desktop/zz_IPTCompile/Main.ps1:2728).
4. OpenXML-targetlista var duplicerad i plan + invoke.
   Status: centraliserad via `Get-WorksheetSignatureTargets_OpenXml` i [Modules/OpenXmlHelpers.ps1](/Users/jesperfredriksson/Desktop/zz_IPTCompile/Modules/OpenXmlHelpers.ps1:633).
5. OpenXML row-resolution (name/date) var duplicerad i plan + invoke.
   Status: centraliserad via `Resolve-WorksheetSignatureRows_OpenXml` i [Modules/OpenXmlHelpers.ps1](/Users/jesperfredriksson/Desktop/zz_IPTCompile/Modules/OpenXmlHelpers.ps1:654).
6. Nätverksdetektering fanns i två helpers (`Test-IsNetworkPathSimple` och `Test-IsNetworkPath`).
   Status: dead-variant borttagen från DataHelpers; kvar i Config [Modules/Config.ps1](/Users/jesperfredriksson/Desktop/zz_IPTCompile/Modules/Config.ps1:61).
7. Equipment-scanning hade dubblerad API-yta (`Get-TestSummaryEquipment` + `Get-TestSummaryEquipmentFromWorksheet`) utan call-sites.
   Status: borttaget i FAS 1 (dead code).
8. Overwrite-tooltip sätts flera gånger i init + state-update.
   Status: kvar (avsiktligt p.g.a. UI-state), evidens i [Main.ps1](/Users/jesperfredriksson/Desktop/zz_IPTCompile/Main.ps1:5764) och [Main.ps1](/Users/jesperfredriksson/Desktop/zz_IPTCompile/Main.ps1:5785).
9. Batchlink-beräkning kallas på flera ställen i Main.
   Status: kvar, evidens i [Main.ps1](/Users/jesperfredriksson/Desktop/zz_IPTCompile/Main.ps1:4282) och [Main.ps1](/Users/jesperfredriksson/Desktop/zz_IPTCompile/Main.ps1:4999).
10. Primary/Resample CSV-sortering använder i praktiken samma logik två gånger.
   Status: kvar, evidens i [Main.ps1](/Users/jesperfredriksson/Desktop/zz_IPTCompile/Main.ps1:2812) och [Main.ps1](/Users/jesperfredriksson/Desktop/zz_IPTCompile/Main.ps1:2840).

## 10 största "Main.ps1-smällar"

1. `btnBuild`-händelsen är en monolit med flera ansvarsområden från [Main.ps1](/Users/jesperfredriksson/Desktop/zz_IPTCompile/Main.ps1:2376) till sent i filen.
2. Samma flöde hanterar inputval, snapshot, signering, rule-engine, outputskrivning, audit och öppning av fil.
3. Fil-låshantering med UI-dialoger och retry-logik är hårt kopplad till pipeline i [Main.ps1](/Users/jesperfredriksson/Desktop/zz_IPTCompile/Main.ps1:2351).
4. Hög global state-användning (`$script:*`, `$global:*`) genom hela körningen.
5. Inbyggda lokala hjälpfunktioner mitt i build-flödet (`_SignSealTestSheets`, `_GetPerSheetValueObjects`, `_AggregateStatus`).
6. Signeringslogik och verifiering blandas med UI-bekräftelse i samma block.
7. Direkt läsning av UI-kontroller i businessflödet gör headless-körning svår.
8. Logik för primary/resample låg tidigare inline i event-kod (nu flyttad men större block återstår).
9. Mixed concerns mellan SharePoint-status, audit och resultatpresentation i samma scriptfil.
10. Begränsad testbarhet eftersom ingen tydlig headless entrypoint till full build finns ännu.

## Föreslagen mappstruktur (mål)

```text
Modules/
  Core/
    Pipeline.ps1
    BuildPipeline.ps1
    Regression.ps1
  UI/
    WinForms.Main.ps1
    UiStyling.ps1
    Splash.ps1
  Excel/
    EpplusHelpers.ps1
    ReportWriter.ps1
  OpenXml/
    OpenXmlHelpers.ps1
  Rules/
    RuleEngine.ps1
  Infra/
    Config.ps1
    Logging.ps1
    SharePointClient.ps1
    SignatureHelpers.ps1
```

## Entry points

- GUI: [Main.ps1](/Users/jesperfredriksson/Desktop/zz_IPTCompile/Main.ps1)
- Headless regression (core dry-run): [tools/run_regression.ps1](/Users/jesperfredriksson/Desktop/zz_IPTCompile/tools/run_regression.ps1)
